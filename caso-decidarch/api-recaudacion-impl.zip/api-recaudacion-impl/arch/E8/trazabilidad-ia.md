# Anexo E8 — Trazabilidad del uso de IA

El caso (§16.3) permite usar IA, pero pide dejar trazabilidad de cómo la controló la intención arquitectónica. Este anexo resume esa trazabilidad. La bitácora completa se llevó fuera del repositorio (`.claude/reporte.md`) porque contiene rutas locales, nombres de otros repositorios de TGR y la descripción de las credenciales de TD-006. Aquí se incluye lo que sirve como evidencia.

## 1. Cómo se usó la IA

- **Agente:** Claude Code (modelo Claude Opus) trabajó sobre la copia local del repositorio en todas las etapas: screening, baseline, E1–E8, ADRs y guía.
- **Persona:** eligió el proyecto y el slice, aprobó cada etapa, decidió qué se commitea y cuándo, y fijó las restricciones permanentes (§2).
- **Unidad de trabajo:** una etapa del caso por pedido («continúa con el E4», «cierra TD-026 y commitea»). Ninguna etapa empezó sin que la anterior estuviera en verde.

## 2. Mecanismos de control

| Control | Qué impide | Evidencia |
|---|---|---|
| Restricciones permanentes: sin push (`DISABLED-no-push`), sin commit sin pedido, sin AWS real, no leer ni ejecutar `obligaciones/test/` | Publicar código institucional, efectos sobre ambientes reales, exponer credenciales | D-06, D-14; `AGENTS.md` §4 |
| Bitácora de decisiones con motivo (D-01..D-44) | Decisiones implícitas o no justificadas | §4 de este anexo |
| Tests de caracterización antes de extraer | Que el refactor cambie comportamiento sin que se note | D-12, D-24; `arch/E3-refactoring.md` |
| Mutación manual de cada test y de cada FF | Tests y reglas que no pueden fallar (falsos verdes) | `arch/fitness/mutacion-ff.sh` (15 casos); E3 6/6; TD-026 2/2 |
| Quality gate con ratchet | Que el agente empeore el legado o relaje umbrales | `arch/fitness/quality-gate.sh`, ADR-005 |
| Contrato de intención (`AGENTS.md` + TASK INTENT) | Que un agente nuevo rompa fronteras | `arch/E7-architectural-intent.md` |
| Validación con un agente independiente en worktree aislado | Que el contrato solo funcione para quien lo escribió | `arch/E7/validacion-agente-independiente.md`, D-43 |
| Toda cifra sale de un comando ejecutado | Afirmaciones de memoria | `AGENTS.md` §5.6; baselines `arch/baseline/01..08` |

## 3. Errores del agente detectados y corregidos

Los 6 errores que dieron origen a cláusulas del contrato están en `arch/E7-architectural-intent.md` §3. Además:

| Error | Cómo se detectó | Corrección |
|---|---|---|
| ADR-004 decía que todos los consumidores del stream leen `payload` | Verificación del código al redactar | `envioGCP` y `envioOp` leen solo la imagen cruda; ADR corregido |
| Conteos del E8 (TD resueltos, baselines, mutaciones de FF-4) | Recuento con comandos | E8 corregido |
| La TASK INTENT de ejemplo del E7 era contradictoria | El agente independiente se detuvo (§4 de `AGENTS.md`) | E7, E8 y ADRs corregidos; cláusula Q8; cierre de TD-026 |
| Afirmación sobre `cuadraturaTest` en el informe de validación | Revisión contra el código | Documento de validación corregido |
| Comando AS-IS de la guía con menos exclusiones (87/23/60 en vez de 86/22/26, y escaneaba `obligaciones/test/`) | Ejecución del comando de la guía | Arreglo `EXCL` común en `arch/GUIA-REPLICACION.md` |

Patrón: los errores fueron afirmaciones no verificadas, no código roto. Por eso el contrato exige evidencia ejecutada y no confía en lo que el agente declara.

## 4. Registro de decisiones

| ID | Fecha | Decisión | Motivo |
|---|---|---|---|
| D-01 | 2026-10-08 | Screening con shell, sin graphify | 509 repos; elección explícita del usuario |
| D-02 | 2026-10-08 | Candidato principal `api-recaudacion-impl` (propuesto) | Dominio FlowNow-like, tests base, pasa 7/7 (P1 con reserva) |
| D-03 | 2026-10-08 | Alternativa `core-ordenes-pago-back` | Mejores síntomas, menor testabilidad |
| D-04 | 2026-10-08 | Documentar todo en `.claude/reporte.md` y scripts en `.claude/scripts/` | Pedido del usuario; baseline reproducible para E1 |
| D-05 | 2026-10-08 | **Candidato confirmado: `api-recaudacion-impl`**, copiado a `casoDecidArch/api-recaudacion-impl` (con historia git, sin `node_modules`) | Indicación del usuario |
| D-06 | 2026-10-08 | Push al remoto CodeCommit deshabilitado en la copia (`git remote set-url --push origin DISABLED-no-push`); fetch intacto | Evitar publicar por accidente cambios del caso en el repo institucional |
| D-07 | 2026-10-08 | Herramientas del baseline: scripts propios en Node (sin dependencias) + `eslint@8.57.0` (complejidad) + `jscpd@4.0.5` (duplicación) + `jest` del proyecto (tests/cobertura), versiones fijas vía `npx` | Reproducible, mismo stack del proyecto, mínimas instalaciones |
| D-08 | 2026-10-08 | Scripts dentro del proyecto en `arch/scripts/`, salida en `arch/baseline/<corrida>/` | Que el baseline viaje con el código (E1, E4, E8) |
| D-09 | 2026-10-08 | Reemplazar DynamoDB Local (Java) por un fake en memoria en `recaudacion-int` | Recomendación aceptada por el usuario: más liviano y sin dependencias externas |
| D-10 | 2026-10-08 | Reactivar los 5 tests `it.skip` que pasan con el fake; dejar `postM2Test` para el E3 | Recuperar red de seguridad sin cambiar aserciones ni código productivo |
| D-11 | 2026-10-08 | Medir la cobertura sobre todo el código prod y conservar cada baseline (`01-as-is-original`, `02-tests-con-mock`) | Evitar una cobertura inflada y mantener la trazabilidad AS-IS → TO-BE |
| D-12 | 2026-10-08 | Tests de caracterización: actualizar expectativas al comportamiento **actual** y registrar los defectos en el debt ledger en vez de corregir código productivo | Refactoring seguro (§11): primero fijar el comportamiento, después cambiarlo |
| D-13 | 2026-10-08 | Simular servicios externos con router de `axios` por URL que rechaza lo no simulado; mockear `utils/adf` como frontera externa | Tests sin red y que fallan de forma explícita ante dependencias nuevas |
| D-14 | 2026-10-08 | Excluir `src/obligaciones/test/` de jest y no ejecutar `cargo.test.js` | Scripts manuales contra servicios reales con credenciales embebidas |
| D-15 | 2026-10-08 | ESM vía `babel-jest` (`sourceType: unambiguous`) en vez de actualizar Jest | Cambio mínimo; actualizar Jest 24 queda como deuda de herramientas |
| D-16 | 2026-10-08 | Escenarios E1: EC-1 proveedor/formato M2, EC-2 canal de notificación, EC-3 modelo de Institución, EC-4 separar reporting | Corresponden a los escenarios sugeridos en §15 paso 2, adaptados al dominio (Institución ≈ Customer) |
| D-17 | 2026-10-08 | Impacto medido como archivos con la decisión + Lambdas que dependen de ellos (transitivo) | Métrica reproducible y comparable AS-IS/TO-BE; la Lambda es la unidad de despliegue |
| D-18 | 2026-10-08 | Corregir heurísticas del baseline (ownership por objeto, comentarios, babel) y dejar las corridas 01–03 sin tocar | Trazabilidad: las correcciones quedan explícitas, no se reescribe la historia |
| D-19 | 2026-10-08 | Corregir R-01 y documentar otro repositorio candidato; mantener `api-recaudacion-impl` | Error de screening reconocido; el candidato con IA no tiene la erosión que exige el caso |
| D-20 | 2026-10-08 | Slice E3 = confirmación de pago (M2) | Lo confirmó el usuario; cubre EC-1 y toca `eventos` y la notificación |
| D-21 | 2026-10-08 | Módulos como carpetas con `index.js` dentro de los 2 desplegables existentes; Lambdas como handlers delgados | Bajo `C_coordination`; sin cambiar infraestructura ni contratos externos |
| D-22 | 2026-10-08 | ACL M2 con DTO canónico `Confirmacion` v1 y expand/contract del registro persistido | Permite migrar los consumidores de forma incremental sin romper las lecturas actuales |
| D-23 | 2026-10-08 | Sin interfaz de repositorio ni Strategy en el slice | Variabilidad inexistente: una implementación y 3 casos estables (§9 del caso) |
| D-24 | 2026-10-08 | Caracterizar antes de extraer y preservar incluso los comportamientos raros (id `#undefined#`, carrito parcial, TD-012) | Refactoring ≠ corrección; los defectos se registran y se corrigen solo donde el E2 lo comprometió (TD-010, TD-011) |
| D-25 | 2026-10-08 | TD-010: unificar con el contrato de error existente de carrito (`{statusCode:400, body:'NOK'}`) | No inventar un contrato nuevo para el proveedor |
| D-26 | 2026-10-08 | Medir el AS-IS sobre un worktree del commit base (`SRC_ROOT`) | Las métricas de impacto deben ser reproducibles por commit, no depender del árbol actual |
| D-27 | 2026-10-08 | Mantener la invocación a `deleteRegistrosEventos` y DSS en el suscriptor | Fuera del alcance del slice; cambiar la topología requiere ADR y validación operacional |
| D-28 | 2026-10-09 | E4 con dependency-cruiser (FF-1, FF-4) + Semgrep (FF-2, 3, 5, 6) + Jest (FF-7), versiones fijadas | Grafo resuelto para CJS/ESM y reglas sobre el AST; sin servidor (SonarQube) ni análisis pesado (CodeQL) |
| D-29 | 2026-10-09 | Gate en dos niveles: código intervenido en 0; legado con ratchet por (regla, archivo) que referencia un TD | Las reglas sobre todo el repo dejarían el gate siempre en rojo; sin ratchet la deuda podría crecer |
| D-30 | 2026-10-09 | Corregir las 3 violaciones del código intervenido (billetera a `integraciones/`, `SSM_WALLET_PATH`, sin *fallback* de región) en vez de aceptarlas | La meta del anexo E es 0 en el código intervenido |
| D-31 | 2026-10-09 | Validar cada FF inyectando una violación (`mutacion-ff.sh`) | Una FF que nunca falla no protege; así apareció el error de `exclude` en dependency-cruiser |
| D-32 | 2026-10-09 | Inventario SATD con marcadores en español, config y comentarios del propio E3, no solo `TODO` | El repo está en español y el E3 dejó deuda con forma de documentación («Caracterizado», «heredado») |
| D-33 | 2026-10-09 | Borrar un `TODO` solo con evidencia (test + mutación, blame, mensaje de error real) | §7.1: «No quedan TODO» no es evidencia; S-12 parecía resuelto y no lo estaba (TD-021) |
| D-34 | 2026-10-09 | Aceptar deuda con la cadena completa (owner por rol, fecha propuesta, verificación por test) | Owners y fechas reales los define TGR; la verificación queda ejecutable |
| D-35 | 2026-10-09 | FF-6 ampliada a marcadores en español y a tests, sin deuda aceptada en la lista | Mantener UnmanagedSATD = 0 de forma automática después del E5 |
| D-36 | 2026-10-09 | ADRs con status honesto: ADR-004 y la distribución de ADR-002 quedan «Propuesto» | No se implementaron ni se pudieron verificar (el `serverless package` requiere SSM de TGR) |
| D-37 | 2026-10-09 | ADR-001 registra las diferencias entre el contrato del E2 y lo implementado | La trazabilidad del caso exige coherencia entre modelo, código y ADR (§19) |
| D-38 | 2026-10-09 | ADR-002 propone un paquete local `file:` en vez de un Layer o una API | Un Layer repite el problema de TD-014; una API agrega `C_coordination` |
| D-39 | 2026-10-09 | Contrato de intención en `AGENTS.md` (raíz) + `CLAUDE.md` con `@AGENTS.md` | Se carga solo en Claude Code y por convención en otros agentes; un solo archivo como fuente de verdad |
| D-40 | 2026-10-09 | Dos niveles: intención del sistema (estable) + TASK INTENT por tarea | Lo estable cambia con los ADR; lo variable se declara antes de cada implementación |
| D-41 | 2026-10-09 | Cada cláusula del contrato ligada a una FF o a evidencia exigida, y cláusulas derivadas de los errores reales del agente en E3–E5 | El contrato no puede depender de que el agente obedezca |
| D-42 | 2026-10-09 | E8 con estado por indicador (✔ / ◐ parcial) y una sección de brechas, en vez de presentar todo como logrado | §19 exige triangulación; los parciales tienen deuda con ratchet y un ADR de cierre |
| D-43 | 2026-10-09 | Validar AGENTS.md con un agente sin contexto en un worktree aislado; aceptar su detención y corregir la TASK INTENT de ejemplo y las afirmaciones de E7/E8 | Si el contrato se valida solo con quien lo escribió, no hay validación |
| D-44 | 2026-10-09 | Cerrar TD-026 (idempotencia por `confirmacion.idTransaccion`; `payload` solo si hay `legado`) y mantener la cláusula Q8 como la protección de los lectores legados | Paso 1 recomendado tras la validación; sin cambio observable para M2 (35/35, mutación 2/2) |
