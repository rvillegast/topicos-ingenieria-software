# E1 — Diagnóstico AS-IS: api-recaudacion-impl

> Caso DecidArch §17.1. Commit analizado: `66a2873` (rama `develop`). Baseline: `arch/baseline/04-diagnostico-e1/` (2026-10-08).
> Toda cifra de este documento sale de esa carpeta y se regenera con `arch/scripts/baseline.sh <carpeta>`.

## 0. Resumen ejecutivo

`api-recaudacion-impl` recibe solicitudes de recaudación de instituciones del Estado, las valida contra servicios de TGR (catálogo de conceptos, ADF), redirige al contribuyente a pagar, recibe la confirmación de pago (mensaje M2), notifica a la institución y alimenta procesos de cuadratura y órdenes de pago. Funciona y está en producción. Sin embargo:

- **La decisión más volátil no está oculta.** El formato del mensaje de confirmación de pago (M2) se interpreta en **9 archivos y 9 de 30 Lambdas**, repartidos en los dos desplegables (EC-1).
- **El modelo de Institución (el "Customer" del caso) está disperso.** Cambiarlo impacta **14 archivos y 13 de 30 Lambdas** (EC-3).
- **No hay dueño de los datos.** La tabla `eventos` tiene **5 archivos escritores en 2 desplegables** y 12 lectores. Los procesos de reporting escriben sus estados sobre los registros transaccionales (EC-4).
- **La complejidad está concentrada en los handlers.** 17 funciones superan complejidad 10 (máximo 40), 46 funciones superan 50 líneas y la duplicación es de **22,7 %**: hay módulos de infraestructura copiados entre 2 y 3 veces.
- **Red de seguridad débil.** Al inicio pasaban 0/14 tests y había 11 desactivados. Tras la recuperación pasan 24 (6 siguen en skip), con **~14 % de cobertura de líneas**.

## 1. Mapa de módulos actual

Dos desplegables Serverless (AWS Lambda + API Gateway): `api-recaudacion` (13 funciones) y `api-recaudacion-int` (17), **30 en total**, **66 archivos productivos (11.515 LOC)**. No existe capa de dominio: cada handler mezcla validación, reglas, persistencia e integración. 17 de 28 archivos handler acceden directamente a DynamoDB y 11 hacen HTTP directo.

| Responsabilidad observada | Lambdas (desplegable) | Archivos principales (LOC) |
|---|---|---|
| Ingreso de solicitudes de recaudación | `postSolicitud`, `postSolicitud2` (rec) | `postSolicitud.js` (1.189), `validaciones.js` (422), `validarJson.js` (339), `utils/prepParam.js` (471), `utils/adf.js` (225) |
| Consulta de solicitudes/estado | `getSolicitud`, `getSolicitudes` (rec); `detalle` (int) | `getSolicitud.js` (393), `getSolicitudes.js` (209), `obtenerDetalle.mjs` |
| Obligaciones (cargos, descargos, liquidación, pagos, saldo, aviso de recibo) | 7 Lambdas `obligaciones-*` + `liquidar-cargo` (rec) | `src/obligaciones/*` (consulta 605, descargos 572, utils/util 524, liquidar 357) |
| Identidad / token | `oauth2Token` (rec) | `oauth2Token.mjs`, `util.js` (`getDataFromToken`) |
| Intento de pago y confirmación (M1/M2) | `intentoPago`, `intentoPagoCarrito`, `recibeM1`, `postM2`, `callback`, `reenvioM2OnPremise`, `suscriptorSnsReplicaGenerica` (int) | `recibeM1.js` (340), `postM2.js` (327), `reenvioM2Tierra.mjs` (282) |
| Notificación a instituciones | `publishSnsEventos` (int); eventos de obligaciones (rec) | `publishSnsEventos.js` (533), `src/obligaciones/eventos.js` |
| Reporting: cuadratura, órdenes de pago, auditoría, métricas | `cuadratura`, `estadoCuadratura`, `envioOP`, `dataOP`, `estadoOP`, `envioGCP`, `putMetrica` (int) | `estadoCuadratura.mjs` (408), `getDataOP.js`, `envioOp.js`, `envioGCP.mjs` |
| Mantención | `deleteRegistrosEventos` (int) | `deleteRegistrosEventos.mjs` |

```mermaid
flowchart LR
  inst[Institución] -->|POST solicitudes| REC[api-recaudacion<br/>13 Lambdas]
  REC -->|HTTP| PA[Portal autoservicios<br/>conceptos, intentoPago]
  REC -->|HTTP via SSM| ADF[ADF validación/liquidación]
  REC -->|HTTP| CUT[CUT aviso recibo]
  REC -->|Lambda| ORA[Oracle on-prem / DSS]
  REC -->|put RECIBIDA| EV[(eventos)]
  REC -->|put/update| OB[(obligaciones)]
  BANCO[Pasarela / Tesorería] -->|M2| INT[api-recaudacion-int<br/>17 Lambdas]
  INT -->|put PAGO_CONFIRMADO<br/>update estado_cuad / estado_op<br/>delete| EV
  EV -->|stream| INT
  INT -->|SNS 3 tópicos| inst
  INT -->|HTTP| GCP[Auditoría GCP]
  INT -->|HTTP| TIERRA[On-prem 'tierra']
```

Observación: `api-recaudacion` llama por HTTP a `recaudacion-interno/v1/intentoPago`, presumiblemente la Lambda `intentoPago` de `api-recaudacion-int` (la ruta coincide; el base path no está en el repo). Si se confirma, **los dos desplegables se acoplan a la vez por HTTP y por la tabla `eventos`**.

## 2. Smells y complejidad

| Familia (§8) | Evidencia AS-IS | Riesgo |
|---|---|---|
| Clases/funciones grandes | 5 archivos > 500 LOC. Handler de `descargos.js` CC 40; `postSolicitud` handler CC 36, `procesoRecaudacionCarrito` CC 33, `procesoRecaudacion` CC 31; `postM2` CC 32; `publishSnsEventos` CC 28. 46 funciones > 50 líneas, 36 con anidamiento > 4 | Múltiples razones de cambio por archivo |
| Lógica de negocio en handlers | Sin capa de dominio. `procesoRecaudacion` valida concepto, etapa, esquema, ADF, tolerancia, guarda giro, persiste y arma la URL de redirección en una sola función | Imposible cambiar una regla sin tocar el handler |
| Duplicación | **22,7 %** (87 clones). `s3Services.js` ×3 **idénticos** (md5), `dynamoDbServices.js` ×3, `service.js`, `billetera.js` y `tokenBilletera.js` ×2, `util.js` ×4. Dos clientes ADF distintos (`utils/adf.js`+`validaADF.js` vs `obligaciones/callValidarAdf.js`). `getResponseItemMOP` copiado con variaciones en `getSolicitud` y `getSolicitudes`. `estadoCuadratura.mjs`≈`reenvioM2Tierra.mjs` (215 líneas) | Correcciones inconsistentes |
| Utilitarios genéricos mezclados | `obligaciones/utils/util.js` (524 LOC): SSM, ADF, HTTP, formato | Baja cohesión |
| Valores hard-coded | 27 en prod: región `us-east-1` ×18, rutas SSM `/tgr/${ENV}/...` ×7 (ignoran `BUILD_SSM_PREFIX`), `ipCliente: "127.0.0.1"` y `codigoAplicacion: "PRD033"` en auditoría, `callbackURL: "https://www.google.cl"` en `recibeM1.js`, flag `Pagos700WL`, institución `'MOP'` ×2 | Configuración acoplada al código |
| Referencias a proveedores / código externo filtrado | Estructura M2 (`Message.MessageId`, `Confirmacion.Pago`) leída en 9 archivos; tipos de stream DynamoDB (`NewImage.x.S`) recorridos a mano en consumidores | Lock-in conceptual, ver EC-1 |
| Estado global mutable | `global.mapBilletera`, cachés de módulo en `postSolicitud.js` y `util.js` (caché por `client_id` sin expiración) | Comportamiento dependiente del contenedor Lambda |
| Mezcla tecnológica | aws-sdk v2 y v3, CommonJS y ESM (`.mjs`), Jest 24, dependencia de un Lambda Layer (`tgr-sdk`) no declarada en `package.json` | Fricción de evolución y de pruebas |
| Defectos detectados | TD-003 (CUT 404 → HTTP 200), TD-004 (error CUT ≠404 → `TypeError`), TD-008 (`redirectURL: "undefined?..."`) | Ver `arch/debt-ledger.md` |
| Seguridad | Credenciales reales en `src/obligaciones/test/cargo.test.js` (TD-006) | Crítico, fuera del alcance de refactor |

## 3. SATD clasificada

Clasificación según Maldonado & Shihab (design, defect, documentation, requirement, test). Hay 12 comentarios `TODO`: 5 en código productivo y 7 en tests. No hay `FIXME`, `HACK`, `TEMP` ni `WORKAROUND`.

| Ubicación | Texto (resumido) | Tipo | Observación |
|---|---|---|---|
| `getSolicitudes.js:44` | Borrar IF de MOP cuando DGA configure la fecha | Design (workaround) | Regla de una institución hard-coded en el handler; depende de un tercero (DGA) |
| `getSolicitudes.js:156` | Borrar función cuando DGA configure `fechaPago` | Design (workaround) | Función `getResponseItemMOP` duplicada (ver §2) |
| `getSolicitud.js:266` | Cuando DGA tenga presupuesto… borrar dos funciones | Design (workaround) | Igual que la anterior; condición de salida sin fecha ni responsable |
| `publishSnsEventos.js:214` | Configurar flujo Carrito | Documentation (obsoleta) | La rama carrito **ya está implementada** justo debajo: el comentario quedó desactualizado |
| `publishSnsEventos.js:393` | Configurar flujo Carrito | Documentation (obsoleta) | Ídem |
| `postSolicitudTest.js:287, 352` | `fechaEvento //TODO` | Test | Aserción débil sobre la fecha |
| `postSolicitudTest.js:297, 362` | "esto no debería ir acá" (campo `url` en el evento) | Design | El callback de la institución se guarda dentro del evento transaccional |
| `postSolicitudTest.js:367, 414, 466` | "arreglar" / "hay que arreglar el código" | Defect (por confirmar) | Hoy el código rechaza rut/monto como string con 400 (caracterizado); falta confirmar si se esperaba otro comportamiento |

**Estado:** `UnmanagedSATD = 5` en código productivo. Ninguna tiene issue, owner ni fecha (§7.1). La gestión corresponde al E5.

## 4. Ciclos y dependencias problemáticas

| Hallazgo | Evidencia | Por qué importa |
|---|---|---|
| Ciclo entre carpetas | `obligaciones/consulta.js → obligaciones/dss/callOnpremise.js → obligaciones/oracleProvider.js` | Pequeño (un solo ciclo, 0 ciclos entre archivos), pero `oracleProvider` vive fuera de la frontera `dss` que lo usa |
| Acoplamiento entre desplegables | Ambos escriben `eventos` y ambos parsean M2; además `api-recaudacion` → HTTP → `intentoPago` (probablemente de `api-recaudacion-int`) | No se pueden desplegar ni versionar de forma independiente |
| Acoplamiento por stream | `envioOP`, `publishSnsEventos` y `envioGCP` consumen el mismo stream de `eventos` y filtran por `nombreEstado` y por la presencia de `estado_cuad`/`estado_op` | Un cambio de reporting dispara la lógica de notificación y auditoría |
| Dependencias externas sin frontera | ADF (2 clientes), portal de autoservicios (4 rutas en `postSolicitud`), CUT, on-prem "tierra", Oracle vía Lambda, `tgr-sdk` (Layer) | Sin adapter: los tipos externos llegan al handler |
| Grafo interno | 131 dependencias `require/import`; la mayoría de los handlers son hojas que importan utilitarios duplicados | La modularidad real es por copia, no por contrato |

## 5. Ownership de datos actual

| Tabla | Escritores (archivos) | Lectores | Owner declarado | Problema |
|---|---|---|---|---|
| `eventos` | **5** en 2 desplegables: `aws/dynamoDbServices.js` (put RECIBIDA), `postM2.js` (put PAGO_CONFIRMADO), `cuadratura.js` (update `estado_cuad`), `estadoOP.js` (update `estado_op`), `deleteRegistrosEventos.mjs` (delete) | 12 | Ninguno | Transaccional + reporting en el mismo registro. Clave compuesta `institucion#environment` construida en 4 archivos |
| `obligaciones` | 3 (`utils/dynamoDbServices.js`, `descargos.js`, `pagos.js`) | 4 | Implícito: carpeta `obligaciones` | Aceptable dentro de un módulo, pero sin contrato |
| `conceptos-instituciones` / `portal-autoservicios-conceptos-instituciones` | 0 (owner externo) | 3 | Portal autoservicios | Se lee **directo de su tabla** además de por su API: dos caminos para el mismo dato |
| `m1-security` | 0 | 1 | Externo/no documentado | — |

`DatosSinOwner = 1` (`eventos`, el dato central). Corrección metodológica: el baseline 01 reportaba 2 escritores en `conceptos-instituciones`. Era un falso positivo de la heurística por archivo; desde el baseline 04 la operación se clasifica por objeto de parámetros.

## 6. Escenarios de cambio e impacto AS-IS

Impacto medido con `arch/scripts/escenarios.sh`. Se cuentan los archivos productivos que contienen la decisión y las Lambdas cuyo handler depende de ellos (también de forma transitiva). Total: 30 Lambdas.

| # | Escenario | Decisión que hoy no está oculta | Archivos | Lambdas | Desplegables |
|---|---|---|---|---|---|
| EC-1 | **Cambiar el proveedor de pago o el formato de su confirmación** (M2 de la pasarela/Tesorería; p. ej. migrar a JSON o a otra pasarela) | Estructura `Message.MessageId` / `Confirmacion.Pago` | **9** | **9** | 2 |
| EC-2 | **Agregar un canal de notificación** a la institución (p. ej. webhook firmado además de SNS) | Cómo y cuándo se notifica un pago | 2 | 6 | 2 |
| EC-3 | **Cambiar el modelo de Institución** (p. ej. agregar sub-institución, o reemplazar la clave `institucion#environment`) | Identidad de la institución, ambiente y código on-prem | **14** | **13** | 2 |
| EC-4 | **Separar reporting de datos transaccionales** (cuadratura y órdenes de pago en su propio almacén) | Estados de reporting guardados en el evento de pago | 7 | 7 | 1 |

**EC-1 — Proveedor de pago.** El mensaje M2 se navega a mano en `suscriptorSnsReplicaGenerica.mjs` (30 referencias), `postM2.js` (25), `getSolicitud.js` (12), `publishSnsEventos.js` (7), `getSolicitudes.js` (6), `cuadratura.js` (3), `estadoCuadratura.mjs`, `reenvioM2Tierra.mjs` y `getDataOP.js`. Además se persiste tal cual como `payload` del evento, y las consultas `getSolicitud`/`getSolicitudes` arman su respuesta navegando `payload.Message.Confirmacion.Pago` (p. ej. `getSolicitud.js:183`): **la API de consulta depende del formato del proveedor**. Expectativa TO-BE (§4.3): *ChangeImpact ≈ 1 módulo*. Hoy son 9 archivos en 2 desplegables. Es el mejor ejemplo del caso para el criterio de Parnas.

**EC-2 — Canal de notificación.** Pocos archivos, pero el costo es **complejidad interna**. `publishSnsEventos.handler` (533 LOC, CC 28) mezcla lectura de `eventos`, deduplicación, ramas unitario/carrito/réplica y **4 puntos de publicación** con mensajes armados inline. Las obligaciones publican por otra implementación (`eventos.js`, aws-sdk v3). Agregar un canal obliga a editar los 4 puntos y a duplicar la decisión de "qué evento merece aviso". Es el caso `C_internal` de §5.

**EC-3 — Modelo de Institución.** La identidad se obtiene del claim `aud` parseado por posición (`util.js`). `institucion#environment` se construye en `getSolicitudes.js`, `aws/dynamoDbServices.js` (×2), `obligaciones/utils/dynamoDbServices.js` y `postM2.js` (×2, uno con `#PRODUCCION` fijo). Esa clave es partición del índice `instEnv-idx`. Además hay reglas por institución hard-coded (`'MOP'`). Es el escenario de mayor propagación.

**EC-4 — Separar reporting.** `cuadratura.js` y `estadoOP.js` hacen `update` de `estado_cuad`/`estado_op` sobre el registro `PAGO_CONFIRMADO`. `envioGCP`, `envioOP` y `publishSnsEventos` reaccionan al `MODIFY` del mismo stream, y `getDataOP` consulta la tabla transaccional por índice. Separar el reporting exige cambiar el modelo de escritura **y** los 3 consumidores del stream.

## 7. Síntesis: síntomas del caso (§14.2) vs evidencia

| Síntoma FlowNow | ¿Presente? | Evidencia |
|---|---|---|
| Lógica de negocio en controladores | Sí | §1, §2 (`procesoRecaudacion`) |
| Clases y métodos excesivamente grandes | Sí | 5 archivos > 500 LOC, CC máx 40 |
| Utilitarios genéricos mezclados | Sí | `utils/util.js` ×4, `obligaciones/utils/util.js` 524 LOC |
| Valores hard-coded / URLs, proveedores y flags distribuidos | Sí | 27 en prod; M2 en 9 archivos |
| Acceso directo a tablas desde varios componentes | Sí | `eventos`: 5 escritores, 12 lectores |
| Dependencias circulares | Sí (leve) | 1 ciclo de carpetas |
| Duplicación | Sí | 22,7 % |
| Interfaces sin variabilidad real | No observado | No hay interfaces ni abstracciones: el riesgo es el opuesto (ninguna frontera) |
| Uso inconsistente de SOLID | Sí | SRP violado en handlers; sin DIP hacia proveedores |
| Ausencia de fronteras para APIs de terceros | Sí | ADF ×2 clientes, CUT, portal, on-prem sin adapter |
| TODO/FIXME/HACK/TEMP/WORKAROUND | Sí (solo TODO) | 5 prod sin gestionar |
| Pruebas insuficientes en comportamiento crítico | Sí | Inicio 0/14; hoy ~14 % de cobertura de líneas |
| Origen asistido por IA | **No** | Historial git sin rastros de asistentes (riesgo R-01): la erosión viene de casi 7 años de desarrollo incremental (primer commit 2019-12-09) con 28 autores |

**Candidato de slice para E3** (a decidir en E2): la **confirmación de pago (M2)**. Concentra el escenario más ilustrativo (EC-1), toca `eventos` (ownership) y `publishSnsEventos` (EC-2), y ya tiene tests de caracterización parciales (`postM2Test` en skip, TD-009).

## Anexos (generados, `arch/baseline/04-diagnostico-e1/`)

| Archivo | Contenido |
|---|---|
| `RESUMEN.md` | Matriz E8 (columna AS-IS) y tablas consolidadas |
| `inventario.tsv`, `deps.tsv`, `ciclos.txt` | Archivos/LOC, grafo de dependencias, ciclos |
| `tablas.tsv` | Cada acceso a tabla con operación y línea |
| `satd.tsv`, `hardcoded.tsv`, `integraciones.tsv` | Inventarios |
| `complejidad.json`, `jscpd/` | ESLint (complexity, max-lines, max-depth, max-params) y duplicación |
| `tests-*.json`, `coverage-*/` | Resultados de jest y cobertura sobre todo el código prod |
| `escenarios.json` | Impacto EC-1..EC-4 con listas de archivos y Lambdas |
| `commit.txt`, `fecha.txt` | Trazabilidad de la corrida |

Reproducción: `cd api-recaudacion-impl && arch/scripts/baseline.sh arch/baseline/<nombre>` (requiere `npm install` en `back/recaudacion` y `back/recaudacion-int`).
