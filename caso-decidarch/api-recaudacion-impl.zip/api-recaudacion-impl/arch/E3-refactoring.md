# E3 — Plan e implementación de refactoring: slice "confirmación de pago (M2)"

> Caso DecidArch §17.3. Arquitectura objetivo: `arch/E2-arquitectura-to-be.md`.
> Commit base (AS-IS): `66a2873`. Diffs: `arch/E3/slice-codigo.patch` y `arch/E3/slice-tests.patch`. Estos dos son del cierre del E3. El diff final, que incluye E4, E5 y TD-026, está en `arch/E3/diff-final-back.patch`.
> Baselines: `arch/baseline/04-diagnostico-e1/` (antes) y `arch/baseline/05-post-slice-e3/` (después).

## 1. Secuencia incremental

Orden del caso (§11.1): *CharacterizationTests → SmallRefactoring → Tests → ArchitectureCheck → Commit*. Cada paso terminó con la suite completa en verde antes de seguir.

| Paso | Cambio | Tipo | Tests `recaudacion-int` |
|---|---|---|---|
| 0 | Recuperación de tests previa (fake DynamoDB, 5 tests reactivados) | Red de seguridad | 8/8 (+6 skip) |
| 1 | `postM2Test` reescrito como caracterización: 6 casos originales + 3 nuevos (fecha de registro, TD-010, carrito con rechazo parcial). Dobles de billetera y portal; tabla vacía por test | Caracterización | 17/17 |
| 2 | `suscriptorSnsReplicaGenericaTest` nuevo (5 casos): traducción XML→M2, reemplazo de pago existente, DSS, errores (TD-011). `TZ=UTC` en jest, como en Lambda | Caracterización | 22/22 |
| 3 | Extraer `src/confirmacion-pago/adaptadores/m2.js` (ACL M2 JSON/XML, DTO `Confirmacion` v1) | Extract Module / Adapter | 22/22 |
| 4 | Extraer `src/eventos/` (owner de `eventos`, claves compuestas), `src/institucion/` y `src/integraciones/portalAutoservicios.js` | Extract Module | 22/22 |
| 5 | Extraer `src/confirmacion-pago/index.js` (`registrar()`, 3 casos por despacho de función). `postM2.js` pasa a handler delgado. **Corrige TD-010** | Extract + Fix | 22/22 + 1 actualizado (test 8) |
| 6 | Persistir `confirmacion` v1 junto a `payload` (expand, ADR-003) | Expand | 23/23 (+test 10) |
| 7 | Suscriptor: usa el adaptador XML y `eventos.buscarPorId` (sale el cliente DynamoDB v3 propio). **Corrige TD-011** (relanza) | Move + Fix | 23/23 (2 tests TD-011 actualizados) |
| 8 | Borrar código muerto: `putItemM2` (sin usuarios), variable `fecha` sin uso, rama `Pago.formulario` en minúscula (ningún emisor la produce), imports sin uso | Remove Dead Code | 23/23 |
| 9 | Medición: baseline 05 + escenarios contra el commit AS-IS en un worktree | Architecture check | 16/16 y 23/23 |

## 2. Pruebas de caracterización

| Suite | Casos | Qué fija |
|---|---|---|
| `postM2Test.js` | 10 | Unitario; RECIBIDA con `idTramite` tratada como carrito (y su id `…#undefined#…`); carrito con monto por trámite y pago doble; on-prem con `GENERICO_<inst>` o concepto en PRODUCCION; pagos previos del mismo `IdExt`; reenvío idempotente; `fechaEvento` = hora de registro; abono rechazado unitario (TD-010) y en carrito (registro parcial, TD-013); `confirmacion` v1 persistido |
| `suscriptorSnsReplicaGenericaTest.js` | 5 | M2 XML→JSON (tipos numéricos, `flag`, `REENVIO`, `ID_PROCESO_JSON_DET`); conversión de fechas con TD-012; borrado previo vía Lambda `deleteRegistrosEventos`; parámetros de DSS; propagación de errores |

**¿Cómo sabemos que la red detecta regresiones?** Con una prueba de mutación manual. Se introdujeron mutantes en las reglas y se verificó que algún test fallara.

| Mutante | Sobre el AS-IS | Sobre el TO-BE |
|---|---|---|
| Romper detección de reenvío | 5 tests fallan | 5 fallan |
| `Folio` sin `Number()` | 1 | 1 |
| Quitar `TotalPago` por trámite (carrito) | 1 | — (ahora `conTotal`; cubierto por el test 3) |
| Cambiar `GENERICO_<inst>` | 1 | — |
| Orden de partes del id de carrito | — | 2 |
| Quitar el rechazo por abono (I5) | — | 2 |
| `Folio` XML sin `Number()` | — | 1 |
| Quitar el `throw` de TD-011 | — | 2 |

## 3. Cambios realizados

| Archivo | Antes | Después |
|---|---|---|
| `postM2.js` | 326 LOC, handler CC 32, 10 alertas de anidamiento | 18 LOC, sin alertas |
| `suscriptorSnsReplicaGenerica.mjs` | 180 LOC, conoce XML y M2, cliente DynamoDB v3 propio, `catch` silencioso | 77 LOC; delega formato y tabla; relanza |
| `src/confirmacion-pago/adaptadores/m2.js` | — | 106 LOC: `desdeM2Json`, `m2JsonDesdeXml`, copias inmutables del legado (`conTotal`, `conFolioNumerico`, `conConcepto`) |
| `src/confirmacion-pago/index.js` | — | 100 LOC: `registrar()`, I1–I5, despacho unitario/carrito/on-prem |
| `src/eventos/index.js` | — | 56 LOC: `buscarPorSolicitud`, `buscarPorId`, `registrarPagoConfirmado`, claves compuestas |
| `src/institucion/index.js`, `src/integraciones/portalAutoservicios.js` | — | 15 + 22 LOC |
| `aws/dynamoDbServices.js` (int) | `putItemM2` + `getItems` | Solo `getItems` (lo siguen usando `callback` y `recibeM1`) |

Total del slice: 506 → 394 LOC, repartidas en 7 archivos con responsabilidades declaradas. Ninguna función supera complejidad 10. Solo el handler del suscriptor sigue por encima de 50 líneas (orquesta 4 pasos: borrado, createM2, DSS y logs).

**Contratos externos sin cambios:** cuerpo y respuestas de `POST /giradores/m2/createM2`, formato SNS de la réplica, invocaciones a `createM2` y `deleteRegistrosEventos`, SQL de DSS y forma del registro `PAGO_CONFIRMADO` (solo se **agrega** `confirmacion`).

## 4. Cambios de comportamiento intencionales

Son los únicos en que el comportamiento observable cambia. Cada uno tiene su test.

| # | Cambio | Antes | Después | Evidencia |
|---|---|---|---|---|
| C1 | TD-010: abono rechazado en unitario | 400, body `{}` (`ReferenceError`) | 400, body `{"statusCode":400,"body":"NOK"}` (mismo contrato que carrito); no persiste | Test 8 |
| C2 | TD-011: errores en el suscriptor | Se registraban en el log y la Lambda terminaba "OK" | Se relanzan: Lambda reporta error y la invocación asíncrona de SNS reintenta | 2 tests TD-011 |
| C3 | Expand ADR-003 | — | Atributo `confirmacion` v1 en cada `PAGO_CONFIRMADO` nuevo | Test 10 |
| C4 | Región de los clientes del slice | `'us-east-1'` fija | `process.env.AWS_REGION` con *fallback* `us-east-1` (Lambda define `AWS_REGION`). **E4:** se quitó el *fallback* (FF-5) | Revisión de código |

Riesgo de C2: con los reintentos, un fallo en DSS repite el borrado y la recreación del pago (idempotente por `idTransaccion`) y la llamada a DSS. Hay que confirmar con el equipo de base de datos que `act_fecha_aceptacion` es idempotente, y configurar una DLQ o un *on-failure destination* (TD-011, pendiente de infraestructura).

## 5. Evidencia: AS-IS vs. post-slice

El impacto por escenario se midió con `escenarios.sh`. El AS-IS se recalculó sobre un worktree del commit `66a2873` (`SRC_ROOT`), porque el script lee el código del árbol indicado y no el de la carpeta del baseline.

| Indicador | AS-IS (04 / `66a2873`) | Post-slice (05) | Lectura |
|---|---|---|---|
| EC-1: archivos que conocen el formato M2 | 9 | **8** | Entrada (`postM2`, suscriptor) detrás del ACL. Quedan 7 consumidores de lectura que usan `payload` (ADR-003) |
| EC-1: Lambdas afectadas | 9 | 9 | Las 2 Lambdas de entrada ahora dependen del ACL; mismo número, pero el cambio de formato de **entrada** se hace en 1 archivo |
| EC-2 / EC-4 | 2 / 7 archivos | 2 / 7 | Fuera del slice |
| EC-3: archivos (proxy por nombres de campo) | 14 | 16 | Sube porque los módulos nuevos *nombran* `codigoInstitucionOnPrem`. La **construcción** de `institucion#environment` en el slice pasó de 2 sitios en `postM2` a 1 en `eventos/` |
| Escritores de `eventos` | 5 | 5 | `postM2` se reemplazó por el owner `eventos/`. Quedan `recaudacion/aws/dynamoDbServices` (RECIBIDA), `cuadratura`, `estadoOP`, `deleteRegistrosEventos` |
| Funciones CC > 10 | 17 | **16** | Sale `postM2` (CC 32) |
| Anidamiento > 4 | 36 | **26** | |
| Funciones > 50 líneas | 46 | 45 | |
| Duplicación | 22,71 % | 22,46 % | |
| Tests `recaudacion-int` | 8 (+6 skip) | **23/23** | |
| Cobertura de líneas `recaudacion-int` | 14,56 % | **27,31 %** | |
| SATD prod | 5 | 5 | El slice no contenía SATD; la gestión corresponde al E5 |
| Defectos del slice | TD-009, TD-010, TD-011 abiertos | Resueltos | `arch/debt-ledger.md` |

**Conclusión honesta:** el slice cumple lo que prometía el E2 §7 ("entrada detrás del adaptador"), pero **no** lleva EC-1 a "1 módulo": 7 consumidores siguen leyendo el M2 legado. El siguiente incremento es migrar esos consumidores a `confirmacion` (ADR-003, fase *contract*), empezando por `getSolicitud`/`getSolicitudes`, que exponen el formato en la API de consulta.

## 6. Hallazgos durante el refactor

- **TD-012:** la conversión de fechas del XML usa el desfase horario de Santiago vigente al ejecutar, no el de la fecha del pago. Preservado y caracterizado.
- **TD-013:** en carrito, un rechazo de billetera a mitad de camino deja trámites abonados y persistidos. Preservado; no hay contrato de reversa.
- **TD-014:** `@aws-sdk/*` v3 y `tgr-sdk-layer` no están en `package.json`, sino que los provee el runtime de Lambda. En los tests se mockean como módulos virtuales.
- La métrica de ownership no reconocía `{ TableName, Item }` (forma abreviada); se corrigió en `metrics.js`, y el AS-IS no cambia.
- `impacto.js` medía el código actual aunque se le pasara un baseline antiguo; se agregó `SRC_ROOT` para medir cualquier commit.

## 7. Cómo reproducir

```bash
cd api-recaudacion-impl
(cd back/recaudacion && npm install) && (cd back/recaudacion-int && npm install)
(cd back/recaudacion-int && npx jest)                     # 23/23
arch/scripts/baseline.sh arch/baseline/<nombre>            # post-slice
git worktree add --detach /tmp/asis 66a2873                # AS-IS
SRC_ROOT=/tmp/asis/back arch/scripts/escenarios.sh arch/baseline/04-diagnostico-e1
```

Los cambios **no están commiteados**: el diff está en `arch/E3/*.patch`.
