// Consolida los artefactos del baseline en RESUMEN.md (matriz E8, columna medida).
// uso: node resumen.js <OUT_DIR> > RESUMEN.md
const fs = require('fs'), path = require('path');
const out = path.resolve(process.argv[2]);
const read = f => { try { return JSON.parse(fs.readFileSync(path.join(out, f), 'utf8')); } catch { return null; } };
const tsv = f => fs.readFileSync(path.join(out, f), 'utf8').trim().split('\n').slice(1).map(l => l.split('\t'));

const m = read('metrics.json');
const eslint = read('complejidad.json') || [];
const dup = read('jscpd/jscpd-report.json');
const rules = {}, worst = [];
for (const f of eslint) for (const x of f.messages) {
  rules[x.ruleId] = (rules[x.ruleId] || 0) + 1;
  if (x.ruleId === 'complexity') worst.push([+x.message.match(/complexity of (\d+)/)[1], path.relative(process.cwd(), f.filePath), x.line, x.message.split(' has')[0]]);
}
worst.sort((a, b) => b[0] - a[0]);

const tests = ['recaudacion', 'recaudacion-int'].map(p => {
  const t = read(`tests-${p}.json`), c = read(`coverage-${p}/coverage-summary.json`);
  const log = (() => { try { return fs.readFileSync(path.join(out, `tests-${p}.log`), 'utf8'); } catch { return ''; } })();
  return {
    p, ok: t ? `${t.numPassedTests}/${t.numTotalTests}` : 'no ejecutable',
    suites: t ? `${t.numPassedTestSuites}/${t.numTotalTestSuites}` : '-',
    lines: c ? `${c.total.lines.pct}%` : '-', branches: c ? `${c.total.branches.pct}%` : '-',
    causa: t ? '' : (log.match(/Unable to locate a Java Runtime|ECONNREFUSED|Cannot find module[^\n]*/) || ['ver log'])[0],
  };
});
const satdAll = tsv('satd.tsv');
const satdProd = tsv('satd.tsv').filter(r => r[3] === 'prod');
const hard = tsv('hardcoded.tsv');
const hosts = {}; hard.forEach(r => { const h = r[3].replace(/^(https?:\/\/[^/]+).*/, '$1'); hosts[h] = (hosts[h] || 0) + 1; });
const tablas = {}; tsv('tablas.tsv').forEach(([t, f, w]) => { (tablas[t] ||= { lee: new Set(), escribe: new Set() })[w].add(f); });
const ciclos = fs.readFileSync(path.join(out, 'ciclos.txt'), 'utf8').trim();

console.log(`# Baseline AS-IS — api-recaudacion-impl

Generado por \`arch/scripts/baseline.sh\`. Detalle en los TSV/JSON de esta carpeta.

## Matriz E8 (columna AS-IS)

| Indicador | AS-IS | Fuente |
|---|---|---|
| SATD no gestionada (sin TD-xxx, E5) | ${satdAll.filter(r => !/TD-\d{3}/.test(r[4])).length} de ${m.satd_total} comentarios SATD (prod: ${m.satd_prod}) | satd.tsv |
| Ciclos entre módulos (carpetas) | ${m.ciclos_carpetas} | ciclos.txt |
| Ciclos entre archivos | ${m.ciclos_archivos} | ciclos.txt |
| Dependencias prohibidas | n/d (sin reglas definidas aún) | — |
| Hard-coded (URL/IP/ambiente/región/ruta SSM) en prod | ${m.hardcoded_total} | hardcoded.tsv |
| Tablas con más de un escritor (sin owner) | ${m.tablas_con_multiples_escritores.length} | tablas.tsv |
| Funciones con complejidad > 10 | ${rules.complexity || 0} | complejidad.json |
| Funciones > 50 líneas | ${rules['max-lines-per-function'] || 0} | complejidad.json |
| Anidamiento > 4 | ${rules['max-depth'] || 0} | complejidad.json |
| Duplicación (bloques ≥10 líneas) | ${dup ? `${dup.statistics.total.percentage}% (${dup.statistics.total.clones} clones)` : 'n/d'} | jscpd/ |
| Tests que pasan | ${tests.map(t => `${t.p}: ${t.ok}`).join(' · ')} | tests-*.json |
| Cobertura de líneas | ${tests.map(t => `${t.p}: ${t.lines}`).join(' · ')} | coverage-*/ |
| ADRs | 0 | — |
| Fitness functions | 0 | — |

## Tamaño
- Archivos prod: ${m.archivos_prod} (${m.loc_prod} LOC) · test: ${m.archivos_test} (${m.loc_test} LOC)
- Archivos prod > 500 LOC: ${m.archivos_prod_gt_500_loc} · mayor: \`${m.archivo_mayor[0]}\` (${m.archivo_mayor[2]} LOC)
- Dependencias internas (require/import): ${m.dependencias_internas}

## Ciclos
\`\`\`
${ciclos}
\`\`\`

## Ownership de datos (archivos distintos que leen / escriben)
| Tabla | Lee | Escribe |
|---|---|---|
${Object.entries(tablas).map(([t, v]) => `| \`${t}\` | ${v.lee.size} | ${v.escribe.size} |`).join('\n')}

## Complejidad: top 10 funciones
| CC | Archivo:línea | Función |
|---|---|---|
${worst.slice(0, 10).map(([c, f, l, n]) => `| ${c} | \`${f}:${l}\` | ${n} |`).join('\n')}

## SATD en código productivo
| Archivo:línea | Texto |
|---|---|
${satdProd.map(r => `| \`${r[0]}:${r[1]}\` | ${r[4] || '(vacío)'} |`).join('\n')}

## Hard-coded por destino
${Object.entries(hosts).sort((a, b) => b[1] - a[1]).map(([h, n]) => `- \`${h}\`: ${n}`).join('\n')}

## Integraciones externas (archivos prod por tipo)
${Object.entries(m.integraciones_por_tipo).map(([k, v]) => `- ${k}: ${v}`).join('\n')}

## Tests
| Subproyecto | Tests OK | Suites OK | Líneas | Ramas | Observación |
|---|---|---|---|---|---|
${tests.map(t => `| ${t.p} | ${t.ok} | ${t.suites} | ${t.lines} | ${t.branches} | ${t.causa} |`).join('\n')}
`);
