// Impacto AS-IS de un escenario de cambio: archivos prod que contienen la decisión (regex)
// + funciones Lambda cuyo handler depende (transitivamente) de alguno de ellos.
// uso: node impacto.js <BASELINE_DIR> <regex> [--files]
const fs = require('fs'), path = require('path');
const [dir, re, flag] = process.argv.slice(2);
// SRC_ROOT permite medir otro árbol (p. ej. un worktree del commit AS-IS); por defecto, el código actual
const back = path.resolve(process.env.SRC_ROOT || path.join(__dirname, '../../back'));
const tsv = f => fs.readFileSync(path.join(dir, f), 'utf8').trim().split('\n').slice(1).map(l => l.split('\t'));
const prod = tsv('inventario.tsv').filter(r => r[1] === 'prod').map(r => r[0]);
const adj = {};
tsv('deps.tsv').forEach(([a, b]) => (adj[a] ||= []).push(b));
const rx = new RegExp(re);
const touched = new Set(prod.filter(f => rx.test(fs.readFileSync(path.join(back, f), 'utf8'))));

// handlers declarados en serverless.yml: "handler: ruta/archivo.funcion"
const lambdas = [];
for (const sub of ['recaudacion', 'recaudacion-int']) {
  const yml = fs.readFileSync(path.join(back, sub, 'serverless.yml'), 'utf8').split('\n');
  let name;
  for (const l of yml) {
    const n = l.match(/^  ([A-Za-z0-9_-]+):\s*$/); if (n) name = n[1];
    const h = l.match(/^\s+handler:\s*([^\s#]+)\.\w+\s*$/);
    if (h && name) {
      const base = path.join(sub, h[1]);
      const file = prod.find(f => f === base + '.js' || f === base + '.mjs');
      if (file) lambdas.push([`${sub}:${name}`, file]);
    }
  }
}
const reach = (f, seen = new Set()) => { if (seen.has(f)) return seen; seen.add(f); (adj[f] || []).forEach(g => reach(g, seen)); return seen; };
const hit = lambdas.filter(([, f]) => [...reach(f)].some(x => touched.has(x)));
const subs = new Set([...touched].map(f => f.split('/')[0]));
console.log(JSON.stringify({ archivos: touched.size, lambdas: hit.length, lambdas_total: lambdas.length, subproyectos: subs.size,
  ...(flag === '--files' && { lista_archivos: [...touched], lista_lambdas: hit.map(h => h[0]) }) }));
