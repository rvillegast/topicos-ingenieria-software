// uso: node dircycles.js ROOT -> ciclos entre carpetas + tablas tocadas por >1 archivo
const fs=require('fs'),path=require('path');const root=path.resolve(process.argv[2]);
const files=[];(function w(d){for(const e of fs.readdirSync(d,{withFileTypes:true})){if(['node_modules','.git','dist','build','coverage'].includes(e.name))continue;const p=path.join(d,e.name);e.isDirectory()?w(p):/\.(js|ts)$/.test(e.name)&&!/\.d\.ts$/.test(e.name)&&files.push(p)}})(root);
const D=f=>path.dirname(path.relative(root,f))||'.';const g={},tab={};
for(const f of files){const s=fs.readFileSync(f,'utf8');const a=D(f);g[a]=g[a]||new Set;
 for(const m of s.matchAll(/(?:require\(\s*|from\s+)['"](\.[^'"]+)['"]/g)){let t=path.resolve(path.dirname(f),m[1]);for(const c of [t,t+'.js',t+'.ts',t+'/index.js',t+'/index.ts'])if(fs.existsSync(c)&&fs.statSync(c).isFile()){if(D(c)!==a)g[a].add(D(c));break}}
 for(const m of s.matchAll(/(?:TableName\s*:\s*[`'"]?|(?:FROM|INTO|UPDATE|JOIN)\s+)([A-Za-z_$][\w${}.-]{3,})/g)){const t=m[1].replace(/\$\{[^}]*\}-?/g,'').toUpperCase();if(t.length>3)(tab[t]=tab[t]||new Set).add(path.relative(root,f))}}
let i=0;const idx={},low={},st=[],on=new Set,out=[];
function sc(v){idx[v]=low[v]=i++;st.push(v);on.add(v);for(const w of g[v]||[]){if(!(w in idx)){sc(w);low[v]=Math.min(low[v],low[w])}else if(on.has(w))low[v]=Math.min(low[v],idx[w])}if(low[v]===idx[v]){const c=[];let w;do{w=st.pop();on.delete(w);c.push(w)}while(w!==v);if(c.length>1)out.push(c)}}
for(const v of Object.keys(g))if(!(v in idx))sc(v);
console.log('ciclos entre carpetas:',out.length);out.forEach(c=>console.log('  ',c.join(' <-> ')));
console.log('tablas escritas/leidas por >=3 archivos:');Object.entries(tab).filter(([,s])=>s.size>=3).sort((a,b)=>b[1].size-a[1].size).slice(0,8).forEach(([t,s])=>console.log('  ',t,s.size,'archivos'));
