#!/bin/bash
# uso: screen.sh DIR -> TSV por repo
cd "$1" || exit 1
for d in */; do
  d=${d%/}
  case "$d" in *-setup|*-setup-backup) continue;; esac
  files=$(find "$d" -type f \( -name '*.java' -o -name '*.ts' -o -name '*.js' -o -name '*.py' -o -name '*.go' -o -name '*.cs' -o -name '*.kt' \) \
    -not -path '*/node_modules/*' -not -path '*/target/*' -not -path '*/dist/*' -not -path '*/build/*' -not -path '*/.git/*' -not -name '*.min.js' -not -name '*.d.ts' -not -path '*/.angular/*' -not -path '*/coverage/*' 2>/dev/null)
  [ -z "$files" ] && continue
  n=$(echo "$files" | wc -l | tr -d ' ')
  loc=$(echo "$files" | tr '\n' '\0' | xargs -0 cat 2>/dev/null | wc -l | tr -d ' ')
  big=$(echo "$files" | tr '\n' '\0' | xargs -0 wc -l 2>/dev/null | grep -v ' total$' | sort -rn | head -1 | awk '{print $1}')
  lang=$(echo "$files" | sed 's/.*\.//' | sort | uniq -c | sort -rn | head -1 | awk '{print $2}')
  tests=$(echo "$files" | grep -Eic '(test|spec)[^/]*$')
  satd=$(echo "$files" | tr '\n' '\0' | xargs -0 grep -EI 'TODO|FIXME|HACK|XXX|TEMP|WORKAROUND' 2>/dev/null | wc -l | tr -d ' ')
  http=$(echo "$files" | tr '\n' '\0' | xargs -0 grep -EIl 'RestTemplate|WebClient|HttpClient|axios|fetch\(|requests\.|FeignClient|SoapClient|WebServiceTemplate' 2>/dev/null | wc -l | tr -d ' ')
  urls=$(echo "$files" | tr '\n' '\0' | xargs -0 grep -EIo 'https?://[a-zA-Z0-9._-]+' 2>/dev/null | grep -v -E 'localhost|apache.org|w3.org|xmlns|schemas|example' | wc -l | tr -d ' ')
  db=$(echo "$files" | tr '\n' '\0' | xargs -0 grep -EIl 'JdbcTemplate|@Repository|JpaRepository|EntityManager|createQuery|SELECT |INSERT INTO|UPDATE .* SET|DynamoDB|mongoose|sequelize|typeorm|knex|prisma' 2>/dev/null | wc -l | tr -d ' ')
  ctrl=$(echo "$files" | grep -Eic 'controller')
  git=$([ -d "$d/.git" ] && echo y || echo n)
  echo -e "$d\t$lang\t$n\t$loc\t$big\t$tests\t$satd\t$http\t$urls\t$db\t$ctrl\t$git"
done
