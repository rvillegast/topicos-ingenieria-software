// Métricas estáticas AS-IS/TO-BE sin dependencias externas.
// uso: node metrics.js <SRC_ROOT> <OUT_DIR>
// Genera: inventario.tsv, satd.tsv, deps.tsv, ciclos.txt, tablas.tsv, hardcoded.tsv, integraciones.tsv, metrics.json
const fs = require('fs'), path = require('path');
const [root, out] = process.argv.slice(2).map(p => path.resolve(p));
if (!root || !out) { console.error('uso: node metrics.js <SRC_ROOT> <OUT_DIR>'); process.exit(1); }
fs.mkdirSync(out, { recursive: true });

const SKIP = new Set(['node_modules', '.git', 'coverage', 'dist', 'build', '.serverless', '.dynamodb']);
const files = [];
(function walk(d) {
  for (const e of fs.readdirSync(d, { withFileTypes: true })) {
    if (SKIP.has(e.name)) continue;
    const p = path.join(d, e.name);
    if (e.isDirectory()) walk(p); else if (/\.(c|m)?js$/.test(e.name)) files.push(p);
  }
})(root);

const rel = f => path.relative(root, f);
// ponytail: heurística por ruta/nombre; ajustar si aparecen tests fuera de estas carpetas
const isTest = f => /(^|\/)(__tests__|__mocks__|mocks|testing|test|test-support)\//.test(rel(f)) || /(test|spec)\.(m)?js$/i.test(f) || /jest.*config|babel\.config/.test(f);
const dirOf = f => path.dirname(rel(f)) || '.';
const src = Object.fromEntries(files.map(f => [f, fs.readFileSync(f, 'utf8')]));
const tsv = (name, header, rows) => fs.writeFileSync(path.join(out, name), [header, ...rows].map(r => r.join('\t')).join('\n') + '\n');
const clean = s => s.replace(/\s+/g, ' ').trim().slice(0, 200);

// 1. Inventario
const inv = files.map(f => [rel(f), isTest(f) ? 'test' : 'prod', src[f].split('\n').length]).sort((a, b) => b[2] - a[2]);
tsv('inventario.tsv', ['archivo', 'tipo', 'loc'], inv);

// 2. SATD (solo comentarios)
const satd = [];
for (const f of files) src[f].split('\n').forEach((l, i) => {
  const m = l.match(/(\/\/|\/\*|\*)\s*.*?\b(TODO|FIXME|HACK|XXX|TEMP|WORKAROUND)\b(.*)/);
  if (m) satd.push([rel(f), i + 1, m[2], isTest(f) ? 'test' : 'prod', clean(m[3].replace(/^[:\s-]+/, ''))]);
});
tsv('satd.tsv', ['archivo', 'linea', 'tag', 'tipo', 'texto'], satd);

// 3. Dependencias internas (archivo y carpeta) + ciclos (Tarjan)
const edges = [];
for (const f of files) for (const m of src[f].matchAll(/(?:require\(\s*|from\s+|import\(\s*)['"](\.[^'"]+)['"]/g)) {
  const t = path.resolve(path.dirname(f), m[1]);
  const hit = [t, t + '.js', t + '.mjs', t + '/index.js'].find(c => fs.existsSync(c) && fs.statSync(c).isFile());
  if (hit) edges.push([f, hit]);
}
tsv('deps.tsv', ['desde', 'hacia'], edges.map(([a, b]) => [rel(a), rel(b)]));
function sccs(nodes, adj) {
  let i = 0; const idx = {}, low = {}, st = [], on = new Set(), res = [];
  const visit = v => {
    idx[v] = low[v] = i++; st.push(v); on.add(v);
    for (const w of adj[v] || []) {
      if (!(w in idx)) { visit(w); low[v] = Math.min(low[v], low[w]); } else if (on.has(w)) low[v] = Math.min(low[v], idx[w]);
    }
    if (low[v] === idx[v]) { const c = []; let w; do { w = st.pop(); on.delete(w); c.push(w); } while (w !== v); if (c.length > 1) res.push(c); }
  };
  nodes.forEach(v => { if (!(v in idx)) visit(v); });
  return res;
}
const fAdj = {}, dAdj = {};
for (const [a, b] of edges) {
  (fAdj[rel(a)] ||= []).push(rel(b));
  if (dirOf(a) !== dirOf(b)) (dAdj[dirOf(a)] ||= new Set()).add(dirOf(b));
}
const fileCycles = sccs(files.map(rel), fAdj);
const dirCycles = sccs([...new Set(files.map(dirOf))], Object.fromEntries(Object.entries(dAdj).map(([k, v]) => [k, [...v]])));
fs.writeFileSync(path.join(out, 'ciclos.txt'),
  `Ciclos entre archivos: ${fileCycles.length}\n${fileCycles.map(c => '  ' + c.join(' <-> ')).join('\n')}\n` +
  `Ciclos entre carpetas: ${dirCycles.length}\n${dirCycles.map(c => '  ' + c.join(' <-> ')).join('\n')}\n`);

// 4. Tablas: por cada objeto de parámetros con TableName se clasifica la operación por sus campos
// (Item=put, UpdateExpression=update, KeyConditionExpression=query, Key=get|delete, resto=scan).
// Normaliza a nombre lógico: PREFIX = tgr-<env>-api-recaudacion (serverless.yml); ambiente literal -> {ENV}
const tableName = s => s.replace(/[`'"\s]/g, '')
  .replace(/\$\{process\.env\.PREFIX\}|process\.env\.PREFIX\+/g, 'tgr-{ENV}-api-recaudacion')
  .replace(/\$\{process\.env\.ENV\}/g, '{ENV}').replace(/^tgr-(dev|qa|lab|prod)-/, 'tgr-{ENV}-');
const enclosing = (s, at) => {             // objeto literal { ... } que contiene la posición `at`
  let i = at, j = at, d = 0;
  while (i > 0 && !(s[i] === '{' && d === 0)) { if (s[i] === '}') d++; if (s[i] === '{') d--; i--; }
  d = 0;
  while (j < s.length && !(s[j] === '}' && d === 0)) { if (s[j] === '{') d++; if (s[j] === '}') d--; j++; }
  return [i, j];
};
const tablas = [];
for (const f of files.filter(f => !isTest(f))) {
  const s = src[f];
  for (const m of s.matchAll(/TableName\s*:\s*(`[^`]*`|'[^']*'|"[^"]*"|[^,\n}]+)/g)) {
    const [i, j] = enclosing(s, m.index), obj = s.slice(i, j);
    const op = /\bItem\s*([:,}]|$)/.test(obj) ? 'put' : /UpdateExpression/.test(obj) ? 'update'
      : /KeyConditionExpression/.test(obj) ? 'query'
      : /\bKey\s*:/.test(obj) ? (/\.delete\(/.test(s.slice(j, j + 300)) ? 'delete' : 'get') : 'scan';
    tablas.push([tableName(m[1]), rel(f), /put|update|delete/.test(op) ? 'escribe' : 'lee', op, s.slice(0, m.index).split('\n').length]);
  }
}
tsv('tablas.tsv', ['tabla', 'archivo', 'modo', 'operacion', 'linea'], tablas.sort());

// 5. Hard-coded (URLs, ARN, IPs, ids de cuenta AWS, nombres de ambiente)
const HC = [
  ['url', /https?:\/\/[^\s'"`)]+/g], ['arn', /arn:aws:[^\s'"`]+/g],
  ['ip', /\b\d{1,3}(?:\.\d{1,3}){3}\b/g], ['ambiente', /\btgr-(?:dev|qa|lab|prod)[\w-]*/gi],
  ['region', /\b(?:us|sa|eu)-(?:east|west|central)-\d\b/g], ['ssm-path', /['"`]\/tgr\/[^'"`]+['"`]/g],
];
const hard = [];
for (const f of files.filter(f => !isTest(f))) src[f].split('\n').forEach((l, i) => {
  if (/^\s*(\/\/|\*)/.test(l)) return;
  l = l.replace(/(^|[\s;,)])\/\/.*$/, '$1');   // comentario al final de la línea (no corta 'https://')
  for (const [k, re] of HC) for (const m of l.matchAll(re)) {
    // URLs armadas desde variables y namespaces XML no son valores de ambiente hard-coded
    if (k === 'url' && /^https?:\/\/(\$\{|www\.w3\.org|schemas\.|www\.bea\.com|www\.openuri\.org)/.test(m[0])) continue;
    hard.push([rel(f), i + 1, k, m[0].slice(0, 120)]);
  }
});
tsv('hardcoded.tsv', ['archivo', 'linea', 'tipo', 'valor'], hard);

// 6. Puntos de integración externos (SDK/clientes por archivo)
const INT = {
  'http(axios/https)': /require\(['"](axios|https)['"]\)|from ['"](axios|https)['"]/,
  'aws-lambda': /client-lambda|Lambda\(|\.invoke\(/, 'aws-sns': /client-sns|SNS\(|\.publish\(/,
  'aws-dynamodb': /DynamoDB|lib-dynamodb|DocumentClient/, 'aws-s3': /\bS3\(|client-s3/,
  'aws-sqs': /SQS\(|client-sqs/, 'aws-sigv4': /aws4/, 'jwt/oauth': /jsonwebtoken|jwt-decode|oauth/i,
  'tgr-sdk(layer)': /tgr-sdk/, 'xml/soap': /xml2js|xml-js|jsontoxml|soap/i, 'oracle': /oracle/i, 'gcp': /gcp|pubsub/i,
};
const integ = [];
for (const f of files.filter(f => !isTest(f))) for (const [k, re] of Object.entries(INT)) if (re.test(src[f])) integ.push([k, rel(f)]);
tsv('integraciones.tsv', ['tipo', 'archivo'], integ.sort());

// 7. Resumen
const prod = inv.filter(r => r[1] === 'prod');
const tablaArch = {};
tablas.forEach(([t, f, w]) => { (tablaArch[t] ||= { lee: new Set(), escribe: new Set() })[w].add(f); });
const metrics = {
  archivos_prod: prod.length, archivos_test: inv.length - prod.length,
  loc_prod: prod.reduce((s, r) => s + r[2], 0), loc_test: inv.filter(r => r[1] === 'test').reduce((s, r) => s + r[2], 0),
  archivos_prod_gt_500_loc: prod.filter(r => r[2] > 500).length, archivo_mayor: prod[0],
  satd_total: satd.length, satd_prod: satd.filter(r => r[3] === 'prod').length,
  satd_por_tag: satd.reduce((o, r) => (o[r[2]] = (o[r[2]] || 0) + 1, o), {}),
  dependencias_internas: edges.length, ciclos_archivos: fileCycles.length, ciclos_carpetas: dirCycles.length,
  tablas_distintas: Object.keys(tablaArch).length,
  tablas_con_multiples_escritores: Object.entries(tablaArch).filter(([, v]) => v.escribe.size > 1).map(([t, v]) => `${t} (${v.escribe.size})`),
  hardcoded_total: hard.length, hardcoded_por_tipo: hard.reduce((o, r) => (o[r[2]] = (o[r[2]] || 0) + 1, o), {}),
  integraciones_por_tipo: integ.reduce((o, r) => (o[r[0]] = (o[r[0]] || 0) + 1, o), {}),
};
fs.writeFileSync(path.join(out, 'metrics.json'), JSON.stringify(metrics, null, 2) + '\n');
console.log(JSON.stringify(metrics, null, 2));
