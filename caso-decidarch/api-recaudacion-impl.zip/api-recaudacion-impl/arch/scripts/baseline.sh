#!/bin/bash
# Baseline arquitectónico reproducible (E1 / E8).
# uso: arch/scripts/baseline.sh [OUT_DIR]   (desde la raíz del repo; por defecto arch/baseline/<fecha-hora>)
# Requiere: node, npx (descarga eslint@8.57.0 y jscpd@4.0.5), npm install hecho en back/recaudacion y back/recaudacion-int
set -uf  # -f: sin globbing, los patrones ** se pasan literales a las herramientas
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
DEST="${1:-$ROOT/arch/baseline/$(date +%Y%m%d-%H%M)}"
OUT=$(mkdir -p "$DEST" && cd "$DEST" && pwd)
SCRIPTS="$ROOT/arch/scripts"
TEST_IGNORES='**/node_modules/**,**/test-support/**,**/coverage/**,**/__tests__/**,**/__mocks__/**,**/mocks/**,**/testing/**,**/test/**'
cd "$ROOT"

echo "[1/6] métricas estáticas (inventario, SATD, dependencias, ciclos, tablas, hard-coded, integraciones)"
node "$SCRIPTS/metrics.js" back "$OUT" > /dev/null

echo "[2/6] complejidad (eslint: complexity>10, función>50 líneas, anidamiento>4, params>5)"
npx -y eslint@8.57.0 --no-eslintrc -c "$SCRIPTS/eslint-metrics.json" --ext .js,.mjs \
  $(echo "$TEST_IGNORES" | tr ',' '\n' | sed 's/^/--ignore-pattern /') -f json back > "$OUT/complejidad.json" 2>/dev/null

echo "[3/6] duplicación (jscpd, bloques >=10 líneas)"
npx -y jscpd@4.0.5 back --silent --min-lines 10 --format javascript --ignore "$TEST_IGNORES" \
  --reporters json --output "$OUT/jscpd" > /dev/null 2>&1

echo "[4/6] tests y cobertura (jest, cobertura sobre todo el código prod .js, no solo lo cargado por tests)"
for p in recaudacion recaudacion-int; do
  (cd "back/$p" && npx jest --json --outputFile="$OUT/tests-$p.json" --coverage \
     --collectCoverageFrom='**/*.js' --collectCoverageFrom='!**/{node_modules,coverage,__tests__,__mocks__,mocks,test,test-support}/**' \
     --collectCoverageFrom='!jest*.js' --coverageReporters=json-summary --coverageDirectory="$OUT/coverage-$p" > "$OUT/tests-$p.log" 2>&1)
  echo "  $p: exit $?"
done

echo "[5/6] escenarios de cambio (impacto AS-IS)"
"$SCRIPTS/escenarios.sh" "$OUT"

echo "[6/6] resumen"
node "$SCRIPTS/resumen.js" "$OUT" > "$OUT/RESUMEN.md"
git rev-parse HEAD > "$OUT/commit.txt" 2>/dev/null
date -u +%FT%TZ > "$OUT/fecha.txt"
echo "listo: $OUT/RESUMEN.md"
