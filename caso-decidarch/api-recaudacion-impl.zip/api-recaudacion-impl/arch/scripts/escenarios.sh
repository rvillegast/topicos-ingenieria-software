#!/bin/bash
# Impacto AS-IS de los escenarios de cambio del E1 (archivos que contienen la decisión + Lambdas afectadas).
# uso: arch/scripts/escenarios.sh <BASELINE_DIR>   (requiere inventario.tsv y deps.tsv de metrics.js)
set -uf
S=$(cd "$(dirname "$0")" && pwd); B="$1"
run() { printf '"%s": %s,\n' "$1" "$(node "$S/impacto.js" "$B" "$2" --files)"; }
{
  echo "{"
  # EC-1 cambiar proveedor de pago: formato del mensaje de confirmación M2 (Message.MessageId / Confirmacion.Pago)
  run "EC-1 proveedor de pago (formato M2)" '\.(Confirmacion|MessageId)\b|["'"'"']?\b(MessageId|Confirmacion)["'"'"']?\s*:'
  # EC-2 nuevo canal de notificación: puntos donde hoy se publica a SNS
  run "EC-2 canal de notificacion" 'TopicArn|\.publish\(|PublishCommand'
  # EC-3 modelo de Institucion (cliente): clave compuesta institucion#environment, datos del token, codigo on-prem
  run "EC-3 modelo de Institucion" 'institucionEnvironment|getDataFromToken|codigoInstitucionOnPrem'
  # EC-4 separar reporting: estados de cuadratura / orden de pago escritos sobre los eventos transaccionales
  run "EC-4 separar reporting" 'estado_cuad|estado_op|ESTADO_CUAD|ESTADO_OP'
  echo '"_": null }'
} > "$B/escenarios.json"
node -e 'const e=require(process.argv[1]);for(const[k,v]of Object.entries(e))if(v)console.log(`${k}: ${v.archivos} archivos, ${v.lambdas}/${v.lambdas_total} Lambdas, ${v.subproyectos} subproyectos`)' "$(cd "$B" && pwd)/escenarios.json"
