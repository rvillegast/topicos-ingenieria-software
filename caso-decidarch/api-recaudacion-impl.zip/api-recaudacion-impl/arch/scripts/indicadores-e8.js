// Indicadores de la matriz E8 a partir de uno o más baselines (complejidad, duplicación, cobertura, tests, escenarios).
// uso: node arch/scripts/indicadores-e8.js [baseline ...]   (por defecto 04-diagnostico-e1 y 08-e8-final; desde la raíz del repo)
const fs=require("fs"),path=require("path");
const J=f=>{try{return JSON.parse(fs.readFileSync(f,"utf8"))}catch(e){return null}};
for (const d of (process.argv.length > 2 ? process.argv.slice(2) : ["04-diagnostico-e1","08-e8-final"])) {
  const b="arch/baseline/"+d+"/"; const m=J(b+"metrics.json");
  const pick={}; for(const k of ["archivos_prod","loc_prod","archivos_prod_gt_500_loc","archivo_mayor","satd_total","satd_prod","ciclos_archivos","ciclos_carpetas","tablas_con_multiples_escritores","hardcoded_total","hardcoded_por_tipo"]) pick[k]=m[k];
  const es=J(b+"complejidad.json")||[]; const r={}; let maxcc=[0,""];
  for(const f of es) for(const x of f.messages){r[x.ruleId]=(r[x.ruleId]||0)+1; if(x.ruleId==="complexity"){const c=+x.message.match(/complexity of (\d+)/)[1]; if(c>maxcc[0]) maxcc=[c,path.basename(f.filePath)+":"+x.line]}}
  pick.eslint=r; pick.maxcc=maxcc;
  const dup=J(b+"jscpd/jscpd-report.json"); pick.dup=dup&&dup.statistics.total.percentage;
  for(const p of ["recaudacion","recaudacion-int"]){const c=J(b+"coverage-"+p+"/coverage-summary.json"); if(c){pick["cov_"+p]=c.total.lines.pct; for(const [k,v] of Object.entries(c)) if(/postM2|suscriptorSnsReplica|confirmacion-pago|eventos\/index|institucion\/index|integraciones|publishSnsEventos/.test(k)) pick["cov:"+k.split("back/")[1]]=v.lines.pct+"/"+v.branches.pct;}
    const t=J(b+"tests-"+p+".json"); if(t) pick["tests_"+p]=t.numPassedTests+"/"+t.numTotalTests;}
  const esc=J(b+"escenarios.json")||{}; pick.esc=Object.fromEntries(Object.entries(esc).filter(([,v])=>v).map(([k,v])=>[k,v.archivos+" archivos / "+v.lambdas+" Lambdas"]));
  console.log("=====",d); console.log(JSON.stringify(pick,null,1));
}
