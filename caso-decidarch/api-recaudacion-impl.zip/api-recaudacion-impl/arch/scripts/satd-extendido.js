// Inventario SATD extendido (E5): comentarios con marcadores en inglés y en español, en código prod y tests.
// Más amplio que FF-6 (incluye palabras como "revisar", "pendiente", "mientras"): sirve para revisar a mano, no como gate.
// Uso: node arch/scripts/satd-extendido.js back > salida.tsv   (archivo, línea, texto)
const fs=require('fs'),path=require('path');const root=process.argv[2];
const RX=/\b(TODO|FIXME|HACK|XXX|TEMP|WORKAROUND|KLUDGE)\b|\b(arregl\w*|temporal\w*|provisori\w*|parche\w*|chanch\w*|mejorar|pendiente|revisar|ojo|borrar|eliminar cuando|quitar|deprecad\w*|no deber[ií]a|por ahora|mientras|corregir|hardcode\w*|en duro|hack\w*|feo|workaround)\b/i;
const out=[];function walk(d){for(const f of fs.readdirSync(d)){const p=path.join(d,f);if(/node_modules|coverage|\.git$/.test(p))continue;const st=fs.statSync(p);if(st.isDirectory())walk(p);else if(/\.(m?js)$/.test(f)){fs.readFileSync(p,'utf8').split(/\r?\n/).forEach((l,i)=>{const m=l.match(/(\/\/|\/\*|^\s*\*)(.*)$/);if(m&&!/https?:$/.test(l.slice(0,l.indexOf(m[1])))&&RX.test(m[2]))out.push([path.relative(root,p),i+1,m[2].trim().slice(0,140)].join('\t'))})}}}
walk(root);console.log(out.join('\n'));
