# ADR-002: EventosRecaudacion como owner único de la tabla `eventos`

**Status:**
- **Aceptado:** el owner único y su implementación en `recaudacion-int` (E3).
- **Propuesto:** el mecanismo para compartirlo con el desplegable `recaudacion`. Requiere el spike de verificación indicado abajo.

**Context:**
- La tabla `eventos` no tenía owner (E1 §5). La escribían 5 componentes y la nombraban 14 archivos (FF-3 sobre el AS-IS: 22 hallazgos).
- Cada uno conocía la clave compuesta `id#idTransaccion`, `institucion#environment`, los índices y el `PREFIX`.
- Por eso un cambio de esquema (EC-3) o la separación de reporting (EC-4) se propagan a todos esos archivos.
- La tabla se usa desde **dos desplegables** Serverless distintos: `recaudacion`, que registra las `RECIBIDA` y las consulta, y `recaudacion-int`, que registra los `PAGO_CONFIRMADO` y hace la conciliación.

**Architectural concern:** Ownership de datos y ocultamiento del esquema físico (Parnas). Modificabilidad ante EC-3 y EC-4.

**Decision:**
1. `src/eventos/` es el **único** módulo que nombra la tabla, construye sus claves compuestas y usa `DocumentClient` para ella.
   - Interfaz: `buscarPorSolicitud`, `buscarPorId`, `registrarPagoConfirmado`, `idPago`, `idPagoTramite`, `idAbonoTramite` e `institucionEnvironment`.
   - Es una hoja: no depende de ningún módulo de dominio.
2. Sin interfaz de repositorio. Hay una sola implementación, y en los tests la sustitución la hace `moduleNameMapper` → `test-support/fakeDynamo.js` (D-23).
3. *(Propuesto)* Para compartirlo con `recaudacion`, se mueve a un paquete local `back/shared/eventos` referenciado con una dependencia `file:` desde ambos `package.json`. Cada desplegable lo empaqueta en su zip.

**Alternatives considered:**

| Opción | Por qué no (o todavía no) |
|---|---|
| Lambda Layer (como `tgr-sdk-layer`) | Versionado y orden de despliegue fuera del repo. TD-014 muestra el costo: dependencias implícitas que no se pueden testear sin mocks virtuales |
| Exponer EventosRecaudacion como API o Lambda | Convierte llamadas en proceso en llamadas de red (`C_coordination`). Ya hay un antecedente costoso: I1 cruza 3 Lambdas para borrar y recrear |
| Copiar el módulo en ambos desplegables | Dos owners de hecho: el esquema volvería a divergir |
| Fusionar los dos desplegables | Cambio de infraestructura y de API Gateway sin un driver que lo justifique |
| Interfaz `IEventosRepository` + implementación DynamoDB | Una sola implementación, sin variabilidad (§9, abstracción innecesaria) |

**Consequences:**
- En el slice, `postM2` dejó de nombrar la tabla.
- Los escritores siguen siendo 5: `postM2` se reemplazó por `eventos/`, y faltan `recaudacion/aws/dynamoDbServices` (RECIBIDA), `cuadratura`, `estadoOP` y `deleteRegistrosEventos`.
- 12 archivos legados siguen nombrando la tabla (TD-016, con ratchet). La meta del E2 (1 escritor) depende de la opción 3 y de migrar Conciliacion (ADR-004).

**Trade-offs:**
- La opción `file:` agrega un paso de empaquetado que hoy no existe.
- `npm install --production` debe copiar el paquete y no solo enlazarlo (symlink). Si Serverless no lo incluye en el zip, la Lambda falla al cargar, y eso se detecta en el deploy, no en los tests. Por eso queda como **Propuesto** hasta el spike.

**Evidence / fitness function:**
- **FF-3** (Semgrep `ff3-tabla-eventos-fuera-del-owner`): 0 en el código intervenido. En el legado, de 22 hallazgos en 14 archivos a 18 en 12, con ratchet TD-016.
- **FF-4** `ff4-eventos-es-hoja`.
- Tests con el fake: `fakeDynamoTest`, `postM2Test` y `suscriptorSnsReplicaGenericaTest`.
- **Spike pendiente para la opción 3:** `serverless package` en ambos desplegables e inspección del zip (`unzip -l .serverless/*.zip | grep shared/eventos`). No se pudo correr localmente: `serverless.yml` resuelve variables `${ssm:...}` que requieren credenciales de AWS de TGR.

**Affected modules:** EventosRecaudacion; ConfirmacionPago; en TO-BE completo: Solicitud (`postSolicitud`, `getSolicitud(es)`, `validaciones`) y Conciliacion (`cuadratura`, `estadoOP`, `envioOp`, `getDataOP`, `obtenerDetalle`), y también `callback`, `publishSnsEventos` y `deleteRegistrosEventos`.

**Date:** 2026-10-08 (E2/E3). Actualizado el 2026-10-09 (E6: opción de distribución).
