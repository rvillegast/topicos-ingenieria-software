# ADR-004: El stream de `eventos` como canal del evento `PagoConfirmado v1`

**Status:** Propuesto. No implementado. Su alcance está fuera del slice del E3.

**Context:**
- Hoy 3 Lambdas consumen el DynamoDB Stream de `eventos`: `publishSnsEventos` (avisos SNS a la institución y réplica al girador), `envioGCP` y `envioOP-OLD` (TD-022).
- Las 3 interpretan la imagen DynamoDB cruda (`NewImage` con tipos `S`, `N`, `M`). `publishSnsEventos` además navega el `payload` M2 (ADR-003) y separa la clave compuesta para encontrar la `RECIBIDA` del trámite.
- `publishSnsEventos` concentra 4 puntos de publicación en una función de CC 28 (E1, EC-2).
- El acoplamiento es a nivel de **esquema físico**, aunque el canal ya es asíncrono.

**Architectural concern:**
- Interoperabilidad entre módulos sin dependencias directas: Notificacion y Conciliacion no deben depender de ConfirmacionPago.
- Modificabilidad ante un canal nuevo de notificación (EC-2) y ante la separación de reporting (EC-4).

**Decision:**
- Mantener el stream de `eventos` como canal (Observer/Pub-Sub sobre infraestructura existente), pero con un **contrato** en lugar del registro crudo.
- EventosRecaudacion publica una función de proyección: `aPagoConfirmadoV1(imagenStream) → PagoConfirmado v1`, igual a `confirmacion` v1 + `institucionEnvironment` + `idRecibida` (E2 §3.3).
- Los consumidores solo usan esa proyección.
- Notificacion: un canal = una función.
- Conciliacion: mantiene su propia proyección de estados (`estado_cuad`, `estado_op`) en lugar de escribir sobre el registro transaccional (E2 §5).

**Alternatives considered:**

| Opción | Problema |
|---|---|
| ConfirmacionPago publica directamente en SNS o EventBridge después de `registrar()` | Escritura doble sin transacción: si la publicación falla después de persistir, el evento se pierde. Exigiría un *outbox*, que es el stream mismo |
| EventBridge alimentado por el stream (Pipes) | Más filtrado y enrutamiento, pero agrega infraestructura y costo sin un consumidor que lo necesite hoy. Se puede agregar sobre esta decisión sin cambiar el contrato |
| Que los consumidores sigan leyendo el registro crudo | Mantiene el acoplamiento al esquema: cada cambio de EC-3 o EC-4 toca 3 Lambdas |
| Llamadas síncronas de ConfirmacionPago a Notificacion | Acopla la latencia y la disponibilidad del registro de pago a los canales de aviso |

**Consequences:**
- Un canal nuevo de notificación es una función nueva que consume `PagoConfirmado v1`, sin tocar ConfirmacionPago.
- Los consumidores deben ser **idempotentes**: el stream entrega *at-least-once*, y la réplica on-prem borra y recrea registros (`REMOVE` + `INSERT`).
- El stream guarda los cambios 24 h: si un consumidor falla más tiempo, pierde eventos. Se necesita un *on-failure destination* por consumidor.

**Trade-offs:** Consistencia eventual entre el registro del pago y los avisos (ya ocurre hoy). Se acepta a cambio de desacoplar módulos sin agregar infraestructura. El contrato versionado agrega una proyección que mantener.

**Evidence / fitness function:**
- **Comportamiento actual:** `publishSnsEventosTest` (E5, 4 casos: unitario; carrito INSERT; carrito MODIFY/`PAGO_CUADRADO`; sin `RECIBIDA`). Es la red de seguridad para migrar.
- **FF-2** sobre `publishSnsEventos` (ratchet TD-015: 7 hallazgos): al migrar debe llegar a 0.
- **FF propuesta FF-8:** los handlers de stream solo importan la proyección de `eventos`, no `aws-sdk` ni el `payload` (dependency-cruiser + Semgrep). Se activa al implementar.

**Affected modules:** EventosRecaudacion (proyección); Notificacion (`publishSnsEventos`); Conciliacion (`envioGCP`, `envioOP-OLD`, `cuadratura`, `estadoOP`).

**Date:** 2026-10-09.
