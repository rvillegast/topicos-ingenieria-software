# ADR-003: Expand/contract del registro `PAGO_CONFIRMADO` (`payload` M2 → `confirmacion` v1)

**Status:** Aceptado.
- Fase **expand**: implementada (E3).
- Fase **migrate**: pendiente.
- Fase **contract**: bloqueada hasta que FF-2 llegue a 0.

**Context:**
- Cada `PAGO_CONFIRMADO` persiste el M2 completo del proveedor en `payload`.
- 7 consumidores de lectura (`getSolicitud`, `getSolicitudes`, `cuadratura`, `getDataOP`, `publishSnsEventos`, `estadoCuadratura`, `reenvioM2Tierra`) navegan esa estructura. Dos de ellos exponen el formato en la API pública de consulta.
- Con la ACL de ADR-001 la **entrada** queda aislada, pero el formato sigue filtrándose por lo **persistido**.
- No se pueden migrar todos los lectores y los datos históricos en un solo paso: hay registros de años anteriores, y el reenvío y la réplica on-prem reescriben registros.

**Architectural concern:** Interoperabilidad y evolución del esquema sin romper consumidores. EC-1 (cambio de proveedor).

**Decision:** Migrar en 3 fases.
1. **Expand (hecho):** cada `PAGO_CONFIRMADO` nuevo guarda `confirmacion` (DTO v1, E2 §3.1) **junto a** `payload`. El `payload` no cambia (C3 del E3).
2. **Migrate:** cada consumidor pasa a leer `confirmacion`, con *fallback* a `payload` mientras existan registros antiguos. Orden: `getSolicitud` y `getSolicitudes` primero, porque exponen el formato hacia afuera; después Conciliacion y Notificacion (ADR-004).
3. **Contract:** cuando FF-2 tenga 0 hallazgos fuera del adaptador, se rellena `confirmacion` en los registros históricos (backfill con `desdeM2Json` sobre `payload`) y se deja de escribir `payload`.

**Versionado de `confirmacion`:** solo cambios aditivos en v1. Un cambio incompatible crea `version: 2`, y v1 se mantiene mientras haya lectores.

**Alternatives considered:**
- **Migración big-bang** (reescribir los 7 lectores y los datos de una vez): exige congelar el sistema y no deja vuelta atrás incremental.
- **Tabla nueva para confirmaciones:** duplica el ownership y obliga a escribir en dos almacenes sin transacción (ADR-002).
- **Normalizar `payload` en el lugar** (reemplazar el M2 por el DTO): rompe a los 7 lectores al mismo tiempo.
- **Dejar `payload` para siempre:** el formato del proveedor queda acoplado al esquema, y EC-1 nunca baja de 8 archivos.

**Consequences:**
- **(2026-10-09, validación E7)** Mientras no termine la fase *migrate*, **todo** `PAGO_CONFIRMADO` nuevo, de cualquier proveedor, debe conservar `payload`: `cuadratura`, `getDataOP` y `publishSnsEventos` lo recorren para todos los pagos de una solicitud. Lo exige la cláusula Q8 de `AGENTS.md`.
- Mientras dure la transición, los registros nuevos pesan más.
- Los lectores migrados necesitan el *fallback* hasta el backfill.
- El backfill depende de que `desdeM2Json` sea correcto para datos históricos, incluido el supuesto de zona horaria de TD-012.

**Trade-offs:** Un período de doble representación a cambio de migrar consumidor por consumidor, con vuelta atrás. Hay riesgo de que la fase contract nunca llegue. Lo mitiga el ratchet de FF-2, que impide sumar lectores del formato legado.

**Evidence / fitness function:**
- `postM2Test` caso 10: `confirmacion` v1 persistido con `payload` intacto.
- **FF-2** con ratchet (TD-015): 29 hallazgos en 7 archivos, que solo pueden bajar. Es la condición de entrada a la fase contract.
- Indicador EC-1 de `escenarios.sh`: 9 → 8 archivos. La meta del contract es 1.

**Affected modules:** ConfirmacionPago (escritura); EventosRecaudacion (esquema); Solicitud, Conciliacion y Notificacion (lectores).

**Date:** 2026-10-08 (decisión E2; expand implementado en el E3).
