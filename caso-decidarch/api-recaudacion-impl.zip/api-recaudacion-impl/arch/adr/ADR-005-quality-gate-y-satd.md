# ADR-005: Quality gate arquitectónico y política de SATD

**Status:** Aceptado. Implementado en el E4 y el E5. Falta crear el proyecto CodeBuild y la regla de aprobación en TGR.

**Context:**
- Las decisiones de ADR-001 a ADR-003 solo existían en documentos.
- El AS-IS muestra cómo se erosionan: el formato M2 se filtró a 9 archivos, la tabla `eventos` quedó sin owner y hay valores de ambiente en 23 archivos.
- Había 12 comentarios SATD sin gestión, uno de ellos obsoleto desde 2021.
- El propio refactor del E3, hecho con un agente de IA, dejó 5 comentarios que admitían defectos sin registrarlos. Además, en el E5 el agente reformuló un supuesto no validado como si fuera una decisión.
- No basta con revisiones manuales: la regla tiene que ejecutarse en cada cambio, sin importar quién (o qué) escribe el código.

**Architectural concern:** Conservar las decisiones arquitectónicas en el tiempo (§12) y gestionar la deuda sin ocultarla (§7). Restricciones para el agente de coding (§13).

**Decision:**
1. **Quality gate** `arch/fitness/quality-gate.sh`, obligatorio en cada pull request a `develop` (`buildspec-quality-gate.yml` + regla de aprobación de CodeCommit). Corre 7 fitness functions:

   | FF | Regla | Herramienta |
   |---|---|---|
   | FF-1 | Sin ciclos | dependency-cruiser 16.10.4 |
   | FF-2 | El formato M2 solo vive en el adaptador (ADR-001, ADR-003) | Semgrep 1.180.0 |
   | FF-3 | Solo `eventos/` nombra la tabla (ADR-002) | Semgrep |
   | FF-4 | Módulos por `index.js`, dirección handlers → dominio → `eventos`/`integraciones`, sin SDK en el dominio | dependency-cruiser |
   | FF-5 | Sin región, rutas SSM, hosts ni ambientes en el código | Semgrep |
   | FF-6 | Toda SATD referencia un `TD-xxx` (marcadores en inglés y en español, incluidos tests) | Semgrep |
   | FF-7 | Tests de ambos desplegables; `src/` con ≥ 90 % de líneas y ≥ 75 % de ramas | Jest |

2. **Dos niveles:**
   - El **código intervenido** (`recaudacion-int/src/**`, `postM2`, suscriptor, `__tests__/`) debe tener 0 hallazgos.
   - El **legado** se controla con un *ratchet* por (regla, archivo) en `deuda-conocida.tsv`. Cada fila referencia un TD. Las filas solo pueden bajar: si un archivo mejora, el gate falla hasta actualizar la fila.
3. **Política de SATD:**
   - Cada comentario de deuda se **resuelve**, se **elimina con evidencia** (un test, la historia de git o el error real) o se **acepta** con la cadena SATD → Issue (TD) → Owner → Rationale → DueDate → Verification en `arch/debt-ledger.md`.
   - Borrar un comentario sin evidencia está prohibido.
4. **Validación de las propias reglas:** `mutacion-ff.sh` inyecta una violación por regla. Cada FF nueva entra con su caso de mutación.
5. **Cambiar una regla, un umbral o `deuda-conocida.tsv` hacia arriba** requiere actualizar este ADR. Agregar deuda al legado no es un cambio rutinario.

**Alternatives considered:**

| Opción | Por qué no |
|---|---|
| Aplicar todas las reglas a todo el repo desde el día 1 | 43 combinaciones en falta: el gate quedaría siempre en rojo y se terminaría ignorando |
| Aplicarlas solo al código nuevo (diff) | Permite que la deuda legada crezca dentro de los archivos existentes |
| SonarQube | Requiere un servidor y sus reglas genéricas no expresan los límites de este diseño (M2, owner de `eventos`) |
| CodeQL | Análisis más pesado; no agrega reglas que no cubran dependency-cruiser y Semgrep |
| Meta «0 `TODO`» | El caso lo descarta explícitamente: borrar comentarios oculta deuda. En el E5, un `TODO` que parecía resuelto (TD-021) no lo estaba |

**Consequences:**
- Las violaciones nuevas bloquean el merge, también las que introduce un agente de IA.
- Pagar deuda obliga a actualizar el *ratchet*: es fricción deliberada, para que la mejora quede registrada.
- El gate depende de Semgrep (Python) en CI.

**Trade-offs:**
- Las reglas Semgrep son heurísticas sobre el AST. Accesos dinámicos (`obj[campo]`) o nombres de tabla pasados por variable no se detectan (E4 §7).
- El *ratchet* cuenta por archivo, no por línea: un cambio que elimina un hallazgo y agrega otro en el mismo archivo pasa.
- Owners y fechas de la deuda aceptada son propuestas hasta que TGR las confirme.

**Evidence / fitness function:**
- `arch/baseline/07-e5-satd/quality-gate.log`: ✔ con exit 0. Tests 17/17 y 33/33.
- `mutacion-ff.sh`: 15/15 casos con el resultado esperado. La mutación encontró un error de configuración del propio gate (`exclude` de `node_modules`).
- Unmanaged SATD: 12 → 0.
- `arch/E4-fitness-functions.md` y `arch/E5-gestion-satd.md`.

**Affected modules:** Todos. Archivos `arch/fitness/*`, `arch/debt-ledger.md`, `back/*/jest.config.js`.

**Date:** 2026-10-09.
