# ADRs — api-recaudacion-impl (E6)

Plantilla: anexo C del caso. Las decisiones vienen del E2 §8 y se revisaron contra lo implementado en el E3 a E5.

| ADR | Decisión | Status | Fitness function | Deuda relacionada | Tests / evidencia |
|---|---|---|---|---|---|
| [ADR-001](ADR-001-confirmacion-pago-y-acl-m2.md) | ConfirmacionPago + ACL M2 (JSON y XML) | Aceptado, implementado | FF-2, FF-4 | TD-009 a TD-011 (resueltas); TD-012, TD-013, TD-024, TD-025; TD-026 (resuelta) | `postM2Test` (14), `suscriptorSnsReplicaGenericaTest` (5) |
| [ADR-002](ADR-002-eventos-owner-unico.md) | EventosRecaudacion como owner único de `eventos` | Aceptado (owner) / Propuesto (compartirlo con `recaudacion`) | FF-3, FF-4 | TD-014, TD-016, TD-020 | `fakeDynamoTest`, `postM2Test` |
| [ADR-003](ADR-003-expand-contract-pago-confirmado.md) | Expand/contract `payload` → `confirmacion` v1 | Aceptado; expand hecho | FF-2 (condición de contract) | TD-015 | `postM2Test` caso 10 |
| [ADR-004](ADR-004-stream-eventos-pago-confirmado.md) | Stream de `eventos` como canal de `PagoConfirmado v1` | Propuesto | FF-8 (propuesta), FF-2 | TD-015, TD-022 | `publishSnsEventosTest` (4) |
| [ADR-005](ADR-005-quality-gate-y-satd.md) | Quality gate y política de SATD | Aceptado, implementado | FF-1 a FF-7 | TD-017, TD-018 (resuelta), TD-019 a TD-025 | `quality-gate.log`, `mutacion-ff.sh` (15/15) |

**Regla de mantenimiento** (anexo D del caso, «Los ADRs afectados fueron actualizados»): un PR que cambia un módulo listado en «Affected modules» revisa su ADR. Un PR que cambia una regla de `arch/fitness/` o sube un máximo de `deuda-conocida.tsv` actualiza ADR-005. Un ADR aceptado o modificado que cambia módulos, secretos, contratos o dependencias se refleja en `AGENTS.md` §1 (contrato de intención, E7).
