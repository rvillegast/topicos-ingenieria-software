# ADR-001: Módulo ConfirmacionPago con Anti-Corruption Layer para el mensaje M2

**Status:** Aceptado. Implementado en el E3.

**Context:**
- El formato M2 del proveedor de pagos (`Message.MessageId`, `Message.Confirmacion.Pago`) aparecía en 9 archivos y 9 Lambdas (E1, EC-1). En esos archivos había 86 accesos a su estructura (FF-2 sobre el AS-IS).
- Llega en dos formatos reales: JSON por `POST /giradores/m2/createM2` y XML por la réplica on-prem (SNS).
- `postM2.js` mezclaba en una función de 326 LOC y CC 32 el parseo del M2, las reglas de registro (idempotencia, unitario/carrito/on-prem, abono a billetera), el acceso a la tabla `eventos` y las llamadas HTTP.

**Architectural concern:** Modificabilidad ante un cambio de proveedor o de formato (EC-1), interoperabilidad y testabilidad. Criterio de Parnas: ¿qué decisión volátil hay que ocultar? El formato del proveedor y las reglas de registro.

**Decision:**
- Crear `src/confirmacion-pago/` (ConfirmacionPago) en `recaudacion-int`. Su interfaz pública es `index.js`: `registrar()`, `desdeM2Json()` y `m2JsonDesdeXml()`.
- `adaptadores/m2.js` es la ACL y el **único** lugar que conoce la estructura M2, en JSON y en XML. Traduce al DTO neutral `Confirmacion` v1 (E2 §3.1).
- Las reglas de registro (invariantes I1–I6) viven en `index.js`, con un despacho por función con 3 casos. Las Lambdas `postM2` y `suscriptorSnsReplicaGenerica` quedan como handlers delgados.

**Alternatives considered:**
- **Estructura por capas** (`controllers/services/repositories`): el M2 seguiría cruzando todas las capas, así que EC-1 no mejora.
- **Strategy por tipo de registro** (unitario, carrito, on-prem): son 3 casos estables decididos por datos. Una jerarquía agrega complejidad accidental sin variabilidad nueva (E2 §6).
- **Microservicio de confirmación:** comparte tabla, equipo y despliegue. Solo agregaría `C_coordination`.
- **Adaptar solo el JSON:** el XML de la réplica seguiría con su propio parseo. El E2 eligió ACL porque hay **dos** formatos reales.

**Consequences:**
- Un cambio de formato de **entrada** se hace en un solo archivo (`adaptadores/m2.js`).
- `postM2` pasa de 326 LOC con CC 32 a 18 LOC. Las funciones CC > 10 bajan de 17 a 16.
- Se corrigieron TD-010 (abono rechazado en unitario) y TD-011 (errores silenciosos en el suscriptor).
- Los 7 consumidores de **lectura** siguen leyendo el M2 legado (`payload`): su migración es ADR-003. Hasta entonces, EC-1 está en 8 archivos, no en 1.
- **(2026-10-09, validación E7)** La ACL aislaba el **formato** M2, pero no la **política**: la idempotencia (I1) y las 3 ramas de `registrar()` leían el `payload` M2 persistido (TD-026). **Cerrado el mismo día:** I1 compara contra `confirmacion.idTransaccion` (con *fallback* a `payload` para registros anteriores al expand) y `payload` se construye solo si hay `legado` (tests 13 y 14, mutación 2/2).

**Diferencias con el contrato del E2**, aceptadas en el E3 para no cambiar contratos externos:

| E2 §3.1 | Implementado | Motivo |
|---|---|---|
| `registrar(Confirmacion) → {resultado, ids}` | `registrar({confirmacion, legado}) → 'REGISTRADA' \| 'REENVIO'` | `legado` es necesario para seguir persistiendo `payload` (ADR-003) |
| Error tipado `AbonoRechazado` | Lanza `{statusCode: 400, body: 'NOK'}` | Es el contrato que el proveedor ya recibía en carrito (D-25) |
| `desdeM2Xml(xml) → Confirmacion` | `m2JsonDesdeXml(xml) → M2 JSON` | El suscriptor todavía invoca `createM2` y `deleteRegistrosEventos` (D-27) |
| I1 con `reemplazar()` en EventosRecaudacion | Se mantiene la invocación a la Lambda `deleteRegistrosEventos` | Cambiar esa topología requiere validación operacional (D-27) |

**Trade-offs:**
- Durante la transición conviven `payload` y `confirmacion` en el mismo registro (más almacenamiento y dos formas de leerlo).
- Se preservaron comportamientos raros para no mezclar refactor con corrección: TD-012, TD-013, TD-024 y TD-025.
- Que el suscriptor relance errores (TD-011) exige confirmar que DSS es idempotente y configurar una DLQ.

**Evidence / fitness function:**
- **FF-2** (Semgrep `ff2-m2-fuera-del-adaptador`): el código intervenido tiene 0 hallazgos; el legado pasó de 86 hallazgos en 9 archivos a 29 en 7, con ratchet TD-015.
- **FF-4:** `confirmacion-pago` no usa `aws-sdk`, `axios`, `aws4`, `utils/` ni `aws/`, y se importa solo por `index.js`.
- `postM2Test`: 12 casos de caracterización. `suscriptorSnsReplicaGenericaTest`: 5 casos.
- Mutación manual 6/6 (E3).
- `arch/E3-refactoring.md` §5.

**Affected modules:** ConfirmacionPago; Lambdas `postM2` y `suscriptorSnsReplicaGenerica`; EventosRecaudacion e Institucion (dependencias de salida); `integraciones/billetera`.

**Date:** 2026-10-08 (decisión E2, implementación E3). Actualizado el 2026-10-09 (E4: billetera en `integraciones/`).
