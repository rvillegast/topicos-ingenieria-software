# E8 — Informe de evidencia AS-IS / TO-BE

> Caso DecidArch §17.8 y §19. Proyecto: `api-recaudacion-impl` (TGR), slice intervenido: **confirmación de pago (M2)**.
> AS-IS: commit `66a2873` (baselines `01-as-is-original` y `04-diagnostico-e1`; los escenarios se midieron sobre un worktree de `66a2873`).
> TO-BE: árbol actual sin commitear (baseline `08-e8-final`, gate en `08-e8-final/quality-gate.log`).
> **Actualización posterior al baseline 08 (2026-10-09):** validación de `AGENTS.md` con un agente independiente y cierre de TD-026 (`arch/E7/`). Ahora `recaudacion-int` tiene **35/35** tests y `src/` **97,74 %** de líneas y **82,89 %** de ramas (`arch/E7/quality-gate-td026.log`). El resto de las cifras de la matriz no cambia.
> Todas las cifras salen de `arch/scripts/baseline.sh`, `arch/fitness/quality-gate.sh` o Semgrep sobre los dos árboles (§7).

## 1. Matriz del caso

| Indicador | AS-IS | Meta TO-BE | TO-BE medido | Estado | Evidencia |
|---|---|---|---|---|---|
| **SATD no gestionada** | 12 comentarios (5 prod, 7 test); el E3 agregó 5 implícitas | 0 | **0**. Quedan 3 `TODO` en prod, todos gestionados como TD-019 | ✔ | FF-6; `08/satd.tsv`; E5 |
| **Ciclos entre módulos** | 0 entre archivos; 1 entre carpetas (`obligaciones` ↔ `obligaciones/dss`, dentro del mismo módulo) | 0 | **0** | ✔ | FF-1 (dependency-cruiser, 110 módulos, 188 dependencias) |
| **Dependencias prohibidas** | Sin reglas. El handler del slice (`postM2`) usaba directamente DynamoDB, `axios`, `aws4` y `utils/` | 0 | **0** violaciones de las 5 reglas FF-4. Fuera de `src/` no hay reglas de módulo: el legado está bajo ratchet | ✔ | FF-4; mutación 3/3 |
| **Hard-coded críticos** | 27 (18 región, 7 ruta SSM, 1 IP, 1 URL); FF-5: 26 en 23 archivos | 0 o justificados | **0 en el código intervenido**; legado 24 (FF-5: 23 en 21 archivos), justificados por TD-017 con ratchet | ✔ (justificados) | FF-5; `deuda-conocida.tsv` |
| **Datos sin owner** | 1: `eventos`, con 5 escritores y 14 archivos que la nombran | 0 | **0 sin owner declarado** (ADR-002). Pero siguen 5 escritores y 12 archivos que la nombran fuera del owner (TD-016, ratchet) | ◐ parcial | FF-3; `08/tablas.tsv` |
| **Complejidad extrema** | 17 funciones con CC > 10 (máximo 40); 36 con anidamiento > 4; 46 de más de 50 líneas; `postM2` CC 32 | ↓ | **16 / 26 / 45**; `postM2` sin alertas. El máximo sigue en 40 (`descargos.js`, fuera del slice) | ✔ (en el slice) | `08/complejidad.json` |
| **Duplicación relevante** | 22,71 % | ↓ | **22,49 %** | ◐ marginal | `08/jscpd` |
| **Cobertura crítica** | `postM2` 4,9 % de líneas y 0 % de ramas (tests en skip); suscriptor y `publishSnsEventos` sin tests. `recaudacion` 0/14 tests; `recaudacion-int` no ejecutable (Java) | ↑ | **Código intervenido (`src/`): 97,69 % líneas, 81,43 % ramas**; `postM2` 100/100; `publishSnsEventos` 64,9/73,9. `recaudacion-int` 40,69 % (33/33); `recaudacion` 14,83 % (17/17) | ✔ | FF-7; `08/coverage-*` |
| **Cambio de proveedor afecta** | **9 archivos, 9/30 Lambdas, 2 subproyectos** (86 accesos a la estructura M2) | Acotado | **Cambio del formato M2 en la entrada: 1 módulo** (`adaptadores/m2.js`; 2 parsers → 1). **Total EC-1: 8 archivos**: 7 lectores del `payload` legado (29 accesos), con ratchet TD-015. **Proveedor con otro formato:** `registrar()` ya lo soporta (TD-026 cerrado, tests 13 y 14), pero los 3 lectores que recorren todos los pagos exigen ADR-003 *migrate* (detectado por el agente independiente, E7 §6) | ◐ parcial | FF-2; `escenarios.json` |
| **ADRs** | 0 | ≥ 5 | **5** (3 aceptados e implementados; ADR-002 aceptado en el owner y propuesto en la distribución; ADR-004 propuesto) | ✔ | `arch/adr/` |
| **Fitness functions** | 0 | ≥ 3 | **7** automatizadas en un gate reproducible + 15/15 casos de mutación de las propias reglas | ✔ | `arch/fitness/`; E4 |

**Lectura:** el slice cumple en los 11 indicadores. Los parciales (◐) se deben a que la intervención se acotó a un slice, como pide el caso (§16.3), y no a una falla del diseño. Cada parcial tiene deuda registrada que no puede crecer (ratchet) y un ADR que define cómo cerrarla (§5).

## 2. Métricas específicas del stack (Node.js / Serverless / DynamoDB)

| Métrica | AS-IS | TO-BE | Fuente |
|---|---|---|---|
| Tests que pasan (`recaudacion` / `recaudacion-int`) | 0/14 / no ejecutable (requería DynamoDB Local con Java; 11 en `skip`) | **17/17 / 33/33** | `tests-*.json` |
| Lambdas afectadas por EC-1 | 9/30 | 9/30. Las 2 de entrada ahora pasan por la ACL: un cambio de formato de entrada toca 1 archivo | `escenarios.json` |
| Accesos a la estructura M2 fuera del adaptador | 86 en 9 archivos | 29 en 7 | Semgrep FF-2 sobre `66a2873` y sobre el árbol actual |
| Archivos que nombran la tabla `eventos` fuera del owner | 14 (22 accesos) | 12 (18) | Semgrep FF-3 |
| Escritores de `eventos` | 5 | 5 (`postM2` → owner `eventos/`) | `tablas.tsv` |
| `postM2.js` | 326 LOC, CC 32, 10 alertas de anidamiento | 18 LOC, sin alertas | `complejidad.json` |
| Suscriptor de réplica XML | 180 LOC, sin tests, errores silenciosos (TD-011) | 77 LOC, 5 tests, relanza | E3 |
| Defectos corregidos con test | — | TD-010 (abono rechazado), TD-011 (errores silenciosos) | `postM2Test` 8; suscriptor TD-011 |
| Mutación manual de la red de tests | — | 4/4 (AS-IS), 6/6 (TO-BE), 2/2 (`publishSnsEventos`) | E3 §2, E5 §3.1 |
| Mutación de las fitness functions | — | 15/15 | `mutacion-ff.sh` |
| Debt ledger | 0 entradas | 26 TD: 8 resueltos (TD-001, 002, 009, 010, 011, 018, 023, 026), 18 abiertos; los que tocan el código intervenido tienen owner, fecha y verificación | `debt-ledger.md` |
| Valores de ambiente en el slice | Región fija en el suscriptor, ruta SSM de billetera en código | 0 (`AWS_REGION`, `SSM_WALLET_PATH`) | FF-5 |
| Dependencias implícitas del runtime | `@aws-sdk/*`, `tgr-sdk-layer` sin declarar | Iguales, registradas (TD-014) | — |

## 3. Escenarios de cambio comparados (E1 vs. final)

| Escenario | AS-IS (archivos / Lambdas) | TO-BE (archivos / Lambdas) | Qué cambió | Qué falta |
|---|---|---|---|---|
| **EC-1** Cambio de proveedor o formato M2 | 9 / 9 | 8 / 9 | La entrada (`postM2`, suscriptor) pasa por la ACL: un formato nuevo es 1 adaptador + 1 handler (E7 §5) | 7 lectores del `payload` (ADR-003, fase migrate) |
| **EC-2** Nuevo canal de notificación | 2 / 6 | 2 / 6 | Contrato `PagoConfirmado v1` definido (ADR-004); `publishSnsEventos` caracterizado (4 tests) | Implementar la proyección y un canal = una función |
| **EC-3** Cambio del modelo de Institución | 14 / 13 | 16 / 14 (proxy) | En el slice, `institucion#environment` se construye en 1 lugar (`eventos/`), no en 2 | El proxy cuenta nombres de campo: los módulos nuevos *nombran* `codigoInstitucionOnPrem`. El legado (`util.js`, token TD-005) sigue disperso |
| **EC-4** Separar reporting | 7 / 7 | 7 / 7 | Ownership declarado: Conciliacion tendrá su propia proyección (ADR-004, E2 §5) | Fuera del slice |

**Regla de evidencia del §19** («una sustitución de proveedor dejó de modificar N componentes y ahora se concentra en un adapter, con una regla automática que impide filtrar tipos externos»):
- Para la **entrada**, el formato M2 pasó de 2 parsers con 86 accesos repartidos a 1 adaptador, protegido por FF-2. La mutación «`l.Message.MessageId` en `confirmacion-pago`» bloquea el gate.
- Para la **lectura persistida**, todavía no: son 7 archivos, y el ratchet impide que sean más.
- Para un **proveedor con otro formato**: la validación con un agente independiente (E7 §6) descubrió que la idempotencia y las reglas de registro leían el `payload` M2 (TD-026). Eso ya está cerrado: `registrar()` funciona sin M2, verificado con test y mutación 2/2. Lo que falta son los lectores legados, bloqueados por la cláusula Q8 de `AGENTS.md`.
- Ese es el resultado honesto del slice, el mismo que el E2 §7 había comprometido.

## 4. Triangulación (§19): modelo + código + evidencia automática

| Afirmación | 1. Problema observado | 2. Decisión | 3. Artefacto que cambió | 4. Prueba o regla que lo demuestra | 5. Escenario que mejoró |
|---|---|---|---|---|---|
| El formato del proveedor quedó detrás de una frontera | M2 en 9 archivos; `postM2` CC 32 mezclaba formato, reglas, tabla y HTTP | ADR-001: ConfirmacionPago + ACL | `src/confirmacion-pago/`, `postM2.js` (18 LOC), suscriptor | FF-2 (0 en código intervenido), `postM2Test` (12), mutación 6/6 | EC-1 (entrada) |
| La tabla `eventos` tiene owner | 5 escritores, claves compuestas repetidas | ADR-002 | `src/eventos/` | FF-3, FF-4 `eventos-es-hoja`, `fakeDynamoTest` | EC-3, EC-4 (en el slice) |
| El esquema evoluciona sin romper lectores | `payload` M2 leído por 7 consumidores | ADR-003: expand/contract | Atributo `confirmacion` v1 | `postM2Test` caso 10; ratchet FF-2 (TD-015) | EC-1 (habilita el contract) |
| Se preservó el comportamiento | Tests en skip o rotos (0/14 y no ejecutable) | Caracterizar antes de extraer (D-24) | `test-support/fakeDynamo.js`; 4 suites nuevas, 1 reescrita, 4 reactivadas y 4 reparadas | 17/17 y 33/33 en cada paso; mutación 4/4 y 6/6 | Todos |
| La deuda está gestionada, no oculta | 12 SATD sin gestionar + 5 introducidas por el agente | ADR-005: cadena SATD → TD → owner → fecha → verificación | `debt-ledger.md`, 2 `TODO` eliminados con test, 3 con TD | FF-6 ampliada; 15/15 de mutación de las FF | — |
| Las decisiones no se erosionan | Reglas que solo existían en documentos | ADR-005: gate en 2 niveles + ratchet | `arch/fitness/`, `buildspec-quality-gate.yml` | Gate exit 0; mutaciones bloquean | Todos |
| Un agente puede extender el sistema sin romper fronteras | La erosión vino de prompts locales «que funcione» | E7: `AGENTS.md` + TASK INTENT | `AGENTS.md`, `CLAUDE.md` | Cada cláusula ligada a una FF | EC-1 (ejemplo PasarelaX) |

## 5. Lo que no se logró (y cómo queda controlado)

| Brecha | Por qué | Control vigente | Cierre previsto |
|---|---|---|---|
| EC-1 no llega a «1 módulo» (8 archivos) | 7 lectores del `payload` fuera del slice | FF-2 con ratchet (TD-015) | ADR-003, fase migrate y contract |
| `eventos` sigue con 5 escritores | `recaudacion` es otro desplegable; Conciliacion fuera del slice | FF-3 con ratchet (TD-016) | ADR-002, opción `file:` (spike pendiente) + ADR-004 |
| Duplicación casi sin cambios | La duplicación está en `obligaciones` y `postSolicitud`, fuera del slice | Medida en cada baseline | Siguiente slice |
| El buildspec del gate no corrió en CodeBuild | Push al repositorio de TGR deshabilitado | El mismo script corrió local con versiones fijadas | TGR crea el proyecto y la regla de aprobación |
| Owners y fechas de la deuda son propuestas | Las define TGR | Cadena completa en el ledger | Validación con TGR |
| Credenciales reales en el repo (TD-006, R-06) | Responsabilidad de TGR | Carpeta excluida de jest y del contrato del agente | TGR rota las credenciales y limpia el historial |
| Proveedor no-M2: `cuadratura`, `getDataOP` y `publishSnsEventos` fallan con registros sin `payload` | Lectores legados (TD-015); `registrar()` ya no lo impide desde el cierre de TD-026, así que la protección pasó de un `TypeError` a la cláusula Q8 | Cláusula Q8 de `AGENTS.md` (validada: el agente se detuvo) | ADR-003 *migrate* + test que siembre un registro sin `payload` en esos lectores |
| Cobertura del `.mjs` del suscriptor no se mide | `collectCoverageFrom` cubre `src/**/*.js` | 5 tests de caracterización + mutación | Agregar `*.mjs` al reporte de cobertura |
| ADR-004 sin implementar | Fuera del slice | `publishSnsEventosTest` como red de seguridad | Siguiente slice (EC-2 / EC-4) |

## 6. Autoevaluación contra la rúbrica (§18)

| Dimensión (peso) | Evidencia principal | Brecha |
|---|---|---|
| Diagnóstico fundamentado (10 %) | Baseline reproducible (7 corridas completas), SATD, dependencias, 4 escenarios medidos por script y por commit | — |
| Descomposición por Parnas (20 %) | Módulos definidos por secreto (E2 §1), no por capas; capas y microservicios descartados con argumentos | Institucion es delgado (1 función) |
| Cohesión, acoplamiento y complejidad (15 %) | `postM2` de CC 32 a handler de 18 LOC; FF-1 y FF-4 en 0; `C_internal` vs `C_coordination` (E2 §6) | Complejidad máxima fuera del slice sin cambios |
| Data ownership e interoperabilidad (15 %) | Owner único, DTO versionado, expand/contract, contrato `PagoConfirmado v1` | 5 escritores todavía; ADR-004 propuesto |
| SATD y calidad de código (10 %) | UnmanagedSATD = 0, cadena completa, eliminación solo con evidencia, SATD del propio agente detectada | Duplicación marginal |
| Refactoring y pruebas (15 %) | Caracterización antes de extraer, mutación, cambios intencionales C1–C4 con test | Sin tests de contrato contra proveedores reales (R-05) |
| Fitness functions / quality gates (10 %) | 7 FF, ratchet, mutación de reglas 15/15 | CI no ejecutado en CodeBuild |
| ADRs y Vibe Architecting (5 %) | 5 ADR con status honesto y trazabilidad; `AGENTS.md` con cláusulas tomadas de errores reales; **validado con un agente independiente**, que se detuvo ante una tarea contradictoria | La TASK INTENT de ejemplo era contradictoria (corregida con la cláusula Q8) |

## 7. Respuestas breves a las preguntas de defensa (§20)

1. **Secreto de cada módulo.**
   - ConfirmacionPago: el formato del proveedor y las reglas de registro.
   - EventosRecaudacion: el esquema físico de `eventos`.
   - Institucion: cómo se resuelve el concepto, con su regla `GENERICO_<inst>`.
   - Cada adaptador de `integraciones/`: endpoint, firma y rutas SSM.

   (`AGENTS.md` §1.)
2. **Qué módulo eliminaría al simplificar.** El E2 §6 propone fusionar EventosRecaudacion con Solicitud. Se mantiene separado porque concentra EC-3 y EC-4 y lo usan dos módulos. Institucion (15 LOC) es el más delgado y se mantiene por EC-3.
3. **Dependencias que siguen siendo riesgosas:**
   - Los 7 lectores del `payload` M2 (TD-015).
   - `recaudacion` escribiendo `eventos` directamente (TD-016).
   - El suscriptor invocando la Lambda `deleteRegistrosEventos`, más los reintentos sobre DSS sin idempotencia confirmada (TD-011, D-27).
   - El `tgr-sdk-layer` implícito (TD-014).
4. **Deuda aceptada conscientemente:**
   - TD-019: la rama MOP, que depende de DGA.
   - TD-013: el carrito parcial sin contrato de reversa.
   - TD-024 y TD-025: reglas heredadas sin definición de negocio.
   - TD-015 a TD-017: el legado bajo ratchet.
5. **Dónde una interfaz no aporta nada.** `IEventosRepository`: hay una sola implementación, y el reemplazo en tests ya lo hace `moduleNameMapper` (ADR-002).
6. **Patrón rechazado.**
   - Strategy para unitario/carrito/on-prem: 3 casos estables decididos por datos (ADR-001).
   - Lambda Layer para compartir `eventos` (ADR-002).
7. **Cómo sabemos que se preservó el comportamiento.**
   - Tests de caracterización escritos antes de extraer, con la suite en verde en cada paso.
   - Mutación 4/4 sobre el AS-IS y 6/6 sobre el TO-BE.
   - Los únicos cambios observables (C1–C4) son intencionales y cada uno tiene su test.
8. **Fitness function que protege la decisión más importante.** FF-2, la frontera M2 de ADR-001. Bloquea cualquier acceso nuevo, en código intervenido o legado (ratchet), y la mutación lo demuestra.
9. **Si cambia el modelo de datos de Institución** (equivalente a Customer, EC-3):
   - En el slice, la clave `institucion#environment` está en 1 lugar y el concepto en Institucion.
   - En el legado tocaría unos 14 archivos (token en `util.js`, TD-005; `obligaciones`). Es el siguiente slice natural.
10. **Cómo impedir que un agente reintroduzca el problema.** Tres capas: `AGENTS.md` + TASK INTENT antes del código, el gate en el merge y la evidencia ejecutada en la revisión (E7 §7). Las cláusulas salen de los 6 errores reales del agente en este proyecto (E7 §3).

## 8. Reproducir

```bash
cd api-recaudacion-impl
(cd back/recaudacion && npm install) && (cd back/recaudacion-int && npm install)
arch/scripts/baseline.sh arch/baseline/<nombre>                 # matriz: RESUMEN.md + metrics.json + escenarios.json
git worktree add --detach /tmp/asis 66a2873                      # AS-IS
SRC_ROOT=/tmp/asis/back arch/scripts/escenarios.sh arch/baseline/04-diagnostico-e1
(cd /tmp/asis/back && semgrep scan --config ../../api-recaudacion-impl/arch/fitness/semgrep.yml --json .)   # FF-2/3/5 AS-IS
SEMGREP=semgrep arch/fitness/quality-gate.sh                     # TO-BE: gate
SEMGREP=semgrep arch/fitness/mutacion-ff.sh                      # las FF detectan violaciones
```

**Entregables:**

| Entregable | Archivo |
|---|---|
| E1 | `arch/E1-diagnostico-as-is.md` |
| E2 | `arch/E2-arquitectura-to-be.md` |
| E3 | `arch/E3-refactoring.md` |
| E4 | `arch/E4-fitness-functions.md` |
| E5 | `arch/E5-gestion-satd.md` |
| E6 | `arch/adr/` |
| E7 | `AGENTS.md` + `arch/E7-architectural-intent.md` |
| E8 | este documento |
| Ledger | `arch/debt-ledger.md` |
