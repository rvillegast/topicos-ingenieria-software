# E7 — Architectural Intent Prompt

> Caso DecidArch §13 y §17.7: «un contrato reusable que permita a otro agente de IA implementar una nueva capacidad sin romper las fronteras propuestas».
> Contrato operativo: **`AGENTS.md`**, en la raíz del repositorio. `CLAUDE.md` lo importa (`@AGENTS.md`), así que Claude Code lo carga en cada sesión. Otros agentes (Codex, Copilot y Cursor, entre otros) leen `AGENTS.md` por convención.

## 1. Diseño del contrato

El contrato tiene **dos niveles**, porque una parte cambia poco y otra cambia en cada tarea:

| Nivel | Dónde | Contenido | Cuándo cambia |
|---|---|---|---|
| Intención del sistema | `AGENTS.md` | Módulos con responsabilidad, secreto, datos, contrato y dependencias permitidas o prohibidas; restricciones Q1–Q8; forma de trabajar; prohibiciones; evidencia exigida | Al aceptar o cambiar un ADR |
| Intención de la tarea | Plantilla de §4, completada por quien pide el cambio (o por el agente, que la muestra antes de implementar) | Qué capacidad se agrega, en qué módulo, qué secreto nuevo aparece y qué evidencia se espera | En cada tarea |

Cada restricción del contrato está ligada a una verificación automática. Si el agente la ignora, el gate lo detecta, sin depender de que el agente «obedezca»:

| Campo del §13 | En `AGENTS.md` | Lo hace cumplir |
|---|---|---|
| Module / Responsibility / Secret | Tabla §1 | Revisión + ADR-001, ADR-002 |
| Owned data | Tabla §1 (owner único de `eventos`) | FF-3 |
| Allowed / Forbidden dependencies | Tabla §1 | FF-1, FF-4 (dependency-cruiser) |
| Public contract | Tabla §1 + Q8 | FF-4 (solo `index.js`) + tests de caracterización |
| Quality constraints | Q1–Q8 | FF-1 a FF-7 (`quality-gate.sh`) |
| Evidence | §5 del contrato | Informe obligatorio + gate + `mutacion-ff.sh` |

## 2. Intención por módulo en el formato del §13

Es lo mismo que la tabla de `AGENTS.md` §1, en el formato literal del caso, para el módulo central del slice:

```text
ARCHITECTURAL INTENT

Module:
  ConfirmacionPago (back/recaudacion-int/src/confirmacion-pago/)

Responsibility:
  Registrar de forma idempotente la confirmación de pago de una solicitud de recaudación.

Secret:
  Formato del mensaje de cada proveedor (hoy M2 JSON y M2 XML, en adaptadores/);
  detección de reenvío por idTransaccion; reglas unitario / carrito / on-prem; cuándo abonar a billetera.

Owned data:
  Registros PAGO_CONFIRMADO (persistidos solo a través de EventosRecaudacion).

Allowed dependencies:
  EventosRecaudacion (index.js), Institucion (index.js), integraciones/billetera, moment-timezone.

Forbidden dependencies:
  aws-sdk / @aws-sdk, axios, aws4, utils/, aws/, tabla eventos por nombre,
  Notificacion, Conciliacion, handlers de Lambda.

Public contract:
  registrar({confirmacion, legado?}) -> 'REGISTRADA' | 'REENVIO'   (lanza {statusCode:400, body:'NOK'} si billetera rechaza)
  desdeM2Json(m2) -> {confirmacion: Confirmacion v1, legado}
  m2JsonDesdeXml(xml, {idProcesoJsonDet, reenvio}) -> M2 JSON

Quality constraints:
  - no circular dependency                                  (FF-1)
  - provider fields must not leak outside its adapter       (FF-2)
  - only EventosRecaudacion names/keys the eventos table    (FF-3)
  - dependency direction handlers -> domain -> eventos/integraciones (FF-4)
  - provider configuration externalized                     (FF-5)
  - no unmanaged SATD                                       (FF-6)
  - behavior preserved by tests; src/ >= 90% lines, 75% branches (FF-7)
  - external contracts unchanged (createM2, SNS replica, PAGO_CONFIRMADO additive only)

Evidence:
  characterization tests (postM2Test, suscriptorSnsReplicaGenericaTest) + mutation of new tests
  + quality-gate.sh exit 0 + ADR-001/ADR-003 updated + debt-ledger entries for preserved oddities
```

EventosRecaudacion, Institucion e `integraciones/` siguen el mismo formato en la tabla de `AGENTS.md` §1. No se repiten aquí para no tener dos fuentes de verdad.

## 3. Lecciones de este proyecto incorporadas al contrato

El refactor E3–E6 se hizo con un agente de IA. Sus errores reales son la mejor evidencia de qué tiene que exigir el contrato:

| Error del agente en este proyecto | Dónde | Cláusula que lo impide |
|---|---|---|
| Afirmó «ninguna función supera 50 líneas» y era falso | E3 §3 (corregido) | §5.6: cada cifra sale de un comando ejecutado |
| Comentó «Caracterizado» en 2 sitios sin que hubiera un test | E3 → E5 (tests 11 y 12) | §5.6: «caracterizado» exige nombrar el test; FF-6 trata «caracterizado» como marcador de SATD |
| Reformuló un supuesto no validado (`DateTime` con `Z`) como «secreto del módulo», con lo que FF-6 ya no lo veía | E5 §3.5 | §4: prohibido reformular deuda para escapar de FF-6 |
| Configuró dependency-cruiser excluyendo `node_modules`, y la regla «sin SDK en el dominio» nunca podía fallar | E4 §4.2 | §3: todo test o regla nueva se valida rompiéndola a propósito |
| Interpretó mal una búsqueda y concluyó que ningún repo tenía commits de IA | Reporte R-01 | §5.6 |
| Un `TODO` parecía resuelto porque el test daba 400, pero el rechazo era incidental | E5 S-12, TD-021 | §4: borrar un comentario de deuda exige evidencia |

## 4. Plantilla de intención por tarea

Se copia en el pedido al agente. El agente la completa o la valida antes de escribir código.

```text
TASK INTENT

Capability:            <qué capacidad nueva, en una frase de negocio>
Change scenario:       <EC-1..EC-4 u otro; por qué esta capacidad cambia>
Target module:         <módulo de AGENTS.md §1 donde vive>
New secret (if any):   <qué decisión volátil nueva aparece y quién la oculta>
Data touched:          <datos; owner; ¿cambio aditivo?>
New dependencies:      <ninguna | cuáles y por qué>
Contracts affected:    <externos: ninguno | cuáles (requiere aprobación); internos: cuáles>
Behavior to preserve:  <tests de caracterización existentes que deben seguir en verde>
New tests:             <casos; y cómo se prueba que fallan si se rompe la regla>
New fitness rule:      <ninguna | regla + caso en mutacion-ff.sh>
ADRs to update:        <ADR-00x>
Debt:                  <TD nuevos o tocados>
Out of scope:          <lo que el agente NO debe tocar>
```

## 5. Ejemplo resuelto: EC-1, un segundo proveedor de pagos

Escenario EC-1 del E1: TGR incorpora un proveedor (`PasarelaX`) que confirma pagos con un webhook JSON propio (`{ payment: { id, orderRef, amount, paidAt, channel } }`).

```text
TASK INTENT

Capability:            Registrar confirmaciones de pago enviadas por PasarelaX.
Change scenario:       EC-1 (cambio / nuevo proveedor de pagos). Objetivo E2: impacto = 1 módulo.
Target module:         ConfirmacionPago.
New secret:            Formato y semántica del webhook de PasarelaX -> nuevo adaptador
                       confirmacion-pago/adaptadores/pasarelaX.js que produce Confirmacion v1
                       (origen: 'PASARELA_X'). registrar() NO cambia.
Data touched:          PAGO_CONFIRMADO vía EventosRecaudacion. Solo `confirmacion` v1 (sin `payload` M2:
                       los lectores legados no conocen PasarelaX; ver ADR-003). Cambio aditivo.
New dependencies:      ninguna.
Contracts affected:    Externo nuevo: POST /pasarelax/confirmaciones (handler nuevo, delgado).
                       Existentes: ninguno (createM2, réplica SNS intactos).
Behavior to preserve:  postM2Test (12), suscriptorSnsReplicaGenericaTest (5), publishSnsEventosTest (4).
New tests:             adaptador PasarelaX (montos, fechas a ISO UTC, idempotencia por id de pago);
                       registrar() con origen PASARELA_X; mutación: quitar la idempotencia -> falla.
New fitness rule:      FF-2b en semgrep.yml: los campos `orderRef`/`paidAt` del webhook solo dentro de
                       adaptadores/pasarelaX.js; caso nuevo en mutacion-ff.sh.
ADRs to update:        ADR-001 (tercer formato; el ACL ya lo previó), ADR-003 (registros sin payload).
Debt:                  ninguna nueva esperada; si registrar() necesita `legado`, registrar TD.
Out of scope:          migrar lectores legados (TD-015), Notificacion (ADR-004), infraestructura.
```

**Qué demostró el ejemplo:** se validó con un agente independiente (§6, `arch/E7/validacion-agente-independiente.md`), y la validación mostró que **esta TASK INTENT es contradictoria**. «`registrar()` NO cambia», «sin `payload`» y «cambio aditivo» no pueden cumplirse a la vez:
- La idempotencia (I1) y las 3 ramas de `registrar()` leen el `payload` M2 (TD-026).
- `cuadratura`, `getDataOP` y `publishSnsEventos` recorren el `payload` de todos los pagos.

Por eso, «1 adaptador + 1 handler» vale para un cambio **del formato M2**, no para un proveedor con otro formato. Este necesitaba primero cerrar TD-026 (**cerrado** el 2026-10-09: tests 13 y 14 de `postM2Test`) y todavía necesita la fase *migrate* de ADR-003. Se deja el ejemplo tal cual, como evidencia de lo que la validación detectó. La cláusula Q8 de `AGENTS.md` ahora lo dice explícitamente.

## 6. Cómo se valida que el contrato funciona

Checklist de PR del anexo D del caso, conectado con el contrato:

| Ítem del anexo D | Verificación |
|---|---|
| El comportamiento observable sigue pasando sus pruebas | FF-7 + informe §5.2 |
| La responsabilidad modificada está declarada | TASK INTENT (*Target module*, *Capability*) |
| El secreto del módulo no se filtra | FF-2 (+ regla nueva por proveedor) |
| No hay dependencias prohibidas | FF-1, FF-4 |
| Los datos modificados tienen owner claro | FF-3 + *Data touched* |
| No aparece SATD no gestionada | FF-6 |
| Configuración no hard-coded | FF-5 |
| No hay abstracción sin presión de cambio | AGENTS.md §3 + revisión |
| ADRs actualizados | *ADRs to update* + regla de mantenimiento en `arch/adr/README.md` |
| Fitness functions pasan en CI | `buildspec-quality-gate.yml` |
| El agente respetó el Architectural Intent | Informe §5.1: cumplimiento de Q1–Q8 con evidencia |

**Validación con un agente independiente (2026-10-09):** detalle en `arch/E7/validacion-agente-independiente.md`.
- El agente recibió solo el repositorio y la TASK INTENT del §5.
- **No escribió código:** detectó que la tarea violaba Q8 y ADR-003, se detuvo como exige §4 y pidió una decisión humana con 3 opciones. Cada afirmación vino respaldada por un comando.
- Resultado: el contrato evitó una implementación que habría pasado FF-1 a FF-6 y roto la conciliación en producción.
- La validación también encontró deuda nueva (TD-026, ya cerrada) y un hueco del gate: ningún test siembra `PAGO_CONFIRMADO` sin `payload` en los lectores legados.

## 7. Pregunta de defensa: ¿cómo impedir que un agente vuelva a introducir el problema original?

El problema original fue la erosión: el formato del proveedor llegó a 9 archivos, la tabla `eventos` quedó sin dueño, había valores de ambiente escritos en el código y deuda sin gestionar. Se ataca en tres capas, y ninguna depende de la buena voluntad del agente:

1. **Antes de escribir código.** `AGENTS.md` se carga solo y declara secreto, frontera, datos y prohibiciones. La TASK INTENT obliga a decidir dónde vive la capacidad antes de escribirla.
2. **Al integrar.** El quality gate bloquea el merge si el formato sale del adaptador, si alguien distinto del dueño nombra la tabla, si hay dependencias prohibidas, valores hard-coded o SATD sin TD, o si los tests y la cobertura caen. Para el legado, el *ratchet* impide empeorar.
3. **Al revisar.** El informe del agente debe traer evidencia ejecutada, y el checklist del anexo D se aplica en el PR. Cada regla nueva entra con su caso de mutación, para que el gate no dé falsos verdes.
