# E2 — Arquitectura TO-BE basada en Parnas: api-recaudacion-impl

> Caso DecidArch §17.2. Parte de `arch/E1-diagnostico-as-is.md` y del baseline `arch/baseline/04-diagnostico-e1/`.
> **Slice elegido para el E3:** confirmación de pago (M2). El documento define la arquitectura objetivo completa, pero detalla los contratos de los módulos del slice.

## 1. Criterio de descomposición

No se reorganiza por capas técnicas (`controllers/services/repositories`). En el AS-IS eso no habría evitado que el formato M2 aparezca en 9 archivos. Cada módulo se define por **la decisión volátil que oculta** (§3, pregunta de Parnas) y se valida contra los escenarios EC-1 a EC-4 del E1.

| Decisión volátil (evidencia E1) | Escenario | Módulo que la oculta |
|---|---|---|
| Formato del mensaje de confirmación del proveedor (M2 JSON y M2 XML de la réplica) | EC-1 | **ConfirmacionPago** (adaptadores M2) |
| Reglas de registro de un pago: idempotencia, unitario/carrito/on-prem, abono a billetera | EC-1 | **ConfirmacionPago** (política) |
| Esquema físico de `eventos`: claves compuestas `id#idTransaccion`, `institucion#environment`, índices, `payload` | EC-3, EC-4 | **EventosRecaudacion** |
| Cómo se identifica una institución y su ambiente (claim `aud`, código on-prem, concepto por formulario) | EC-3 | **Institucion** |
| Canales y formato de aviso a la institución (3 tópicos SNS, atributos, flags) | EC-2 | **Notificacion** |
| Estados de cuadratura y orden de pago y su almacenamiento | EC-4 | **Conciliacion** |
| Ingreso y consulta de solicitudes de recaudación | — | **Solicitud** |
| Cargos, descargos, liquidación de obligaciones | — | **Obligaciones** (sin cambios en esta etapa) |
| API, autenticación y errores de cada servicio externo (billetera, portal de autoservicios, ADF, CUT, DSS/Oracle, auditoría GCP) | EC-1, EC-3 | **Un adaptador por proveedor** en `integraciones/` |

## 2. Módulos propuestos

Los módulos son **carpetas con un `index.js` público** dentro de los desplegables existentes. No se crean servicios nuevos: las 30 Lambdas se mantienen como puntos de entrada delgados. Granularidad: ver §6.

| Módulo | Responsabilidad | Secreto (información oculta) | Interfaz pública | Datos que posee |
|---|---|---|---|---|
| **ConfirmacionPago** | Registrar la confirmación de un pago para una solicitud | Formato M2 (JSON/XML); regla de reenvío por `IdTransaccion`; casos unitario/carrito/on-prem; cuándo abonar billetera | `registrar(confirmacion)`, `desdeM2Json(body)`, `desdeM2Xml(xml)` | Registros `PAGO_CONFIRMADO` (vía EventosRecaudacion) |
| **EventosRecaudacion** | Único punto de lectura/escritura del ciclo de vida en `eventos` | Tabla, claves, índices, `payload` legado, consistencia | `registrarRecibida`, `registrarPagoConfirmado`, `buscarPorSolicitud`, `buscarPorInstitucion` | Tabla `eventos` (**owner único**) |
| **Institucion** | Resolver identidad, ambiente y conceptos de una institución | Parseo del token, portal de autoservicios, tabla `conceptos-instituciones` | `deToken(authHeader)`, `conceptoPorFormulario(form, inst)` | Ninguno (lee al owner externo vía API) |
| **Notificacion** | Avisar a la institución que un pago se confirmó | Tópicos SNS, atributos, flags (`Pagos700WL`), réplica girador | Consume el evento `PagoConfirmado v1` | Ninguno |
| **Conciliacion** | Cuadratura con IRAs, envío y estado de órdenes de pago, auditoría | Estados `estado_cuad`/`estado_op` y su almacén | `marcarCuadratura`, `marcarOrdenPago`, `consultarParaOP`; consume `PagoConfirmado v1` | **Proyección propia** de conciliación (TO-BE; hoy en `eventos`) |
| **Solicitud** | Ingreso, validación y consulta de solicitudes | Reglas de validación, prepararParametros, redirección, reglas especiales por institución (MOP) | Handlers `postSolicitud`, `getSolicitud(es)` | Registros `RECIBIDA` (vía EventosRecaudacion) |
| **Obligaciones** | Ciclo de vida de obligaciones | (sin cambios) | Handlers `obligaciones-*` | Tabla `obligaciones` |
| **integraciones/** `billetera`, `portalAutoservicios`, `adf`, `cut`, `dss`, `auditoriaGcp` | Hablar con un proveedor externo | Endpoint, firma (aws4/OAuth), rutas SSM, mapeo de errores | Una función por operación, con tipos propios del dominio | Ninguno |

## 3. Contratos (Module Contract, anexo A) — módulos del slice

### 3.1 ConfirmacionPago

| Campo | Contenido |
|---|---|
| Module | `ConfirmacionPago` (`back/recaudacion-int/src/confirmacion-pago/`) |
| Responsibility | Registrar de forma idempotente la confirmación de pago de una solicitud de recaudación |
| Information secret | Estructura de M2 (`Message.MessageId`, `Confirmacion.Pago`) en JSON y XML; `DateTime` sin zona = America/Santiago; `Folio` numérico; composición de ids de carrito; detección de reenvío |
| Reason to change | Cambio de pasarela/proveedor o del formato de su mensaje; nuevas reglas de registro |
| Owned data | Registros `PAGO_CONFIRMADO` (persistidos por EventosRecaudacion) |
| Public interface | `desdeM2Json(body) → Confirmacion`, `desdeM2Xml(xml) → Confirmacion`, `registrar(Confirmacion) → {resultado: 'REGISTRADA' \| 'REENVIO', ids}`; error `AbonoRechazado` |
| Incoming dependencies | Lambdas `postM2` (HTTP `createM2`), `suscriptorSnsReplicaGenerica` (SNS) |
| Outgoing dependencies | `EventosRecaudacion`, `Institucion.conceptoPorFormulario`, `integraciones/billetera` |
| Forbidden dependencies | DynamoDB/`aws-sdk` directo; `Notificacion`; `Conciliacion`; `axios`/`aws4` directo |
| Invariants | I1–I6 (§3.4) |
| Quality drivers | Modifiability (EC-1), Testability, Interoperability |
| SATD status | TD-009, TD-010, TD-011 a resolver en E3 |
| Tests / evidence | Caracterización de `postM2` (6 casos de `postM2Test`) + tests unitarios de adaptadores M2 + regla FF-2 |
| ADR reference | ADR-001 (límite ConfirmacionPago y ACL M2), ADR-003 (expand/contract de `payload`) |

**DTO canónico `Confirmacion` v1** (neutral respecto del proveedor):

```json
{
  "version": 1,
  "idSolicitud": "string (IdExt)",
  "idTransaccion": "number",
  "idOperacion": "number",
  "folio": "number",
  "formulario": "number",
  "fechaPago": "ISO-8601 UTC",
  "montoTotal": "number",
  "medioPago": { "codigo": "number", "nombre": "string" },
  "rutPagador": "number",
  "tipoPago": "string | null",
  "vencimiento": "YYYY-MM-DD",
  "resultado": "number",
  "institucion": "string (ToAddress)",
  "codigoInstitucionOnPrem": "number | null (RefAddress)",
  "emitidoEn": "ISO-8601 UTC (MessageId.DateTime)",
  "origen": "M2_JSON | M2_XML_REPLICA",
  "reenvio": "boolean"
}
```

Esos son los campos que los consumidores leen hoy del M2 (inventario en E1 §6, EC-1). Ningún consumidor necesita `Status`, `Number`, `MsgDesc`, `Code` ni `FromAddress`: quedan dentro del adaptador.

### 3.2 EventosRecaudacion

| Campo | Contenido |
|---|---|
| Module | `EventosRecaudacion` (`back/recaudacion-int/src/eventos/` en el slice; ver ADR-002 para compartirlo con `recaudacion`) |
| Responsibility | Persistir y consultar el ciclo de vida de una solicitud (`RECIBIDA`, `PAGO_CONFIRMADO`) |
| Information secret | Nombre de la tabla, `PREFIX`, claves `id`/`fechaEvento`, índices `ids-idx` e `instEnv-idx`, clave compuesta `institucion#environment`, coexistencia `payload` (legado) + `confirmacion` (canónico) |
| Reason to change | Cambio de esquema (EC-3), separación de reporting (EC-4), migración de almacén |
| Owned data | Tabla `eventos` — **owner único** |
| Public interface | `buscarPorSolicitud(institucion, idSolicitud)`, `registrarPagoConfirmado(confirmacion, solicitudRecibida?)`, `registrarRecibida(...)` (fuera del slice) |
| Incoming dependencies | ConfirmacionPago; en TO-BE completo: Solicitud, Conciliacion (solo lectura) |
| Outgoing dependencies | `aws-sdk/clients/dynamodb` (DocumentClient) |
| Forbidden dependencies | Cualquier módulo de dominio (es una hoja) |
| Invariants | La clave `id` de un `PAGO_CONFIRMADO` es `idSolicitud#idTransaccion` (carrito: `idSolicitud#tramite#idTransaccion`); `institucionEnvironment = institucion#environment` siempre se construye aquí |
| Tests / evidence | Tests con `fakeDynamo`; regla FF-3 (solo este módulo nombra la tabla) |
| ADR reference | ADR-002 |

Decisión deliberada: **no** se define una interfaz `IEventosRepository` con una implementación DynamoDB. Con una sola implementación, la interfaz agregaría ceremonia sin variabilidad real (§9, "Abstracción innecesaria"). La sustitución en tests ya la resuelve `moduleNameMapper` → `fakeDynamo`.

### 3.3 Contratos que el slice consume o produce

| Contrato | Tipo | Versionado y compatibilidad |
|---|---|---|
| `POST /giradores/m2/createM2` (M2 JSON) | API HTTP externa | **Sin cambios.** Mismo body y mismas respuestas `OK` / 400. Compatibilidad total hacia atrás |
| SNS réplica genérica (M2 XML) | Evento externo | **Sin cambios** en el formato de entrada. Cambia el manejo de errores (TD-011) |
| Registro `PAGO_CONFIRMADO` en `eventos` | Esquema persistido | **Expand/contract (ADR-003).** Se agrega `confirmacion` (DTO v1) y se mantiene `payload` (M2) mientras haya consumidores legados. Contract cuando FF-2 llegue a 0 consumidores fuera del adaptador |
| `PagoConfirmado v1` | Evento de dominio (proyección del stream) | Campos = DTO `Confirmacion` v1 + `institucionEnvironment`. Solo cambios aditivos en v1; un cambio incompatible publica v2 en paralelo |
| `integraciones/billetera.abonar(confirmacion)` | Interfaz interna | Encapsula `abonarBilletera` actual; error tipado `AbonoRechazado` |
| `Institucion.conceptoPorFormulario(form, inst)` | Interfaz interna | Encapsula `GET /portal-autoservicios/v1/formularios`; regla "si no hay concepto en PRODUCCION → `GENERICO_<inst>`" |

### 3.4 Invariantes de ConfirmacionPago

| # | Invariante | Estado AS-IS |
|---|---|---|
| I1 | Idempotencia: un `(idSolicitud, idTransaccion)` se registra a lo sumo una vez; un reenvío responde `OK` sin crear registros. Excepción explícita: la réplica on-prem **reemplaza** el registro (hoy borra invocando la Lambda `deleteRegistrosEventos` y vuelve a crear vía `createM2`). En TO-BE es una operación `reemplazar()` de EventosRecaudacion, sin invocar otra Lambda | Cumple (`validaIdTrx`); el reemplazo cruza 3 Lambdas |
| I2 | Unitario y carrito: solo se registra si existe la solicitud `RECIBIDA` de esa institución. Sin `RECIBIDA` se trata como girador on-prem: `environment = PRODUCCION`, concepto por formulario o `GENERICO_<institucion>` | Cumple |
| I3 | `folio`, `idTransaccion` y `montoTotal` son numéricos | Parcial (solo `folio` se normaliza en JSON) |
| I4 | Carrito: un `PAGO_CONFIRMADO` por trámite con `montoTotal` = monto del trámite | Cumple, mutando el `payload` compartido |
| I5 | Si el abono a billetera falla, no se persiste nada y se responde 400 `NOK` | **No cumple** en unitario (TD-010) |
| I6 | Fechas en ISO-8601 UTC; `emitidoEn` interpreta `DateTime` sin zona como America/Santiago | Cumple en JSON; el XML usa `formatISO` propio |

## 4. Dependencias permitidas y prohibidas

```mermaid
flowchart TB
  subgraph Lambdas[Handlers delgados]
    H1[postM2]:::h
    H2[suscriptorSnsReplicaGenerica]:::h
    H3[postSolicitud / getSolicitud*]:::h
    H4[publishSnsEventos]:::h
    H5[cuadratura / estadoOP / envioOp / dataOP / envioGCP]:::h
  end
  H1 --> CP[ConfirmacionPago]
  H2 --> CP
  H3 --> SOL[Solicitud]
  H4 --> NOT[Notificacion]
  H5 --> CON[Conciliacion]
  CP --> EV[EventosRecaudacion]
  CP --> INS[Institucion]
  CP --> BIL[integraciones/billetera]
  SOL --> EV
  SOL --> INS
  SOL --> ADF[integraciones/adf]
  INS --> PA[integraciones/portalAutoservicios]
  CON --> EV
  EV --> DDB[(eventos)]
  DDB -. stream PagoConfirmado v1 .-> NOT
  DDB -. stream PagoConfirmado v1 .-> CON
  classDef h fill:#eee,stroke:#999
```

| Regla | Tipo | Fitness function (E4) |
|---|---|---|
| R1. No hay ciclos entre módulos | Prohibida | FF-1: dependency-cruiser `no-circular` |
| R2. Solo `confirmacion-pago/adaptadores/` conoce el formato M2 (`Message.MessageId`, `Confirmacion.Pago`) | Prohibida fuera del adaptador | FF-2: Semgrep o grep sobre `src/`; métrica: archivos con M2 fuera del adaptador (AS-IS 9 → meta 0) |
| R3. Solo `eventos/` nombra la tabla `*-eventos` o instancia `DocumentClient` para ella | Prohibida fuera del owner | FF-3: regla Semgrep `TableName` + `-eventos` |
| R4. Los módulos se importan solo por su `index.js` (sin rutas internas ajenas) | Prohibida | FF-4: dependency-cruiser `no-private-imports` |
| R5. Handlers → módulos de dominio → `integraciones/` o `eventos/`, nunca al revés | Dirección | FF-4 |
| R6. Notificacion y Conciliacion no escriben `PAGO_CONFIRMADO` ni `RECIBIDA` | Prohibida | FF-3 (solo `eventos/` escribe) |
| R7. Región, rutas SSM y hosts vienen de configuración | Prohibida en código | FF-5: Semgrep sobre `us-east-1` y `'/tgr/` |
| R8. Sin SATD no gestionada en archivos intervenidos | Gate | FF-6: SATD debe referenciar `TD-xxx` |

## 5. Ownership de datos TO-BE

| Dato | Owner | Lectura por otros | Escritura | AS-IS (E1 §5) |
|---|---|---|---|---|
| Solicitud `RECIBIDA` | Solicitud (vía EventosRecaudacion) | API `getSolicitud(es)`; ConfirmacionPago vía `buscarPorSolicitud` | Solo EventosRecaudacion | 1 escritor en `recaudacion` |
| `PAGO_CONFIRMADO` | ConfirmacionPago (vía EventosRecaudacion) | Evento `PagoConfirmado v1`; consultas vía EventosRecaudacion | Solo EventosRecaudacion | `postM2` + `deleteRegistrosEventos` (borrado invocado por el suscriptor) |
| `estado_cuad`, `estado_op` | **Conciliacion** | API `consultarParaOP` | Solo Conciliacion, en su proyección | Escritos sobre el registro transaccional por `cuadratura.js` y `estadoOP.js` |
| `obligaciones` | Obligaciones | API `obligaciones-*` | Obligaciones | Sin cambio |
| Conceptos por institución | Portal autoservicios (externo) | `Institucion` vía API | — | Se lee por API **y** directo de la tabla: se elimina el acceso directo |

Resultado esperado: `DatosSinOwner` pasa de 1 (`eventos`) a 0, y la tabla `eventos` queda con 1 escritor (EventosRecaudacion) contra 5 hoy.

## 6. Granularidad: por qué este número de módulos

`C_total = C_internal + C_coordination` (§5).

- **Se descartó un microservicio por módulo.** Los módulos comparten tabla, equipo y ciclo de despliegue. Separar en servicios convertiría llamadas en proceso en llamadas de red (más `C_coordination`) sin un driver que lo pida.
- **Se descartó la estructura por capas (`controllers/services/repositories`).** Ordena carpetas, pero el M2 seguiría cruzando todas las capas: EC-1 no mejora.
- **Se descartó un módulo `Integration` genérico.** Juntaría secretos distintos (billetera, ADF, CUT, DSS), igual que hoy `utils/util.js`. Se prefiere un adaptador pequeño por proveedor, sin código compartido entre ellos.
- **Se descartó una interfaz por repositorio.** Ver §3.2.
- **Se descartó Strategy para unitario/carrito/on-prem.** Son 3 casos estables, decididos por datos de la solicitud. Una función de despacho con 3 ramas basta. Una jerarquía de clases agregaría complejidad accidental sin variabilidad nueva.
- **Patrones adoptados:** Adapter / Anti-Corruption Layer para M2, porque hay **dos** formatos reales (JSON y XML) y el escenario EC-1; Observer/Pub-Sub sobre el stream ya existente, para Notificacion y Conciliacion.
- **Si hubiera que simplificar**, EventosRecaudacion podría fusionarse con Solicitud. Se mantiene separado porque es el único lugar donde EC-3 y EC-4 tienen que cambiar, y porque lo usan dos módulos (Solicitud y ConfirmacionPago).

Tamaño esperado: los módulos del slice deberían quedar bajo 300 LOC cada uno, con funciones de complejidad ≤ 10. Hoy `postM2.handler` tiene CC 32 en 327 LOC.

## 7. Impacto esperado por escenario

| Escenario | AS-IS (E1) | TO-BE objetivo | Al cerrar el slice E3 |
|---|---|---|---|
| EC-1 proveedor / formato M2 | 9 archivos, 9 Lambdas | **1 módulo** (adaptadores de ConfirmacionPago) | Entrada (`postM2`, suscriptor) detrás del adaptador. Los consumidores de lectura (`getSolicitud(es)`, `cuadratura`, `getDataOP`, `publishSnsEventos`, `estadoCuadratura`, `reenvioM2Tierra`) siguen leyendo `payload` hasta migrar a `confirmacion` (ADR-003) |
| EC-2 canal de notificación | 4 puntos de publicación en una función de CC 28 | 1 módulo (Notificacion), un canal = una función | Contrato `PagoConfirmado v1` definido; implementación fuera del slice |
| EC-3 modelo de Institución | 14 archivos, 13 Lambdas | Institucion + EventosRecaudacion | `institucionEnvironment` del slice se construye solo en EventosRecaudacion |
| EC-4 separar reporting | 7 archivos, 7 Lambdas | Conciliacion con proyección propia | Fuera del slice; ownership declarado |

El E3 debe medir la columna "Al cerrar el slice" con `arch/scripts/escenarios.sh` y no prometer más que eso.

## 8. Decisiones que requieren ADR (E6)

Redactados en el E6: `arch/adr/` (índice y trazabilidad en `arch/adr/README.md`).

| ADR | Decisión |
|---|---|
| ADR-001 | Límite de ConfirmacionPago y Anti-Corruption Layer para M2 (JSON + XML) |
| ADR-002 | EventosRecaudacion como owner único de `eventos`, y cómo compartirlo entre los dos desplegables (opciones: paquete local con `package.patterns`, Lambda Layer como el actual `tgr-sdk`, o exponerlo como API). En el slice vive en `recaudacion-int` |
| ADR-003 | Expand/contract del registro `PAGO_CONFIRMADO`: agregar `confirmacion` v1 junto a `payload` y retirar `payload` cuando FF-2 llegue a 0 |
| ADR-004 | Integración asíncrona entre módulos: el stream de `eventos` como canal de `PagoConfirmado v1` para Notificacion y Conciliacion |
| ADR-005 | Política de SATD y quality gate (FF-1 a FF-6) |

## 9. Alcance del slice para el E3 (vista previa)

1. Caracterizar `postM2` con los 6 casos de `postM2Test` (TD-009), dobles HTTP y `__reset()` del fake por test.
2. Extraer `desdeM2Json` y `desdeM2Xml` (del suscriptor) hacia `confirmacion-pago/adaptadores/`.
3. Extraer `registrar()` con I1–I6, corrigiendo TD-010 (abono rechazado) con un test que lo demuestre.
4. Extraer `eventos/` con las operaciones que usa el slice. Persistir `confirmacion` además de `payload`.
5. Dejar `postM2` y el suscriptor como handlers delgados. El suscriptor relanza errores (TD-011).
6. Agregar FF-1 a FF-3 en CI y medir de nuevo EC-1 a EC-4.
