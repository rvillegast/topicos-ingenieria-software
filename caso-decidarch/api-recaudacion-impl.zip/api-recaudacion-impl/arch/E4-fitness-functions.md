# E4 — Fitness functions y quality gate

> Caso DecidArch §12 y §17.4. Reglas de origen: `arch/E2-arquitectura-to-be.md` §4 (R1–R8).
> Implementación: `arch/fitness/`. Evidencia: `arch/baseline/06-e4-quality-gate/`.

## 1. Qué se automatizó

Siete fitness functions, ejecutadas con tres herramientas y un solo comando (`arch/fitness/quality-gate.sh`):

| FF | Regla E2 | Qué verifica | Herramienta | Archivo |
|---|---|---|---|---|
| FF-1 | R1 | No hay ciclos de dependencias | dependency-cruiser 16.10.4 (`no-circular`) | `dependency-cruiser.cjs` |
| FF-2 | R2 | Solo `confirmacion-pago/adaptadores/` conoce el formato M2 (`MessageId`, `Confirmacion`) | Semgrep 1.180.0 (patrones sobre el AST) | `semgrep.yml` |
| FF-3 | R3, R6 | Solo `src/eventos/` nombra la tabla `eventos` | Semgrep | `semgrep.yml` |
| FF-4 | R4, R5 y dependencias prohibidas de E2 §3.1 | Módulos solo por su `index.js`; handlers → dominio → `eventos`/`integraciones`, nunca al revés; `eventos` es hoja; `integraciones` no conoce el dominio; ConfirmacionPago e Institucion sin `aws-sdk`, `axios`, `aws4`, `utils/` ni `aws/` | dependency-cruiser | `dependency-cruiser.cjs` |
| FF-5 | R7 | Sin región, ruta SSM, host ni nombre de ambiente escritos en el código | Semgrep (literales de string y template) | `semgrep.yml` |
| FF-6 | R8 | Todo `TODO`/`FIXME`/`HACK`/`XXX`/`WORKAROUND` referencia un `TD-xxx` del debt ledger | Semgrep (`pattern-regex`) | `semgrep.yml` |
| FF-7 | Pruebas críticas (§12.2.7) | Las suites de ambos desplegables pasan, y `src/` (código intervenido) tiene ≥ 90 % de líneas y ≥ 75 % de ramas cubiertas | Jest 24 (`coverageThreshold`) | `quality-gate.sh` |

Cobertura de las reglas mínimas del caso (§12.2):

| Regla mínima del caso | Cubierta por |
|---|---|
| 1. No existen ciclos entre módulos | FF-1 |
| 2. Solo el owner autorizado modifica determinado dato | FF-3 |
| 3. Detalles de proveedor externo no atraviesan la frontera del adapter | FF-2 (M2) y FF-4 (SDK y HTTP solo en `eventos`/`integraciones`) |
| 4. No existe SATD no gestionada en código nuevo o intervenido | FF-6 |
| 5. Valores de ambiente no quedan hard-coded | FF-5 |
| 6. Dependencias prohibidas bloquean el merge | FF-4 + `buildspec-quality-gate.yml` como build obligatorio del PR |
| 7. Contratos y pruebas críticas continúan pasando | FF-7 |
| 8. Reglas arquitectónicas ejecutables en CI | `quality-gate.sh` + `buildspec-quality-gate.yml` |

**Por qué estas herramientas.** dependency-cruiser resuelve `require` e `import` reales (CJS y ESM conviven en el repo), así que las reglas de dirección se escriben sobre rutas resueltas y no sobre texto. Semgrep compara contra el AST: no confunde `ConfirmacionPago` con la propiedad `Confirmacion` ni una URL en un comentario con un literal. SonarQube y CodeQL quedaron fuera porque piden un servidor o un análisis más pesado, y no agregan reglas que estas dos herramientas no cubran (§12: «se evalúa que la selección sea coherente con los riesgos detectados»).

## 2. Política: código intervenido en cero, legado con *ratchet*

Aplicar las reglas a todo el repo de golpe dejaría el gate en rojo para siempre: el legado tiene 43 combinaciones (regla, archivo) en falta. No aplicarlas al legado permitiría que la deuda creciera. Por eso `ratchet.js` aplica dos niveles:

| Alcance | Condición | Ejemplo de falla |
|---|---|---|
| **Código intervenido**: `recaudacion-int/src/**`, `postM2.js`, `suscriptorSnsReplicaGenerica.mjs` | **0 hallazgos**; no se puede aceptar deuda ahí | `ff2-m2-fuera-del-adaptador en código intervenido …/confirmacion-pago/index.js:101 (meta 0)` |
| **Legado** | Cada (regla, archivo) aceptado está en `deuda-conocida.tsv` con su máximo y su `TD-xxx` | `ff2-m2-fuera-del-adaptador sube en recaudacion/getSolicitud.js: 13 > 12 aceptados (TD-015)` |
| **Ratchet** | Si un archivo baja de su máximo, o deja de tener hallazgos, el gate falla hasta actualizar la fila | `ratchet: … bajó … a N; actualiza deuda-conocida.tsv` |

Las filas sin un `TD-xxx` válido también hacen fallar el gate: la deuda aceptada siempre está gestionada (ADR-005). Para dependency-cruiser no hizo falta lista de deuda: el grafo completo tiene 0 violaciones.

Deuda aceptada en `deuda-conocida.tsv` (registrada en `arch/debt-ledger.md`):

| TD | Regla | Archivos | Plan |
|---|---|---|---|
| TD-015 | FF-2: consumidores que leen el M2 legado (`payload`) | 7 (`getSolicitud`, `getSolicitudes`, `cuadratura`, `getDataOP`, `publishSnsEventos`, `estadoCuadratura`, `reenvioM2Tierra`) | ADR-003, fase *contract*: migrar a `confirmacion` |
| TD-016 | FF-3: acceso directo a la tabla `eventos` | 12 | ADR-002: pasar lectores y escritores por EventosRecaudacion |
| TD-017 | FF-5: región, rutas SSM, hosts y ambientes hard-coded | 21 | Mover a `serverless.yml`/SSM al intervenir cada archivo |
| TD-018 | FF-6: SATD legada sin clasificar | 3 (5 comentarios) | E5 |

## 3. Cambios de código hechos en el E4

Al activar las reglas, aparecieron tres violaciones en el código intervenido del E3. Se corrigieron en vez de aceptarlas:

| Hallazgo | Regla | Corrección |
|---|---|---|
| `confirmacion-pago` importaba `utils/billetera` (un util legado, no un adaptador) | FF-4 `ff4-dominio-sin-sdk` | `utils/billetera.js` → `src/integraciones/billetera.js` (sin otros usuarios en `recaudacion-int`) |
| El adaptador de billetera arma la ruta SSM `/tgr/${ENV}/api-recaudacion/back/wallet/` | FF-5 | Variable `SSM_WALLET_PATH` en `serverless.yml`; mismo valor que antes |
| `process.env.AWS_REGION \|\| 'us-east-1'` en `eventos` y el suscriptor (C4 del E3) | FF-5 | Sin *fallback*: el runtime de Lambda siempre define `AWS_REGION`, y en tests el cliente se reemplaza |

Con el adaptador de billetera dentro de `src/`, la cobertura de ramas del código intervenido bajó a 57 %, porque los tests lo mockeaban. Se agregó `__tests__/billeteraTest.js` (4 casos: armado del abono, billetera del trámite en carrito, reintento exitoso, 4 intentos fallidos que devuelven el error que ConfirmacionPago convierte en rechazo I5). `recaudacion-int` queda en **27/27**.

## 4. Evidencia

### 4.1 Gate en verde (`06-e4-quality-gate/quality-gate.log`)

| Paso | Resultado |
|---|---|
| FF-7 `recaudacion` | 16/16 |
| FF-7 `recaudacion-int` | 27/27; `src/`: 97,69 % de líneas, 81,43 % de ramas |
| FF-1/FF-4 | `no dependency violations found (110 modules, 188 dependencies cruised)` |
| FF-2/3/5/6 | `sin violaciones nuevas ni en código intervenido` |
| **Gate** | **✔ QUALITY GATE OK** (exit 0) |

### 4.2 Las fitness functions detectan violaciones (`06-e4-quality-gate/mutacion-ff.log`)

Una fitness function que nunca falla no protege nada. `arch/fitness/mutacion-ff.sh` inyecta una violación por regla, corre la herramienta y restaura el archivo:

| Violación inyectada | FF | Resultado |
|---|---|---|
| `institucion` importa `confirmacion-pago` (ciclo) | FF-1 | ✗ detectada |
| `postM2` importa `confirmacion-pago/adaptadores/m2` | FF-4 | ✗ |
| `confirmacion-pago` importa `axios` | FF-4 | ✗ |
| `eventos` importa el handler `callback` | FF-4 | ✗ |
| `confirmacion-pago` lee `l.Message.MessageId` | FF-2 | ✗ (código intervenido) |
| `getSolicitud` (legado) agrega una lectura de `Confirmacion` | FF-2 | ✗ (ratchet: 13 > 12) |
| `postM2` nombra la tabla `${PREFIX}-eventos` | FF-3 | ✗ |
| `eventos` usa `'us-east-1'` | FF-5 | ✗ |
| `institucion` arma una ruta `/tgr/${ENV}/…` | FF-5 | ✗ |
| `// TODO revisar índices` en `eventos` | FF-6 | ✗ |
| `// TODO TD-016 migrar lectores` en `eventos` | FF-6 | ✔ pasa (SATD gestionada) |

10/10 violaciones detectadas y 1/1 caso válido aceptado. FF-7 se validó en el E3 con la mutación manual del slice (6/6). El E5 agregó 4 casos para FF-6 (15 en total; ver `arch/E5-gestion-satd.md`).

**Corrección de método durante la validación:** la primera versión de la configuración excluía `node_modules` del grafo, así que dependency-cruiser no veía dependencias externas y la mutación `axios` pasaba. Se cambió a `doNotFollow` y la mutación quedó detectada.

### 4.3 AS-IS vs. ahora con las mismas reglas

Semgrep corrido sobre un worktree del commit `66a2873` y sobre el árbol actual:

| Regla | AS-IS (`66a2873`) | Ahora | Lectura |
|---|---|---|---|
| FF-2 M2 fuera del adaptador | 86 hallazgos en 9 archivos | 29 en 7 | Coincide con EC-1 del E1 y E3 (9 → 8 contando el adaptador) |
| FF-3 tabla `eventos` fuera del owner | 22 en 14 | 18 en 12 | Salen `postM2` y el suscriptor |
| FF-5 hard-coded | 26 en 23 | 23 en 21 | Salen la región del suscriptor y la ruta SSM de billetera |
| FF-6 SATD sin TD | 5 en 3 | 5 en 3 | Pendiente para el E5 |
| FF-1 ciclos entre archivos | 0 | 0 | El ciclo entre carpetas `obligaciones` ↔ `obligaciones/dss` (E1) queda dentro del módulo Obligaciones; R1 es entre módulos |
| FF-4 | No aplica (no había módulos) | 0 violaciones | |

## 5. Quality gate del ejercicio (anexo E del caso)

| Regla del anexo E | Condición | Estado |
|---|---|---|
| Unmanaged SATD en código intervenido | 0 | **0** (FF-6; las 5 SATD legadas están fuera del código intervenido y referenciadas por TD-018 hasta el E5) |
| Ciclos entre módulos TO-BE | 0 | **0** (FF-1) |
| Dependencias prohibidas | 0 | **0** (FF-4) |
| Hard-coded de secretos/URLs de ambiente | 0 | **0 en código intervenido**; 23 legados con ratchet (TD-017). Los secretos reales de TD-006 están en un test excluido y su rotación depende de TGR |
| Fitness functions automatizadas | ≥ 3 | **7** |
| ADRs | ≥ 5 | Pendiente (E6) |
| Escenarios de cambio comparados | ≥ 4 | 4 (E1 y E3) |
| Pruebas críticas | Pasan antes y después | 16/16 y 27/27 (FF-7) |

## 6. CI

`arch/fitness/buildspec-quality-gate.yml` instala Node 22 (el runtime de las Lambdas), Python 3.12 y `semgrep==1.180.0`, hace `npm ci` en ambos subproyectos y corre `quality-gate.sh`. Integración propuesta en CodeCommit/CodeBuild:

1. Un proyecto CodeBuild con este buildspec, disparado por los eventos de pull request (EventBridge `pullRequestCreated` / `pullRequestSourceBranchUpdated`).
2. Una plantilla de regla de aprobación que exige el build en verde para hacer merge a `develop`. Así se cumple «dependencias prohibidas bloquean el merge».
3. El deploy existente (`back/buildspec.yml`) no cambia; queda detrás del merge.

**Limitación honesta:** el buildspec no se ejecutó en CodeBuild (el push al repositorio de TGR está deshabilitado). Lo que se verificó es el mismo script de forma local, con las mismas versiones fijadas. Las versiones de las herramientas están fijadas para que el resultado sea reproducible.

## 7. Límites conocidos de las reglas

- **FF-3** detecta el nombre de la tabla en `TableName`. Un archivo que la reciba por una variable de otro módulo no se detecta. Hoy todos los accesos usan el literal; FF-4 complementa esto en el código intervenido, porque ahí `aws-sdk` solo puede usarlo `eventos`.
- **FF-2** detecta los nombres de propiedad `MessageId` y `Confirmacion`. Un acceso dinámico (`obj[campo]` con `campo` calculado) no se detecta.
- **El ratchet cuenta por (regla, archivo), no por línea.** Mover código no rompe el gate, pero un cambio que elimina un hallazgo y agrega otro en el mismo archivo pasa. Para el legado se aceptó ese costo a cambio de no tener que actualizar líneas en cada commit.
- **FF-7 cubre solo el comportamiento caracterizado.** No hay tests de contrato contra los proveedores reales (R-05).
