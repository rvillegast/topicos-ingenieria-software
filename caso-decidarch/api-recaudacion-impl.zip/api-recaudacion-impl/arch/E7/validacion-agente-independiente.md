# Validación de AGENTS.md con un agente independiente (2026-10-09)

**Protocolo (E7 §6):**
- Un agente nuevo, sin el contexto de la conversación, en un worktree aislado (rama `validacion-agente-e7` desde `2c8b3d5`).
- Recibió solo el repositorio, la TASK INTENT del E7 §5 («PasarelaX»), el formato del webhook y la ruta de Semgrep. No recibió ninguna pista sobre las reglas.

## Resultado

**El agente no escribió código y se detuvo** citando AGENTS.md §4 («Cambiar … la forma de `PAGO_CONFIRMADO` (salvo cambios aditivos) → detente y pregunta»). Se verificó que el worktree quedó sin cambios (`git status` vacío) y que no hubo commit ni push.

Los conflictos que reportó (todos verificados por el revisor):

| # | Afirmación del agente | Verificación |
|---|---|---|
| A | Un `PAGO_CONFIRMADO` sin `payload` rompe a lectores legados que recorren todos los pagos de la solicitud | `cuadratura.js:30` y `getDataOP.js:43` leen `Items[i].payload.Message.Confirmacion.Pago.TotalPago` en un bucle; `publishSnsEventos.js:55-62`, ídem |
| A | Dejar de escribir `payload` es la fase *contract* de ADR-003, bloqueada hasta FF-2 = 0 (hoy 29) | ADR-003 y gate |
| B | `registrar()` depende de `legado` en sus 3 ramas y `esReenvio` (I1) lee el `payload` de cada pago previo | `node -e`: `conFolioNumerico`, `conTotal` e `idTransaccionDePayload` con `undefined` lanzan `TypeError` |
| B | Un registro de PasarelaX sin `payload` haría fallar después cualquier M2 de la misma solicitud (rompe `createM2`) | Consecuencia directa de `esReenvio` (`index.js:13-14`) |
| — | Faltan decisiones de mapeo: `payment.id` → `idTransaccion`; tipo de registro; `folio` y `formulario` que el webhook no trae | Correcto: el DTO v1 los exige |

El agente propuso 3 opciones para decisión humana:
1. M2 sintético.
2. Adelantar la fase *migrate* de ADR-003.
3. Cambio de contrato aprobado.

## Lectura

| Pregunta | Respuesta |
|---|---|
| ¿El contrato evitó una violación? | **Sí.** Sin §4 y Q8, la implementación «obvia» (adaptador + `registrar()` sin `legado`) habría pasado FF-1 a FF-6. Habría roto la conciliación en producción para esas solicitudes, y ningún test actual lo detecta: ninguno siembra un `PAGO_CONFIRMADO` sin `payload` |
| ¿El informe cumplió §5? | Sí: Q1–Q8, gate inicial (exit 0), conteo de tests (17 + 33) y evidencia ejecutada por cada afirmación |
| ¿Qué falló? | **La TASK INTENT de ejemplo (E7 §5), escrita por el equipo/revisor:** era internamente contradictoria («`registrar()` NO cambia» + «sin `payload`» + «cambio aditivo»). También era excesiva la afirmación de E7 §5 y E8 de que un proveedor nuevo se resuelve con «1 adaptador + 1 handler». Eso solo vale para cambios del formato M2 |
| ¿Hueco del gate? | Sí: ninguna FF ni test protege la invariante «todo `PAGO_CONFIRMADO` tiene `payload` mientras existan lectores legados». Se registra como acción en TD-026 |
| Deuda nueva descubierta | **TD-026:** las reglas de registro de ConfirmacionPago (I1, unitario/carrito/on-prem) dependen del `payload` M2 persistido, no del DTO `confirmacion`. El secreto del proveedor sigue condicionando la política del módulo |
| Otros | El agente heredó la regla global del usuario sobre graphify. La declaró y no la aplicó, por la instrucción de trabajar aislado. Correcto |

## Decisión recomendada (pendiente de aprobación humana)

Opción 2 acotada, en dos pasos y antes de cualquier proveedor no-M2:
1. **Paso 1**, dentro del módulo intervenido y sin cambio observable para M2: `esReenvio` compara contra `confirmacion.idTransaccion`, con *fallback* a `payload` en registros antiguos. Las 3 ramas construyen el `payload` solo si hay `legado`. Así se cierra TD-026.
2. **Paso 2**, ADR-003 fase *migrate*: llevar a `confirmacion` los lectores que recorren todos los pagos (`cuadratura`, `getDataOP`, `publishSnsEventos`). Después, un test de caracterización que siembre un registro sin `payload`.

Hasta entonces, la opción 1 (M2 sintético) queda **descartada**: haría que un proveedor nuevo dependa del formato de otro, que es justo el problema que el diseño resuelve.

## Cierre de TD-026 (2026-10-09, aprobado por el usuario)

Se ejecutó el paso 1 recomendado.

**Cambios en `src/confirmacion-pago/index.js`:**
- `esReenvio` compara contra `confirmacion.idTransaccion`, con *fallback* a `payload` para los registros anteriores al expand de ADR-003.
- Las 3 ramas construyen `payload` solo si hay `legado`.

**Evidencia:**
- `postM2Test` caso 13: un pago previo sin `payload` no rompe un M2 posterior; el reenvío no duplica.
- Caso 14: `registrar()` sin `legado` registra y detecta el reenvío.
- Mutación 2/2:
  - volver a la idempotencia por `payload` hace fallar los casos 13 y 14;
  - quitar la guarda en on-prem hace fallar el caso 14.
- Suite 35/35 y quality gate en verde.

**Efecto colateral declarado:** antes, un registro sin `payload` reventaba en `registrar()`, lo que en la práctica impedía crearlo. Ahora la única protección para los lectores legados es la cláusula Q8 de `AGENTS.md`, hasta la fase *migrate* de ADR-003.

