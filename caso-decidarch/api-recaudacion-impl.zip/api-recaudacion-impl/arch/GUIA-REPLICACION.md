# Guía de replicación — Caso DecidArch sobre `api-recaudacion-impl`

Instrucciones, comandos y scripts para reproducir el trabajo del caso (E1 a E8): selección del proyecto, baselines, refactor del slice, fitness functions, gestión de SATD, ADRs, contrato de intención y validación con un agente independiente.

La guía tiene dos caminos:
- **Camino A (rápido, unos 10 minutos):** clonar la rama ya hecha y reproducir toda la evidencia.
- **Camino B (completo):** rehacer el proceso paso a paso, en el mismo orden en que se hizo.

> Convenciones: los comandos se ejecutan desde la raíz del repositorio (`api-recaudacion-impl/`) salvo que se indique otra cosa. Están probados en macOS (zsh/bash, `sed -i ''` de BSD); en Linux usa `sed -i` sin las comillas vacías.
> **Confidencialidad:** el código es institucional de TGR. `back/recaudacion/src/obligaciones/test/` contiene credenciales reales (TD-006): no se ejecuta, no se copia y no se abre.

---

## 0. Requisitos

| Herramienta | Versión usada | Para qué | Instalación |
|---|---|---|---|
| Node.js / npm | 22.x (runtime `nodejs22.x` de las Lambdas) | Tests, scripts, `npx` | — |
| git | cualquiera reciente | Worktrees del AS-IS, rama de trabajo | — |
| Python | 3.12 | Semgrep | — |
| Semgrep | **1.180.0** | FF-2, FF-3, FF-5, FF-6 | `python3 -m venv .venv-sg && .venv-sg/bin/pip install semgrep==1.180.0` |
| dependency-cruiser | **16.10.4** | FF-1, FF-4 | Se descarga con `npx -y dependency-cruiser@16.10.4` |
| ESLint | **8.57.0** | Complejidad (baseline) | Se descarga con `npx -y eslint@8.57.0` |
| jscpd | **4.0.5** | Duplicación (baseline) | Se descarga con `npx -y jscpd@4.0.5` |
| Jest | 24 (del proyecto) + `@babel/core` y `@babel/preset-env` ^7.26.0 | Tests y cobertura | `npm install` en cada subproyecto |

**No se necesita** Java ni DynamoDB Local (se reemplazaron por un fake en memoria), ni credenciales de AWS.

Con Semgrep en un venv, exporta su ruta para los scripts:

```bash
export SEMGREP="$PWD/.venv-sg/bin/semgrep"
```

El mensaje `Failed to register segfault signal handler!` que Semgrep muestra en algunos entornos con sandbox es inofensivo.

**Exclusiones de Semgrep.** Usa siempre las mismas que el gate. Con menos exclusiones los conteos cambian (por ejemplo, 87/23/60 en vez de 86/22/26 en el AS-IS) y se escanearía `obligaciones/test/`, que tiene las credenciales de TD-006. Defínelas como arreglo; funciona igual en bash y zsh:

```bash
EXCL=(--exclude node_modules --exclude __tests__ --exclude __mocks__ --exclude test --exclude test-support \
      --exclude testing --exclude mocks --exclude coverage --exclude 'jest*.js' --exclude babel.config.js)
```

`quality-gate.sh` no excluye `__tests__`, porque FF-6 también revisa los tests (E5). Para comparar con el AS-IS del E4, usa `EXCL` tal cual.

---

## Camino A — Reproducir la evidencia desde la rama

```bash
# 1. Repositorio y rama de trabajo (local; el push al remoto de TGR está deshabilitado)
cd api-recaudacion-impl
git switch caso-decidarch/e1-e8          # commits 2c8b3d5 (E1–E8) y 769b19b (validación + TD-026)

# 2. Dependencias
(cd back/recaudacion && npm install)
(cd back/recaudacion-int && npm install)

# 3. Tests
(cd back/recaudacion && npx jest)        # 17/17
(cd back/recaudacion-int && npx jest)    # 35/35

# 4. Quality gate (7 fitness functions)
arch/fitness/quality-gate.sh             # debe terminar en "✔ QUALITY GATE OK" (exit 0)

# 5. Las fitness functions detectan violaciones (inyecta 15 violaciones y restaura cada archivo)
arch/fitness/mutacion-ff.sh              # 13 casos "✗"/"error" y 2 casos "✔" (válidos)

# 6. Baseline completo del estado actual (métricas de la matriz E8)
arch/scripts/baseline.sh arch/baseline/mi-corrida
cat arch/baseline/mi-corrida/RESUMEN.md
node arch/scripts/indicadores-e8.js 04-diagnostico-e1 mi-corrida   # AS-IS vs. tu corrida

# 7. Medición del AS-IS sobre el commit original (worktree aparte)
git worktree add --detach /tmp/asis 66a2873
SRC_ROOT=/tmp/asis/back arch/scripts/escenarios.sh arch/baseline/04-diagnostico-e1   # EC-1..EC-4 AS-IS: 9/2/14/7 archivos
(cd /tmp/asis/back && "$SEMGREP" scan --metrics=off -q --json \
   --config "$OLDPWD/arch/fitness/semgrep.yml" "${EXCL[@]}" . ) \
   | node -e 'const r=JSON.parse(require("fs").readFileSync(0)).results,o={};for(const h of r){const k=h.check_id.split(".").pop();o[k]=(o[k]||0)+1}console.log(o)'
# esperado: ff2 86, ff3 22, ff5 26, ff6 5
git worktree remove /tmp/asis
```

Resultado esperado: los mismos números de `arch/E8-informe-evidencia.md` §1–§2. La cobertura puede variar unas centésimas según la versión de Node.

---

## Camino B — Rehacer el proceso paso a paso

### Paso 1. Leer el caso

El caso (`Caso DecidArch.pdf`, 22 páginas) se convirtió a texto (`Caso DecidArch.pdf.md`) para poder buscar en él. Se usó `pypdf` en un venv; cualquier extractor de texto sirve:

```bash
python3 -m venv .venv-pdf && .venv-pdf/bin/pip install pypdf
.venv-pdf/bin/python -c "import pypdf,sys; r=pypdf.PdfReader(sys.argv[1]); print('\n'.join(p.extract_text() for p in r.pages))" \
  "Caso DecidArch.pdf" > "Caso DecidArch.pdf.md"
grep -n "17\.[1-8]\|12\.2\|Plantilla\|quality gate" "Caso DecidArch.pdf.md"   # entregables, FF mínimas, plantillas
```

Secciones clave:

| Tema | Sección del caso |
|---|---|
| Requisitos del proyecto | §14 |
| Metodología | §15 |
| Entregables E1–E8 | §17 |
| Rúbrica | §18 |
| Criterios de evidencia | §19 |
| Preguntas de defensa | §20 |
| Plantillas | Anexos A–E |

### Paso 2. Seleccionar el proyecto (prueba rápida de 7 preguntas)

Screening de todos los repositorios candidatos con `arch/scripts/screening/`:

```bash
# Una fila TSV por repo: dir, lenguaje, archivos, LOC, archivo mayor, tests, SATD, archivos con HTTP, URLs, archivos con BD, controllers, ¿git?
arch/scripts/screening/screen.sh /ruta/a/los/repos > screen.tsv
sort -t$'\t' -k4 -n screen.tsv | column -t

# Para los finalistas: ciclos entre carpetas y tablas tocadas por más de un archivo
node arch/scripts/screening/dircycles.js /ruta/a/los/repos/<finalista>

# Rastros de IA en la historia (pregunta del contexto Vibe Coding)
git -C /ruta/a/los/repos/<finalista> log --all --format='%an %s %b' | grep -iE 'claude|copilot|chatgpt|cursor|co-authored'
```

Después, para cada finalista, se responden las 7 preguntas (§2.9 del reporte):
1. ¿Se ejecuta localmente?
2. ¿Tiene 5 o más responsabilidades y 2 o más proveedores?
3. ¿Tiene ciclo, clase dios y tabla compartida?
4. ¿Tiene SATD?
5. ¿Admite 4 o más escenarios con impacto mayor a 1 módulo?
6. ¿Es de tamaño acotado?
7. ¿Hay evidencia automatizable?

Se eligió `api-recaudacion-impl`: Node.js + Serverless, 30 Lambdas, DynamoDB compartida, M2 de proveedor de pagos, SNS y billetera.

### Paso 3. Copiar el proyecto y bloquear el push

```bash
cp -R /ruta/origen/api-recaudacion-impl ~/Downloads/casoDecidArch/
cd ~/Downloads/casoDecidArch/api-recaudacion-impl
git remote set-url --push origin DISABLED-no-push     # nada puede llegar al remoto de TGR
git log --oneline -1                                  # 66a2873 = commit AS-IS de todo el caso
```

### Paso 4. Baseline AS-IS original (`arch/baseline/01-as-is-original`)

Los scripts de medición viven en `arch/scripts/` para que el baseline viaje con el código:

| Script | Uso | Genera |
|---|---|---|
| `metrics.js` | `node arch/scripts/metrics.js back <OUT>` | `inventario.tsv`, `satd.tsv`, `deps.tsv`, `ciclos.txt` (Tarjan), `tablas.tsv` (lectores y escritores por tabla), `hardcoded.tsv`, `integraciones.tsv`, `metrics.json` |
| `eslint-metrics.json` | Configuración de ESLint | Reglas: `complexity` > 10, `max-lines-per-function` > 50, `max-depth` > 4, `max-params` > 5 |
| `impacto.js` | `SRC_ROOT=<árbol> node arch/scripts/impacto.js <BASELINE> '<regex>' --files` | Archivos que contienen una decisión + Lambdas cuyo handler depende de ellos (transitivo) |
| `escenarios.sh` | `arch/scripts/escenarios.sh <BASELINE>` | `escenarios.json` con EC-1..EC-4 |
| `resumen.js` | `node arch/scripts/resumen.js <BASELINE> > RESUMEN.md` | Matriz E8 (columna medida) |
| `baseline.sh` | `arch/scripts/baseline.sh <BASELINE>` | Corre los 5 anteriores + ESLint + jscpd + Jest con cobertura (6 pasos) |

```bash
(cd back/recaudacion && npm install)
(cd back/recaudacion-int && npm install)
arch/scripts/baseline.sh arch/baseline/01-as-is-original
```

En el AS-IS, `recaudacion` daba 0/14 tests y `recaudacion-int` no era ejecutable: su preset `@shelf/jest-dynamodb` exige Java y tenía 11 tests en `skip`.

### Paso 5. Red de tests sin dependencias externas (baselines 02 y 03)

**5.1 Babel para que Jest 24 cargue los `.mjs` (ESM):**

```bash
for p in recaudacion recaudacion-int; do
  (cd back/$p && npm install --save-dev @babel/core@^7.26.0 @babel/preset-env@^7.26.0)
  printf "module.exports = { presets: [['@babel/preset-env', { targets: { node: 'current' } }]], sourceType: 'unambiguous' };\n" \
    > back/$p/babel.config.js
done
```

**5.2 Fake de DynamoDB en memoria** (`back/test-support/fakeDynamo.js`):
- Implementa el `DocumentClient` v2 con `put/get/delete/query/scan/update`, operadores `= < <= > >=`, `begins_with`, `BETWEEN`, `AND`, `set` y `ConditionExpression`.
- Toma el esquema de `recaudacion-int/jest-dynamodb-config.js`, con nombres lógicos sin el prefijo de ambiente.
- Exporta `__reset()` para aislar los tests.

Se conecta en el `jest.config.js` de **ambos** subproyectos:

```js
process.env.TZ = 'UTC';                       // como en Lambda (fechas)
module.exports = {
  testEnvironment: 'node',
  moduleFileExtensions: ['js', 'mjs', 'json'],
  transform: { '^.+\\.m?js$': 'babel-jest' },
  moduleNameMapper: { '^aws-sdk/clients/dynamodb$': '<rootDir>/../test-support/fakeDynamo.js' },
  // solo recaudacion: scripts manuales con credenciales reales (TD-006/TD-007)
  testPathIgnorePatterns: ['/node_modules/', '<rootDir>/src/obligaciones/test/'],
};
```

**5.3 Reparar y reactivar tests:**
- Tokens con el claim `aud`.
- `getAvisoRecibo` → `postAvisoRecibo`.
- Mensajes de CID actualizados.
- Dobles con `jest.mock` para `axios`, ADF y billetera.

```bash
arch/scripts/baseline.sh arch/baseline/02-tests-con-mock
arch/scripts/baseline.sh arch/baseline/03-tests-recaudacion-reparados
```

### Paso 6. E1 — Diagnóstico AS-IS (`arch/baseline/04-diagnostico-e1`)

```bash
arch/scripts/baseline.sh arch/baseline/04-diagnostico-e1

# Los escenarios se miden SIEMPRE sobre el código del commit AS-IS (impacto.js lee SRC_ROOT, no la carpeta del baseline)
git worktree add --detach /tmp/asis 66a2873
SRC_ROOT=/tmp/asis/back arch/scripts/escenarios.sh arch/baseline/04-diagnostico-e1
# EC-1 proveedor/formato M2: 9 archivos, 9/30 Lambdas · EC-2: 2 · EC-3: 14 · EC-4: 7
```

Las regex de cada escenario están en `escenarios.sh`. Para probar otra:

```bash
SRC_ROOT=/tmp/asis/back node arch/scripts/impacto.js arch/baseline/04-diagnostico-e1 'TopicArn|\.publish\(' --files
```

Documento: `arch/E1-diagnostico-as-is.md`. Deuda inicial: `arch/debt-ledger.md` (plantilla B).

### Paso 7. E2 — Arquitectura TO-BE

Es trabajo de diseño, sin comandos: `arch/E2-arquitectura-to-be.md`. Incluye:
- módulos por secreto (Parnas);
- contratos del anexo A;
- el DTO `Confirmacion` v1;
- las invariantes I1–I6;
- las reglas R1–R8 que luego serán fitness functions.

### Paso 8. E3 — Refactor del slice de confirmación de pago (`arch/baseline/05-post-slice-e3`)

Secuencia del caso: *caracterización → refactor pequeño → tests → chequeo arquitectónico*. **La suite completa se corre después de cada paso:**

```bash
(cd back/recaudacion-int && npx jest)
```

**Prueba de mutación manual.** Demuestra que la red detecta regresiones. Se aplica a cada regla del slice:

```bash
F=back/recaudacion-int/src/confirmacion-pago/index.js
cp "$F" /tmp/backup.js
sed -i '' 's/<expresión original>/<expresión mutada>/' "$F"     # p. ej. romper la detección de reenvío
(cd back/recaudacion-int && npx jest __tests__/postM2Test.js)   # debe FALLAR
cp /tmp/backup.js "$F"                                         # restaurar SIEMPRE
(cd back/recaudacion-int && npx jest)                          # vuelve a verde
```

Resultados: 4/4 mutantes detectados en el AS-IS y 6/6 en el TO-BE (tabla en `arch/E3-refactoring.md` §2).

```bash
arch/scripts/baseline.sh arch/baseline/05-post-slice-e3
SRC_ROOT=/tmp/asis/back arch/scripts/escenarios.sh arch/baseline/04-diagnostico-e1   # comparación AS-IS
arch/scripts/escenarios.sh arch/baseline/05-post-slice-e3                           # post-slice: EC-1 = 8

# Diffs del slice (formato diff -u)
git diff 66a2873 -- back/recaudacion-int/postM2.js back/recaudacion-int/suscriptorSnsReplicaGenerica.mjs \
   back/recaudacion-int/src back/recaudacion-int/aws/dynamoDbServices.js > arch/E3/slice-codigo.patch
git diff 66a2873 -- back/recaudacion-int/__tests__ > arch/E3/slice-tests.patch
```

### Paso 9. E4 — Fitness functions y quality gate

Archivos en `arch/fitness/`:

| Archivo | Rol |
|---|---|
| `dependency-cruiser.cjs` | FF-1 (sin ciclos) y FF-4 (solo por `index.js`, dirección, `eventos` hoja, `integraciones` sin dominio, dominio sin SDK) |
| `semgrep.yml` | FF-2 (M2 fuera del adaptador), FF-3 (tabla `eventos` fuera del owner), FF-5 (hard-coded), FF-6 (SATD sin `TD-xxx`) |
| `ratchet.js` | Compara los hallazgos de Semgrep con `deuda-conocida.tsv`: 0 en el código intervenido; en el legado, solo puede bajar |
| `deuda-conocida.tsv` | Deuda legada aceptada: `regla, archivo, máximo, TD` |
| `quality-gate.sh` | FF-7 (Jest + cobertura de `src/` ≥ 90 % líneas y ≥ 75 % ramas) + dependency-cruiser + Semgrep/ratchet |
| `mutacion-ff.sh` | Inyecta una violación por regla y verifica que el gate la detecte |
| `buildspec-quality-gate.yml` | CodeBuild para PRs (Node 22, Python 3.12, `semgrep==1.180.0`) |

```bash
# Herramientas por separado
(cd back && npx -y dependency-cruiser@16.10.4 -c ../arch/fitness/dependency-cruiser.cjs recaudacion recaudacion-int)
(cd back && "$SEMGREP" scan --metrics=off -q --json --config ../arch/fitness/semgrep.yml "${EXCL[@]}" . \
   | node ../arch/fitness/ratchet.js)

# Todo junto
arch/fitness/quality-gate.sh
arch/fitness/mutacion-ff.sh
```

**Generar la lista de deuda inicial** (solo una vez, al introducir el gate sobre un legado con violaciones). Cada regla se asigna a un TD del ledger:

```bash
(cd back && "$SEMGREP" scan --metrics=off -q --json --config ../arch/fitness/semgrep.yml "${EXCL[@]}" . ) > /tmp/sg.json
node -e '
const r=JSON.parse(require("fs").readFileSync("/tmp/sg.json")).results;
const TD={"ff2-m2-fuera-del-adaptador":"TD-015","ff3-tabla-eventos-fuera-del-owner":"TD-016","ff5-valor-de-ambiente-hard-coded":"TD-017","ff6-satd-no-gestionada":"TD-018"};
const c={};for(const h of r){const k=h.check_id.split(".").pop()+"\t"+h.path;c[k]=(c[k]||0)+1}
console.log("regla\tarchivo\tmax\ttd\n"+Object.keys(c).sort().map(k=>k+"\t"+c[k]+"\t"+TD[k.split("\t")[0]]).join("\n"))' \
> arch/fitness/deuda-conocida.tsv
```

**Integración en CI** (la debe hacer TGR):
1. Crear un proyecto CodeBuild con `arch/fitness/buildspec-quality-gate.yml`.
2. Dispararlo con los eventos de PR de CodeCommit (`pullRequestCreated` / `pullRequestSourceBranchUpdated`).
3. Exigirlo en verde con una regla de aprobación para `develop`.

Evidencia: `arch/baseline/06-e4-quality-gate/`.

### Paso 10. E5 — Gestión de SATD (`arch/baseline/07-e5-satd`)

```bash
# Inventario: marcadores clásicos (satd.tsv del baseline) + marcadores en español (revisión manual)
node arch/scripts/satd-extendido.js back > /tmp/satd.tsv
node arch/scripts/satd-extendido.js /tmp/asis/back > /tmp/satd-asis.tsv     # AS-IS

# Deuda admitida en configuración
grep -n -iE 'TODO|FIXME|-OLD|^\s*#\s*-' back/buildspec.yml back/*/serverless.yml

# En la carpeta con credenciales (TD-006) solo se CUENTA, no se lee
grep -rcE 'TODO|FIXME|HACK' back/recaudacion/src/obligaciones/test | grep -v ':0'

# ¿Un TODO está obsoleto? Historia ignorando cambios de formato + búsqueda pickaxe
git blame -w -C -L 214,216 --date=short back/recaudacion-int/publishSnsEventos.js
git log -S"Configurar flujo Carrito" --format="%h %ad %s" --date=short -- back/recaudacion-int/publishSnsEventos.js

# ¿Un test que «pasa» rechaza por la causa correcta? Registrar temporalmente el error real y restaurar
cp back/recaudacion/__tests__/postSolicitudTest.js /tmp/pst.bak
perl -0pi -e 's/(expect\(body\.errors\.length\)\.toEqual\(1\);)/process.stdout.write("ERRMSG "+JSON.stringify(body.errors)+"\\n"); $1/g' \
  back/recaudacion/__tests__/postSolicitudTest.js
(cd back/recaudacion && npx jest __tests__/postSolicitudTest.js -t "rut como string|conceptoPago|monto como String" | grep ERRMSG)
cp /tmp/pst.bak back/recaudacion/__tests__/postSolicitudTest.js

arch/scripts/baseline.sh arch/baseline/07-e5-satd
```

Regla aplicada: un `TODO` solo se borra con evidencia (test + mutación, historia de git o error real). Si no, se acepta con la cadena *SATD → TD → owner → justificación → fecha → verificación* en `arch/debt-ledger.md`. Documento: `arch/E5-gestion-satd.md`.

### Paso 11. E6 — ADRs

`arch/adr/ADR-001` a `ADR-005`, en la plantilla del anexo C. El índice y la trazabilidad ADR ↔ FF ↔ TD ↔ tests están en `arch/adr/README.md`. Antes de cerrar un ADR, verificar con comandos cada afirmación sobre el código. Por ejemplo, qué consumidores del stream leen `payload`:

```bash
grep -n -B8 "stream:" back/recaudacion-int/serverless.yml | grep -E "handler|stream"
for f in envioGCP.mjs envioOp.js publishSnsEventos.js; do echo "$f: $(grep -c payload back/recaudacion-int/$f)"; done
```

### Paso 12. E7 — Contrato de intención para agentes

- **`AGENTS.md`** (raíz): módulos, secretos, contratos, dependencias permitidas y prohibidas, restricciones Q1–Q8 ligadas a FF, forma de trabajar, prohibiciones y evidencia obligatoria.
- **`CLAUDE.md`**: contiene `@AGENTS.md`, para que Claude Code lo cargue solo.
- **`arch/E7-architectural-intent.md`**: diseño, formato del §13, plantilla TASK INTENT y ejemplo.

**Validación con un agente independiente.** El agente no debe tener el contexto de quien escribió el contrato:

```bash
git worktree add -b validacion-agente /tmp/val-agente caso-decidarch/e1-e8
for p in recaudacion recaudacion-int; do ln -s "$PWD/back/$p/node_modules" /tmp/val-agente/back/$p/node_modules; done
(cd /tmp/val-agente && arch/fitness/quality-gate.sh)       # verde antes de empezar
```

1. Lanzar un agente nuevo con solo tres cosas: la ruta `/tmp/val-agente`, la TASK INTENT de `arch/E7-architectural-intent.md` §5 y el formato del webhook. No darle pistas sobre las reglas.
2. Al terminar, correr `quality-gate.sh` y `mutacion-ff.sh` en el worktree, revisar el diff con el checklist del anexo D y **verificar cada afirmación del informe del agente**.
3. Limpiar con `git worktree remove /tmp/val-agente && git branch -D validacion-agente`.

Resultado obtenido: el agente se detuvo sin escribir código porque la tarea violaba Q8 y ADR-003, y así se descubrió TD-026 (`arch/E7/validacion-agente-independiente.md`).

### Paso 13. E8 — Informe de evidencia (`arch/baseline/08-e8-final`)

```bash
arch/scripts/baseline.sh arch/baseline/08-e8-final
arch/fitness/quality-gate.sh > arch/baseline/08-e8-final/quality-gate.log 2>&1; echo "gate=$?"
node arch/scripts/indicadores-e8.js 04-diagnostico-e1 08-e8-final   # complejidad, duplicación, cobertura, tests, escenarios
awk -F'\t' 'NR>1{s[$1]+=$3;n[$1]++} END{for(k in s) print k, n[k]" archivos", s[k]" hallazgos"}' arch/fitness/deuda-conocida.tsv
grep "^| TD-" arch/debt-ledger.md | awk -F'|' '$7 ~ /Resuelto/ {print $2}'                    # TD resueltos
```

Documento: `arch/E8-informe-evidencia.md` (matriz del caso, métricas del stack, escenarios, triangulación §19, brechas y defensa).

### Paso 14. Commit en una rama local

```bash
git switch -c caso-decidarch/e1-e8
# Antes de commitear: ningún secreto nuevo en lo que se agrega
git status --porcelain --untracked-files=all | awk '{print $2}' \
  | xargs grep -lE 'AKIA[0-9A-Z]{16}|ASIA[0-9A-Z]{16}|aws_secret_access_key|aws_session_token|BEGIN [A-Z ]*PRIVATE KEY' 2>/dev/null
git add -A && git commit
```

---

## Mapa de baselines

| Carpeta | Momento | Qué fija |
|---|---|---|
| `01-as-is-original` | Antes de tocar nada | Métricas originales; tests 0/14 y no ejecutables |
| `02-tests-con-mock` | Fake DynamoDB | `recaudacion-int` ejecutable |
| `03-tests-recaudacion-reparados` | Tests de `recaudacion` | 16/16 |
| `04-diagnostico-e1` | E1 | Matriz AS-IS; escenarios medidos sobre `66a2873` |
| `05-post-slice-e3` | E3 | Post-refactor del slice |
| `06-e4-quality-gate` | E4 | `quality-gate.log`, `mutacion-ff.log` |
| `07-e5-satd` | E5 | SATD gestionada, inventarios extendidos AS-IS y final |
| `08-e8-final` | E8 | Matriz TO-BE + gate final |
| `arch/E7/` | Validación E7 + TD-026 | Informe del agente independiente, `quality-gate-td026.log` |

## Problemas conocidos y cómo se resolvieron

| Síntoma | Causa | Solución |
|---|---|---|
| `zsh: no matches found: --include=*.js` | zsh expande los globs | Comillas (`--include='*.js'`) o `bash -c` |
| Una regex no detecta líneas en algunos archivos | Finales de línea CRLF: en JS, `.` no matchea `\r` | `split(/\r?\n/)` |
| Fechas distintas entre la máquina y Lambda | El TZ del proceso | `process.env.TZ = 'UTC'` en `jest.config.js` (en runtime no basta) |
| Los escenarios AS-IS dan los números actuales | `impacto.js` lee el árbol actual | `SRC_ROOT=<worktree de 66a2873>` |
| Un `metavariable-regex` de Semgrep no detecta nada | Está anclado al inicio | Anteponer `.*` |
| La regla «sin SDK en el dominio» nunca falla | `exclude: node_modules` en dependency-cruiser saca las dependencias externas del grafo | Usar solo `doNotFollow` (lo detectó `mutacion-ff.sh`) |
| `Cannot find module '@aws-sdk/client-lambda'` en tests | El SDK v3 y `tgr-sdk-layer` los provee el runtime (TD-014) | `jest.mock(..., { virtual: true })` |
| Template literal roto en `resumen.js` | Comillas invertidas dentro de un template | No usar backticks en el texto |
| El ratchet falla tras **mejorar** el código | Comportamiento esperado: la deuda solo baja | Bajar el máximo o borrar la fila en `deuda-conocida.tsv` |
| `TypeError` en el log del caso 11 de `postM2Test` | Caracterización intencional de TD-024 | Ninguna; el test pasa |

## Bitácora y decisiones

El razonamiento completo, las decisiones D-01 a D-44 y los riesgos están en `../.claude/reporte.md`, fuera del repositorio. Los documentos de cada entregable están enlazados en `arch/E8-informe-evidencia.md` §8.
