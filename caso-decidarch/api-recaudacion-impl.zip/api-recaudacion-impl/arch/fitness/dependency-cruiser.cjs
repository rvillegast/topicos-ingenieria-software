// Fitness functions de dependencias (E4): FF-1 (R1) y FF-4 (R4, R5, dependencias prohibidas de E2 §3.1).
// Se ejecuta desde back/: npx dependency-cruiser@16.10.4 -c ../arch/fitness/dependency-cruiser.cjs recaudacion recaudacion-int
const SRC = '^recaudacion-int/src/';
const SDK = '(aws-sdk|@aws-sdk|axios|aws4)';

module.exports = {
  forbidden: [
    {
      name: 'ff1-sin-ciclos',
      comment: 'R1: no hay ciclos de dependencias',
      severity: 'error',
      from: {},
      to: { circular: true },
    },
    {
      name: 'ff4-modulo-solo-por-index',
      comment: 'R4: un módulo de src/ se importa solo por su index.js (integraciones/ es una carpeta de adaptadores, cada archivo es público)',
      severity: 'error',
      from: { path: SRC + '([^/]+)/' },
      to: { path: SRC + '[^/]+/.+', pathNot: [SRC + '$1/', SRC + '[^/]+/index\\.m?js$', SRC + 'integraciones/'] },
    },
    {
      name: 'ff4-handler-solo-por-index',
      comment: 'R4: los handlers importan módulos de src/ por su index.js',
      severity: 'error',
      from: { pathNot: SRC },
      to: { path: SRC + '[^/]+/.+', pathNot: [SRC + '[^/]+/index\\.m?js$', SRC + 'integraciones/'] },
    },
    {
      name: 'ff4-src-no-depende-de-handlers',
      comment: 'R5: handlers -> módulos -> integraciones/eventos, nunca al revés. Cubre también "ConfirmacionPago no depende de Notificacion ni Conciliacion" (hoy son handlers de la raíz)',
      severity: 'error',
      from: { path: SRC },
      to: { path: '^recaudacion-int/[^/]+\\.m?js$' },
    },
    {
      name: 'ff4-eventos-es-hoja',
      comment: 'R5: EventosRecaudacion no depende de otros módulos de dominio ni de integraciones',
      severity: 'error',
      from: { path: SRC + 'eventos/' },
      to: { path: ['^recaudacion-int/(src|utils|aws)/'], pathNot: SRC + 'eventos/' },
    },
    {
      name: 'ff4-integraciones-sin-dominio',
      comment: 'R5: un adaptador de proveedor no conoce módulos de dominio',
      severity: 'error',
      from: { path: SRC + 'integraciones/' },
      to: { path: SRC, pathNot: SRC + 'integraciones/' },
    },
    {
      name: 'ff4-dominio-sin-sdk',
      comment: 'E2 §3.1 forbidden dependencies: ConfirmacionPago e Institucion no usan AWS SDK ni HTTP directo (van por eventos/ o integraciones/)',
      severity: 'error',
      from: { path: SRC + '(confirmacion-pago|institucion)/' },
      to: { path: ['node_modules/' + SDK + '/', '^recaudacion-int/(aws|utils)/'] },
    },
  ],
  options: {
    doNotFollow: { path: 'node_modules' },
    exclude: { path: '(__tests__|__mocks__|/test/|test-support|testing|coverage|jest.*\\.js$|babel\\.config\\.js$)' },
    moduleSystems: ['cjs', 'es6'],
  },
};
