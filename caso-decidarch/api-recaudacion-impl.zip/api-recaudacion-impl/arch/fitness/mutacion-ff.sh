#!/usr/bin/env bash
# Mutación de fitness functions (E4): inyecta una violación por regla, corre la herramienta y restaura el archivo.
# Cada caso debe terminar en "error"/"✗", salvo el último (SATD con TD), que debe pasar. Uso: arch/fitness/mutacion-ff.sh
cd "$(dirname "$0")/../../back"
SG="${SEMGREP:-semgrep}"
BK="$(mktemp -d)"
dc() { npx -y dependency-cruiser@16.10.4 -c ../arch/fitness/dependency-cruiser.cjs recaudacion recaudacion-int 2>&1 | grep -E "^\s+error" | head -3; }
sgr() { $SG scan --metrics=off --disable-version-check -q --json --config ../arch/fitness/semgrep.yml --exclude node_modules --exclude __mocks__ --exclude test --exclude test-support --exclude testing --exclude mocks --exclude coverage --exclude 'jest*.js' --exclude babel.config.js . 2>/dev/null | node ../arch/fitness/ratchet.js | grep -E "✗|✔" | head -3; }
mut() { # $1 nombre, $2 archivo, $3 línea a agregar, $4 herramienta
  mkdir -p $BK; cp "$2" $BK/f; printf '%s\n' "$3" >> "$2"
  echo "### $1"; $4; cp $BK/f "$2"; }
mut "FF-1 ciclo"                    recaudacion-int/src/institucion/index.js "const cp = require('../confirmacion-pago');" dc
mut "FF-4 import interno"            recaudacion-int/postM2.js "const a = require('./src/confirmacion-pago/adaptadores/m2');" dc
mut "FF-4 SDK en dominio"            recaudacion-int/src/confirmacion-pago/index.js "const axios = require('axios');" dc
mut "FF-4 dominio->handler"          recaudacion-int/src/eventos/index.js "const h = require('../../callback');" dc
mut "FF-2 M2 en dominio"             recaudacion-int/src/confirmacion-pago/index.js "const f = (l) => l.Message.MessageId;" sgr
mut "FF-2 M2 nuevo en legado"        recaudacion/getSolicitud.js "const g = (p) => p.Confirmacion;" sgr
mut "FF-3 tabla en handler"          recaudacion-int/postM2.js 'const q = { TableName: `${process.env.PREFIX}-eventos` };' sgr
mut "FF-5 región en eventos"         recaudacion-int/src/eventos/index.js "const reg = 'us-east-1';" sgr
mut "FF-5 ruta SSM"                  recaudacion-int/src/institucion/index.js 'const p = `/tgr/${process.env.ENV}/x`;' sgr
mut "FF-6 SATD sin TD"               recaudacion-int/src/eventos/index.js "// TODO revisar índices" sgr
mut "FF-6 SATD con TD (debe pasar)"  recaudacion-int/src/eventos/index.js "// TODO TD-016 migrar lectores" sgr
# E5: marcadores en español, del proyecto y en tests
mut "FF-6 SATD en test"              recaudacion/__tests__/postTokenTest.js "// TODO arreglar este caso" sgr
mut "FF-6 'Caracterizado' sin TD"    recaudacion-int/src/institucion/index.js "// Caracterizado: falla con null" sgr
mut "FF-6 'parche' en español"       recaudacion-int/postM2.js "// parche hasta que el proveedor corrija" sgr
mut "FF-6 'todo' común (debe pasar)" recaudacion-int/src/eventos/index.js "// recorre todo el arreglo de items" sgr
