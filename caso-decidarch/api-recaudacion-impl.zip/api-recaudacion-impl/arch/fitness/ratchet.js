#!/usr/bin/env node
// Ratchet de deuda arquitectónica (E4, ADR-005). Lee el JSON de Semgrep por stdin y lo compara con deuda-conocida.tsv:
//  - hallazgo en código intervenido (TO-BE)                → falla: ahí la meta es 0
//  - hallazgo nuevo o más hallazgos que los aceptados      → falla
//  - menos hallazgos que los aceptados o fila sin hallazgo → falla hasta bajar el máximo (la deuda solo baja)
// ponytail: cuenta por (regla, archivo) y no por línea, para que mover código no rompa el gate.
const fs = require('fs');
const path = require('path');

const INTERVENIDO = /^(recaudacion-int\/(src\/|postM2\.js$|suscriptorSnsReplicaGenerica\.mjs$)|recaudacion(-int)?\/__tests__\/)/;
const TSV = path.join(__dirname, 'deuda-conocida.tsv');

const hallazgos = JSON.parse(fs.readFileSync(0, 'utf8')).results;
const actual = {};
for (const h of hallazgos) {
  const k = `${h.check_id.split('.').pop()}\t${h.path}`;
  (actual[k] = actual[k] || []).push(h.start.line);
}

const aceptada = {};
for (const l of fs.readFileSync(TSV, 'utf8').split('\n').slice(1).filter(Boolean)) {
  const [regla, archivo, max, td] = l.split('\t');
  aceptada[`${regla}\t${archivo}`] = { max: Number(max), td };
}

const errores = [];
for (const [k, lineas] of Object.entries(actual)) {
  const [regla, archivo] = k.split('\t');
  const a = aceptada[k];
  if (INTERVENIDO.test(archivo)) errores.push(`${regla} en código intervenido ${archivo}:${lineas.join(',')} (meta 0)`);
  else if (!a) errores.push(`${regla} nuevo en ${archivo}:${lineas.join(',')}`);
  else if (lineas.length > a.max) errores.push(`${regla} sube en ${archivo}: ${lineas.length} > ${a.max} aceptados (${a.td})`);
  else if (lineas.length < a.max) errores.push(`ratchet: ${regla} bajó en ${archivo} a ${lineas.length}; actualiza deuda-conocida.tsv (${a.td})`);
}
for (const [k, a] of Object.entries(aceptada)) {
  if (!actual[k]) errores.push(`ratchet: ${k.replace('\t', ' en ')} ya no tiene hallazgos; borra la fila (${a.td})`);
  if (!/^TD-\d{3}$/.test(a.td)) errores.push(`deuda sin gestionar: ${k} no referencia un TD-xxx`);
}

const porRegla = {};
for (const [k, l] of Object.entries(actual)) porRegla[k.split('\t')[0]] = (porRegla[k.split('\t')[0]] || 0) + l.length;
console.log('Hallazgos por regla (aceptados como deuda + nuevos):', JSON.stringify(porRegla));
errores.forEach(e => console.log('  ✗ ' + e));
console.log(errores.length ? `✗ ratchet: ${errores.length} problemas` : '✔ ratchet: sin violaciones nuevas ni en código intervenido');
process.exit(errores.length ? 1 : 0);
