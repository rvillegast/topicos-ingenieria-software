#!/usr/bin/env bash
# Quality gate del caso (E4, ADR-005). Uso: arch/fitness/quality-gate.sh   (sale con 1 si alguna fitness function falla)
# Requiere: node, npm install en back/recaudacion y back/recaudacion-int, semgrep (pip install semgrep==1.180.0; o SEMGREP=/ruta).
set -u
FIT="$(cd "$(dirname "$0")" && pwd)"
BACK="$FIT/../../back"
SEMGREP="${SEMGREP:-semgrep}"
fallas=()

paso() { echo; echo "── $1"; }

paso "FF-7 pruebas críticas: recaudacion"
(cd "$BACK/recaudacion" && npx jest --silent) || fallas+=("FF-7 tests recaudacion")

paso "FF-7 pruebas críticas: recaudacion-int + cobertura mínima del código intervenido (src/)"
(cd "$BACK/recaudacion-int" && npx jest --silent --coverage --coverageReporters=text-summary \
  --collectCoverageFrom='src/**/*.js' --coverageThreshold='{"global":{"lines":90,"branches":75}}') \
  || fallas+=("FF-7 tests/cobertura recaudacion-int")

paso "FF-1 ciclos y FF-4 dependencias prohibidas (dependency-cruiser)"
(cd "$BACK" && npx -y dependency-cruiser@16.10.4 -c "$FIT/dependency-cruiser.cjs" recaudacion recaudacion-int) \
  || fallas+=("FF-1/FF-4 dependencias")

paso "FF-2 frontera M2, FF-3 owner de eventos, FF-5 hard-coded, FF-6 SATD (Semgrep + ratchet)"
(cd "$BACK" && "$SEMGREP" scan --metrics=off --disable-version-check -q --json --config "$FIT/semgrep.yml" \
  --exclude node_modules --exclude __mocks__ --exclude test --exclude test-support \
  --exclude testing --exclude mocks --exclude coverage --exclude 'jest*.js' --exclude babel.config.js . \
  | node "$FIT/ratchet.js") || fallas+=("FF-2/3/5/6 Semgrep")

echo
if [ ${#fallas[@]} -eq 0 ]; then echo "✔ QUALITY GATE OK"; exit 0; fi
printf '✗ QUALITY GATE FALLA: %s\n' "${fallas[@]}"
exit 1
