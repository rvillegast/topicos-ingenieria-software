# E5 — Gestión de SATD

> Caso DecidArch §7 y §17.5. Meta del alcance intervenido: **UnmanagedSATD = 0**, no «SATDComments = 0».
> Evidencia: `arch/baseline/07-e5-satd/`. Registro: `arch/debt-ledger.md` (TD-012, TD-013, TD-014, TD-018 a TD-025).

## 1. Método de inventario

Buscar solo `TODO` no basta en este repo, por tres razones: el código está en español, hay deuda admitida fuera del código JS, y el propio refactor del E3 dejó comentarios que admiten comportamiento defectuoso. Por eso se usaron cuatro fuentes:

| Fuente | Herramienta | Alcance |
|---|---|---|
| Marcadores clásicos (`TODO`, `FIXME`, `HACK`, `XXX`, `TEMP`, `WORKAROUND`) | `arch/scripts/metrics.js` → `satd.tsv` | Código prod y tests (AS-IS `66a2873` y actual) |
| Marcadores en español («arreglar», «temporal», «parche», «no debería», «borrar cuando», «pendiente», «revisar»…) | `arch/scripts/satd-extendido.js` | Ídem; revisión manual de cada hallazgo |
| Deuda admitida en configuración | Revisión de `serverless.yml` y `buildspec.yml` | Nombres `-OLD`, bloques comentados |
| Deuda admitida en el código intervenido | Lectura de los comentarios de `src/`, `postM2`, suscriptor y tests | Marcadores propios del E3: «Caracterizado», «heredado» |

En `src/obligaciones/test/` (TD-006/TD-007, credenciales reales) solo se contaron marcadores, sin abrir el contenido: hay 0.

**Hallazgo de método:** la búsqueda en español no encontró SATD nueva en el legado. Los 2 hallazgos extra («mientras», «método(params, callback)») son falsos positivos revisados. En cambio, sí encontró 5 comentarios del **código que escribió el agente en el E3** que admitían defectos sin referenciar un TD. Ese es el riesgo que el caso atribuye al Vibe Coding: deuda nueva que entra con apariencia de documentación.

## 2. Inventario y clasificación

Clasificación de Maldonado & Shihab: design, defect, documentation, requirement, test.

| # | Ubicación | Texto | Tipo | Decisión | Resultado |
|---|---|---|---|---|---|
| S-01 | `publishSnsEventos.js:214` | `TODO: Configurar flujo Carrito` | Requirement | **Remove** con evidencia | Obsoleto (§3.1) |
| S-02 | `publishSnsEventos.js:393` | Ídem (flujo de cuadratura) | Requirement | **Remove** con evidencia | Obsoleto (§3.1) |
| S-03 | `getSolicitud.js:266` | `TODO: Cuando DGA tenga presupuesto … borrar las siguientes dos funciones` | Requirement (tercero) | **Accept** | TD-019 |
| S-04 | `getSolicitudes.js:44` | `TODO: Borrar IF de MOP cuando DGA configure lectura de fecha…` | Requirement (tercero) | **Accept** | TD-019 |
| S-05 | `getSolicitudes.js:156` | `TODO: Borrar funcion cuando DGA configure…` | Requirement (tercero) | **Accept** | TD-019 |
| S-06, S-07 | `postSolicitudTest.js` (2 casos) | `fechaEvento: …Items[0].fechaEvento, //TODO` | Test | **Refactor** | Aserción tautológica → formato ISO |
| S-08, S-09 | `postSolicitudTest.js` (2 casos) | `url: …callbackURL, //TODO: esto no deberia ir aca` | Design | **Accept** | TD-020 |
| S-10 | `postSolicitudTest.js` «rut como string» | `//TODO: arreglar` | Test | **Remove** con evidencia | El esquema ya rechaza (§3.2) |
| S-11 | `postSolicitudTest.js` «monto como String» | `// TODO: hay que arreglar el codigo` | Test | **Remove** con evidencia | Ídem |
| S-12 | `postSolicitudTest.js` «conceptoPago…» | `//TODO: hay que arreglar el codigo` | Defect | **Accept** | TD-021 (el rechazo es incidental, §3.2) |
| S-13 | `recaudacion-int/serverless.yml` | Lambdas `envioOP-OLD`, `dataOP-OLD` desplegadas | Design | **Accept** | TD-022 |
| S-14 | `back/buildspec.yml` | 33 líneas comentadas para desplegar `back/obligaciones/` | Design | **Remove** | TD-023 resuelto |
| S-15 | `src/institucion/index.js` (E3) | «Caracterizado: … falla (TypeError)» | Defect | **Accept** | TD-024 + test 11 nuevo |
| S-16 | `src/confirmacion-pago/index.js` (E3) | «comportamiento heredado» (varias RECIBIDA → on-prem) | Defect | **Accept** | TD-025 + test 12 nuevo |
| S-17 | `src/eventos/index.js` (E3) | «Caracterizado: el id que se informa a billetera ordena las partes distinto» | Defect | **Accept** | TD-025 |
| S-18 | `src/confirmacion-pago/index.js` (E3) | «Caracterizado (tests 3 y 9): … un rechazo a mitad deja los anteriores» | Design | **Accept** (ya registrado) | TD-013 |
| S-19 | `src/confirmacion-pago/adaptadores/m2.js` (E3) | «DateTime llega con 'Z' pero en hora de Santiago (comportamiento heredado)» | Defect | **Accept** | TD-012 ampliado |

**Totales:** 19 ítems de SATD.

| Decisión | Ítems | Cantidad |
|---|---|---|
| Remove con evidencia | S-01, S-02, S-10, S-11, S-14 | 5 |
| Refactor | S-06, S-07 | 2 |
| Accept | S-03 a S-05, S-08, S-09, S-12, S-13, S-15 a S-19 | 12, en 8 TDs |

## 3. Evidencia de las resoluciones

Borrar un comentario solo es válido si se demuestra que la condición ya no existe (§7.1, «Importante»).

### 3.1 S-01/S-02: «Configurar flujo Carrito» estaba obsoleto

- `git blame -w -C`: el `TODO` se agregó el 2021-07-14 (`93243b8`), un día después de que naciera la rama `else if (recibida.length > 1)` (`bfc8273`). Esa rama se completó después, hasta publicar en SNS.
- `publishSnsEventos` no tenía tests. Se creó `__tests__/publishSnsEventosTest.js` (4 casos): unitario; carrito en INSERT (cada `PAGO_CONFIRMADO` se publica con la `RECIBIDA` de **su** trámite y su `tipoEgreso`); carrito en MODIFY con `estado_cuad` (`PAGO_CUADRADO` por trámite); sin `RECIBIDA` no publica.
- **Mutación:** se rompió la composición de `idRecibida` en cada una de las 2 ramas de carrito. Las 2 mutaciones las detectó el test correspondiente.
- Con esa evidencia se eliminaron los 2 comentarios. El flujo de carrito existe y está protegido por FF-7.

### 3.2 S-10, S-11 y S-12: los tests de validación de `postSolicitud`

Se registró el mensaje de error real de los 3 tests, que esperaban un 400 sin verificar la causa:

| Test | Error real | Lectura |
|---|---|---|
| rut como string | `.data.receptor.rut should be integer` (esquema) | Resuelto: el `TODO` era viejo (2020-06-25, `a90863c`) |
| monto como String | `.data.recaudacion.monto should be number` (esquema) | Resuelto |
| conceptoPago en vez de conceptoRecaudacion | code 101: «El Concepto de Recaudación: **undefined**, no está registrado…» | **No resuelto:** el esquema no exige el campo; el código consulta el portal con `undefined` y el rechazo es incidental → TD-021 |

Las aserciones ahora verifican la causa (`toContain('.data.receptor.rut')`, etc.). Así, si el rechazo pasara a ocurrir por otro motivo, el test fallaría.

### 3.3 S-06/S-07: aserción tautológica

`fechaEvento: dynamodbResult.Items[0].fechaEvento` compara el valor consigo mismo. Ahora se verifica que sea un ISO UTC con milisegundos.

### 3.4 S-14: configuración muerta

`back/obligaciones/` no existe desde `ceab727` («Se quitan fuentes antiguas de obligaciones»), y sus Lambdas hoy se despliegan desde `recaudacion/serverless.yml`. Se borraron solo líneas comentadas: el diff no tiene ninguna línea activa eliminada.

### 3.5 Deuda que el E3 había dejado con apariencia de documentación

Dos comentarios del E3 decían «Caracterizado» sin que hubiera un test que lo hiciera: el `TypeError` de `institucion` y la clasificación «varias RECIBIDA → on-prem». Se agregaron los tests 11 y 12 de `postM2Test`, y los 5 comentarios ahora referencian su TD.

Además, durante el E5 el agente reformuló el comentario de S-19 como «secreto del módulo», lo que ocultaba un supuesto no validado. Se detectó al revisar y se volvió a marcar con TD-012. Queda registrado como ejemplo de por qué la regla de §7.1 no puede depender solo de la buena fe de quien escribe el comentario.

## 4. Deuda aceptada: cadena completa (§7.1)

SATD → Issue → Owner → Rationale → DueDate → Verification. Los owners son roles, porque las personas las asigna TGR. Las fechas son propuestas a validar con TGR.

| Issue | SATD | Owner | Rationale | DueDate | Verification |
|---|---|---|---|---|---|
| TD-019 | S-03 a S-05 | Product owner Recaudación TGR + contraparte DGA | Depende de que DGA lea el formato estándar | Revisión 2027-03-31 | Test «TD-019» de `getSolicitudesTest` (nuevo) pasa a esperar el formato estándar; se borran las 2 funciones `getResponseItemMOP` |
| TD-020 | S-08, S-09 | equipo caso | `url` lo leen `callback.js` y el carrito; retirarlo es parte de mover `RECIBIDA` a EventosRecaudacion | Con TD-016, 2027-01-31 | Ningún lector de `.url`; el test de `postSolicitud` sin `url` |
| TD-021 | S-12 | Product owner API Recaudación TGR | Corregirlo cambia el error de una API pública fuera del slice | 2027-01-31 | El test espera error de esquema `required` y ninguna llamada al portal |
| TD-022 | S-13 | Operaciones TGR | `envioOP-OLD` sigue con trigger del stream; no se puede retirar sin datos de producción | 2026-12-31 | `Invocations` de CloudWatch = 0 durante 30 días y reemplazo identificado |
| TD-024 | S-15 | Product owner Recaudación TGR | La regla correcta no está definida | 2027-01-31 | Test 11 de `postM2Test` con la regla acordada |
| TD-025 | S-16, S-17 | equipo caso + equipo Billetera | Billetera y los consumidores pueden depender de esos ids | 2027-01-31 | Tests 2, 3 y 12 con la regla acordada |
| TD-013 | S-18 | equipo Billetera TGR | No hay contrato de reversa | 2027-03-31 | Test 9 espera la reversa o el rechazo de todo el carrito |
| TD-012 | S-19 y la conversión XML | equipo caso + integración on-prem TGR | Requiere validar el formato con on-prem y con el proveedor | 2027-01-31 | Test del suscriptor (invierno y verano) y test 10 (`emitidoEn`) |

TD-014 (dependencias implícitas del runtime) también recibió owner, fecha y verificación, porque afecta al código intervenido.

## 5. Automatización: FF-6 ampliada

FF-6 (`arch/fitness/semgrep.yml`) era la regla del E4 para «SATD sin `TD-xxx`». En el E5 se amplió:

- **Marcadores:** a `TODO`, `FIXME`, `HACK`, `XXX` y `WORKAROUND` se suman «arreglar», «temporal», «provisorio», «parche», «no debería», «caracterizado» y «heredado». `TODO` sigue siendo sensible a mayúsculas, porque «todo» es una palabra común en español.
- **La referencia `TD-xxx` puede estar en cualquier parte del comentario.** El regex se ancla al inicio del comentario, y antes no aceptaba `// TD-025: … heredado`.
- **Alcance:** también los tests (`__tests__/`), que ahora cuentan como código intervenido (meta 0). FF-2, FF-3 y FF-5 siguen excluyendo los tests.

Validación (`mutacion-ff.sh`, ahora con 15 casos; log en `06-e4-quality-gate/mutacion-ff.log`):

| Violación inyectada | Resultado |
|---|---|
| `// TODO arreglar este caso` en un test | ✗ detectada |
| `// Caracterizado: falla con null` en `src/institucion` | ✗ |
| `// parche hasta que el proveedor corrija` en `postM2` | ✗ |
| `// recorre todo el arreglo de items` | ✔ pasa (no es SATD) |
| `// TODO TD-016 migrar lectores` | ✔ pasa (gestionada) |

El *ratchet* del E4 funcionó como estaba previsto: cuando la SATD legada bajó a 0, el gate falló hasta que se borraron las 3 filas `ff6` de `deuda-conocida.tsv` (43 → 40 filas). FF-6 ya no tiene deuda aceptada en la lista: cualquier SATD sin `TD-xxx`, en cualquier archivo, bloquea el merge.

## 6. Estado final

| Indicador | AS-IS (04) | Post-E3 (05) | Post-E5 (07) |
|---|---|---|---|
| Comentarios SATD (`satd.tsv`) | 12 (5 prod, 7 test) | 12 | **3** (prod, todos `TD-019`) |
| SATD no gestionada (sin TD) | 12 | 12 + 5 implícitas del E3 | **0** |
| SATD no gestionada en el alcance intervenido | — | 7 (tests) + 5 (`src/`) | **0** |
| Deuda en configuración sin registrar | 2 | 2 | **0** (TD-022 aceptada, TD-023 resuelta) |
| Tests `recaudacion` / `recaudacion-int` | 0/14 / 8 (+6 skip) | 16 / 23 | **17 / 33** |
| Cobertura de líneas `recaudacion-int` | 14,56 % | 27,31 % | **40,69 %** |
| Quality gate | — | — | ✔ (`07-e5-satd/quality-gate.log`) |

**UnmanagedSATD = 0** en el alcance intervenido y también en el resto del repositorio. Los 3 `TODO` que quedan están gestionados (TD-019) y caracterizados por un test. Se cumple la condición del caso: «la condición señalada fue corregida, transformada en una decisión consciente o registrada como deuda gestionada».

## 7. Cómo reproducir

```bash
arch/scripts/baseline.sh arch/baseline/<nombre>              # satd.tsv + RESUMEN («SATD no gestionada»)
node arch/scripts/satd-extendido.js back                       # inventario en español
SEMGREP=semgrep arch/fitness/quality-gate.sh                   # FF-6 en el gate
SEMGREP=semgrep arch/fitness/mutacion-ff.sh                    # 15 casos
```
