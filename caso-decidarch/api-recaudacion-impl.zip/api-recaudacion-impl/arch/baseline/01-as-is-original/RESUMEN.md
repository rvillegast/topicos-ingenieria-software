# Baseline AS-IS — api-recaudacion-impl

Generado por `arch/scripts/baseline.sh`. Detalle en los TSV/JSON de esta carpeta.

## Matriz E8 (columna AS-IS)

| Indicador | AS-IS | Fuente |
|---|---|---|
| SATD no gestionada (código prod) | 5 (total con tests: 12) | satd.tsv |
| Ciclos entre módulos (carpetas) | 1 | ciclos.txt |
| Ciclos entre archivos | 0 | ciclos.txt |
| Dependencias prohibidas | n/d (sin reglas definidas aún) | — |
| Hard-coded (URLs/IP/ambiente) en prod | 6 | hardcoded.tsv |
| Tablas con más de un escritor (sin owner) | 2 | tablas.tsv |
| Funciones con complejidad > 10 | 17 | complejidad.json |
| Funciones > 50 líneas | 46 | complejidad.json |
| Anidamiento > 4 | 36 | complejidad.json |
| Duplicación (bloques ≥10 líneas) | 22.75% (87 clones) | jscpd/ |
| Tests que pasan | recaudacion: 0/14 · recaudacion-int: no ejecutable | tests-*.json |
| Cobertura de líneas | recaudacion: 9.69% · recaudacion-int: - | coverage-*/ |
| ADRs | 0 | — |
| Fitness functions | 0 | — |

## Tamaño
- Archivos prod: 66 (11515 LOC) · test: 46 (3812 LOC)
- Archivos prod > 500 LOC: 5 · mayor: `recaudacion/postSolicitud.js` (1189 LOC)
- Dependencias internas (require/import): 129

## Ciclos
```
Ciclos entre archivos: 0

Ciclos entre carpetas: 1
  recaudacion/src/obligaciones/dss <-> recaudacion/src/obligaciones
```

## Ownership de datos (archivos que leen / escriben)
| Tabla | Lee | Escribe |
|---|---|---|
| `tgr-{ENV}-api-portal-autoservicios-conceptos-instituciones` | 1 | 0 |
| `tgr-{ENV}-api-recaudacion-eventos` | 8 | 6 |
| `tgr-{ENV}-api-recaudacion-m1-security` | 1 | 0 |
| `tgr-{ENV}-api-recaudacion-obligaciones` | 4 | 1 |
| `tgr-{ENV}-conceptos-instituciones` | 0 | 2 |

## Complejidad: top 10 funciones
| CC | Archivo:línea | Función |
|---|---|---|
| 40 | `back/recaudacion/src/obligaciones/descargos.js:19` | Async arrow function |
| 36 | `back/recaudacion/postSolicitud.js:29` | Async arrow function |
| 33 | `back/recaudacion/postSolicitud.js:730` | Async function 'procesoRecaudacionCarrito' |
| 32 | `back/recaudacion-int/postM2.js:10` | Async arrow function |
| 31 | `back/recaudacion/postSolicitud.js:390` | Async function 'procesoRecaudacion' |
| 28 | `back/recaudacion-int/publishSnsEventos.js:15` | Async arrow function |
| 24 | `back/recaudacion/getSolicitud.js:9` | Async arrow function |
| 21 | `back/recaudacion/src/obligaciones/consulta.js:21` | Async arrow function |
| 13 | `back/recaudacion/src/obligaciones/avisoRecibo.js:100` | Function 'validarCID' |
| 13 | `back/recaudacion/utils/adf.js:3` | Async function |

## SATD en código productivo
| Archivo:línea | Texto |
|---|---|
| `recaudacion/getSolicitud.js:266` | Cuando DGA tenga presupuesto para que un programador configure la recepcion de un arreglo de datos y la fecha en formato correcto, borrar las siguientes |
| `recaudacion/getSolicitudes.js:44` | Borrar IF de MOP cuando DGA configure lectura de fecha con formato correcto. |
| `recaudacion/getSolicitudes.js:156` | Borrar funcion cuando DGA configure lectura correcta de fechaPago. |
| `recaudacion-int/publishSnsEventos.js:214` | Configurar flujo Carrito |
| `recaudacion-int/publishSnsEventos.js:393` | Configurar flujo Carrito |

## Hard-coded por destino
- `https://wstest.tesoreria.cl`: 4
- `127.0.0.1`: 1
- `https://www.google.cl`: 1

## Integraciones externas (archivos prod por tipo)
- aws-dynamodb: 10
- aws-lambda: 3
- aws-s3: 3
- aws-sigv4: 7
- aws-sns: 2
- gcp: 4
- http(axios/https): 22
- jwt/oauth: 11
- oracle: 7
- tgr-sdk(layer): 8
- xml/soap: 4

## Tests
| Subproyecto | Tests OK | Suites OK | Líneas | Ramas | Observación |
|---|---|---|---|---|---|
| recaudacion | 0/14 | 0/5 | 9.69% | 1.6% |  |
| recaudacion-int | no ejecutable | - | - | - | Unable to locate a Java Runtime |

