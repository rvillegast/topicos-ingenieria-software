# Baseline AS-IS — api-recaudacion-impl

Generado por `arch/scripts/baseline.sh`. Detalle en los TSV/JSON de esta carpeta.

## Matriz E8 (columna AS-IS)

| Indicador | AS-IS | Fuente |
|---|---|---|
| SATD no gestionada (código prod) | 5 (total con tests: 12) | satd.tsv |
| Ciclos entre módulos (carpetas) | 1 | ciclos.txt |
| Ciclos entre archivos | 0 | ciclos.txt |
| Dependencias prohibidas | n/d (sin reglas definidas aún) | — |
| Hard-coded (URL/IP/ambiente/región/ruta SSM) en prod | 27 | hardcoded.tsv |
| Tablas con más de un escritor (sin owner) | 2 | tablas.tsv |
| Funciones con complejidad > 10 | 16 | complejidad.json |
| Funciones > 50 líneas | 45 | complejidad.json |
| Anidamiento > 4 | 26 | complejidad.json |
| Duplicación (bloques ≥10 líneas) | 22.44% (83 clones) | jscpd/ |
| Tests que pasan | recaudacion: 16/16 · recaudacion-int: 23/23 | tests-*.json |
| Cobertura de líneas | recaudacion: 14.19% · recaudacion-int: 27.28% | coverage-*/ |
| ADRs | 0 | — |
| Fitness functions | 0 | — |

## Tamaño
- Archivos prod: 71 (11386 LOC) · test: 51 (3900 LOC)
- Archivos prod > 500 LOC: 5 · mayor: `recaudacion/postSolicitud.js` (1189 LOC)
- Dependencias internas (require/import): 137

## Ciclos
```
Ciclos entre archivos: 0

Ciclos entre carpetas: 1
  recaudacion/src/obligaciones/dss <-> recaudacion/src/obligaciones
```

## Ownership de datos (archivos distintos que leen / escriben)
| Tabla | Lee | Escribe |
|---|---|---|
| `tgr-{ENV}-api-portal-autoservicios-conceptos-instituciones` | 1 | 0 |
| `tgr-{ENV}-api-recaudacion-eventos` | 11 | 5 |
| `tgr-{ENV}-api-recaudacion-m1-security` | 1 | 0 |
| `tgr-{ENV}-api-recaudacion-obligaciones` | 4 | 3 |
| `tgr-{ENV}-conceptos-instituciones` | 2 | 0 |

## Complejidad: top 10 funciones
| CC | Archivo:línea | Función |
|---|---|---|
| 40 | `back/recaudacion/src/obligaciones/descargos.js:19` | Async arrow function |
| 36 | `back/recaudacion/postSolicitud.js:29` | Async arrow function |
| 33 | `back/recaudacion/postSolicitud.js:730` | Async function 'procesoRecaudacionCarrito' |
| 31 | `back/recaudacion/postSolicitud.js:390` | Async function 'procesoRecaudacion' |
| 28 | `back/recaudacion-int/publishSnsEventos.js:15` | Async arrow function |
| 24 | `back/recaudacion/getSolicitud.js:9` | Async arrow function |
| 21 | `back/recaudacion/src/obligaciones/consulta.js:21` | Async arrow function |
| 13 | `back/recaudacion/src/obligaciones/avisoRecibo.js:100` | Function 'validarCID' |
| 13 | `back/recaudacion/utils/adf.js:3` | Async function |
| 13 | `back/recaudacion/utils/adf.js:114` | Async function |

## SATD en código productivo
| Archivo:línea | Texto |
|---|---|
| `recaudacion/getSolicitud.js:266` | Cuando DGA tenga presupuesto para que un programador configure la recepcion de un arreglo de datos y la fecha en formato correcto, borrar las siguientes |
| `recaudacion/getSolicitudes.js:44` | Borrar IF de MOP cuando DGA configure lectura de fecha con formato correcto. |
| `recaudacion/getSolicitudes.js:156` | Borrar funcion cuando DGA configure lectura correcta de fechaPago. |
| `recaudacion-int/publishSnsEventos.js:214` | Configurar flujo Carrito |
| `recaudacion-int/publishSnsEventos.js:393` | Configurar flujo Carrito |

## Hard-coded por destino
- `us-east-1`: 18
- ``/tgr/${process.env.ENV}/api-recaudacion/back/``: 4
- ``/tgr/${process.env.ENV}/api-recaudacion/back/wstIntentoPago/``: 2
- `127.0.0.1`: 1
- `https://www.google.cl`: 1
- ``/tgr/${process.env.ENV}/api-recaudacion/back/wallet/``: 1

## Integraciones externas (archivos prod por tipo)
- aws-dynamodb: 10
- aws-lambda: 3
- aws-s3: 3
- aws-sigv4: 7
- aws-sns: 2
- gcp: 4
- http(axios/https): 22
- jwt/oauth: 11
- oracle: 7
- tgr-sdk(layer): 8
- xml/soap: 5

## Tests
| Subproyecto | Tests OK | Suites OK | Líneas | Ramas | Observación |
|---|---|---|---|---|---|
| recaudacion | 16/16 | 4/4 | 14.19% | 9.52% |  |
| recaudacion-int | 23/23 | 7/7 | 27.28% | 24.59% |  |

