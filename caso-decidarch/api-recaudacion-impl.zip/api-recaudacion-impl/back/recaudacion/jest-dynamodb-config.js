process.argv.push('--config');
process.argv.push('serverless.debug.yml');

module.exports = async () => {
    const serverless = new (require('serverless'))();
    
    await serverless.init();
    const service = await serverless.variables.populateService();
    const resources = (Array.isArray(service.resources) ? service.resources[0] : service.resources).Resources;
    
    const tables = Object.keys(resources)
        .map(name => resources[name])
        .filter(r => r.Type === 'AWS::DynamoDB::Table')
        .map(r => r.Properties);
    
    return {
        tables,
        port: process.env.CONFIG_DYNAMODB_PORT
    }
}

/*module.exports = {
    tables: [
        {
            TableName: 'tgr-dev-api-recaudacion-eventos',
            KeySchema: [
                {AttributeName: 'id', KeyType: 'HASH'},
                {AttributeName: 'fechaEvento', KeyType: 'RANGE'}],
            AttributeDefinitions: [
                {AttributeName: 'id', AttributeType: 'S'},
                {AttributeName: 'fechaEvento', AttributeType: 'S'},
                {AttributeName: 'institucion', AttributeType: 'S'}
            ],
            BillingMode: "PAY_PER_REQUEST",
            GlobalSecondaryIndexes: [{
                IndexName: 'tgr-dev-api-recaudacion-eventos-idx',
                Projection: {
                    ProjectionType: "ALL"
                },
                KeySchema: [{
                    AttributeName: 'institucion',
                    KeyType: 'HASH'
                }, {
                    AttributeName: 'fechaEvento',
                    KeyType: 'RANGE'
                }]
            }]
        }
    ]
}*/
