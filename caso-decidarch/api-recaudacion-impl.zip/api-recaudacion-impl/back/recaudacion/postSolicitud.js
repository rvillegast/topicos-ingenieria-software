'use strict';

const queryDB = require('./aws/dynamoDbServices');
const token = require("./token");
const billetera = require("./utils/billetera");
const adf = require("./utils/adf");
const cid = require("./utils/validaCID");
const param = require("./utils/prepParam");
const s3 = require('./aws/s3Services');
const moment = require('moment-timezone');
const AWS = require('aws-sdk');
const util = require("./util");
var convert = require('xml-js');
var fs = require('fs');
const _ = require('lodash');
const validar = require("./validarJson");
const validarEntrada = require("./validaciones");
const urlPortalPagos = process.env.PATH_PORTAL_PAGOS;
const urlPortalPagosMock = process.env.PATH_PORTAL_PAGOS_MOCK;
const urlBotonPagoCloud = process.env.BOTON_PAGO_CLOUD_BASE_URL;
const tolerancia = process.env.TOLERANCIA;
const axios = require('axios');
const aws4 = require('aws4');
global.mapBilletera = new Map();
const detalleConcepto = new Map();
let responseAllConceptosLocal;
let errorConceptos;

exports.handler = async (event) => {
    console.log('event: ', event);

    let errores = [];

    const json = JSON.parse(event.body);
    let path = event.path.split("/")[3];
    console.log("Path: " + path);
    let config = await s3.getObjectJSON(process.env.BUCKET_NAME, 'config.json'); // Cargar datos de S3.
    // Se atienden mensajes que utilizan M1 onpremise
    if (path === "solicitudes2") {
        var institucion = json.data.institucion;
        var environment = "PRODUCCION";
        return await procesoRecaudacion(json, institucion, environment, config);
    }
    // Se atienden M1 Cloud
    else {
        // Flujo carrito
        if (Array.isArray(json.data)) {
            try {
                console.time('=====> Total');
                console.time('=====> Validaciones Iniciales');
                var { institucion, environment } = await util.getDataFromToken(event.headers.Authorization); // Obtener informacion desde Token.
                await validar.validarJsonCarrito(json);
                await validarEntrada.validarIdTramiteYDv(json);

                //Se valida que un mismo concepto utilice la misma billetera
                //y que una billetera solo sea ocupado por el mismo concepto
                await validarEntrada.validacionesConceptoBilletera(json.data);

                let salida;
                let respuesta = [];
                let vecData = json.data;
                let metadata = json.metadata;

                //Se valida que la suma de los montos de los tramite sea igual al monto total
                await validarEntrada.validacionMontoTotal(json.data, metadata.montoCarrito);

                //Se valida que la moneda de cada trámite sea CLP
                await validarEntrada.validacionMonedaCLP(json.data);

                //Validaciones de carga
                //Validamos que haya al menos un F18B
                console.time('=====> Preparacion de conceptos');
                detalleConcepto.clear();
                try {
                    responseAllConceptosLocal = await getAllConceptosByInstitucion(institucion);
                } catch (e) {
                    let error = {
                        statusCode: 400,
                        body: JSON.stringify({
                            errors: [{
                                message: e.message ? e.message : `Error al consultar conceptos para la institución ${institucion}: ${err}`,
                                codError: 400
                            }]
                        })
                    }
                    console.log(`Error al consultar conceptos para la institución ${institucion}: ${e}`);
                    throw error;
                }
                const conceptos = [... new Set(vecData.map(tramite => tramite.conceptoRecaudacion))];
                let e;
                await Promise.all(conceptos.map(async (concepto) => {
                    try {
                        let results = responseAllConceptosLocal.data.data.conceptos;
                        e = validarEntrada.validacionesConcepto(results, institucion, concepto); //VALIDA CONCEPTO
                        errorConceptos = e;
                        if(e !== null) {
                            console.log(e);
                            throw e;
                        }
                        const resp = await getDetalleConceptoInstitucion(concepto, institucion);
                        detalleConcepto.set(concepto, resp);
                    }catch(err) {
                        let error = {
                            statusCode: 400,
                            body: JSON.stringify({
                                errors: [{
                                    message: err.message ? err.message : `Error al consultar concepto ${concepto}: ${err}`,
                                    codError: 400
                                }]
                            })
                        }
                        console.log(`Error al consultar concepto ${concepto}: ${err}`);
                        throw error
                    }
                }));
                console.timeEnd('=====> Preparacion de conceptos');
                const cid_present = vecData.some(tramite => tramite.recaudacion.cid);
                const is_f18b = [...detalleConcepto.values()].some(concepto => cid_present && concepto.data.data.formulario === '18');
                const limit = 70;
                if (vecData.length > limit) {
                    let error = {
                        statusCode: 400,
                        body: JSON.stringify({
                            errors: [{
                                message: `Se ha superado el límite de carga de ${limit} trámites.`,
                                codError: 400
                            }]
                        })
                    }
                    console.log(`Se ha superado el límite de carga de ${limit} trámites.`);
                    throw error;
                }

                if (cid_present) {
                    const repetidos = buscarCidDuplicados(vecData);
                    if (repetidos.length > 0) {
                        const errors = [];
                        repetidos.forEach(cid => { 
                            const message = `Error de Validación: CID repetido: ${cid}`;
                            console.log(message);
                            errors.push({
                                message,
                                codError: 400
                            })
                        })
                        const error = {
                            statusCode: 400,
                            body: JSON.stringify({
                                errors
                            })
                        }
                        throw error;
                    }
                }

                console.timeEnd('=====> Validaciones Iniciales')

                //Se procesa cada subtramite del carrito
                console.time('=====> Preparar Parametros y ValidaADF');
                for (let i in vecData) {
                    salida = await procesoRecaudacionCarrito(vecData[i], institucion, environment, config, metadata);
                    const validation_error = (salida.body && JSON.parse(salida.body).errors)
                    if (salida.errors || validation_error) {
                        const list = validation_error ? JSON.parse(salida.body).errors : [];
                        let validation_error_list = [];
                        if(list.length > 0) {
                            list.map(err_list => err_list.message.map(err => validation_error_list.push(`${err.message} idTramite: ${vecData[i].idTramite}`)));  
                        }
                        const error_list_messages = salida.errors ? salida.errors : [];
                        const error_list = [];
                        error_list_messages.map(err => error_list.push(`${err} idTramite: ${vecData[i].idTramite}`));
                        const messages = [
                            ...validation_error_list,
                            ...error_list
                        ];
                        const errors = [];
                        messages.forEach(message => errors.push({message, codError: 400}));
                        let error = {
                            statusCode: 400,
                            body: JSON.stringify({errors})
                        }
                        throw error;
                    } else {
                        salida.subtramite.contribuyente = metadata.contribuyente;
                        salida.subtramite.callbackURL = metadata.callbackURL;
                    }
                    respuesta.push(salida);
                }
                console.timeEnd('=====> Preparar Parametros y ValidaADF');

                console.time('=====> Guardar data en Nube');
                //Se limpia map que realiza el manejo de las billeteras para el carrito
                global.mapBilletera.clear();

                let idExt = await param.generarIdExterno();
                var idGirador = "";
                var fechaOrigen = "";

                let billeteraConcepto = new Map();
                let billeteraMonto = new Map();
                let sumaAbonoBill;
                let sumaTotalPagar = 0;
                let sumaTotalPagarValidacion = 0;
                let listaForms = []
                for (let j in respuesta){
                    sumaTotalPagarValidacion += respuesta[j].intentoPago.montoTotal;
                }
                console.log("sumaTotalPagarValidacion: ",sumaTotalPagarValidacion);
                console.log("monto carrito: ",json.metadata.montoCarrito);
                // Se calcula que diferencia de lo calculado por adf y el monto del carro
                // no se mayor a cierta tolerancia
                if(Math.abs(parseInt(sumaTotalPagarValidacion) - parseInt(json.metadata.montoCarrito)) > tolerancia){
                    let error = {
                        statusCode: 400,
                        body: JSON.stringify({
                            errors: [{
                                message: 'Error de validación: Monto carrito informado no corresponde según reglas de liquidación de moneda.',
                                codError: 400
                            }]
                        })
                    }
                    throw error;
                }
                for (let i in respuesta) {
                    sumaAbonoBill = 0;
                    let fechaEvento = moment().toISOString();
                    if (idGirador == "") {
                        idGirador = respuesta[i].idGirador;
                    }

                    if (fechaOrigen == "") {
                        fechaOrigen = respuesta[i].fechaOrigen;
                    }
                    listaForms.push(respuesta[i].intentoPago);
                    sumaTotalPagar += respuesta[i].intentoPago.montoTotal;
                    let data = { data: respuesta[i].subtramite };

                    //Se guarda cada subtramite a la BD
                    await queryDB.putItemCarrito(data, institucion, environment, respuesta[i].intentoPago.formCod, idGirador,
                        idExt + "#" + respuesta[i].subtramite.idTramite, respuesta[i].intentoPago.formFolio, fechaEvento, metadata.callbackURL); // Persistir data en DynamoDB.

                    //Se calcula el monto abonado a cada billetera
                    if (respuesta[i].subtramite.idBilletera != undefined) {
                        billeteraConcepto.set(respuesta[i].subtramite.idBilletera, respuesta[i].subtramite.conceptoRecaudacion);
                        if (billeteraMonto.has(respuesta[i].subtramite.idBilletera)) {
                            sumaAbonoBill = billeteraMonto.get(respuesta[i].subtramite.idBilletera);
                            sumaAbonoBill += respuesta[i].subtramite.recaudacion.monto;
                            billeteraMonto.set(respuesta[i].subtramite.idBilletera, sumaAbonoBill);
                        } else {
                            sumaAbonoBill += respuesta[i].subtramite.recaudacion.monto;
                            billeteraMonto.set(respuesta[i].subtramite.idBilletera, sumaAbonoBill);
                        }
                    }

                }
                console.timeEnd('=====> Guardar data en Nube');

                console.time('=====> Intento Pago');
                //Se prepara data para intento de pago
                let dataintentoPago = {
                    data: {
                        "idGirador": idGirador,
                        "fechaOrigen": fechaOrigen,
                        "idExterno": idExt,
                        "totalPagar": sumaTotalPagar,
                        "listaFormularios": listaForms
                    }
                };
                console.log();
                let redirectURL;
                // Intento de pago solo para un tramite F18B
                let guardarGiroResult
                if(listaForms.length !== 0) {
                    try{
                        guardarGiroResult = await guardaGiroCarrito(dataintentoPago);
                        console.log("Respuesta guardarGiroCarrito: ", guardarGiroResult);
                        console.log("Respuesta guardarGiroCarrito data: " + JSON.stringify(guardarGiroResult.data));
                    } catch(e) {
                        console.log('Inicio Error guardaGiroCarrito');
                        console.log('Request Payload: ', dataintentoPago);
                        console.log('Request Error: ', e);
                        let errMessage = e.response?.data?.message ?? e.message ?? 'Ha ocurrido un error inesperado al intentar guardar giro.';
                        console.log(`Mensaje: [${e.code}]`, errMessage);
                        console.log('Fin Error guardaGiroCarrito');
                        let error = {
                            statusCode: 400,
                            body: JSON.stringify({
                                errors: [{
                                    message: 'Ha ocurrido un error inesperado al intentar guardar giro.',
                                    codError: 400
                                }]
                            })
                        }
                        throw error;
                    }
                }
                if (!is_f18b && guardarGiroResult.data.data.codRetorno != 0) {
                    console.log('Inicio Error guardarGiroResult:');
                    console.log('Request Payload: ', dataintentoPago);
                    console.log('Request Error: ', guardarGiroResult);
                    console.log('Fin Error guardarGiroResult:');
                    let error = {
                        statusCode: 400,
                        body: JSON.stringify({
                            errors: [{
                                message: "Error al realizar intento de pago: " + guardarGiroResult.data.data.msjRetorno,
                                codError: 400
                            }]
                        })
                    }
                    throw error;
                }
                if (is_f18b) {
                    const ambiente = process.env.ENV;
                    // const url = urlEnvioMedioPago;
                    let listaCodBarra = [];
                    if(guardarGiroResult && guardarGiroResult.data.data.codigoBarra) {
                        listaCodBarra.push({
                            'codigoBarra': guardarGiroResult.data.data.codigoBarra,
                            'monto': dataintentoPago.data.totalPagar
                        });
                    }
                    const url = process.env.boton_pago_url;
                    const body = new URLSearchParams();
                    body.append('listaContribuciones', `on, ${listaCodBarra.length > 0 ? listaCodBarra[0].codigoBarra + ', ' : ''}`);
                    body.append('CANAL', 'AWS');
                    const resp = await axios.post(url, body, {
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        }
                    });
                    console.log('resp', resp.data);
                    const match = resp.data.match(/window\.top\.location\.href\s*=\s*["']([^"']+)["']/);
                    if (!match) {
                        let error = {
                        statusCode: 400,
                        body: JSON.stringify({
                            errors: [{
                                message: `Error de validación: No se ha encontrado URL de pago para flujo F18B.`,
                                codError: 400
                            }]
                        })
                        }
                        throw error;
                    }
                    console.log('match', match);
                    redirectURL = match[1];
                    console.log(redirectURL);
                } else {
                    redirectURL = await getRedirectUrl(environment, institucion, metadata, idExt);
                }
                console.timeEnd('=====> Intento Pago');

                console.time('=====> Respuesta Final')
                let billeteras = []
                for (let elem of billeteraConcepto.entries()) {
                    billeteras.push({
                        billetera: elem[0],
                        concepto: elem[1],
                        monto: billeteraMonto.get(elem[0])
                    });
                }

                let response = {
                    statusCode: 200,
                    body: JSON.stringify({
                        id: idExt,
                        redirectURL: redirectURL,
                        montoTotal: metadata.montoCarrito,
                        billeteras
                    })
                };
                console.log(response);
                console.timeEnd('=====> Respuesta Final');
                console.timeEnd('=====> Total');
                return response;
            } catch (ex) {
                console.log(ex);
                if (ex.statusCode === 400) {
                    return ex;
                }
            }
        } else {
            var { institucion, environment } = await util.getDataFromToken(event.headers.Authorization); // Obtener informacion desde Token.
            return await procesoRecaudacion(json, institucion, environment, config);
        }
    }
};

async function procesoRecaudacion(json, institucion, environment, config) {
    let errores = [];
    try {
        console.time('=====> Total');
        console.log("institucion: " + institucion);
        console.log("environment: " + environment);
        console.time('=====> Validaciones Iniciales y Preparar Parametros');

        let formulario, girador, etapa, modelo, modeloCut;
        let responseAllConceptos = await getAllConceptosByInstitucion(institucion);
        let results = responseAllConceptos.data.data.conceptos;
        let e = validarEntrada.validacionesConcepto(results, institucion, json.data.conceptoRecaudacion); //VALIDA CONCEPTO

        if (json.data.id) {
            await validarEntrada.validacionesIdExt(json.data.id);
        }

        if (e !== null) {
            errores.push(e);
            let response = {
                statusCode: 400,
                body: JSON.stringify({
                    errors: errores
                })
            };
            console.log(response);
            return response;
        } else { // Si concepto es valido

            let detalleConceptoInstitucion = await getDetalleConceptoInstitucion(json.data.conceptoRecaudacion, institucion); // Obtener detalle de tabla Conceptos.

            etapa = detalleConceptoInstitucion.data.data.etapa; // Obtener etapa

            if (environment === 'PRODUCCION' && etapa === 'CERTIFICACION') { // Validar etapa
                let response = {
                    statusCode: 400,
                    body: JSON.stringify({
                        message: `No puede usar credenciales de producción si la integración del concepto: ${json.data.conceptoRecaudacion} aun esta en etapa de certificación`,
                        code: 17002
                    })
                }

                console.log(response);
                return response;
            } else {
                formulario = detalleConceptoInstitucion.data.data.formulario;
                girador = detalleConceptoInstitucion.data.data.codigoInstitucionOnPrem;
                modelo = detalleConceptoInstitucion.data.data.modelo;
                modeloCut = detalleConceptoInstitucion.data.data.modeloCut;
                console.log('Modelo: ', modelo);
                var parametros, billeteraSalida;

                if (modelo == 'EGRESO_AUTOMATICO') {
                    let resultadoVal = await validar.validarjson(json); // Validar JSON de entrada con Swagger
                    errores = validarEntrada.validacionesCuenta(json.data); //VALIDA TIPO CUENTA
                    parametros = await param.prepararParametros(json, config);
                } else if (modelo == 'EGRESO_CUENTA_FIJA') {
                    let resultadoVal = await validar.validarjsonV2(json); // Validar JSON de entrada con Swagger
                    errores = validarEntrada.validacionesDatos(json.data); //VALIDA DATOS JSON
                    parametros = await param.prepararParametrosV2(json, config);
                } else if (modelo == 'EGRESO_DIFERIDO') {
                    let resultadoVal = await validar.validarjsonV2(json); // Validar JSON de entrada con Swagger
                    errores = validarEntrada.validacionesDatos(json.data); //VALIDA DATOS JSON
                    parametros = await param.prepararParametrosV2(json, config);

                    let billeteraEntrada = json.data.recaudacion.idBilletera; //VERIFICAMOS SI VIENE BILLETERA

                    if (billeteraEntrada == undefined) {

                        console.log('Crear Billetera');
                        let idBilletera = await billetera.crearBilletera(institucion); //SE CREA BILLETERA

                        json.data.recaudacion.idBilletera = idBilletera; //Se agrega billetera a payload
                        billeteraSalida = idBilletera;

                        console.log('Crear relación Billetera-Institucion');
                        billetera.crearBilleteraInstitucion(idBilletera, institucion); //SE CREA RELACIÓN BILLETERA-INSTITUCIÓN EN PORTAL AUTOSERVICIO
                    } else {
                        console.log('Buscar Billetera');
                        let salidaBusqueda = await billetera.buscarBilletera(billeteraEntrada);
                        if (salidaBusqueda.data !== undefined) {
                            billeteraSalida = salidaBusqueda.data.idBilletera; // Existe billetera
                        } else {
                            console.log("no existe billetera");
                            let e = validarEntrada.validacionBilletera(); // No existe billetera
                            if (e !== null) {
                                errores.push(e);
                            }
                        }
                    }
                }
            }
            console.timeEnd('=====> Validaciones Iniciales y Preparar Parametros');

            //SI HAY DATOS CON ERRORES SE RECHAZA
            if (!_.isEmpty(errores)) {
                let response = {
                    statusCode: 400,
                    body: JSON.stringify({
                        errors: errores
                    })
                };
                console.log(response);
                return response;
            }

            let redirectURL;

            console.time('=====> ValidaADF');

            if (environment == 'PRODUCCION') {

                let validaADFResult = await adf.validaADF(parametros, json, modeloCut, formulario, girador, modelo);
                console.log("Respuesta ValidaADF: " + JSON.stringify(validaADFResult));
                if (validaADFResult.data.resultCode === 5 || validaADFResult.data.resultCode === 4) {
                    console.log(validaADFResult.data.resultMessage);
                    let response = {
                        statusCode: 500,
                        body: JSON.stringify({
                            errors: {
                                message: "Error de sistema",
                                code: 18005
                            }
                        })
                    };
                    console.log(response);
                    return response
                }

                if (validaADFResult.data.resultCode !== 1 && validaADFResult.data.resultCode !== 2) {
                    let recaMensajes = validaADFResult.data.recaMensajes;
                    let errores = [];
                    for (let i in recaMensajes) {
                        errores.push({
                            "codigo": recaMensajes[i].codigo,
                            "errMsg": recaMensajes[i].errMsg,
                            "objName": recaMensajes[i].objName,
                            "objValue": recaMensajes[i].objValue,
                            "objDescrip": recaMensajes[i].objDescrip
                        })
                    }
                    let e = {
                        message: "Error de validación",
                        code: 18000,
                        errores: errores
                    };
                    return {
                        statusCode: 400,
                        body: JSON.stringify({
                            errors: e
                        })
                    };
                }

                console.timeEnd('=====> ValidaADF');
                console.time('=====> Intento Pago');
                // Se calcula que diferencia de lo calculado por adf y el monto
                // no se mayor a cierta tolerancia
                if(Math.abs(parseInt(validaADFResult.data.contextADF.lqAPagar) - parseInt(json.data.recaudacion.monto)) > tolerancia){
                    let response = {
                        statusCode: 400,
                        body: JSON.stringify({
                            message: "Error de validación: Monto informado no corresponde según reglas de liquidación de moneda"
                        })
                    }
    
                    console.log(response);
                    return response;
                }

                let guardaGiroInput = {
                    "idGirador": girador,
                    "fechaOrigen": moment(parametros[2]).format('YYYY-MM-DD'),
                    "rut": validaADFResult.data.contextADF.rutRol,
                    "formCod": validaADFResult.data.contextADF.formCod,
                    "formVer": validaADFResult.data.contextADF.formVer,
                    "formFolio": validaADFResult.data.contextADF.folio,
                    "fechaVcto": moment(validaADFResult.data.contextADF.fechaVcto).format('YYYY-MM-DD'),
                    "periodo": moment(validaADFResult.data.contextADF.periodoCta).format('YYYY-MM-DD'),
                    "montoPlazo": validaADFResult.data.contextADF.lqMontoAfecto,
                    "reajustes": validaADFResult.data.contextADF.lqReajuste,
                    "intereses": validaADFResult.data.contextADF.lqInteres,
                    "multas": validaADFResult.data.contextADF.lqMulta,
                    "condonaciones": validaADFResult.data.contextADF.lqCondonacion,
                    "montoTotal": validaADFResult.data.contextADF.lqAPagar,
                    "idMoneda": validaADFResult.data.contextADF.monedaMov,
                    "totalPagar": json.data.recaudacion.monto,
                    "idExterno": parametros[3]
                }
                let items = [];
                validaADFResult.data.itemsADF.forEach(element => {
                    items.push({
                        "codigo": element.codigo,
                        "valor": element.valor
                    })
                });
                guardaGiroInput["items"] = items;
                let guardarGiroResult = await guardaGiro(guardaGiroInput);
                console.log("Respuesta guardarGiro: ", guardarGiroResult);
                console.log("Respuesta guardarGiro data: " + JSON.stringify(guardarGiroResult.data));
                console.log("Respuesta guardarGiro status: " + guardarGiroResult.status);
                console.log("Respuesta guardarGiro statusText: " + guardarGiroResult.statusText);

                if (guardarGiroResult.status !== 200) {
                    let e = {
                        message: "Error al guardar giro",
                        code: 19000
                    };
                    return {
                        statusCode: 400,
                        body: JSON.stringify({
                            errors: e
                        })
                    };
                }
                console.timeEnd('=====> Intento Pago');

                console.time('=====> Guardar data en Nube');
                await queryDB.putItem(parametros, json, { institucion, environment, formulario, girador }); // Persistir data en DynamoDB.
                console.timeEnd('=====> Guardar data en Nube');

                redirectURL = `${urlPortalPagos}?idext=${parametros[3]}&org=${institucion}`;
                if (json.metadata.mock) {
                    redirectURL = `${urlPortalPagosMock}?idext=${parametros[3]}&org=${institucion}`;
                }
            } else {
                let validaADFResult = await adf.validaADF(parametros, json, modeloCut, formulario, girador, modelo);
                console.log("Respuesta ValidaADF: " + JSON.stringify(validaADFResult));
                if (validaADFResult.data.resultCode === 5 || validaADFResult.data.resultCode === 4) {
                    console.log(validaADFResult.data.resultMessage);
                    let response = {
                        statusCode: 500,
                        body: JSON.stringify({
                            errors: {
                                message: "Error de sistema",
                                code: 18005
                            }
                        })
                    };
                    console.log(response);
                    return response
                }

                if (validaADFResult.data.resultCode !== 1 && validaADFResult.data.resultCode !== 2) {
                    let recaMensajes = validaADFResult.data.recaMensajes;
                    let errores = [];
                    for (let i in recaMensajes) {
                        errores.push({
                            "codigo": recaMensajes[i].codigo,
                            "errMsg": recaMensajes[i].errMsg,
                            "objName": recaMensajes[i].objName,
                            "objValue": recaMensajes[i].objValue,
                            "objDescrip": recaMensajes[i].objDescrip
                        })
                    }
                    let e = {
                        message: "Error de validación",
                        code: 18000,
                        errores: errores
                    };
                    return {
                        statusCode: 400,
                        body: JSON.stringify({
                            errors: e
                        })
                    };
                }
                console.timeEnd('=====> ValidaADF');

                console.time('=====> Guardar data en Nube');
                await queryDB.putItem(parametros, json, { institucion, environment, formulario, girador }); // Persistir data en DynamoDB.
                console.timeEnd('=====> Guardar data en Nube');

                let valorB64 = Buffer.from(JSON.stringify({
                    id: undefined,
                    idSolicitudRecaudacion: parametros[3],
                    formulario: formulario,
                    email: "",
                    idGirador: institucion,
                    info: {
                        montos: [{
                            valor: json.data.recaudacion.monto,
                            tipo: "ONLINE",
                            moneda: "CLP"
                        }]
                    },
                    environment: environment
                })).toString('base64');

                redirectURL = `${urlBotonPagoCloud}/solicitud?pago=${valorB64}`;
            }

            if (modelo == 'EGRESO_AUTOMATICO' || modelo == 'EGRESO_CUENTA_FIJA') {
                let response = {
                    statusCode: 201,
                    body: JSON.stringify({
                        id: `${parametros[3]}`,
                        redirectURL: redirectURL
                    })
                };
                console.log(response);
                console.timeEnd('=====> Total');
                return response;
            } else if (modelo == 'EGRESO_DIFERIDO') {
                // SE RETORNA ID BILLETERA
                let response = {
                    statusCode: 201,
                    body: JSON.stringify({
                        id: `${parametros[3]}`,
                        redirectURL: redirectURL,
                        idBilletera: billeteraSalida
                    })
                };
                console.log(response);
                console.timeEnd('=====> Total');
                return response;
            }
        }
    } catch (ex) {
        console.log(ex);

        if (ex.statusCode === 400) {
            return ex;
        } else {
            let e = {
                message: "Error interno TGR",
                code: 49000
            };

            errores.push(e);
            return {
                statusCode: 500,
                body: JSON.stringify({
                    errors: errores
                })
            };
        }
    }
}

async function procesoRecaudacionCarrito(data, institucion, environment, config, metadata) {

    let errores = [];
    try {
        console.time('Proceso tramite', data.idTramite);
        console.log();
        console.log("institucion: " + institucion);
        console.log("environment: " + environment);

        let formulario;
        let girador;
        let etapa;
        let modelo;
        let modeloCut;
        let responseAllConceptos = responseAllConceptosLocal;
        // let results = responseAllConceptos.data.data.conceptos;
        // let e = validarEntrada.validacionesConcepto(results, institucion, data.conceptoRecaudacion); //VALIDA CONCEPTO
        let e = errorConceptos;
        if (e !== null) {
            errores.push(e);
            let response = {
                message: "Error de validación",
                code: 18001,
                errors: errores
            };
            console.log(response);
            return response;
        } else { // Si concepto es valido

            console.time('Validacion egreso');
            let detalleConceptoInstitucion = detalleConcepto.get(data.conceptoRecaudacion);
            // await getDetalleConceptoInstitucion(data.conceptoRecaudacion, institucion); // Obtener detalle de tabla Conceptos.

            etapa = detalleConceptoInstitucion.data.data.etapa; // Obtener etapa

            if (environment === 'PRODUCCION' && etapa === 'CERTIFICACION') { // Validar etapa
                e = {
                    message: `No puede usar credenciales de producción si la integración del concepto: ${data.conceptoRecaudacion} aun esta en etapa de certificación`,
                    code: 17002
                };
                errores.push(e);
                let response = {
                    message: "Error de validación",
                    code: 18001,
                    errors: errores
                };

                console.log(response);
                return response;
            } else {

                formulario = detalleConceptoInstitucion.data.data.formulario;
                girador = detalleConceptoInstitucion.data.data.codigoInstitucionOnPrem;
                modelo = detalleConceptoInstitucion.data.data.modelo;
                modeloCut = detalleConceptoInstitucion.data.data.modeloCut;
                console.log('Modelo: ', modelo);
                var parametros;
                var billeteraSalida;
                if (modelo == 'EGRESO_AUTOMATICO') {
                    let resultadoVal = await validar.validarJsonCarritoAutomatico(data); // Validar JSON de entrada con Swagger
                    errores = validarEntrada.validacionesCuenta(data); //VALIDA TIPO CUENTA
                    parametros = await param.prepararParametrosCarrito(data, config, metadata);
                } else if (modelo == 'EGRESO_CUENTA_FIJA') {
                    errores = validarEntrada.validacionesDatosCarrito(data, metadata); //VALIDA DATOS JSON
                    parametros = await param.prepararParametrosV2Carrito(data, config, metadata);
                } else if (modelo == 'EGRESO_DIFERIDO') {
                    errores = validarEntrada.validacionesDatosCarrito(data, metadata); //VALIDA DATOS JSON
                    parametros = await param.prepararParametrosV2Carrito(data, config, metadata);

                    let billeteraEntrada = data.idBilletera; //VERIFICAMOS SI VIENE BILLETERA

                    if (billeteraEntrada == undefined) {
                        //Se maneja billeteras para carrito
                        if (global.mapBilletera.get(data.conceptoRecaudacion) == undefined) {
                            console.log('Crear Billetera');
                            let idBilletera = await billetera.crearBilletera(institucion); //SE CREA BILLETERA
                            global.mapBilletera.set(data.conceptoRecaudacion, idBilletera);
                            console.log('Crear relación Billetera-Institucion');
                            billetera.crearBilleteraInstitucion(idBilletera, institucion); //SE CREA RELACIÓN BILLETERA-INSTITUCIÓN EN PORTAL AUTOSERVICIO
                        }
                        data.idBilletera = global.mapBilletera.get(data.conceptoRecaudacion); //Se agrega billetera a payload
                        billeteraSalida = global.mapBilletera.get(data.conceptoRecaudacion);
                    } else {
                        console.log('Buscar Billetera');
                        let salidaBusqueda = await billetera.buscarBilletera(billeteraEntrada);
                        if (salidaBusqueda.data !== undefined) {
                            billeteraSalida = salidaBusqueda.data.idBilletera; // Existe billetera
                        } else {
                            console.log("no existe billetera");
                            let e = validarEntrada.validacionBilletera(); // No existe billetera

                            return {
                                errors: e
                            };
                        }
                    }
                }
            }
            console.timeEnd('Validacion egreso');

            var validaADFResult
            var guardaGiroInput
            let is_cid_correct;
            console.time('=====> ValidaCID');
            if(data.recaudacion.cid) {
                // Agregar data para validar el cid
                is_cid_correct = await cid.validaCID(data, detalleConceptoInstitucion.data.data);
                if(!is_cid_correct.success) {
                    let errors = [];
                    is_cid_correct.error.issues.map(err => errors.push(err.message))
                    let response = {
                        statusCode: 400,
                        errors
                    }
                    console.log(response);
                    return response;
                }
            }
            console.timeEnd('=====> ValidaCID');
            if (environment == 'PRODUCCION' && !data.recaudacion.cid) {
                try {
                    validaADFResult = await adf.validaADFCarrito(parametros, data, modeloCut, formulario, girador, modelo, metadata);
                    console.log("Respuesta ValidaADF: " + JSON.stringify(validaADFResult));
                    if (validaADFResult?.data?.resultCode === 5 || validaADFResult?.data?.resultCode === 4) {
                        console.log(validaADFResult.data.resultMessage);
                        let response = {
                            statusCode: 500,
                            body: JSON.stringify({
                                errors: {
                                    message: "Error de sistema",
                                    code: 18005
                                }
                            })
                        };
                        console.log(response);
                        return response
                    }

                    if (validaADFResult?.data?.resultCode !== 1 && validaADFResult?.data?.resultCode !== 2) {
                        let recaMensajes = validaADFResult.data.recaMensajes;
                        let errores = [];
                        for (let i in recaMensajes) {
                            errores.push({
                                "codigo": recaMensajes[i].codigo,
                                "errMsg": recaMensajes[i].errMsg,
                                "objName": recaMensajes[i].objName,
                                "objValue": recaMensajes[i].objValue,
                                "objDescrip": recaMensajes[i].objDescrip
                            })
                        }
                        let e = {
                            message: "Error de validación",
                            code: 18000,
                            errores: errores
                        };
                        return {
                            errors: e
                        };
                    }
                    // Se calcula que diferencia de lo calculado por adf y el monto del tramite
                    // no se mayor a cierta tolerancia
                    if(Math.abs(parseInt(validaADFResult.data.contextADF.lqAPagar) - parseInt(data.recaudacion.monto)) > tolerancia){
                        let e = {
                            message: `Monto tramite ${data.idTramite} informado no corresponde según reglas de liquidación de moneda`
                        };
                        return {
                            errors: e
                        };
                    }
                    guardaGiroInput = {
                        "clienteTipo": validaADFResult.data.contextADF.tipoCont,
                        "rutRol": validaADFResult.data.contextADF.rutRol,
                        "formCod": validaADFResult.data.contextADF.formCod,
                        "formVer": validaADFResult.data.contextADF.formVer,
                        "formFolio": validaADFResult.data.contextADF.folio,
                        "fechaVcto": moment(validaADFResult.data.contextADF.fechaVcto).format('YYYY-MM-DD'),
                        "periodo": moment(validaADFResult.data.contextADF.periodoCta).format('YYYY-MM-DD'),
                        "montoPlazo": validaADFResult.data.contextADF.lqMontoAfecto,
                        "reajustes": validaADFResult.data.contextADF.lqReajuste,
                        "intereses": validaADFResult.data.contextADF.lqInteres,
                        "multas": validaADFResult.data.contextADF.lqMulta,
                        "condonaciones": validaADFResult.data.contextADF.lqCondonacion,
                        "montoTotal": validaADFResult.data.contextADF.lqAPagar,
                        "idMoneda": validaADFResult.data.contextADF.monedaMov
                    }
                    let items = [];
                    validaADFResult.data.itemsADF.forEach(element => {
                        items.push({
                            "codigo": element.codigo,
                            "valor": element.valor
                        })
                    });
                    guardaGiroInput["items"] = items;
                } catch (e) {
                    let errors = [];
                    errors.push(`Error al validar ADF para el trámite ${data.idTramite}.`);
                    let response = {
                        statusCode: 400,
                        errors
                    }
                    console.log(`Error al validar ADF para el trámite ${data.idTramite}.`);
                    console.log(response);
                    return response;
                }
            } else if(!data.recaudacion.cid) {
                try {
                    validaADFResult = await adf.validaADFCarrito(parametros, data, modeloCut, formulario, girador, modelo, metadata);
                
                    console.log("Respuesta ValidaADF: " + JSON.stringify(validaADFResult));
                    if (validaADFResult.data.resultCode === 5 || validaADFResult.data.resultCode === 4) {
                        console.log(validaADFResult.data.resultMessage);
                        let response = {
                            statusCode: 500,
                            body: JSON.stringify({
                                errors: {
                                    message: "Error de sistema",
                                    code: 18005
                                }
                            })
                        };
                        console.log(response);
                        return response
                    }

                    if (validaADFResult.data.resultCode !== 1 && validaADFResult.data.resultCode !== 2) {
                        let recaMensajes = validaADFResult.data.recaMensajes;
                        let errores = [];
                        for (let i in recaMensajes) {
                            errores.push({
                                "codigo": recaMensajes[i].codigo,
                                "errMsg": recaMensajes[i].errMsg,
                                "objName": recaMensajes[i].objName,
                                "objValue": recaMensajes[i].objValue,
                                "objDescrip": recaMensajes[i].objDescrip
                            })
                        }
                        let e = {
                            message: "Error de validación",
                            code: 18000,
                            errores: errores
                        };
                        return {
                            errors: e
                        };
                    }
                } catch (e) {
                    let errors = [];
                    errors.push(`Error al validar ADF para el trámite ${data.idTramite}.`);
                    let response = {
                        statusCode: 400,
                        errors
                    }
                    console.log(`Error al validar ADF para el trámite ${data.idTramite}.`); 
                    console.log(response);
                    return response;
                }
            } else {
                guardaGiroInput = {
                    "clienteTipo": 1,
                    "rutRol": metadata.contribuyente.rut,
                    "formCod": Number(detalleConceptoInstitucion.data.data.formulario),
                    "formVer": '',
                    "formFolio": 0,
                    "fechaVcto": '',
                    "periodo": '',
                    "montoPlazo": data.recaudacion.monto,
                    "reajustes": 0,
                    "intereses": 0,
                    "multas": 0,
                    "condonaciones": 0,
                    "montoTotal": data.recaudacion.monto,
                    "idMoneda": 0
                }
                const items = [{
                    "codigo": 9924,
                    "valor": `CID:${data.recaudacion.cid}`
                }];
                guardaGiroInput["items"] = items;
            }

            if (modelo == 'EGRESO_AUTOMATICO' || modelo == 'EGRESO_CUENTA_FIJA') {
                let response = {
                    subtramite: data,
                    idGirador: girador,
                    fechaOrigen: moment(parametros[2]).format('YYYY-MM-DD'),
                    intentoPago: guardaGiroInput
                };
                console.log('Return Proceso Recaudacion: ', JSON.stringify(response));
                console.timeEnd('Proceso tramite', data.idTramite);
                return response;
            } else if (modelo == 'EGRESO_DIFERIDO') {
                // SE RETORNA ID BILLETERA
                let response = {
                    subtramite: data,
                    idGirador: girador,
                    fechaOrigen: moment(parametros[2]).format('YYYY-MM-DD'),
                    idBilletera: billeteraSalida,
                    intentoPago: guardaGiroInput
                };
                console.log('Return Proceso Recaudacion: ', JSON.stringify(response));
                console.timeEnd('Proceso tramite', data.idTramite);
                return response;
            }
        }
    } catch (ex) {
        console.log(ex);

        if (ex.statusCode === 400) {
            return ex;
        } else {
            let e = {
                message: "Error interno TGR",
                code: 49000
            };

            errores.push(e);
            return {
                statusCode: 500,
                body: JSON.stringify({
                    errors: errores
                })
            };
        }
    }
}

function getDetalleConceptoInstitucion(concepto, instit) {
    let request = {
        method: 'GET',
        host: process.env.API_AUTOSERVICIOS_HOST_SERVICE,
        path: `/portal-autoservicios/v1/conceptos/${concepto}?institucion=${instit}`,
        service: 'execute-api'
    }

    let signedRequest2 = aws4.sign(request, {
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        sessionToken: process.env.AWS_SESSION_TOKEN
    })

    return axios({
        ...signedRequest2,
        url: `https://${request.host}${request.path}`,
    })
}

function getAllConceptosByInstitucion(instit) {
    let request = {
        method: 'GET',
        host: process.env.API_AUTOSERVICIOS_HOST_SERVICE,
        path: `/portal-autoservicios/v1/conceptos?institucion=${instit}`,
        service: 'execute-api'
    }

    let signedRequest2 = aws4.sign(request, {
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        sessionToken: process.env.AWS_SESSION_TOKEN
    })

    return axios({
        ...signedRequest2,
        url: `https://${request.host}${request.path}`,
    })
}

function guardaGiro(guardaGiroInput) {

    let input = {
        data: guardaGiroInput
    };
    console.log("guardaGiroInput: " + JSON.stringify(input));

    let request = {
        method: 'POST',
        host: process.env.API_AUTOSERVICIOS_HOST_SERVICE,
        path: `/recaudacion-interno/v1/intentoPago`,
        service: 'execute-api',
        body: JSON.stringify(input)
    }

    let signedRequest2 = aws4.sign(request, {
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        sessionToken: process.env.AWS_SESSION_TOKEN
    })

    return axios({
        ...signedRequest2,
        method: 'post',
        url: `https://${request.host}${request.path}`,
        data: input
    })
}

function guardaGiroCarrito(guardaGiroInput) {

    console.log("guardaGiroInput: " + JSON.stringify(guardaGiroInput));

    let request = {
        method: 'POST',
        host: process.env.API_AUTOSERVICIOS_HOST_SERVICE,
        path: `/recaudacion-interno/v1/intentoPagoCarrito`,
        service: 'execute-api',
        body: JSON.stringify(guardaGiroInput)
    }

    let signedRequest2 = aws4.sign(request, {
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        sessionToken: process.env.AWS_SESSION_TOKEN
    })

    return axios({
        //...signedRequest2,
        method: 'post',
        url: `https://${request.host}${request.path}`,
        data: guardaGiroInput
    })
}

function getRedirectUrl(environment, institucion, metadata, idExt) {
    let redirectURL;
    if (environment == 'PRODUCCION') {
        redirectURL = `${urlPortalPagos}?idext=${idExt}&org=${institucion}`;
        if (metadata.mock) {
            redirectURL = `${urlPortalPagosMock}?idext=${idExt}&org=${institucion}`;
        }
    } else {
        let valorB64 = Buffer.from(JSON.stringify({
            id: undefined,
            idSolicitudRecaudacion: idExt,
            email: "",
            idGirador: institucion,
            environment: environment
        })).toString('base64');
        redirectURL = `${urlBotonPagoCloud}/solicitud?pago=${valorB64}`;
    }
    return redirectURL;
}

function buscarCidDuplicados(tramites) {
    const vistos = new Set();
    const duplicados = new Set();
    let tiene_duplicado = false;

    tramites.forEach(tramite => {
        if(tramite.recaudacion.cid) {
            const cid = tramite.recaudacion.cid;
            if (vistos.has(cid)) {
                tiene_duplicado = true;
                duplicados.add(cid);
            }
            vistos.add(cid);
        }
    });

    return Array.from(duplicados);
}
