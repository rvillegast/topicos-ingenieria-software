const jwt = require('jsonwebtoken')
const cache = {};

exports.getDataFromToken = (authorizationHeader) => {
    try {
        const token = authorizationHeader.match(/Bearer (.*)/)[1];
        const decoded = jwt.decode(token);

        const clientId = decoded.client_id;
        const aud = decoded.aud;

        if (!aud) {
            throw new Error("El token no contiene 'aud'");
        }

        // Cache
        if (cache[clientId]) {
            return cache[clientId];
        }

        const audParts = aud.split(',');
        let institucion = '';
        let girador = '';
        let environment = '';

        if (audParts.length <= 3) {
            // Solo asigna institucion y girador, y usa PRODUCCION
            for (const part of audParts) {
                const [key, value] = part.split('=');
                if (key === 'institucion') institucion = value;
                if (key === 'formulario') girador = value;
            }
            environment = 'PRODUCCION';
        } else {
            // También extrae environment
            for (const part of audParts) {
                const [key, value] = part.split('=');
                if (key === 'institucion') institucion = value;
                if (key === 'formulario') girador = value;
            }
            const ambientePart = audParts[3];
            const ambienteValue = ambientePart.split('=')[1];
            environment = ambienteValue || 'PRODUCCION';
        }

        const resultado = { institucion, girador, environment };

        // Guardar en cache
        cache[clientId] = resultado;

        return resultado;
    } catch (err) {
        console.error("Error en getDataFromToken:", err);
        throw err;
    }
}
      