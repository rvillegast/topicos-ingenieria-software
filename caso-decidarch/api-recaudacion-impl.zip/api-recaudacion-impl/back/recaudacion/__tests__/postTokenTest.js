process.env.USER_POOL_URL = 'https://tgr-dev-api-recaudacion-at-186180787863.auth.us-east-1.amazoncognito.com'

let axios = require('axios')
let token = require('../oauth2Token');

jest.mock('axios');

describe('Obtención de Token', () => {
    it('-> token exitoso', async () => {
        let clientId = 'el client id'
        let clientSecret = 'el client secret'
        
        let event = {
            body: `client_id${clientId},client_secret=${clientSecret},grant_type=client_credentials,scope=recaudacion/ips`
        }
    
        let data = {access_token: 'fake-token'};
        
        axios.mockImplementation((options) => {
            if (options.url.endsWith('oauth2/token')) {
                expect(options.data).toBeDefined()

                return Promise.resolve({
                    status: 200, data: data
                });
            }
            return Promise.resolve({data: {data: {formulario, codigoInstitucionOnPrem, etapa: 'PRODUCCION'}}})
        })
        
        let response = await token.handler(event)
        console.log(response)
        expect(response.statusCode).toBe(200)
        expect(response.body).toBe(JSON.stringify(data))
    })
})
