const axios = require('axios');
const { postAvisoRecibo } = require('../src/obligaciones/avisoRecibo');

jest.mock('axios');

describe('Obtencion de AR', () => {
    beforeAll(() => {
        process.env.hostNameCUT = 'api.dev.tegere.info';
        process.env.ENV = 'dev';
    });

    beforeEach(() => {
        jest.clearAllMocks();
    });

    // CID: posiciones 12-17 = fecha AAMMDD. Se calcula para que siga vigente sin importar cuándo corra el test.
    const cidVigente = () => {
        const d = new Date();
        d.setFullYear(d.getFullYear() + 1);
        const p = n => String(n).padStart(2, '0');
        return `011618000003${p(d.getFullYear() % 100)}${p(d.getMonth() + 1)}${p(d.getDate())}01809218`;
    };

    const callLambda = (CID) =>
        new Promise((resolve) => {
            const event = { body: JSON.stringify({ CID }) };
            postAvisoRecibo(event, {}, (err, response) => resolve({ err, response }));
        });

    it('-> Aviso de recibo no encontrado', async () => {
        axios.mockRejectedValueOnce({
            response: { status: 404, data: { message: 'Not found' } },
        });

        const { err, response } = await callLambda(cidVigente());
        expect(err).toBeNull();
        // Caracterización: CUT 404 se responde con HTTP 200 (defecto registrado TD-003, debería ser 404)
        expect(response.statusCode).toBe(200);

        const body = JSON.parse(response.body);
        expect(body).toEqual({ message: 'Aviso de recibo no encontrado' }); // 'mensaje' -> 'message' en 5d52db7
    });

    it('-> error de CUT distinto de 404 hace fallar el handler', async () => {
        axios.mockRejectedValueOnce({ response: { status: 503, data: {} } });

        // Caracterización: obtieneAvisoRecibo retorna undefined y el handler lanza (defecto registrado TD-004)
        await expect(postAvisoRecibo({ body: JSON.stringify({ CID: cidVigente() }) }, {}, () => {}))
            .rejects.toThrow(TypeError);
    });

    it('-> Aviso de recibo con letras', async () => {
        const { err, response } = await callLambda('A1161800000326022101809218');

        expect(err).toBeNull();
        expect(response.statusCode).toBe(400);

        const body = JSON.parse(response.body);
        expect(body).toEqual({ message: ['El CID debe ser numérico'] });
    });

    it('-> Aviso de recibo con fecha invalida', async () => {
        const { response } = await callLambda('01161800000326322101809218');

        expect(response.statusCode).toBe(400);

        const body = JSON.parse(response.body);
        expect(body).toEqual({
            message: ['El CID no es válido'],
        });
    });

    it('-> Aviso de recibo con fecha no vigente', async () => {
        const { response } = await callLambda('01161800000326020101809218');

        expect(response.statusCode).toBe(400);

        const body = JSON.parse(response.body);
        expect(body).toEqual({
            message: ['EL CID no está vigente'],
        });
    });

    it('-> Aviso de recibo con rango diferente a 26', async () => {
        const { response } = await callLambda('011618000003260201');

        expect(response.statusCode).toBe(400);

        const body = JSON.parse(response.body);
        expect(body).toEqual({
            message: ['El CID debe de tener un largo de 26'],
        });
    });

    it('-> Aviso de recibo con todas las anteriores', async () => {
        const { response } = await callLambda('01A1618000003263201');

        expect(response.statusCode).toBe(400);

        const body = JSON.parse(response.body);
        expect(body).toEqual({
            message: ['El CID debe ser numérico', 'El CID debe de tener un largo de 26'],
        });
    });
});
