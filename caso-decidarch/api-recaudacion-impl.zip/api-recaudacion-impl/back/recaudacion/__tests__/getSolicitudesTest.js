const getSolicitudes = require('../getSolicitudes');
const jwt = require('jsonwebtoken');
jest.setTimeout(20000);

let {docClient} = require('../aws/dynamoDbServices')

describe('Consulta Eventos', function () {
    
    beforeAll(async () => {
        process.env.PREFIX = 'tgr-lab-api-recaudacion'
    });
    
    it('-> consulta a Dynamodb correctamente', async () => {
        
        let fechaEvento = new Date().toISOString();
        let idSolicitud = "18523676132249716242622";
    
        let institucion = "CBRR";
        let environment= 'PRODUCCION';
        
        let item = {
            "id": idSolicitud,
            "numeroSolicitudRecaudacion": idSolicitud,
            "institucion": institucion,
            "fechaEvento": fechaEvento,
            "nombreEstado": "RECIBIDA",
            "payload": {
                "data": {
                    "contribuyente": {"rut": 7023934, "dv": "5"},
                    "callbackURL": "http://52.3.3.94:4200/callback",
                    "receptor": {
                        "rut": 9799598,
                        "dv": "2",
                        "apellidoPaternoORazonSocial": "RS DEL BENEFICIARIO",
                        "cuentaDeposito": {
                            "nombreBanco": "CORPBANCA",
                            "banco": 27,
                            "tipo": "CUENTA_CORRIENTE",
                            "numero": 47311207
                        },
                        "nombre": "Juanito"
                    },
                    "recaudacion": {"moneda": "CLP", "monto": 50},
                    "conceptoRecaudacion": "Certificado de Dominio Vigente de Titulos de Dominio"
                },
                "metadata": {"mock": false, "sentDate": "2019-12-19T19:54:38.994Z"}
            },
            "url": "http://52.3.3.94:4200/callback",
            "environment": environment,
            "institucionEnvironment": `${institucion}#${environment}`
        };
        await docClient.put({
            TableName: `${process.env.PREFIX}-eventos`,
            Item: item
        }).promise();
        
        let event = {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${jwt.sign({client_id: '5ikm6fkfq2d698ttfplbt72ml9', aud: 'institucion=CBRR,formulario=776,girador=123'}, 'xxxxx')}`
            },
            "resource": "/solicitudes",
            "path": "/solicitudes",
            "httpMethod": "GET",
            "queryStringParameters": {
                "interval": "600"
            }
        };
        
        let data = await getSolicitudes.handler(event);
        expect(data.body).toBeDefined();
        let parse = JSON.parse(data.body);
        expect(parse.metadata).toEqual({
            request: {
                interval: parseInt(event.queryStringParameters.interval),
            },
            response: {}
        });
        
        let filter = parse.data.filter(i => i.solicitud.id === idSolicitud);
        expect(filter).toEqual([{
            estado: {
                fechaEstado: fechaEvento,
                nombreEstado: "RECIBIDA",
            },
            fechaEvento: fechaEvento,
            solicitud: {
                id: idSolicitud,
            }
        }])
    }, 30000);

    // TD-019: MOP recibe fechaEstado en hora de Santiago con sufijo 'Z' (workaround mientras DGA no lea el formato estándar); el resto, FechaPago tal cual.
    // Al cerrar TD-019 este caso debe esperar el mismo formato que las demás instituciones.
    it('-> TD-019: formato de fechaEstado distinto para MOP', async () => {
        const fechaEvento = new Date().toISOString();
        const consultar = async (institucion) => {
            await docClient.put({ TableName: `${process.env.PREFIX}-eventos`, Item: {
                id: `S-${institucion}#TX`, institucion, fechaEvento, nombreEstado: 'PAGO_CONFIRMADO', environment: 'PRODUCCION',
                institucionEnvironment: `${institucion}#PRODUCCION`,
                payload: { Message: { Confirmacion: { Pago: { FechaPago: '2021-05-31T15:10:32.000Z', Ira: { Nombre: 'BANCO', Codigo: 1 } } } } }
            } }).promise();
            const token = jwt.sign({ client_id: `c-${institucion}`, aud: `institucion=${institucion},formulario=776,girador=123` }, 'xxxxx');
            const r = await getSolicitudes.handler({ headers: { Authorization: `Bearer ${token}` }, queryStringParameters: { interval: '600' } });
            return JSON.parse(r.body).data.find(i => i.solicitud.id === `S-${institucion}`).estado.fechaEstado;
        };

        expect(await consultar('CBRR')).toBe('2021-05-31T15:10:32.000Z');
        expect(await consultar('MOP')).toBe('2021-05-31T11:10:32Z'); // UTC-4 en mayo, rotulado como 'Z'
    });
});
