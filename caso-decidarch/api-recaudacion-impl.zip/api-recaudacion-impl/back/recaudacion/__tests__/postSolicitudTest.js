const postSolicitud = require('../postSolicitud');
const getSolicitudes = require('../getSolicitudes');
const jwt = require('jsonwebtoken')
const axios = require('axios')
const AWS = require('aws-sdk')

jest.setTimeout(20000);

jest.mock('aws-sdk');
jest.mock('https');
jest.mock('axios');
jest.mock('../utils/adf'); // ADF: servicio externo de validación/liquidación (vía SSM + https)

const adf = require('../utils/adf');
const CONCEPTO = 'Certificado de Dominio Vigente de Titulos de Dominio';

// Dobles de los servicios externos que postSolicitud consulta hoy (portal autoservicios, ADF, intentoPago).
// Los tests originales solo simulaban Cognito; el flujo actual llama a estos servicios antes de persistir.
function simularServicios({ formulario = 776, codigoInstitucionOnPrem = 800, etapa = 'PRODUCCION' } = {}) {
    axios.mockImplementation((options) => {
        const url = options.url || '';
        if (url.endsWith('TokenSoap/')) return Promise.resolve({ data: { access_token: 'fake-token-123' } });
        if (url.includes('/portal-autoservicios/v1/conceptos?')) return Promise.resolve({ data: { data: { conceptos: [CONCEPTO] } } });
        if (url.includes('/portal-autoservicios/v1/conceptos/')) {
            return Promise.resolve({ data: { data: { formulario, codigoInstitucionOnPrem, etapa, modelo: 'EGRESO_AUTOMATICO', modeloCut: 91 } } });
        }
        if (url.includes('/recaudacion-interno/v1/intentoPago')) return Promise.resolve({ status: 200, data: {} });
        return Promise.reject(new Error(`axios sin simular: ${url}`));
    });
    adf.validaADF.mockImplementation(async (parametros, json) => ({
        data: {
            resultCode: 1,
            contextADF: { lqAPagar: json.data.recaudacion.monto, rutRol: '7023934-5', formCod: formulario, formVer: 'A',
                folio: parametros[4], fechaVcto: '2020-01-01', periodoCta: '2020-01-01' },
            itemsADF: []
        }
    }));
}

const https = require('https');

let {docClient} = require('../aws/dynamoDbServices')

describe('Ingreso de Solicitud', function () {
    
    let tokenProduccion;
    let tokenCertificacion;
    
    let clientIdProduccion = '5ikm6fkfq2d698ttfplbt72ml9';
    let clientIdCertificacion = '89382km6fkfq2d698ttfplbt72ml9';
    let institucion = 'DEM';
    let formulario = 776;
    let codigoInstitucionOnPrem = 800;
    
    beforeAll(async () => {
        process.env.PREFIX = 'tgr-lab-api-recaudacion'
        
        AWS.CognitoIdentityServiceProvider.prototype.describeUserPoolClient = jest.fn((params, callback) => {
            let result;
            switch (params.ClientId) {
                case clientIdProduccion: {
                    result = {
                        UserPoolClient: {
                            ClientName: `institucion=${institucion},formulario=${formulario},girador=${codigoInstitucionOnPrem}`
                        }
                    }
                    break;
                }
                
                case clientIdCertificacion: {
                    result = {
                        UserPoolClient: {
                            ClientName: `institucion=${institucion},formulario=${formulario},girador=${codigoInstitucionOnPrem}, ambiente=CERTIFICACION`
                        }
                    }
                    break;
                }
            }
            callback(null, result);
        });
        
        simularServicios();
        
        // desde f1f74f0 util.getDataFromToken lee el claim 'aud' (antes: ClientName de Cognito)
        tokenProduccion = jwt.sign({
            "client_id": clientIdProduccion,
            "aud": `institucion=${institucion},formulario=${formulario},girador=${codigoInstitucionOnPrem}`
        }, 'xxxxx');
        
        tokenCertificacion = jwt.sign({
            "client_id": clientIdCertificacion,
            "aud": `institucion=${institucion},formulario=${formulario},girador=${codigoInstitucionOnPrem},ambiente=CERTIFICACION`
        }, 'xxxxx');
    });
    
    it('-> la consulta solo retorna lo productivo', async () => {
        let idsProduccion = [];
        let idsCertificacion = [];
        
        let requestGirador = {
            "metadata": {"sentDate": "2019-12-06T11:46:07.581Z"},
            "data": {
                "conceptoRecaudacion": "Certificado de Dominio Vigente de Titulos de Dominio",
                "contribuyente": {
                    "rut": 7023934,
                    "dv": "5"
                },
                "receptor": {
                    "rut": 9799598,
                    "dv": "2",
                    "nombre": "Juanito",
                    "apellidoPaternoORazonSocial": "RS DEL BENEFICIARIO",
                    "cuentaDeposito": {
                        "numero": 47311207,
                        "tipo": "CUENTA_CORRIENTE",
                        "nombreBanco": "CORPBANCA",
                        "banco": 27
                    }
                },
                "recaudacion": {
                    "monto": 12,
                    "moneda": "CLP"
                },
                "callbackURL": "https://www.google.cl"
            }
        };
        
        // se inserta una solicitud productiva usando el token productivo
        let data = await postSolicitud.handler({
            path: '/api-recaudacion/v1/solicitudes',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${tokenProduccion}`
            },
            body: JSON.stringify(requestGirador)
        });
        expect(data.body).toBeDefined();
        idsProduccion.push(JSON.parse(data.body).id);
        
        // se inserta una solicitud productiva sin environment
        let fechaEvento = new Date().toISOString();
        let idSolicitud = "18523676149716242622";
        
        let item = {
            "id": idSolicitud,
            "numeroSolicitudRecaudacion": idSolicitud,
            "institucion": "CBRR",
            "fechaEvento": fechaEvento,
            "nombreEstado": "RECIBIDA",
            "payload": {
                "data": {
                    "contribuyente": {"rut": 7023934, "dv": "5"},
                    "callbackURL": "http://52.3.3.94:4200/callback",
                    "receptor": {
                        "rut": 9799598,
                        "dv": "2",
                        "apellidoPaternoORazonSocial": "RS DEL BENEFICIARIO",
                        "cuentaDeposito": {
                            "nombreBanco": "CORPBANCA",
                            "banco": 27,
                            "tipo": "CUENTA_CORRIENTE",
                            "numero": 47311207
                        },
                        "nombre": "Juanito"
                    },
                    "recaudacion": {"moneda": "CLP", "monto": 50},
                    "conceptoRecaudacion": "Certificado de Dominio Vigente de Titulos de Dominio"
                },
                "metadata": {"mock": false, "sentDate": "2019-12-19T19:54:38.994Z"}
            },
            "url": "http://52.3.3.94:4200/callback",
        };
        await docClient.put({
            TableName: 'tgr-lab-api-recaudacion-eventos',
            Item: item
        }).promise();
        idsProduccion.push(idSolicitud);
        
        // si inserta una solicitud de certificacion
        data = await postSolicitud.handler({
            path: '/api-recaudacion/v1/solicitudes',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${tokenCertificacion}`
            },
            body: JSON.stringify(requestGirador)
        });
        expect(data.body).toBeDefined();
        idsCertificacion.push(JSON.parse(data.body).id);
        
        // se consulta por las solicitudes usando el token de produccion
        let event = {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${tokenProduccion}`
            },
            "resource": "/solicitudes",
            "path": "/solicitudes",
            "httpMethod": "GET",
            "queryStringParameters": {
                "interval": "600"
            }
        };
        data = await getSolicitudes.handler(event);
        expect(data.body).toBeDefined();
        let body1 = JSON.parse(data.body);
        let map1 = body1.data.map(i => i.solicitud.id);
        let filtered = map1.filter(i => idsCertificacion.includes(i))
        expect(filtered.length).toEqual(0);
        //expect(map1.sort()).toEqual(idsProduccion.sort())
        
        // se consulta por las solicitudes usando el token de certificacion
        event = {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${tokenCertificacion}`
            },
            "resource": "/solicitudes",
            "path": "/solicitudes",
            "httpMethod": "GET",
            "queryStringParameters": {
                "interval": "600"
            }
        };
        data = await getSolicitudes.handler(event);
        expect(data.body).toBeDefined();
        let body2 = JSON.parse(data.body);
        let certificationIdsReturned = body2.data.map(i => i.solicitud.id);
        //expect(certificationIdsReturned.sort()).toEqual(idsCertificacion.sort())
        expect(certificationIdsReturned.filter(i => idsProduccion.includes(i)).length).toEqual(0);
    })
    
    it('-> consulta a Dynamodb correctamente', async () => {
        let requestGirador = {
            "metadata": {"sentDate": "2019-12-06T11:46:07.581Z"},
            "data": {
                "conceptoRecaudacion": "Certificado de Dominio Vigente de Titulos de Dominio",
                "contribuyente": {
                    "rut": 7023934,
                    "dv": "5"
                },
                "receptor": {
                    "rut": 9799598,
                    "dv": "2",
                    "nombre": "Juanito",
                    "apellidoPaternoORazonSocial": "RS DEL BENEFICIARIO",
                    "cuentaDeposito": {
                        "numero": 47311207,
                        "tipo": "CUENTA_CORRIENTE",
                        "nombreBanco": "CORPBANCA",
                        "banco": 27
                    }
                },
                "recaudacion": {
                    "monto": 12,
                    "moneda": "CLP"
                },
                "callbackURL": "https://www.google.cl"
            }
        };
        let event = {
            path: '/api-recaudacion/v1/solicitudes',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${tokenProduccion}`
            },
            body: JSON.stringify(requestGirador)
        };
        
        let data = await postSolicitud.handler(event);
        expect(data).toBeDefined();
        expect(data.body).toBeDefined();
        let body = JSON.parse(data.body);
        expect(body.id).toBeDefined();
        expect(body.redirectURL).toBeDefined();
        
        let dynamodbResult = await docClient.query({
            TableName: 'tgr-lab-api-recaudacion-eventos',
            KeyConditionExpression: 'id = :id',
            ExpressionAttributeValues: {
                ':id': body.id
            }
        }).promise()
        
        expect(dynamodbResult.Items.length).toEqual(1);
        expect(dynamodbResult.Items[0]).toEqual({
            fechaEvento: expect.stringMatching(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/), // hora de registro (ISO UTC)
            folio: dynamodbResult.Items[0].folio, // generado por prepParam; putItem lo persiste
            formulario,
            payload: requestGirador,
            nombreEstado: 'RECIBIDA',
            environment: 'PRODUCCION',
            institucion,
            numeroSolicitudRecaudacion: body.id,
            id: body.id,
            codigoInstitucionOnPrem: codigoInstitucionOnPrem,
            url: requestGirador.data.callbackURL, // TD-020: duplica payload.data.callbackURL; lo leen callback.js y el carrito de ConfirmacionPago
            institucionEnvironment: `${institucion}#PRODUCCION`
        })
    });
    
    it('-> sin contribuyente', async () => {
        let requestGirador = {
            "metadata": {"sentDate": "2019-12-06T11:46:07.581Z"},
            "data": {
                "conceptoRecaudacion": "Certificado de Dominio Vigente de Titulos de Dominio",
                "receptor": {
                    "rut": 9799598,
                    "dv": "2",
                    "nombre": "Juanito",
                    "apellidoPaternoORazonSocial": "RS DEL BENEFICIARIO",
                    "cuentaDeposito": {
                        "numero": 47311207,
                        "tipo": "CUENTA_CORRIENTE",
                        "nombreBanco": "CORPBANCA",
                        "banco": 27
                    }
                },
                "recaudacion": {
                    "monto": 12,
                    "moneda": "CLP"
                },
                "callbackURL": "https://www.google.cl"
            }
        };
        let event = {
            path: '/api-recaudacion/v1/solicitudes',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${tokenProduccion}`
            },
            body: JSON.stringify(requestGirador)
        };
        
        let data = await postSolicitud.handler(event);
        expect(data).toBeDefined();
        expect(data.body).toBeDefined();
        let body = JSON.parse(data.body);
        expect(body.id).toBeDefined();
        expect(body.redirectURL).toBeDefined();
        
        let dynamodbResult = await docClient.query({
            TableName: 'tgr-lab-api-recaudacion-eventos',
            KeyConditionExpression: 'id = :id',
            ExpressionAttributeValues: {
                ':id': body.id
            }
        }).promise()
        
        expect(dynamodbResult.Items.length).toEqual(1);
        expect(dynamodbResult.Items[0]).toEqual({
            fechaEvento: expect.stringMatching(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/), // hora de registro (ISO UTC)
            folio: dynamodbResult.Items[0].folio, // generado por prepParam; putItem lo persiste
            formulario,
            payload: requestGirador,
            nombreEstado: 'RECIBIDA',
            environment: 'PRODUCCION',
            institucion,
            numeroSolicitudRecaudacion: body.id,
            id: body.id,
            codigoInstitucionOnPrem: codigoInstitucionOnPrem,
            url: requestGirador.data.callbackURL, // TD-020: duplica payload.data.callbackURL; lo leen callback.js y el carrito de ConfirmacionPago
            institucionEnvironment: `${institucion}#PRODUCCION`
        })
    })
    
    it('rut como string', async () => {
        let event = {
            path: '/api-recaudacion/v1/solicitudes',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${tokenProduccion}`
            },
            body: JSON.stringify({
                "metadata": {"sentDate": "2019-12-06T11:46:07.581Z"},
                "data": {
                    "conceptoRecaudacion": "Certificado de Dominio Vigente de Titulos de Dominio",
                    "receptor": {
                        "rut": "9799598",
                        "dv": "2",
                        "nombre": "Juanito",
                        "apellidoPaternoORazonSocial": "RS DEL BENEFICIARIO",
                        "cuentaDeposito": {
                            "numero": "47311207",
                            "tipo": "CUENTA_CORRIENTE",
                            "nombreBanco": "CORPBANCA",
                            "banco": 27
                        }
                    },
                    "recaudacion": {
                        "monto": "12",
                        "moneda": "CLP"
                    },
                    "callbackURL": "https://www.google.cl"
                }
            })
        };
        
        let data = await postSolicitud.handler(event);
        expect(data).toBeDefined();
        
        expect(data.body).toBeDefined();
        expect(data.statusCode).toEqual(400);
        
        let body = JSON.parse(data.body);
        
        expect(body.errors).toBeDefined();
        expect(body.errors.length).toEqual(1);
        expect(body.errors[0].message).toBeDefined();
        
        expect(typeof body.errors[0].message).toEqual('string');
        expect(body.errors[0].message).toContain('.data.receptor.rut'); // rechazo por esquema (integer)
    })
    
    it('conceptoPago en vez de conceptoRecaudacion', async () => { // TD-021: el esquema no exige conceptoRecaudacion
        let event = {
            path: '/api-recaudacion/v1/solicitudes',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${tokenProduccion}`
            },
            body: JSON.stringify({
                "metadata": {"sentDate": "2019-12-06T11:46:07.581Z"},
                "data": {
                    "conceptoPago": "Certificado de Dominio Vigente de Titulos de Dominio",
                    "receptor": {
                        "rut": "9799598",
                        "dv": "2",
                        "nombre": "Juanito",
                        "apellidoPaternoORazonSocial": "RS DEL BENEFICIARIO",
                        "cuentaDeposito": {
                            "numero": "47311207",
                            "tipo": "CUENTA_CORRIENTE",
                            "nombreBanco": "CORPBANCA",
                            "banco": 27
                        }
                    },
                    "recaudacion": {
                        "monto": 12,
                        "moneda": "CLP"
                    },
                    "callbackURL": "https://www.google.cl"
                }
            })
        };
        
        let data = await postSolicitud.handler(event);
        expect(data).toBeDefined();
        
        console.log(data);
        
        expect(data.body).toBeDefined();
        expect(data.statusCode).toEqual(400);
        
        let body = JSON.parse(data.body);
        
        expect(body.errors).toBeDefined();
        expect(body.errors.length).toEqual(1);
        expect(body.errors[0].message).toBeDefined();
        
        expect(typeof body.errors[0].message).toEqual('string');
        expect(body.errors[0]).toMatchObject({ code: 101, message: expect.stringContaining('Concepto de Recaudación: undefined') }); // TD-021: rechazo incidental
        
        //let queryCalls = AWS.DynamoDB.DocumentClient.prototype.put.mock.calls;
        //expect(queryCalls.length).toBe(1);
    })
    
    it('monto como String', async () => {
        let event = {
            path: '/api-recaudacion/v1/solicitudes',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${tokenProduccion}`
            },
            body: JSON.stringify({
                "metadata": {"sentDate": "2019-12-06T11:46:07.581Z"},
                "data": {
                    "conceptoRecaudacion": "Certificado de Dominio Vigente de Titulos de Dominio",
                    "receptor": {
                        "rut": 9799598,
                        "dv": "2",
                        "nombre": "Juanito",
                        "apellidoPaternoORazonSocial": "RS DEL BENEFICIARIO",
                        "cuentaDeposito": {
                            "numero": 47311207,
                            "tipo": "CUENTA_CORRIENTE",
                            "nombreBanco": "CORPBANCA",
                            "banco": 27
                        }
                    },
                    "recaudacion": {
                        "monto": "12",
                        "moneda": "CLP"
                    },
                    "callbackURL": "https://www.google.cl"
                }
            })
        };
        
        let data = await postSolicitud.handler(event);
        expect(data).toBeDefined();
        
        console.log(data);
        
        expect(data.body).toBeDefined();
        expect(data.statusCode).toEqual(400);
        
        let body = JSON.parse(data.body);
        
        expect(body.errors).toBeDefined();
        expect(body.errors.length).toEqual(1);
        expect(body.errors[0].message).toBeDefined();
        
        expect(typeof body.errors[0].message).toEqual('string');
        expect(body.errors[0].message).toContain('.data.recaudacion.monto'); // rechazo por esquema (number)
        
        //let queryCalls = AWS.DynamoDB.DocumentClient.prototype.put.mock.calls;
        //expect(queryCalls.length).toBe(1);
    });
    
    it('-> no se puede llamar al flujo de certificacion con credenciales de produccion', async () => {
        let requestGirador = {
            "metadata": {"sentDate": "2019-12-06T11:46:07.581Z"},
            "data": {
                "conceptoRecaudacion": "Certificado de Dominio Vigente de Titulos de Dominio",
                "contribuyente": {
                    "rut": 7023934,
                    "dv": "5"
                },
                "receptor": {
                    "rut": 9799598,
                    "dv": "2",
                    "nombre": "Juanito",
                    "apellidoPaternoORazonSocial": "RS DEL BENEFICIARIO",
                    "cuentaDeposito": {
                        "numero": 47311207,
                        "tipo": "CUENTA_CORRIENTE",
                        "nombreBanco": "CORPBANCA",
                        "banco": 27
                    }
                },
                "recaudacion": {
                    "monto": 12,
                    "moneda": "CLP"
                },
                "callbackURL": "https://www.google.cl"
            }
        };
        
        let clientId = '5ikm6fkfq2d698ttfplbt72ml9';
        let institucion = 'DEM';
        let formulario = 776;
        let codigoInstitucionOnPrem = 800;
        
        let tokenProduccion = jwt.sign({
            "client_id": clientId,
            "aud": `institucion=${institucion},formulario=${formulario},girador=${codigoInstitucionOnPrem}`
        }, 'xxxxx');
        
        
        AWS.CognitoIdentityServiceProvider.prototype.describeUserPoolClient = jest.fn((params, callback) => {
            let result;
            if (params.ClientId === clientId) {
                result = {
                    UserPoolClient: {
                        ClientName: `institucion=${institucion},formulario=${formulario},girador=${codigoInstitucionOnPrem}`
                    }
                }
            }
            callback(null, result);
        });
        
        simularServicios({ formulario, codigoInstitucionOnPrem, etapa: 'CERTIFICACION' });
        
        // se inserta una solicitud productiva usando el token productivo
        let data = await postSolicitud.handler({
            path: '/api-recaudacion/v1/solicitudes',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${tokenProduccion}`
            },
            body: JSON.stringify(requestGirador)
        });
        
        expect(data.statusCode).toBe(400);
        expect(data.body).toBeDefined();
        let body = JSON.parse(data.body);
        expect(body.code).toBe(17002);
    })
});

