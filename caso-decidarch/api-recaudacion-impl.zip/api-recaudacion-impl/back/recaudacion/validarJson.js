const Ajv = require('ajv');
const ajv = new Ajv();
const fs = require('fs');

exports.validarjson = (json) => {

  return new Promise((resolve, reject) => {

    var archivo = JSON.parse(fs.readFileSync('openapi.json', 'utf-8'));

    var schemaO = archivo.paths['/solicitudes'].post.parameters[0].schema;

    var validate = ajv.compile(schemaO);

    if (!validate(json)) {
      reject({
        statusCode: 400,
        body: JSON.stringify({
          errors: [{
            message: JSON.stringify(validate.errors)
          }]
        })
      })
    }
    else {
      resolve({
        message: 'JSON valido'
      });
    }
  })
};

exports.validarjsonV2 = (json) => {

  return new Promise((resolve, reject) => {

    try {
      var archivo = JSON.parse(fs.readFileSync('openapi2.json', 'utf-8'));
    }
    catch (e) {
      console.log(e); // error in the above string (in this case, yes)!
    }
    var schemaO = archivo.paths['/solicitudes'].post.parameters[0].schema;
    var validate = ajv.compile(schemaO);
    if (!validate(json)) {
      reject({
        statusCode: 400,
        body: JSON.stringify({
          errors: [{
            message: JSON.stringify(validate.errors)
          }]
        })
      })
    }
    else {
      resolve({
        message: 'JSON valido'
      });
    }
  })
};


exports.validarJsonCarrito = (json) => {

  return new Promise((resolve, reject) => {

    let schema = {
      "type": "object",
      "required": [
        "metadata",
        "data"
      ],
      "properties": {
        "metadata": {
          "type": "object",
          "required": [
            "sentDate",
            "contribuyente",
            "callbackURL",
            "montoCarrito"
          ],
          "properties": {
            "sentDate": {
              "type": "string"
            },
            "contribuyente": {
              "type": "object",
              "properties": {
                "dv": {
                  "type": "string"
                },
                "rut": {
                  "type": "integer"
                }
              }
            },
            "callbackURL": {
              "type": "string"
            },
            "montoCarrito": {
              "type": "integer"
            }
          }
        },
        "data": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "idTramite": {
                "type": "number"
              },
              "conceptoRecaudacion": {
                "type": "string"
              },
              "idBilletera": {
                "type": "string"
              },
              "recaudacion": {
                "type": "object",
                "required": [
                  "moneda",
                  "monto"
                ],
                "properties": {
                  "moneda": {
                    "type": "string"
                  },
                  "monto": {
                    "type": "integer"
                  }
                }
              },
              "receptor": {
                "type": "object",
                "properties": {
                  "apellidoPaternoORazonSocial": {
                    "type": "string"
                  },
                  "cuentaDeposito": {
                    "type": "object",
                    "required": [
                      "banco",
                      "nombreBanco",
                      "numero",
                      "tipo"
                    ],
                    "properties": {
                      "banco": {
                        "type": "integer"
                      },
                      "nombreBanco": {
                        "type": "string"
                      },
                      "numero": {
                        "type": "integer"
                      },
                      "tipo": {
                        "type": "string"
                      }
                    }
                  },
                  "dv": {
                    "type": "string"
                  },
                  "nombre": {
                    "type": "string"
                  },
                  "rut": {
                    "type": "integer"
                  }
                },
                "required": [
                  "apellidoPaternoORazonSocial",
                  "cuentaDeposito",
                  "dv",
                  "nombre",
                  "rut"
                ]
              },
              "payload": {
                "type": "object",
                "properties": {
                  "items": {
                    "type": "array",
                    "items": {
                      "type": "object",
                      "properties": {
                        "codigo": {
                          "type": "integer"
                        },
                        "valor": {
                          "type": [
                            "integer",
                            "string"
                          ]
                        }
                      },
                      "required": [
                        "codigo",
                        "valor"
                      ]
                    }
                  }
                },
                "required": [
                  "items"
                ]
              }
            },
            "required": [
              "idTramite",
              "conceptoRecaudacion",
              "recaudacion"
            ]
          }
        }
      }
    };

    var validate = ajv.compile(schema);

    if (!validate(json)) {
      console.log('Error: ', validate.errors);
      reject({
        statusCode: 400,
        body: JSON.stringify({
          errors: [{
            message: validate.errors,
            codError: 400
          }]
        })
      })
    }
    else {
      resolve({
        message: 'JSON valido'
      });
    }
  })
};

exports.validarJsonCarritoAutomatico = (json) => {

  return new Promise((resolve, reject) => {

    let schema = {
      "type": "object",
      "required": [
        "conceptoRecaudacion",
        "receptor",
        "recaudacion"
      ],
      "properties": {
        "conceptoRecaudacion": {
          "type": "string"
        },
        "receptor": {
          "type": "object",
          "required": [
            "apellidoPaternoORazonSocial",
            "cuentaDeposito",
            "dv",
            "nombre",
            "rut"
          ],
          "properties": {
            "apellidoPaternoORazonSocial": {
              "type": "string"
            },
            "cuentaDeposito": {
              "type": "object",
              "properties": {
                "banco": {
                  "type": "integer"
                },
                "nombreBanco": {
                  "type": "string"
                },
                "numero": {
                  "type": "integer"
                },
                "tipo": {
                  "type": "string"
                }
              }
            },
            "dv": {
              "type": "string"
            },
            "nombre": {
              "type": "string"
            },
            "rut": {
              "type": "integer"
            }
          }
        },
        "recaudacion": {
          "type": "object",
          "required": [
            "monto",
            "moneda"
          ],
          "properties": {
            "monto": {
              "type": "integer"
            },
            "moneda": {
              "type": "string"
            }
          }
        }
      }
    };

    var validate = ajv.compile(schema);

    if (!validate(json)) {
      console.log('Error: ', validate.errors);
      reject({
        statusCode: 400,
        body: JSON.stringify({
          errors: [{
            message: validate.errors,
            codError: 400
          }]
        })
      })
    }
    else {
      resolve({
        message: 'JSON valido'
      });
    }
  })
};
