'use strict';

const isTest = process.env.JEST_WORKER_ID || process.env.IS_SERVERLESS_OFFLINE === 'true';
const { DocumentClient } = require('aws-sdk/clients/dynamodb');

let config;

if (isTest) {
    config = {
        convertEmptyValues: true,
        ...(isTest && { endpoint: 'localhost:8000', sslEnabled: false, region: 'local-env' })
    };
}
else {
    config = {
        region: "us-east-1"
    }
}
var docClient = new DocumentClient(config);

exports.docClient = docClient;

exports.putItem = function(parametros, json, { institucion, environment, formulario, girador }) {
    var params = {
        TableName: `${process.env.PREFIX}-eventos`,
        Item: {
            id: parametros[3],
            folio: parametros[4],
            fechaEvento: parametros[2],
            nombreEstado: 'RECIBIDA',
            payload: json,
            institucion: institucion,
            numeroSolicitudRecaudacion: parametros[3],
            url: parametros[1],
            codigoInstitucionOnPrem: girador,
            formulario: formulario,
            environment: environment,
            institucionEnvironment: `${institucion}#${environment}`
        },
    };

    return new Promise((resolve, reject) => {
        docClient.put(params, function(err, data) {
            if (err) {
                console.log("dynamodb insert error:", params.Item, JSON.stringify(err, null, 2), err.stack);
                reject({
                    errors: [{
                        statusCode: 500,
                        message: "Error al persistir en DynamoDB"
                    }]
                });
            }
            else {
                resolve(data);
            }
        });
    });
};

exports.putItemCarrito = function(json, institucion, environment, formulario, girador, idRecaudacion, folio, fechaEvento, callbackUrl) {
    var params = {
        TableName: `${process.env.PREFIX}-eventos`,
        Item: {
            id: idRecaudacion,
            folio: folio,
            fechaEvento: fechaEvento,
            nombreEstado: 'RECIBIDA',
            payload: json,
            institucion: institucion,
            numeroSolicitudRecaudacion: idRecaudacion,
            url: callbackUrl,
            codigoInstitucionOnPrem: girador,
            formulario: formulario,
            environment: environment,
            institucionEnvironment: `${institucion}#${environment}`
        },
    };

    return new Promise((resolve, reject) => {
        docClient.put(params, function(err, data) {
            if (err) {
                console.log("dynamodb insert error:", params.Item, JSON.stringify(err, null, 2), err.stack);
                reject({
                    errors: [{
                        statusCode: 500,
                        message: "Error al persistir en DynamoDB"
                    }]
                });
            }
            else {
                resolve(data);
            }
        });
    });
};

exports.getItem = function(params) {

    return new Promise((resolve, reject) => {
        docClient.get(params, function(err, data) {
            if (err) {
                console.log("dynamodb get error:", JSON.stringify(err, null, 2), err.stack);
                reject(err);
            }
            else {
                resolve(data.Item);
            }
        });
    });
};

exports.getConcepto = function(concepto) {
    var params = {
        TableName: `tgr-${process.env.ENV}-conceptos-instituciones`,
        KeyConditionExpression: 'idConcepto = :hkey',
        ExpressionAttributeValues: {
            ':hkey': concepto
        }
    };

    return new Promise((resolve, reject) => {
        docClient.query(params, function(err, data) {
            if (err) {
                console.log("dynamodb get error:", JSON.stringify(err, null, 2), err.stack);
                reject(err);
            }
            else {
                resolve(data);
            }
        });
    });
};

exports.getItems = function(params) {

    return new Promise((resolve, reject) => {
        docClient.query(params, function(err, data) {
            if (err) {
                console.log("dynamodb get error:", JSON.stringify(err, null, 2), err.stack);
                reject(err);
            }
            else {
                resolve(data.Items);
            }
        });
    });
};

exports.getDataQuery = function(params) {

    return new Promise((resolve, reject) => {
        docClient.query(params, function(err, data) {
            if (err) {
                console.log("dynamodb get error:", JSON.stringify(err, null, 2), err.stack);
                reject(err);
            }
            else {
                resolve(data);
            }
        });
    });
};
