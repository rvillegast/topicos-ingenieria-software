import axios from 'axios';

export const handler = async (event) => {
    return new Promise(resolve => {
        let bodyParams = new URLSearchParams(event.body);

        if (!bodyParams.has('scope')) {
            bodyParams.append('scope', 'recaudacion/ipps');
        }

        let rq = {
            headers: {
                "content-type": 'application/x-www-form-urlencoded'
            },
            url: `${process.env.USER_POOL_URL}/oauth2/token`,
            data: bodyParams.toString(),
            method: 'POST'
        };

        axios(rq).then(({ status, data }) => {
            resolve({
                statusCode: status,
                body: JSON.stringify(data)
            })
        }).catch(error => {
            console.error(error, error.stack);
            resolve({
                statusCode: 500,
                body: error.message
            })
        })
    })
};
