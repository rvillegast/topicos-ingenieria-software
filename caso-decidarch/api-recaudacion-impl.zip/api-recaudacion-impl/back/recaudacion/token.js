//'use strict';
const axios = require('axios');
const s3 = require('./aws/s3Services');

exports.obtenerToken = async function () {
    try {
        let config = await s3.getObjectJSON(process.env.BUCKET_NAME, 'config.json');

        const host = config['token_host']; //'wstest.tesoreria.cl';
        const clienteId = config['token_id']; //'OauthInRecibeM1v5MBienesClient';
        const scope = config['token_scope']; //'/RecibeM1Seg/RecibeM1WS.jws*';
        const clientSecret = config['token_secret']; //'TGR.B!3nE81';
        const grantType = config['token_grant']; //'client_credentials';

        return new Promise((resolve, reject) => {

            let data = {
                "grant_type": grantType,
                "client_secret": clientSecret,
                "client_id": clienteId,
                "scope": scope
            };

            let postData = new URLSearchParams(data).toString();

            let options = {
                method: 'POST',
                url: `https://${host}/TokenSoap/`,
                data: postData,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'
                }
            };

            axios(options).then((respuesta) => {
                if (respuesta.data && respuesta.data.access_token) {
                    console.log('respuesta.data.access_token: ', respuesta.data.access_token);
                    resolve(respuesta.data.access_token);
                } else {
                    reject({
                        errors: [{
                            statusCode: 500,
                            message: "Error en la solicitud de Token on-premise (2)"
                        }]
                    });
                }
            }).catch((e) => {
                console.error("error res on error:   " + e);
                reject({
                    errors: [{
                        statusCode: 500,
                        message: "Error en la solicitud de Token on-premise"
                    }]
                });
            });
        });
    } catch (err) {
        console.log(err);
    }
};
