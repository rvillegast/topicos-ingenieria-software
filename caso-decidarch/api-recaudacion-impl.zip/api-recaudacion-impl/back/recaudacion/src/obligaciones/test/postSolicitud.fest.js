const postSolicitud = require('../src/cargos');

const jwt = require('jsonwebtoken')
const axios = require('axios')
const AWS = require('aws-sdk')

jest.setTimeout(20000);

jest.mock('aws-sdk');
jest.mock('https');
jest.mock('axios');

const https = require('https');

let { docClient } = require('../aws/dynamoDbServices')

describe('Ingreso de Solicitud', function() {

    let tokenProduccion;
    let tokenCertificacion;

    let clientIdProduccion = '5ikm6fkfq2d698ttfplbt72ml9';
    let clientIdCertificacion = '89382km6fkfq2d698ttfplbt72ml9';
    let institucion = 'DGAC';
    let formulario = 249;
    let codigoInstitucionOnPrem = 852;

    beforeAll(async() => {
        process.env.PREFIX = 'tgr-lab-api-recaudacion'

        AWS.CognitoIdentityServiceProvider.prototype.describeUserPoolClient = jest.fn((params, callback) => {
            let result;
            switch (params.ClientId) {
                case clientIdProduccion:
                    {
                        result = {
                            UserPoolClient: {
                                ClientName: `institucion=${institucion},formulario=${formulario},girador=${codigoInstitucionOnPrem}`
                            }
                        }
                        break;
                    }

                case clientIdCertificacion:
                    {
                        result = {
                            UserPoolClient: {
                                ClientName: `institucion=${institucion},formulario=${formulario},girador=${codigoInstitucionOnPrem}, ambiente=CERTIFICACION`
                            }
                        }
                        break;
                    }
            }
            callback(null, result);
        });

        axios.mockImplementation((options) => {
            if (options.url.endsWith('TokenSoap/')) {
                return Promise.resolve({
                    data: {
                        access_token: 'fake-token-123'
                    }
                });
            }
            return Promise.resolve({ data: { data: { formulario, codigoInstitucionOnPrem, etapa: 'PRODUCCION' } } })
        })

        tokenProduccion = jwt.sign({
            "client_id": clientIdProduccion
        }, 'xxxxx');

        tokenCertificacion = jwt.sign({
            "client_id": clientIdCertificacion
        }, 'xxxxx');
    });

    it('-> la consulta solo retorna lo productivo', async() => {
        let idsProduccion = [];
        let idsCertificacion = [];

        let requestGirador = {
            "data": {
                "concepto": "DGAC_MULTAS",
                "contribuyente": {
                    "rut": 15456543,
                    "dv": "K"
                },
                "payload": {
                    "items": [{
                            "codigo": 1,
                            "valor": "LAN AIRLINES SA"
                        },
                        {
                            "codigo": 2,
                            "valor": "__"
                        },
                        {
                            "codigo": 3,
                            "valor": "898622002"
                        },
                        {
                            "codigo": 5,
                            "valor": "__"
                        },
                        {
                            "codigo": 6,
                            "valor": "CESAR LARRAIN TORO"
                        },
                        {
                            "codigo": 7,
                            "valor": "1196"
                        },
                        {
                            "codigo": 8,
                            "valor": "SANTIAGO"
                        },
                        {
                            "codigo": 9,
                            "valor": "0"
                        },
                        {
                            "codigo": 10,
                            "valor": "2198"
                        },
                        {
                            "codigo": 11,
                            "valor": "__"
                        },
                        {
                            "codigo": 12,
                            "valor": "__"
                        },
                        {
                            "codigo": 13,
                            "valor": "__"
                        },
                        {
                            "codigo": 15,
                            "valor": "20201017"
                        },
                        {
                            "codigo": 24,
                            "valor": "0338"
                        },
                        {
                            "codigo": 25,
                            "valor": "20200401"
                        },
                        {
                            "codigo": 55,
                            "valor": "__"
                        },
                        {
                            "codigo": 70,
                            "valor": "IMM"
                        },
                        {
                            "codigo": 75,
                            "valor": "0,00"
                        },
                        {
                            "codigo": 76,
                            "valor": "206590,00"
                        },
                        {
                            "codigo": 100,
                            "valor": "CIERRA INVESTIGACIÓN INFRACCIONAL N°100-2018Y APLICA SANCIÓ"
                        },
                        {
                            "codigo": 215,
                            "valor": "20200710"
                        },
                        {
                            "codigo": 465,
                            "valor": "20"
                        }
                    ]
                }
            },
            "metadata": {
                "sendDate": new Date()
            }
        };

        // se inserta una solicitud productiva usando el token productivo
        let data = await postSolicitud.handler({
            path: '/api-recaudacion/v1/solicitudes',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${tokenCertificacion}`
            },
            body: JSON.stringify(requestGirador)
        });
        expect(data.body).toBeDefined();
        idsProduccion.push(JSON.parse(data.body).id);

        // se inserta una solicitud productiva sin environment
        let fechaEvento = new Date().toISOString();
        let idSolicitud = "18523676149716242622";

        let item = {
            "id": idSolicitud,
            "numeroSolicitudRecaudacion": idSolicitud,
            "institucion": "CBRR",
            "fechaEvento": fechaEvento,
            "nombreEstado": "RECIBIDA",
            "payload": {
                "data": {
                    "contribuyente": { "rut": 7023934, "dv": "5" },
                    "callbackURL": "http://52.3.3.94:4200/callback",
                    "receptor": {
                        "rut": 9799598,
                        "dv": "2",
                        "apellidoPaternoORazonSocial": "RS DEL BENEFICIARIO",
                        "cuentaDeposito": {
                            "nombreBanco": "CORPBANCA",
                            "banco": 27,
                            "tipo": "CUENTA_CORRIENTE",
                            "numero": 47311207
                        },
                        "nombre": "Juanito"
                    },
                    "recaudacion": { "moneda": "CLP", "monto": 50 },
                    "conceptoRecaudacion": "Certificado de Dominio Vigente de Titulos de Dominio"
                },
                "metadata": { "mock": false, "sentDate": "2019-12-19T19:54:38.994Z" }
            },
            "url": "http://52.3.3.94:4200/callback",
        };
        await docClient.put({
            TableName: 'tgr-lab-api-recaudacion-eventos',
            Item: item
        }).promise();
        idsProduccion.push(idSolicitud);

        // si inserta una solicitud de certificacion
        data = await postSolicitud.handler({
            path: '/api-recaudacion/v1/solicitudes',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${tokenCertificacion}`
            },
            body: JSON.stringify(requestGirador)
        });
        expect(data.body).toBeDefined();
        idsCertificacion.push(JSON.parse(data.body).id);

        // se consulta por las solicitudes usando el token de produccion
        let event = {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${tokenProduccion}`
            },
            "resource": "/solicitudes",
            "path": "/solicitudes",
            "httpMethod": "GET",
            "queryStringParameters": {
                "interval": "600"
            }
        };
        data = await getSolicitudes.handler(event);
        expect(data.body).toBeDefined();
        let body1 = JSON.parse(data.body);
        let map1 = body1.data.map(i => i.solicitud.id);
        let filtered = map1.filter(i => idsCertificacion.includes(i))
        expect(filtered.length).toEqual(0);
        //expect(map1.sort()).toEqual(idsProduccion.sort())

        // se consulta por las solicitudes usando el token de certificacion
        event = {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${tokenCertificacion}`
            },
            "resource": "/solicitudes",
            "path": "/solicitudes",
            "httpMethod": "GET",
            "queryStringParameters": {
                "interval": "600"
            }
        };
        data = await getSolicitudes.handler(event);
        expect(data.body).toBeDefined();
        let body2 = JSON.parse(data.body);
        let certificationIdsReturned = body2.data.map(i => i.solicitud.id);
        //expect(certificationIdsReturned.sort()).toEqual(idsCertificacion.sort())
        expect(certificationIdsReturned.filter(i => idsProduccion.includes(i)).length).toEqual(0);
    })

  
});
