const clase = require('../descargos');

process.env.ENV = "dev";
process.env.USER_POOL_URL = "https://tgr-dev-api-recaudacion-at-186180787863.auth.us-east-1.amazoncognito.com";


process.env.BUILD_API_DOMAIN = "api.dev.tegere.info"

process.env.BUCKET_NAME = "";
process.env.USER_POOL_ID = "us-east-1_iY3gIYii0";

process.env.API_AUTOSERVICIOS_CLIENT_ID = '35l8t1trd8gpge3p53dv936jnj';
process.env.API_AUTOSERVICIOS_CLIENT_SECRET = '1cqg4utvbsea4o2uvctd3rg8oijkna68jg0bgf1m9mir17r3mog5';
process.env.API_AUTOSERVICIOS_HOST_SERVICE = 'api.dev.tegere.info';
process.env.API_AUTOSERVICIOS_TOKEN_HOST_SERVICE = 'id.dev.tegere.info';

process.env.AWS_ACCESS_KEY_ID = 'ASIASWWJ5L2L4B3R3UP2';
process.env.AWS_SECRET_ACCESS_KEY = '5ICxAlxbYSkMvUxSb8jUdcfXsr6dszKWURaOACDh';
process.env.AWS_SESSION_TOKEN = 'FwoGZXIvYXdzEKb//////////wEaDNFVR2ELvPb+wuEMWSKzATN8FHoLA1J8V5vBBgVdJjxfygbtN7iD9rtZUJgarEH+0O60qy9OAdzqqitqqKnPh5EWhuS0JFqFLufFBNECmnYSljR4RXvHwaIBowiFQmj3P/HytF8OFKc/goLVPFhbICTIGRLoPS5nPMSl6nAH050H64PkPsNMvMOOXUytoD3/YO2l1bXGO7+F62H/8C2raZmw/C0witm9R+h1sTS9hEMNbjholHXQ4tJASxH4rfEU+ezvKKSM85AGMi0+buAUdIMAyS4KImNxFzdqGaG1d7fEeUi6DShjT6pknU/j2AiNCLm1za4Y7e0=';


process.env.BUILD_SSM_PREFIX = "/tgr/dev/api-recaudacion/back/";
process.env.PREFIX = "tgr-dev-api-recaudacion";
process.env.HOST_TOKEN = "id.dev.tegere.info";
 
let data = {
    "data": {
        "payload": {
            "items": [{
                    "codigo": 34,
                    "valor": "253"
                },
                {
                    "codigo": 35,
                    "valor": "20200928"
                }
            ]
        }
    },
    "metadata": {
        "sendDate": new Date()
    }
};
let event = {
  "body": JSON.stringify(data),
  "pathParameters": {"id":"d0a6892b-76d7-4dec-954b-29301ceb6fa1"},
  headers: {
        Authorization: "Bearer eyJraWQiOiJhRDM5TklURjJQUEFzZWE3TTBFWkhCNk9pQW1ZM01FNFdWMGhkVnU3MmZFPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiI2ZTJwYm5hN28ya2Q3MGhvZjBxc2I3YzVlMCIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoicmVjYXVkYWNpb25cL2lwcHMiLCJhdXRoX3RpbWUiOjE2NDYwNTE3NDMsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC51cy1lYXN0LTEuYW1hem9uYXdzLmNvbVwvdXMtZWFzdC0xX2lZM2dJWWlpMCIsImV4cCI6MTY0NjA1NTM0MywiaWF0IjoxNjQ2MDUxNzQzLCJ2ZXJzaW9uIjoyLCJqdGkiOiJkNDBmNTU4NS1kYTQ3LTQ0OTktOWVhOS1iN2E5YTliNzU3NzYiLCJjbGllbnRfaWQiOiI2ZTJwYm5hN28ya2Q3MGhvZjBxc2I3YzVlMCJ9.iVoLmq5MK4z2fTMy7S2zYXjFsggQelRD9xGfKavPthKgoBpN7vtP5tyyOCfbBKrh0ZTyxTQu48raiFIevghWvgu_eRa7vUo7TBDIflbzkMh5Ow5s8s5JvJh5CG4SnaE1n_zGNuBNyw7u0ne94_2gG4whCVj5O5WegJmYdmSW-2rs7VKbJ_Xis4BksPc_5o7_Y5UdsJz2NW6bNs35TdPyiXkZh9lSzC-1VbUmw9HUYoXMJ_vqhpJ9VEsROfurvE2KF9YQHmXcPk4LilJAoW0HMJW0haestGqLa4BKY1XNk_8VgXFpiHuUfCkxYZ8ZA02WN7OP2glCecEu_pMAetz40w"
  }
};
 
clase.handler(event, null, () => { console.log("fin") });
