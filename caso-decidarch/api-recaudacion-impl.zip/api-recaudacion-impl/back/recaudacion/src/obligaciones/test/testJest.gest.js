const clase = require('../src/cargos');
const oauth = require('../src/utils/oauth2Token');

process.env.ENV = "dev";
process.env.USER_POOL_URL = "https://tgr-dev-api-recaudacion-at-186180787863.auth.us-east-1.amazoncognito.com";

process.env.BUCKET_NAME = "";
process.env.USER_POOL_ID = "us-east-1_iY3gIYii0";

process.env.API_AUTOSERVICIOS_CLIENT_ID = '35l8t1trd8gpge3p53dv936jnj';
process.env.API_AUTOSERVICIOS_CLIENT_SECRET = '1cqg4utvbsea4o2uvctd3rg8oijkna68jg0bgf1m9mir17r3mog5';
process.env.API_AUTOSERVICIOS_HOST_SERVICE = 'api.dev.tegere.info';
process.env.API_AUTOSERVICIOS_TOKEN_HOST_SERVICE = 'id.dev.tegere.info';

process.env.AWS_ACCESS_KEY_ID = 'ASIASWWJ5L2LRIKALCP5';
process.env.AWS_SECRET_ACCESS_KEY = 'TTVrbKbugiHYmyETg0DayJEBO963daUqN7EUNlbE';
process.env.AWS_SESSION_TOKEN = 'IQoJb3JpZ2luX2VjEPD//////////wEaCXVzLWVhc3QtMSJHMEUCICaHhyIKWU6xH3vQUC72bDuOVRoLbK/7bhsrYXk1vDtYAiEA/OP9a86GMFEPygWvcAYqWzcbnSRN+vg0LU7JN/qtlgMq5wEI2P//////////ARABGgwxODYxODA3ODc4NjMiDDEGzOzSoRxUWPYxKiq7AVXh19RP6eKXiZXUsW+kahtSrIDnkQs8J4G3Iqn9xBXLi041AOfHi8+8Og5C/MSUNaBcHOuuIuZ0LarO4dY/CBSo3DEuJyXy32ytn3mWcunnxYC4U3l+GTZBzvI0PvUD+WuiKEnqs8DLKfhkpTlV5ZcMV/2SMUVIazhrlsk1+mP6sHGo0GamLVaqyVl64ETaXEHbZfQsy6uYsi3xKpAUzpCjMsTsD5hXBCWk9jnH0C5pmxj/iQ0Zh3pnfPcws/SZ+gU64AEuEFuLyvx0WMLNqHLhQzikWYEv9fk2O7FBsa51hSf6F0HnO8CEVEFbihdjYqNzxZtbFY6EpmQdgeHyb1JuocIHwRJ310/rw8kUxY96NBvdC5PlTm2/KWARXKS3yhul2K8kHu98+Bht0Lqlj/Ke4q+a4dyWOpQq4QHXTocrAtFON7drNc+A2AsooOSYyB9ABlGTxzgpRh+FYO6kDYnzweHlHFehTQfNkwlLmtJLbq6lVLa2zerVApZjIAHEkPej07yTYdsnNIg23z7xnozdj477naXGP6ccf0G3L0vUxWHZFA==';


process.env.BUILD_SSM_PREFIX = "/tgr/dev/api-recaudacion/back/";

const jwt = require('jsonwebtoken')
const axios = require('axios')
const AWS = require('aws-sdk')

jest.setTimeout(20000);

jest.mock('aws-sdk');
jest.mock('https');
jest.mock('axios');


describe('Test Api Obligaciones', () => {


    let data = {
        "data": {
            "concepto": "DGAC_MULTAS",
            "contribuyente": {
                "rut": 15456543,
                "dv": "K"
            },
            "payload": {
                "items": [{
                        "codigo": 1,
                        "valor": "LAN AIRLINES SA"
                    },
                    {
                        "codigo": 2,
                        "valor": "__"
                    },
                    {
                        "codigo": 3,
                        "valor": "898622002"
                    },
                    {
                        "codigo": 5,
                        "valor": "__"
                    },
                    {
                        "codigo": 6,
                        "valor": "CESAR LARRAIN TORO"
                    },
                    {
                        "codigo": 7,
                        "valor": "1191"
                    },
                    {
                        "codigo": 8,
                        "valor": "SANTIAGO"
                    },
                    {
                        "codigo": 9,
                        "valor": "0"
                    },
                    {
                        "codigo": 10,
                        "valor": "2198"
                    },
                    {
                        "codigo": 11,
                        "valor": "__"
                    },
                    {
                        "codigo": 12,
                        "valor": "__"
                    },
                    {
                        "codigo": 13,
                        "valor": "__"
                    },
                    {
                        "codigo": 15,
                        "valor": "20201017"
                    },
                    {
                        "codigo": 24,
                        "valor": "0338"
                    },
                    {
                        "codigo": 25,
                        "valor": "20200401"
                    },
                    {
                        "codigo": 55,
                        "valor": "__"
                    },
                    {
                        "codigo": 70,
                        "valor": "IMM"
                    },
                    {
                        "codigo": 75,
                        "valor": "0,00"
                    },
                    {
                        "codigo": 76,
                        "valor": "206590,00"
                    },
                    {
                        "codigo": 100,
                        "valor": "CIERRA INVESTIGACIÓN INFRACCIONAL N°100-2018Y APLICA SANCIÓ"
                    },
                    {
                        "codigo": 215,
                        "valor": "20200710"
                    },
                    {
                        "codigo": 465,
                        "valor": "20"
                    }
                ]
            }
        },
        "metadata": {
            "sendDate": new Date()
        }
    };

    let event = {
        "body": JSON.stringify(data),
        headers: {
            Authorization: "Bearer eyJraWQiOiJhRDM5TklURjJQUEFzZWE3TTBFWkhCNk9pQW1ZM01FNFdWMGhkVnU3MmZFPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiI0dmQ3c2R0NnExdjQ0NGxrY2UwdHAyOWJhYiIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoicmVjYXVkYWNpb25cL2lwcHMiLCJhdXRoX3RpbWUiOjE1OTc4MDU2NDMsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC51cy1lYXN0LTEuYW1hem9uYXdzLmNvbVwvdXMtZWFzdC0xX2lZM2dJWWlpMCIsImV4cCI6MTU5NzgwOTI0MywiaWF0IjoxNTk3ODA1NjQzLCJ2ZXJzaW9uIjoyLCJqdGkiOiJhNGYyNDlmMC0yOWFmLTQ1YWUtODc4Yi0zMWVmMzk5ZDk3OTMiLCJjbGllbnRfaWQiOiI0dmQ3c2R0NnExdjQ0NGxrY2UwdHAyOWJhYiJ9.lhuKPm1FmuOc7mgCkkd-iOyhMXI4Ts0UMOQwFdJQiPH1Mmv-zld7Rgdh4qGh34nUHXkaSlvU7orUne0cp1ppaHRRZPg7loKFIbZwmTjG4K-gboNRy-2_dN7r8ycSEl7oGDsuu5uvcI_KhiDOm327dmguoGDzNGRkZIH6net_tnN3BGBEHxqaRQ0j94uhxQkNvFUgbGZJkbUO99jfc409D8Tn4_05WdHk0zAobF8O42GqwUsO5KODBx2cFb4dzTsfGa7d6yp1OjauwwZegmOCo9z9TqaIhPmh9aV6SN9cqzNBvzF7Z7KBK60Uzi9XIhC3gf1ajhbH-Q3_e5WbZGurSA"
        }
    };

    let tokenProduccion;
    let tokenCertificacion;

    let clientIdProduccion = '5ikm6fkfq2d698ttfplbt72ml9';
    let clientIdCertificacion = '89382km6fkfq2d698ttfplbt72ml9';
    let institucion = 'DGAC';
    let formulario = 249;
    let codigoInstitucionOnPrem = 852;

    beforeAll(async() => {
        process.env.PREFIX = 'tgr-lab-api-recaudacion'

        AWS.CognitoIdentityServiceProvider.prototype.describeUserPoolClient = jest.fn((params, callback) => {
            let result;
            switch (params.ClientId) {
                case clientIdProduccion:
                    {
                        result = {
                            UserPoolClient: {
                                ClientName: `institucion=${institucion},formulario=${formulario},girador=${codigoInstitucionOnPrem}`
                            }
                        }
                        break;
                    }

                case clientIdCertificacion:
                    {
                        result = {
                            UserPoolClient: {
                                ClientName: `institucion=${institucion},formulario=${formulario},girador=${codigoInstitucionOnPrem}, ambiente=CERTIFICACION`
                            }
                        }
                        break;
                    }
            }
            callback(null, result);
        });

        axios.mockImplementation((options) => {
            if (options.url.endsWith('TokenSoap/')) {
                return Promise.resolve({
                    data: {
                        access_token: 'fake-token-123'
                    }
                });
            }
            return Promise.resolve({ data: { data: { formulario, codigoInstitucionOnPrem, etapa: 'PRODUCCION' } } })
        })

        tokenProduccion = jwt.sign({
            "client_id": clientIdProduccion
        }, 'xxxxx');

        tokenCertificacion = jwt.sign({
            "client_id": clientIdCertificacion
        }, 'xxxxx');

        console.log("tokenCertificacion", tokenCertificacion)
    });



    it('Primer Test', async() => {

        /*
                let result = await clase.handler(event);
                
                console.log(result.body)

                expect(result.statusCode).toBe(201);
                
               */


        let event = {
            "body": JSON.stringify(data),
            headers: {
                "Content-Type": 'application/json',
                Authorization: `Bearer ${tokenCertificacion}`
            }
        };

        // Obtengo token.
        let tokenResp = await clase.handler(event);




    });



});
