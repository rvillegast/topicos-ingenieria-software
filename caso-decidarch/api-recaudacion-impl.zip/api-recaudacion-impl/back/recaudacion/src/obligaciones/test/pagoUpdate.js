const clase = require('../pagos');

process.env.ENV = "dev";
process.env.USER_POOL_URL = "https://tgr-dev-api-recaudacion-at-186180787863.auth.us-east-1.amazoncognito.com";


process.env.BUILD_API_DOMAIN = "api.dev.tegere.info"

process.env.BUCKET_NAME = "";
process.env.USER_POOL_ID = "us-east-1_iY3gIYii0";

process.env.API_AUTOSERVICIOS_CLIENT_ID = '35l8t1trd8gpge3p53dv936jnj';
process.env.API_AUTOSERVICIOS_CLIENT_SECRET = '1cqg4utvbsea4o2uvctd3rg8oijkna68jg0bgf1m9mir17r3mog5';
process.env.API_AUTOSERVICIOS_HOST_SERVICE = 'api.dev.tegere.info';
process.env.API_AUTOSERVICIOS_TOKEN_HOST_SERVICE = 'id.dev.tegere.info';

process.env.AWS_ACCESS_KEY_ID = 'ASIASWWJ5L2LZ6MB6CO7';
process.env.AWS_SECRET_ACCESS_KEY = 'oxuQV1L5jcwYNuxr4jvqwv4yh08/lY9jTo5iiIbj';
process.env.AWS_SESSION_TOKEN = 'IQoJb3JpZ2luX2VjEAEaCXVzLWVhc3QtMSJHMEUCIDofmSiC9EvO6yE7CONEDINIbk2ygdbRPWW9CwMMGJw5AiEAg3BLfVzPLyQOdOluTPOemSPcc/Ihxp2ELqGw3fB3LPUq6QEIOhABGgwxODYxODA3ODc4NjMiDFiFwbk1dsb1JoFd2yrGARIC0ef1xw0vbFoEC9ovS7yLeiF+LYM9qJA+ELGeW5OvWcG0mZNuyE1WCY1f4zD9ysAThgWEGhY15sHpg5XUobWA9xog+sCNV5VwUR72bfp7yscFf8h/LMXtAOazV9IuoDWiPI0k2CscsItdIwRZi1o0AA+xbi8btUf8QZkfPgvpXbICupje+zR8b9MRJEM+lqFxerb0Lp2kiCgYnmaD5xsjN06acsKWVnSyVrbPfg9uBbjWMXfAC6h852BNSRppNNoJIXBmKzD63v77BTrgARu0Zh8Xf58UlxA5CG/qle9o+5wnTmlhG0YK4YUxBw3WZQ5ahw4Iag4M0Kf4dzVah1hBe6JY0JPdjWSnhPs0yjPxRT9MMuNViYD3mk/27UOuT7JOttFHgaPTeOUWyXL3IzS9UfODXfVMVdXskwRukQ+7DUA0cel9IAdEk4abTlrfN9tbch+Eh4uGZbxJpSh2uP0LTDEdK/i+A3Xm9BBQkjtod3/zS0xrXLkgaIcrIalQb2saH9epCmChl+d4X1R3V03Vt+n5qFtel6NzuryaGw34Mpgw6diyRi2X0itAbpFx';


process.env.BUILD_SSM_PREFIX = "/tgr/dev/api-recaudacion/back/";
process.env.PREFIX = "tgr-dev-api-recaudacion";


let data = {
    "data": {
        "totalPago": 172100,
        "iraCodigo": 14,
        "iraNombre": "SCOTIABANK CHILE",
        "fechaPago": "2015-02-20T10:33:55.000"
    },
    "metadata": {
        "sendDate": new Date()
    }
};
let event = {
    "body": JSON.stringify(data),
    "pathParameters": { "id": "b4d3584b-e641-4704-89c5-30dd23278c4f" },
    headers: {
        Authorization: "Bearer eyJraWQiOiJhRDM5TklURjJQUEFzZWE3TTBFWkhCNk9pQW1ZM01FNFdWMGhkVnU3MmZFPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiI2ZTJwYm5hN28ya2Q3MGhvZjBxc2I3YzVlMCIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoicmVjYXVkYWNpb25cL2lwcHMiLCJhdXRoX3RpbWUiOjE2MDA5NTg0MDIsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC51cy1lYXN0LTEuYW1hem9uYXdzLmNvbVwvdXMtZWFzdC0xX2lZM2dJWWlpMCIsImV4cCI6MTYwMDk2MjAwMiwiaWF0IjoxNjAwOTU4NDAyLCJ2ZXJzaW9uIjoyLCJqdGkiOiI4NDYyZjUwYS1kNDIwLTRiOTYtOGI4Ny1kZDUwN2QwY2ExMmUiLCJjbGllbnRfaWQiOiI2ZTJwYm5hN28ya2Q3MGhvZjBxc2I3YzVlMCJ9.S1aIRwBCuoXd6zKUuFm7FYDra2zunQPWQZCOXI0D2mm54NaWkV0gTnPLhBPIazJEZJA3iGxIoWEhqiFZkV4BYRuDhBIWATLZZD16s9XtPLXZtOKHPVlCCN5DiMcDOd0J1OfAYFFvaTW96lW7lYhBBJnieU5K4czmpVzYElEOvOqR45xvF6BWvgjKA-lDZw_nx9wSbzxf2hZK3GfdJcDkiqhiXdFwNLju9w6LilGHs8gqLuwFhU3EajMKhj5qh9d3gKpWgIce0mq9wohj1tqT_07SCQYWA1U-jmRj6XBU-ETqxTwldCPrAJuZAeDm4GSGa2z1OUZDqSuX74G427L7VA"
    }
};

clase.handler(event, null, () => { console.log("fin") });
