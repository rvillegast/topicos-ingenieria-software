//const axios = require("axios");
import axios from 'axios';

module.exports.handler = async(event) => {

  return new Promise((resolve) => {
    let rq = {
      headers: {
        "content-type": "application/x-www-form-urlencoded",
      },
      url: "https://api.dev.tegere.info/recaudacion/v1/oauth2/token",
      data: event.body,
      method: "POST",
    };

    axios(rq)
      .then(({ status, data }) => {
        resolve({
          statusCode: status,
          body: JSON.stringify(data),
        });
      })
      .catch((error) => {
        console.error(error, error.stack);
        resolve({
          statusCode: 500,
          body: error.message,
        });
      });

  });
};
