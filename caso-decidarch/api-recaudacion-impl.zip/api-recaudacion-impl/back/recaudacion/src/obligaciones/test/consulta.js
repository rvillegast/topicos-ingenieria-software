process.env.ENV = "dev";
process.env.USER_POOL_URL = "https://tgr-dev-api-recaudacion-at-186180787863.auth.us-east-1.amazoncognito.com";
const clase = require('../consulta');

process.env.BUILD_API_DOMAIN = "api.dev.tegere.info"

process.env.BUCKET_NAME = "";
process.env.USER_POOL_ID = "us-east-1_iY3gIYii0";

process.env.API_AUTOSERVICIOS_CLIENT_ID = '35l8t1trd8gpge3p53dv936jnj';
process.env.API_AUTOSERVICIOS_CLIENT_SECRET = '1cqg4utvbsea4o2uvctd3rg8oijkna68jg0bgf1m9mir17r3mog5';
process.env.API_AUTOSERVICIOS_HOST_SERVICE = 'api.dev.tegere.info';
process.env.API_AUTOSERVICIOS_TOKEN_HOST_SERVICE = 'id.dev.tegere.info';

process.env.AWS_ACCESS_KEY_ID = 'ASIASWWJ5L2L4OJJUMXN';
process.env.AWS_SECRET_ACCESS_KEY = '9bisjQMOh3gHAr4hL0VBFq32v1VHeZzS3Fqb3Fh0';
process.env.AWS_SESSION_TOKEN = 'IQoJb3JpZ2luX2VjEDAaCXVzLWVhc3QtMSJHMEUCIQCnzskY3+w25+OT9/VF7QYng3hNEV0T0kyq6Hj130mzSQIgKA6IfLC6ODNwdqKA/9OC0IpzWL3uMlaWejb8WXsCypsq6gEIeRABGgwxODYxODA3ODc4NjMiDLR+Xe57/CU9cQ5CGyrHAeXsJ9joOV+SEwjLjx7St3rUqPdQniA7NGIevAVCQ4lKKdZsp7iLKzhNZGgcSW0Nv12VaTyw0m2OAYHq6sFb0f9ts5Z3SLlkaw08OceYLIeTRdBNY/VLIBgklMpU1shyF0zPqVvPg6LfzsoKMb5VVhqlpuIIImmLjiW4mUdgyoFsUMm0zqB6sCqxwRTuZKMv46YdN1ZOQQwgmZnYUjYK0kLVx9l5pyBNdNdAtaQhrsjWkAF3LJOC6Xo4AR8L6EQfmO0Y9HquV2Iw1rTB/AU64AHPsrJv86EjQGyI4JN6jyGzMty8p+6lHq2ZgdePrOT5B0XPO6AG19RhUAtHhUd7/Vi2cH8IW4Xe3XxM8xOjYxUCcnWgIJiTxqYfGSBsQtwcnJjbs1cL3W4J9NyBa/Uej+9OCVkvPmEHg7hfUcElFD8o+WkrtmI4QYbabsqMOv3NQPpC9xnims7h59B3hc0cDVCgSaTcePBcZ7U9n0bPezDRlYkzUGMrSbKjy/Hu/1jVdEJmWrLZuep2SFqnNW0PGPZ8Q4RZWemI97cmlna6GTH1Jk0a7E7A6aDxV0+e3kyH4A==';


process.env.BUILD_SSM_PREFIX = "/tgr/dev/api-recaudacion/back/";
process.env.PREFIX = "tgr-dev-api-recaudacion";

 
//let event = {"pathParameters": {"id":"f0a8da65-c7bf-4721-b44f-38e11cf9797d"}}; // json entrada para buscar certificado


let event = {
  "pathParameters": {"id":"5ec5601b-c878-402b-abb6-d203fcb9b205"},
  headers: {
        Authorization: "Bearer eyJraWQiOiJhRDM5TklURjJQUEFzZWE3TTBFWkhCNk9pQW1ZM01FNFdWMGhkVnU3MmZFPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiI2ZTJwYm5hN28ya2Q3MGhvZjBxc2I3YzVlMCIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoicmVjYXVkYWNpb25cL2lwcHMiLCJhdXRoX3RpbWUiOjE2MDA5NTg0MDIsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC51cy1lYXN0LTEuYW1hem9uYXdzLmNvbVwvdXMtZWFzdC0xX2lZM2dJWWlpMCIsImV4cCI6MTYwMDk2MjAwMiwiaWF0IjoxNjAwOTU4NDAyLCJ2ZXJzaW9uIjoyLCJqdGkiOiI4NDYyZjUwYS1kNDIwLTRiOTYtOGI4Ny1kZDUwN2QwY2ExMmUiLCJjbGllbnRfaWQiOiI2ZTJwYm5hN28ya2Q3MGhvZjBxc2I3YzVlMCJ9.S1aIRwBCuoXd6zKUuFm7FYDra2zunQPWQZCOXI0D2mm54NaWkV0gTnPLhBPIazJEZJA3iGxIoWEhqiFZkV4BYRuDhBIWATLZZD16s9XtPLXZtOKHPVlCCN5DiMcDOd0J1OfAYFFvaTW96lW7lYhBBJnieU5K4czmpVzYElEOvOqR45xvF6BWvgjKA-lDZw_nx9wSbzxf2hZK3GfdJcDkiqhiXdFwNLju9w6LilGHs8gqLuwFhU3EajMKhj5qh9d3gKpWgIce0mq9wohj1tqT_07SCQYWA1U-jmRj6XBU-ETqxTwldCPrAJuZAeDm4GSGa2z1OUZDqSuX74G427L7VA"
  }
};
 
clase.handler(event, null, () => { console.log("fin") });
