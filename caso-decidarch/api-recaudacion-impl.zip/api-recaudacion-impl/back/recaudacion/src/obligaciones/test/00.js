const clase = require('../cargos');

process.env.ENV = "dev";
process.env.USER_POOL_URL = "https://tgr-dev-api-recaudacion-at-186180787863.auth.us-east-1.amazoncognito.com";
process.env.USER_POOL_ID = "us-east-1_iY3gIYii0";

process.env.BUILD_API_DOMAIN = "api.dev.tegere.info"

process.env.BUCKET_NAME = "";


process.env.API_AUTOSERVICIOS_CLIENT_ID = '35l8t1trd8gpge3p53dv936jnj';
process.env.API_AUTOSERVICIOS_CLIENT_SECRET = '1cqg4utvbsea4o2uvctd3rg8oijkna68jg0bgf1m9mir17r3mog5';
process.env.API_AUTOSERVICIOS_HOST_SERVICE = 'api.dev.tegere.info';
process.env.API_AUTOSERVICIOS_TOKEN_HOST_SERVICE = 'id.dev.tegere.info';

process.env.AWS_ACCESS_KEY_ID = 'ASIASWWJ5L2LSVAQ2TFB';
process.env.AWS_SECRET_ACCESS_KEY = 'WSh4Ho+bHITZvUS0Z1iGULpsA4PhShcnW/0GQZ46';
process.env.AWS_SESSION_TOKEN = 'IQoJb3JpZ2luX2VjEHkaCXVzLWVhc3QtMSJHMEUCIDWILMbbsKp1YLcxy0A3W4ismCcU+p2G8BbciG/TeoTTAiEAiTMnGT8NxAGZa7rGB7wakshUaogIyPbwTtC2N21qL74q8wEI0v//////////ARABGgwxODYxODA3ODc4NjMiDA4s4q3zyP66jBJT+irHATMb6gGZC1T0LMcNu84VEffliZF1fc5AHdVk3H8b7uPplAI/RCtlLJlPKS+yxvkRNFqt253IGaZnM5R0CscfN3aX4cWc5mjPZ40O6e0A/SJ4z2LkKV0cdrEucHWc8Rg/vpMS4VQUOSdRzjqKFuRCgWJWfih4Muwag+rTXhLkZHeskxadMxiyoBJ4b/EVfq67mN9kKexLZi7/yTD5iNVu5QXsq/OHT+NBQ9WJMSdSiBMsGbFjDkcVmZM+eTnMtF2ex3bOCLpbkfcw8NiJ/QU64AGhbOfbNgKIuBAF7Z0GR4WgpvT2FfrKcs8kz6dQf3HJv8tvAQxs7ophrGBYiM4t6/nXeOjfk+DThf43rJa3etpzduS/WwTZtxa10tZ6bQbu2QNBqnwjCSZSPY1+bu9G9/dZiMkCfSNSEcQiuBvMJwAf26mqFBDfxcQ/5ra0AdvzKxKQLAMuUn7ieGKPGuNBLlUqCtE55YJoO60emk358Ld8Hi3prA/4TwWLIDhhPchPOIcMFby9jPal8Uh43mp1/zxSiHoIyZb9LLqaRjj7zIoH2XId39Xm3nw5lWuLzHO27Q==';


process.env.BUILD_SSM_PREFIX = "/tgr/dev/api-recaudacion/back/";
process.env.PREFIX = "tgr-dev-api-recaudacion";

let data = {
    "data": {
        "concepto": "PATENTES_AGUA_DGA",
        "contribuyente": {
            "rut": 13730993,
            "dv": "9"
        },
        "payload": {
            "items": [{
                    "codigo": 1,
                    "valor": "PEREZ"
                },
                {
                    "codigo": 2,
                    "valor": "PEREZ"
                },
                {
                    "codigo": 5,
                    "valor": "JUAN PABLO"
                },
                {
                    "codigo": 3,
                    "valor": "13730993-9"
                },
                {
                    "codigo": 7,
                    "valor": "47209"
                },
                {
                    "codigo": 8,
                    "valor": "Pica"
                },
                {
                    "codigo": 15,
                    "valor": "20190331"
                },
                {
                    "codigo": 24,
                    "valor": "100"
                },
                {
                    "codigo": 25,
                    "valor": "20200929"
                },
                {
                    "codigo": 70,
                    "valor": "UTM"
                },
                {
                    "codigo": 75,
                    "valor": "470.400000"
                },

                {
                    "codigo": 215,
                    "valor": "20200929"
                }
            ]
        }
    },
    "metadata": {
        "sendDate": new Date()
    }
};


let event = {
    "body": JSON.stringify(data),
    headers: {
        Authorization: "Bearer eyJraWQiOiJhRDM5TklURjJQUEFzZWE3TTBFWkhCNk9pQW1ZM01FNFdWMGhkVnU3MmZFPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiI2ZTJwYm5hN28ya2Q3MGhvZjBxc2I3YzVlMCIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoicmVjYXVkYWNpb25cL2lwcHMiLCJhdXRoX3RpbWUiOjE2MDI1OTc3MDQsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC51cy1lYXN0LTEuYW1hem9uYXdzLmNvbVwvdXMtZWFzdC0xX2lZM2dJWWlpMCIsImV4cCI6MTYwMjYwMTMwNCwiaWF0IjoxNjAyNTk3NzA0LCJ2ZXJzaW9uIjoyLCJqdGkiOiIwN2QwMGE2NC1kOTg0LTRiZDgtOWViNS1iZGI3NmQ0Nzc1YTMiLCJjbGllbnRfaWQiOiI2ZTJwYm5hN28ya2Q3MGhvZjBxc2I3YzVlMCJ9.NTi7RlKSqKi9HUrLRHEZE7xBXTpxphPRVlAliOktCWDVHtpNvYCzdK6dLeGrMIz9zBEs1rHLi5EC6bWEgpftozUwV-YXRVIw3FTG0KQ3Zn7fCy1CoeJiXw0Dpp6CzC4iaYIRXGOCqS7qxsDhx_wODskAy_SVTN5qpHgJ5GkOxMhP2G8zcwc4fiepyNfB5irgB7w-uB-IM5qx_-L7jZXwDfLLzpppXpqzHE4Wk0ETRJO5OCMqBabePzIi5fezR-JK6YyTMT0gqhjjv0q7IQ9ximbmOr1oFzxAuUIjAHoU9FZBISAKZoI8Mr41KEca0Q7Z92G2LWTeOb0lHm6Gc6UORg"
    }
};


clase.handler(event, null, () => { console.log("fin") });
