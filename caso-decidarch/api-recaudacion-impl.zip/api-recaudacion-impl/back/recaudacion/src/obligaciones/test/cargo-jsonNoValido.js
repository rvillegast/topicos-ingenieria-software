process.env.ENV = "dev";
process.env.USER_POOL_URL = "https://tgr-dev-api-recaudacion-at-186180787863.auth.us-east-1.amazoncognito.com";
const clase = require('../cargos');

process.env.BUILD_API_DOMAIN = "api.dev.tegere.info"

process.env.BUCKET_NAME = "";
process.env.USER_POOL_ID = "us-east-1_iY3gIYii0";

process.env.API_AUTOSERVICIOS_CLIENT_ID = '35l8t1trd8gpge3p53dv936jnj';
process.env.API_AUTOSERVICIOS_CLIENT_SECRET = '1cqg4utvbsea4o2uvctd3rg8oijkna68jg0bgf1m9mir17r3mog5';
process.env.API_AUTOSERVICIOS_HOST_SERVICE = 'api.dev.tegere.info';
process.env.API_AUTOSERVICIOS_TOKEN_HOST_SERVICE = 'id.dev.tegere.info';

process.env.AWS_ACCESS_KEY_ID = 'ASIASWWJ5L2LUK2JZMED';
process.env.AWS_SECRET_ACCESS_KEY = 'k55EuYZ+Ok88/8mW9Xwup67oDhb9pUyHI4JqM/pP';
process.env.AWS_SESSION_TOKEN = 'IQoJb3JpZ2luX2VjEMb//////////wEaCXVzLWVhc3QtMSJHMEUCIQDIEBNe70aVy7UUR7c6Wg7T4g14LIwYRFHtAcvAjDJaNQIgM9+QtVewvh6LVqfPXi59LpDYm92YtMCC56nhTK6rB7gq8wEIv///////////ARABGgwxODYxODA3ODc4NjMiDIne5xKEZeP6jCyA1irHAVwfX2QDFornw4liPT2gVRVdAIbli/TtQoaRo+55O4VFZwLpHNN08MAJHx5tLs9ir9fZ8vwBC2KMrn5DW+HNk8LmoGc+mgcFuYbobME1gDEpxfdjG7A7ozmyeCzsghyEXlAQg/9j+RdQ/2K9EwTLbYwkNJ9ffJuz6NHU1mabqCy1nMo+FIXXxsDG1FngwmuIIEVFTbBV7HzRk6OvITF7r1b2xDLBj6iwaDtRTUewO/gWaBs5ezabsn8z4c9sNd9Ykzgisv6chcEw/I3J+gU64AGdi94Yl3YTiQsCgFPll6Zu95iq68Nn6P3k9wQZp+5D89XTC5NCbmKJuIFND4yY3+PN82qHF5E8EfZZfmo9cKzvzDjV6EPVKi6TkV+llwfAS9M/91N9EjpHTd7xLObk0nX7j5yiDuPjwfRvdOLdXjgAYRzJWjjH7d42KO5MhOo0WkzIA/Qi0SO1OabUyjsP2mv9eSa+GcmIDOx7bxJze5gXofpIHUHPUkMzf3jrGrMbMzJD1XuHM8du0AXCaJlhqfEDkufdu3vMLjSdoDWQHO07peS2QueBUKdgolj6lCGvMQ==';

process.env.BUILD_SSM_PREFIX = "/tgr/dev/api-recaudacion/back/";
process.env.PREFIX = "tgr-dev-api-recaudacion";

let data = {
  "data": {
    "contribuyente": {
      "rut": 13730993,
      "dv": "9"
    },
    "payload": {
      "items": [
         {
                "codigo": 1,
                "valor": "OYARZUN"
            },
            {
                "codigo": 2,
                "valor": "GAVILAN"
            },
            {
                "codigo": 3,
                "valor": "137309939"
            },
            {
                "codigo": 5,
                "valor": "JOHANNA VALESKA"
            },
            {
                "codigo": 6,
                "valor": "PJE LA ARCILLA 1114 VILLA LOS SAUCES"
            },
            {
                "codigo": 7,
                "valor": "333"
            },
            {
                "codigo": 8,
                "valor": "LA FLORIDA"
            },
            {
                "codigo": 15,
                "valor": "20141001"
            },
            {
                "codigo": 24,
                "valor": "09090"
            },
            {
                "codigo": 25,
                "valor": "20140403"
            },
            {
                "codigo": 70,
                "valor": "UF"
            },
            {
                "codigo": 75,
                "valor": "9898,98"
            },
            {
                "codigo": 76,
                "valor": "24170,44"
            },
            {
                "codigo": 91,
                "valor": "239262702"
            },
            {
                "codigo": 191,
                "valor": "9898,98"
            },
            {
                "codigo": 215,
                "valor": "20141001"
            },
            {
                "codigo": 260,
                "valor": "239262702"
            }
      ]
    }
  },
  "metadata": {
    "sendDate": new Date()
  }
};


let event = {
  "body": JSON.stringify(data),
  headers: {
    Authorization: "Bearer eyJraWQiOiJhRDM5TklURjJQUEFzZWE3TTBFWkhCNk9pQW1ZM01FNFdWMGhkVnU3MmZFPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiI2Ym5uNzN2MnE4Z24zNHFxNGNkMXRlZGdubiIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoicmVjYXVkYWNpb25cL2lwcHMiLCJhdXRoX3RpbWUiOjE1OTkxODIyNzMsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC51cy1lYXN0LTEuYW1hem9uYXdzLmNvbVwvdXMtZWFzdC0xX2lZM2dJWWlpMCIsImV4cCI6MTU5OTE4NTg3MywiaWF0IjoxNTk5MTgyMjczLCJ2ZXJzaW9uIjoyLCJqdGkiOiI1ZGJiYTU0OC1jN2RiLTRhOTAtODcwZS1iODI0YjY1NzU5Y2EiLCJjbGllbnRfaWQiOiI2Ym5uNzN2MnE4Z24zNHFxNGNkMXRlZGdubiJ9.fbuwY5rhgqJQDv-3DwL_vx1u1sooo7_N4XiBdVeD8e3K-_tIJWrqpvBflGqxrLiDFW0UVQSvfxjq2iW9EfWkCgMe4C6TIbfLnl5rdjYzYDH2n29r8r2POFQ4YG9ZqI7PoapFGRITa0MsI8B9CnTqk2Xj7Jf_CKeutGs8xCN_6SU63jhVQhc3ewBHMzivtBb0JYTINJBwGhbRYO5Ww_8RxLh-PJ6adEW86JRoejtWk4o3irLUrkPfgCHMPDYwF91gTWr-sxaIyrAVZQi3621LpOjmP2UQ2XsDqiEU6AY65cqdBb3jqZHkzHj8dI48_rR2lo81-EDd9Q-AV8XKYsY-7g"
  }
};


clase.handler(event, null, () => { console.log("fin") });
