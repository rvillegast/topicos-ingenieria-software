process.env.ENV = "dev";
process.env.USER_POOL_URL = "https://tgr-dev-api-recaudacion-at-186180787863.auth.us-east-1.amazoncognito.com";
const clase = require('../cargos');

process.env.BUILD_API_DOMAIN = "api.dev.tegere.info"

process.env.BUCKET_NAME = "";
process.env.USER_POOL_ID = "us-east-1_iY3gIYii0";

process.env.API_AUTOSERVICIOS_CLIENT_ID = '35l8t1trd8gpge3p53dv936jnj';
process.env.API_AUTOSERVICIOS_CLIENT_SECRET = '1cqg4utvbsea4o2uvctd3rg8oijkna68jg0bgf1m9mir17r3mog5';
process.env.API_AUTOSERVICIOS_HOST_SERVICE = 'api.dev.tegere.info';
process.env.API_AUTOSERVICIOS_TOKEN_HOST_SERVICE = 'id.dev.tegere.info';

process.env.AWS_ACCESS_KEY_ID = 'ASIASWWJ5L2L6MKP2T4R';
process.env.AWS_SECRET_ACCESS_KEY = 'cRQBV2paGAO3Oz8zA+2SizdeyYu+bhqlBV0/LBse';
process.env.AWS_SESSION_TOKEN = 'IQoJb3JpZ2luX2VjEAEaCXVzLWVhc3QtMSJIMEYCIQDxuyLraTIzwGGUYjdliaHAY1YdFdv6QDZQjJhlXexyywIhAP9JMVRX9B7DhM5IUfR7oy8aveE9sFrkCJ3FnGG5m9nAKvMBCPn//////////wEQARoMMTg2MTgwNzg3ODYzIgwJrF72WL4MWrfB4tkqxwGt+SiNrFVhHkpdMflOpdAGkEXCPxtH/POxl6Bv8c9WTyaJD/9wskw0AL5+mst3XdenraCUAJIX7C0KsI6fQYjlCwobTt6fUKxIxdRjJcGt+OhCeUvWg3fIZMZ5TR24ar4DYaSIgq838/pfdfAiv6fFqxzD5n38q8BRRY08tfpIu6dZecUKL0MxRIYJrovTYwKeZkCpis0cGIdeHPNJdMsZxpvxIJP/z/ZVRdX/oCBgWoTji5GhulpxgBD5+HM9f/08sdJo85sQMLL51foFOt8BLF63TFQsZw8oBp4vsHStkg7j6ArtG5Z9BcSB/kE82o1lxbuZeEnSHaR9C753u0kOlhog+C5DMLQ7CdpQ1oJArSHRFoWCkY+u6Wkp7jfnxatu0ssHPoruQjvy+5uReQwdEQEnIjU7GAFjEaY12Cw/Heg+baUP9Ee9JarZDLXmiQ7Y19S1DWVXA43LxU0eZSA3qYRjJZvH6m5lGYEE7Z9U6PI50Kri21jZ5cFvE41W0dmX8cO4WKkvemPZZu267T2YUvpHjq61TYWv/8QhjAE+/lMqYiFjnaHg3CsFABRXyg==';

process.env.BUILD_SSM_PREFIX = "/tgr/dev/api-recaudacion/back/";
process.env.PREFIX = "tgr-dev-api-recaudacion";

let data = {
  "data": {
    "concepto": "DGA_MULTAS000",
    "contribuyente": {
      "rut": 13730993,
      "dv": "9"
    },
    "payload": {
      "items": [
         {
                "codigo": 1,
                "valor": "OYARZUN"
            },
            {
                "codigo": 2,
                "valor": "GAVILAN"
            },
            {
                "codigo": 3,
                "valor": "137309939"
            },
            {
                "codigo": 5,
                "valor": "JOHANNA VALESKA"
            },
            {
                "codigo": 6,
                "valor": "PJE LA ARCILLA 1114 VILLA LOS SAUCES"
            },
            {
                "codigo": 7,
                "valor": "333"
            },
            {
                "codigo": 8,
                "valor": "LA FLORIDA"
            },
            {
                "codigo": 15,
                "valor": "20141001"
            },
            {
                "codigo": 24,
                "valor": "09090"
            },
            {
                "codigo": 25,
                "valor": "20140403"
            },
            {
                "codigo": 70,
                "valor": "UF"
            },
            {
                "codigo": 75,
                "valor": "9898,98"
            },
            {
                "codigo": 76,
                "valor": "24170,44"
            },
            {
                "codigo": 91,
                "valor": "239262702"
            },
            {
                "codigo": 191,
                "valor": "9898,98"
            },
            {
                "codigo": 215,
                "valor": "20141001"
            },
            {
                "codigo": 260,
                "valor": "239262702"
            }
      ]
    }
  },
  "metadata": {
    "sendDate": new Date()
  }
};


let event = {
  "body": JSON.stringify(data),
  headers: {
    Authorization: "Bearer eyJraWQiOiJhRDM5TklURjJQUEFzZWE3TTBFWkhCNk9pQW1ZM01FNFdWMGhkVnU3MmZFPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiI2Ym5uNzN2MnE4Z24zNHFxNGNkMXRlZGdubiIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoicmVjYXVkYWNpb25cL2lwcHMiLCJhdXRoX3RpbWUiOjE1OTkxODIyNzMsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC51cy1lYXN0LTEuYW1hem9uYXdzLmNvbVwvdXMtZWFzdC0xX2lZM2dJWWlpMCIsImV4cCI6MTU5OTE4NTg3MywiaWF0IjoxNTk5MTgyMjczLCJ2ZXJzaW9uIjoyLCJqdGkiOiI1ZGJiYTU0OC1jN2RiLTRhOTAtODcwZS1iODI0YjY1NzU5Y2EiLCJjbGllbnRfaWQiOiI2Ym5uNzN2MnE4Z24zNHFxNGNkMXRlZGdubiJ9.fbuwY5rhgqJQDv-3DwL_vx1u1sooo7_N4XiBdVeD8e3K-_tIJWrqpvBflGqxrLiDFW0UVQSvfxjq2iW9EfWkCgMe4C6TIbfLnl5rdjYzYDH2n29r8r2POFQ4YG9ZqI7PoapFGRITa0MsI8B9CnTqk2Xj7Jf_CKeutGs8xCN_6SU63jhVQhc3ewBHMzivtBb0JYTINJBwGhbRYO5Ww_8RxLh-PJ6adEW86JRoejtWk4o3irLUrkPfgCHMPDYwF91gTWr-sxaIyrAVZQi3621LpOjmP2UQ2XsDqiEU6AY65cqdBb3jqZHkzHj8dI48_rR2lo81-EDd9Q-AV8XKYsY-7g"
  }
};


clase.handler(event, null, () => { console.log("fin") });
