const clase = require('../getObligaciones');

process.env.ENV = "dev";
process.env.USER_POOL_URL = "https://tgr-dev-api-recaudacion-at-186180787863.auth.us-east-1.amazoncognito.com";

process.env.BUILD_API_DOMAIN = "api.dev.tegere.info"

process.env.BUCKET_NAME = "";
process.env.USER_POOL_ID = "us-east-1_iY3gIYii0";

process.env.API_AUTOSERVICIOS_CLIENT_ID = '35l8t1trd8gpge3p53dv936jnj';
process.env.API_AUTOSERVICIOS_CLIENT_SECRET = '1cqg4utvbsea4o2uvctd3rg8oijkna68jg0bgf1m9mir17r3mog5';
process.env.API_AUTOSERVICIOS_HOST_SERVICE = 'api.dev.tegere.info';
process.env.API_AUTOSERVICIOS_TOKEN_HOST_SERVICE = 'id.dev.tegere.info';

process.env.AWS_ACCESS_KEY_ID = 'ASIASWWJ5L2L5YG37RGI';
process.env.AWS_SECRET_ACCESS_KEY = 'ozgmAto4R3bqVbtW71YTMJQEKRIaLuJT28tsWLzY';
process.env.AWS_SESSION_TOKEN = 'IQoJb3JpZ2luX2VjEE0aCXVzLWVhc3QtMSJHMEUCIFNt1EYyVhZMf8P0Cwf/iJI8QxcAZkQg99IpAfsoLmbLAiEAySOMH0fqeqs4vpi9HB7U7LJysa+l4iQbp3/dbrXeEgwq6gEIdhABGgwxODYxODA3ODc4NjMiDL93QwnsK7e44ZLh1irHAbhO3u1208zzsmZPBG+elvvjv5EXA4kORRclev5geKPfPKviAGOlx/07Bkbpxq6aLIDHfPPpw3g1vw7jbyY4K5QIcjoexXi/tanIVMrgH6XVBQDdM2qzhVvJr/UbGvAA/lnIDIylafCf4a+VTWBFgQ1JkRe9L5oHyx6e72hXdf4/KjCBBxzmBKhPa2L+Hv6RLw8Df61FoW+86rQUqNlNr8oVwK7RFVs5fvcG7+LxeG22P2pSYFY3riRijvv0l2hdZ4gCxo0zZ/sw957X+wU64AHEKUFnDiEXfvhx8qlzjL8uvva9BrJkDqJmoFwytOqhpZFErOgcEQMdAGzXMTpK1c5MDFNex9ViKD3YU3m02CXW7jwpJ/5tmFHMEryQhohKQVKgy5BeP6gEmtOuWaezxnISJDZI/ilph4JwBJxdN7KsLeCOPYrbkjQ676JSvgOhckBBnlo7n2qWX9BDzYm1AIifNG8SYDUrXtBjeZPsYHxh4q72/k6pQ+i3AnuNU45RhKqnSkRZtyPz5uTbzM+MFybJs4cDDUPdRFGsT3j26+fShBCKYfjGCMtsDZWOKw/BCA==';

process.env.BUILD_SSM_PREFIX = "/tgr/dev/api-recaudacion/back/";
process.env.PREFIX = "tgr-dev-api-recaudacion";

process.env.PAGINACION = 3;

let event = {
  headers: {
        Authorization: "Bearer eyJraWQiOiJhRDM5TklURjJQUEFzZWE3TTBFWkhCNk9pQW1ZM01FNFdWMGhkVnU3MmZFPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiI2ZTJwYm5hN28ya2Q3MGhvZjBxc2I3YzVlMCIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoicmVjYXVkYWNpb25cL2lwcHMiLCJhdXRoX3RpbWUiOjE2MDA5NTg0MDIsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC51cy1lYXN0LTEuYW1hem9uYXdzLmNvbVwvdXMtZWFzdC0xX2lZM2dJWWlpMCIsImV4cCI6MTYwMDk2MjAwMiwiaWF0IjoxNjAwOTU4NDAyLCJ2ZXJzaW9uIjoyLCJqdGkiOiI4NDYyZjUwYS1kNDIwLTRiOTYtOGI4Ny1kZDUwN2QwY2ExMmUiLCJjbGllbnRfaWQiOiI2ZTJwYm5hN28ya2Q3MGhvZjBxc2I3YzVlMCJ9.S1aIRwBCuoXd6zKUuFm7FYDra2zunQPWQZCOXI0D2mm54NaWkV0gTnPLhBPIazJEZJA3iGxIoWEhqiFZkV4BYRuDhBIWATLZZD16s9XtPLXZtOKHPVlCCN5DiMcDOd0J1OfAYFFvaTW96lW7lYhBBJnieU5K4czmpVzYElEOvOqR45xvF6BWvgjKA-lDZw_nx9wSbzxf2hZK3GfdJcDkiqhiXdFwNLju9w6LilGHs8gqLuwFhU3EajMKhj5qh9d3gKpWgIce0mq9wohj1tqT_07SCQYWA1U-jmRj6XBU-ETqxTwldCPrAJuZAeDm4GSGa2z1OUZDqSuX74G427L7VA"
  },
  queryStringParameters: {
        "interval": "10000"
        }
};
 
clase.handler(event, null, () => { console.log("fin") });
