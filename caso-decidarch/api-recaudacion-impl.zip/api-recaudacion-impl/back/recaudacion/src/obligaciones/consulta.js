"use strict";

const queryDB = require("./utils/dynamoDbServices");
const util = require("./utils/util");
const error = require('./utils/CustomError');
const { evento: enviarEvento } =  require('./eventos');
//const { OracleProvider } = require('tgr-sdk/clients/dss');
const { OracleProvider} = require('./oracleProvider');
let provider = new OracleProvider();
let oracleSchema = "WEBTGR";
const callOnpremise = require('./dss/callOnpremise');
const { z } = require("zod");
const ERR_MESSAGE = "Validación de forma";


/*if (process.env.API_AUTOSERVICIOS_HOST_SERVICE.toLowerCase().indexOf("api.dev") > -1)
  oracleSchema = 'RECA_DES2';
else
  oracleSchema = 'RECA';*/

module.exports.handler = async (event) => {

  // Inicializo variable.
  let resultadoServicio = {
    "codeStatus": 200,
    "respuesta": null
  };

  let evento = "obligaciones"
  let aplicacion = "api-recaudacion"

  let data = {
    "usuario": null,
    "statusCode": null,
    "operacion": "consulta",
    "tipoOperacion": "GET"
  };

  try {

    console.log("event-->", event);
    let id;
    let institucionBd = "";

    let nombreEstado = "";
    let fechaEstado = "";
    let fechaEvento = "";
    let environment = "";
    let pago = "";
    let erroresBd = "";

    let folio = "";
    let rut = "";
    let concepto = "";
    let vencimiento = "";
    let formulario = "";

    // Obtengo los datos del client-id a traves del token.
    let { institucion } = await util.getDataFromToken(event.headers.Authorization);
    console.log("institucion==>", institucion)
    // Seteo el usuario que esta usando la api.
    data.usuario = institucion;




    //si la consulta es con id   /{id}
    //la consulta se realiza en nube dynamodb
    if (event.hasOwnProperty("pathParameters") && event.pathParameters?.hasOwnProperty("id")) {

      id = event.pathParameters.id;
      console.log("id-->", id);

      var params = {
        TableName: `${process.env.PREFIX}-obligaciones`,
        KeyConditionExpression: 'id = :hkey',
        ExpressionAttributeValues: {
          ':hkey': id,
        }
      };
      var results;

      try {
        // Consulto dynamodb.
        results = await queryDB.getItems(params);
      }
      catch (er) {
        throw new error.CustomError("Error Interno.", 500);
      }

      if (results.length < 1) {
        throw new error.CustomError("Obligación no encontrada.", 404);
      }

      console.log(results);

      institucionBd = results[0].institucion;

      nombreEstado = results[0].nombreEstado;
      fechaEstado = results[0].fechaEstado;
      fechaEvento = results[0].fechaEvento;
      environment = results[0].environment;
      pago = results[0].pago;
      erroresBd = results[0].errors;
      let jsonEntradaCargo = results[0].payload.data.concepto;

      data["concepto"] = jsonEntradaCargo;

    }


    //si la consulta es con parametros folio, rut, concepto, vencimiento
    //?folio=3456789&rut=2345678&concepto=DGA_MULTAS&vecimiento=3034-12-31
    //la consulta va a onPremise via DSS
    else {

      const queryParams = event.queryStringParameters;
      const requiredParams = ['folio', 'rut', 'concepto', 'vencimiento'];
      const missingParams = requiredParams.filter(param => !(param in queryParams));

      if (missingParams.length > 0) {
        const errorMessage = `Falta el parámetro: ${missingParams.join(', ')}`;
        throw new error.CustomError(errorMessage, 403);
      }
      else {
        folio = queryParams.folio;
        rut = queryParams.rut;
        concepto = queryParams.concepto;
        vencimiento = queryParams.vencimiento;

        console.log("folio:", folio, " ;rut:", rut, " ;concepto:", concepto, " ;vencimiento:", vencimiento);
      }

      //consulto el formulario 
      var paramsConcep = {
        TableName: `tgr-${process.env.ENV}-api-portal-autoservicios-conceptos-instituciones`,
        KeyConditionExpression: 'idConcepto = :hkey',
        ExpressionAttributeValues: {
          ':hkey': concepto,
        }
      };
      //console.log("paramsConcep:", paramsConcep);
      var resultsConcep;
      try {
        // Consulto dynamodb.
        resultsConcep = await queryDB.getItems(paramsConcep);
        //console.log("results dynamodb autoservicios: ", resultsConcep);
        formulario = resultsConcep[0].formulario;
        institucionBd = resultsConcep[0].institucion;
        environment = resultsConcep[0].etapa;
        console.log("concepto: ", concepto, "; formulario: ", formulario, "; institucionBd: ", institucionBd, "; environment: ", environment);
      }
      catch (er) {
        throw new error.CustomError("Error Interno.", 500);
      }

      let formularioLimpio = formulario.split("#")[0];
      let vencimientoLimpio = vencimiento.replace(/-/g, '');
      
      //consulta la obligacion a onPremise via dss
      let resultadoBD = await getObligaciones(formularioLimpio, folio, rut, vencimientoLimpio);
      let resultadoDss = resultadoBD[0];
      let resultadoErr = resultadoBD[1];

      if (resultadoErr?.hasOwnProperty('error') && resultadoErr?.error && resultadoErr?.error != "0") {
        erroresBd.errors = resultadoErr.error;
      }

      console.log("resultadoDss: ", resultadoDss);
      console.log("resultadoErr: ", resultadoErr);
      console.log(resultadoDss.OUT_COD);
      console.log(resultadoDss.OUT_CURSOR_SET);
      console.log(resultadoErr.error);

      if (resultadoDss.OUT_COD === 200 && resultadoDss.OUT_CURSOR_SET.length > 0) {
        // Manejar el caso en el que OUT_COD es igual a 200

        let cursor = resultadoDss.OUT_CURSOR_SET;
        //institucionBd = cursor[0].institucion;
        id = cursor[0].ID_TRANSACCION
        nombreEstado = cursor[0].ESTADO;
        fechaEstado = cursor[0].FECHA_ESTADO;
        fechaEvento = cursor[0].FECHA_ESTADO;

        //let jsonEntradaCargo = results[0].payload.data.concepto;
        data["concepto"] = concepto; //jsonEntradaCargo;

        if (nombreEstado === "PAGO_CONFIRMADO") {
          pago = {
            "fechaPago": cursor[0].FECHA_ESTADO,
            "iraCodigo": cursor[0].CODIGO_IRA,
            "iraNombre": cursor[0].NOMBRE_IRA,
            "monedaPago": cursor[0].MONEDA,
            "totalPago": cursor[0].TOTAL_PAGADO
          }
        }

      }
      else {
        if (resultadoDss.OUT_COD === 404 || resultadoDss.OUT_CURSOR_SET.length === 0) {
          // Manejar el caso en el que OUT_COD es igual a 404
          throw new error.CustomError("Obligación no encontrada.", 404);
        }
        else {
          // Manejar cualquier otro caso
          throw new error.CustomError("Error Interno.", 500);
        }
      }

    }


    if (institucion != institucionBd) {
      console.log("institucion:", institucion, " ;institutionBD:", institucionBd);
      throw new error.CustomError("No posee permisos para consultar la obligación.", 403);
    }

    let estadoData;

    if (nombreEstado === 'PAGO_CONFIRMADO') {

      let estado = {
        nombreEstado: nombreEstado,
        fechaEstado: pago.fechaPago,
        medioPago: pago.iraNombre,
        montos: {
          totalPagado: pago.totalPago,
          moneda: pago.monedaPago
        }
      }

      estadoData = estado;

    }
    else {

      let estado = {
        nombreEstado: nombreEstado,
        fechaEstado: fechaEstado
      }

      if (erroresBd) {
        estado["errors"] = erroresBd.errors;
      }

      estadoData = estado;

    }

    let salida = {
      data: {
        fechaEvento: fechaEvento,
        obligacion: {
          id: id
        },
        estado: estadoData,
        etapa: environment
      }
    }

    resultadoServicio.respuesta = salida;

    data.statusCode = resultadoServicio.codeStatus;

    try {
      await enviarEvento({ evento, aplicacion, data });
    }
    catch (e) {
      console.log("Error al Enviar Evento GCP:", e)
    }

    return send(resultadoServicio);

  }
  catch (err) {
    console.error("error:", err);
    let salidaErr = util.getInfoError(err);
    // Seteo el code status.
    data.statusCode = salidaErr.codeStatus;

    try {
      await enviarEvento({ evento, aplicacion, data });
    }
    catch (e) {
      console.log("Error al Enviar Evento GCP:", e)
    }

    return send(salidaErr);
  }

};



function send(resultadoServicio) {

  const response = {
    statusCode: resultadoServicio.codeStatus,
    headers: {
      Accept: "application/json, text/plain, */*",
      "Content-Type": "application/json; charset=utf-8",
    },
  };

  if (resultadoServicio.respuesta) {
    response.body = JSON.stringify(resultadoServicio.respuesta);
  }

  console.log(response);

  return response;
}

function sendResponse(statusCode, payload) {
  return {
    statusCode,
    headers: {
      Accept: "application/json, text/plain, */*",
      "Content-Type": "application/json; charset=utf-8",
    },
    body: JSON.stringify(payload ?? {}),
  };
}


async function getObligaciones(formulario, folio, rut, vencimiento) {

  let resultado;

  let params = [{
    "sql": oracleSchema + ".PKG_OBL_FSC.SP_CSU_LLV_OBL_FSC(IN_FMU, IN_FOL, IN_RUT, IN_VCT, OUT_CURSOR_SET, OUT_COD, OUT_MSJ);",
    "params": [{
        "parameterType": "IN",
        "type": 2,
        "name": "IN_FMU",
        "value": formulario
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "IN_FOL",
        "value": folio
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "IN_RUT",
        "value": rut
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "IN_VCT",
        "value": vencimiento
      },
      {
        "parameterType": "OUT",
        "type": -10,
        "name": "OUT_CURSOR_SET"
      },
      {
        "parameterType": "OUT",
        "type": 2,
        "name": "OUT_COD"
      },
      {
        "parameterType": "OUT",
        "type": 12,
        "name": "OUT_MSJ"
      }
    ]
  }];


  try {
    resultado = await provider.call(params);
    console.log("resultado: ", resultado)


  }
  catch (e) {
    console.log("Exception en getObligaciones: " + e.message);
    throw e;
  }

  return resultado;

}


module.exports.consultaSaldo = async (event) => {
  
  let response = {
    "metaData": {
      "fechaEnvio": null
    },
    "data": [
      {
        "cuenta": {
          "rutRol": null,
          "rutRoldv": null,
          "folio": null,
          "periodo": null,
          "tipoForm": null,
          "version": null,
          "fechaVencimiento": null,
          "tipoMoneda": null,
          "saldo": null
        }
      }
    ]
  };

  let body;
  if (event && typeof event.body === 'string') {
    body = parseBody(event);
  } else if (event && typeof event.body === 'object') {
    body = event.body;
  }

  if (!body) {
    return sendResponse(400, {
      status: 400,
      message: ERR_MESSAGE,
      errors: ["El body no es un JSON válido."],
    });
  }
  
  console.log("body", body);
  const val = validateInputConsultaSaldoCut(body);
  if (!val.ok) return sendResponse(val.statusCode, val.payload);
   
  let resultadoBD = await callOnpremise.getSaldoCut(body.rutRol, body.rutRolDv, body.folio, body.formulario, body.version, body.periodo);
  console.log("resultado getSaldoCut: ", resultadoBD[0]);

  const curData = resultadoBD?.[0]?.cursorRs;
  if (!Array.isArray(curData) || curData.length === 0) {
    response.metaData = {
      fechaEnvio: new Date().toISOString()
    };
    response.data = [
      {
        cuenta: {
          mensaje: 'Cuenta no existe'
        }
      }
    ];
    console.log("Cuenta no existe");
    return sendResponse(200, response);
  }

  response.metaData = {
    fechaEnvio: resultadoBD[0].cursorRs[0].FECHAENVIO
  };
  
  response.data = resultadoBD[0].cursorRs.map(row => ({
    cuenta: {
      rutRol: row.RUTROL,
      rutRoldv: row.RUTROLDV,
      folio: row.FOLIO,
      periodo: row.PERIODO?.substring(0, 10),
      tipoForm: row.TIPOFORM,
      version: row.VERSION,
      fechaVencimiento: row.FECHAVENCIMIENTO?.substring(0, 10),
      tipoMoneda: row.TIPOMONEDA,
      saldo: row.SALDO
    }
  }));
  console.log("resultadoBD"+ JSON.stringify(response));
  return sendResponse(200, response);
}


function parseBody(event) {
  if (!event || !event.body) return null;
  try {
    return typeof event.body === "object" ? event.body : JSON.parse(event.body);
  } catch {
    return null;
  }
}

const num = (fieldName, maxLen) =>
  z.preprocess(
    (v) => {
      if (v === null || v === undefined) return undefined;
      const s = String(v).trim();
      return s === "" ? undefined : s;
    },
    z
      .string({ required_error: `El ${fieldName} es obligatorio` })
      .min(1, { message: `El ${fieldName} es obligatorio` })
      .max(maxLen, {
        message: `El campo ${fieldName} no puede superar el largo ${maxLen}`,
      })
      .regex(/^\d+$/, {
        message: `El ${fieldName} debe ser numérico`,
      })
      .transform((s) => Number(s))
  );
  
const schemaConsultaSaldoCUT = z.object({
  rutRol: num("rutRol", 9),

  rutRolDv: z.preprocess(
    (v) => {
      if (v === null || v === undefined) return undefined;
      const s = String(v).trim();
      return s === "" ? undefined : s;
    },
    z
      .string({ required_error: "El rutRolDv es obligatorio" })
      .min(1, { message: "El rutRolDv es obligatorio" })
      .max(1, { message: "El rutRolDv no puede superar el largo 1" })
  ),

  formulario: num("formulario", 4),
  folio: num("folio", 14),

  // ✅ opcional real (si no viene o viene vacío => undefined, no valida)
  // si viene, valida YYYY-MM-DD y fecha real
  periodo: z.preprocess(
    (v) => {
      if (v === null || v === undefined) return undefined;
      const s = String(v).trim();
      return s === "" ? undefined : s;
    },
    z.union([
      z.undefined(),
      z
        .string()
        .refine(
          (s) => {
            if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
            const [y, m, d] = s.split("-").map(Number);
            const dt = new Date(Date.UTC(y, m - 1, d));
            return (
              dt.getUTCFullYear() === y &&
              dt.getUTCMonth() === m - 1 &&
              dt.getUTCDate() === d
            );
          },
          { message: "El periodo debe tener formato YYYY-MM-DD" }
        ).optional(),
    ])
  )
  .optional(),

  version: z.preprocess(
      (v) => {
        if (v === null || v === undefined) return undefined;
        const s = String(v).trim();
        return s === "" ? undefined : s;
      },
      z.string().max(2, { message: "La versión no puede superar el largo 2" })
      .regex(/^[A-Za-z]+$/, {
        message: "La versión solo puede contener letras",
      })
    ).optional(),
});

function validateInputConsultaSaldoCut(body) {
  if (typeof body !== "object" || body === null || Array.isArray(body)) {
    return {
      ok: false,
      statusCode: 400,
      payload: {
        status: 400,
        message: ERR_MESSAGE,
        errors: ["El parámetro de entrada debe ser un objeto."],
      },
    };
  }

  const result = schemaConsultaSaldoCUT.safeParse(body);

  if (!result.success) {
    const errors = result.error.issues.map((issue) => {
      const missing =
        issue.code === "invalid_type" &&
        (issue.input === undefined ||
          issue.received === "undefined" ||
          issue.message?.includes("received undefined"));

      if (missing) {
        const field = issue.path?.[issue.path.length - 1] || "parámetro";
        return `El campo ${field} es obligatorio`;
      }

      return issue.message;
    });

    return {
      ok: false,
      statusCode: 400,
      payload: {
        status: 400,
        message: ERR_MESSAGE,
        errors,
      },
    };
  }

  return { ok: true, data: result.data };
}