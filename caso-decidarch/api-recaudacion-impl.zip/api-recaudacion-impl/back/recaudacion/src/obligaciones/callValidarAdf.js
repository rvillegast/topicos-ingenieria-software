const axios = require("axios");
const paramssm = require("./utils/ssmUtils");
const util = require("./utils/util");
const error = require('./utils/CustomError');
const queryDB = require("./utils/dynamoDbServices");

module.exports.handler = async(event) => {
  let ssmPrefix = process.env.BUILD_SSM_PREFIX;

  let endpoint = await paramssm.getParameterStore(ssmPrefix + "portalsrv/host");

  return new Promise((resolve, reject) => {
    let rq = {
      headers: {
        "Content-Type": "application/json",
        Authorization: event.authorization,
      },
      url: `https://${endpoint}/v1/formularios`,
      data: event.body,
      method: "PATCH",
    };

    axios(rq)
      .then(({ status, data }) => {
        resolve({
          statusCode: status,
          body: JSON.stringify(data),
        });
      })
      .catch((error) => {
        console.error(error);
        console.log("error.response.status---->", error.response.status);
        resolve({
          statusCode: error.response.status,
          body: JSON.stringify(error.message),
        });
      });
  });
};


module.exports.procesaAdf = async(formVer, formCod, json, uuid, tokenResp, institucion, environment, girador, flagbd,fechaCargaCUT) => {

  // Realizo llamada al validarFormularioADF.
  let eventAdf = {
    body: null,
    authorization: null,
  };

  // Defino objeto de entrada del validarADF.
  let dataValidarADF = util.getDataValidarADF(formVer, formCod, json.data.payload.items);
  
  if(flagbd==false){//solo para descargos
    dataValidarADF.data.contextAdf.fechaCaja=fechaCargaCUT;
  }
  console.log("Data Enviada ADF:", JSON.stringify(dataValidarADF))

  eventAdf.body = JSON.stringify(dataValidarADF);
  eventAdf.authorization = JSON.parse(tokenResp.body).access_token;

  // Realizo llamada al ADF.
  let respuestaAdf = await this.handler(eventAdf);

  // console.log(respuestaAdf)

  if (respuestaAdf.statusCode != 200) {
    console.log("Error al validar formulario:", respuestaAdf.body);
    let errorOb = util.getError(respuestaAdf.statusCode);

    throw new error.CustomError(JSON.parse(errorOb).errors[0].message, respuestaAdf.statusCode);
  }

  // // Recupero data de la respuesta del adf.
  let respADF = JSON.parse(respuestaAdf.body).data;

  console.log("Respuesta ADF:", respADF)

  // Validamos la respuesta del ADF, si es 3=ERROR.
  if (respADF.resultCode > 2 || !respADF.contextADF) {
    console.log("Respuesta ADF:", respADF.resultMessage, respADF.recaMensajes);
    console.log("Respuesta ADF:", util.procesaRespADF(respADF));

    let errorOb = util.procesaRespADF(respADF);

    if (flagbd) {
      console.log("Guardo en Dynamo.")
      await queryDB.putItem(uuid, json, 'RECHAZADO', null, institucion, environment, formCod, girador, JSON.parse(errorOb.body));
    }

    let mes = JSON.parse(errorOb.body);

    throw new error.CustomError(mes, errorOb.statusCode);
  }

  return respADF;

};
