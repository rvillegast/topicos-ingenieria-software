const axios = require("axios");
const aws4 = require("aws4");


//exports.getAvisoRecibo = async function (event, context, callback) {
exports.postAvisoRecibo = async function (event, context, callback) {

    let body;
    try {
        body = typeof event.body === 'string'
            ? JSON.parse(event.body)
            : event.body;
    } catch (err) {
        return callback(null, {
            statusCode: 400,
            body: JSON.stringify({ message: 'Body inválido' }),
            headers: {
                "Access-Control-Allow-Origin": process.env.urlFront,
                "Access-Control-Allow-Credentials": true,
                "Accept": "application/json, text/plain, */*",
                "Content-Type": "application/json"
            }
        });
    }
    const cid = body?.CID;
    if (!cid) {
        return callback(null, {
            statusCode: 400,
            body: JSON.stringify({ message: 'El parámetro CID es obligatorio' }),
            headers: {
                "Access-Control-Allow-Origin": process.env.urlFront,
                "Access-Control-Allow-Credentials": true,
                "Accept": "application/json, text/plain, */*",
                "Content-Type": "application/json"
            }
        });
    }
    //cambio cuando era metodo get
    // const query = event.queryStringParameters || {};
    // const cid = query.CID;

    // if (!cid) {
    //     return callback(null, {
    //         statusCode: 400,
    //         body: JSON.stringify({ message: 'El parámetro CID es obligatorio' }),
    //         headers: {
    //             "Access-Control-Allow-Origin": process.env.urlFront,
    //             "Access-Control-Allow-Credentials": true,
    //             "Accept": "application/json, text/plain, */*",
    //             "Content-Type": "application/json"
    //         }
    //     });
    // }

    // ===== VALIDACIÓN CID =====
    //const result = validarCID(cid);
    const result = validarCID(cid);
    if (!result.ok) {
        //console.log('resultado validacion: ', result.msg);
        //console.log('resultado msj_salida: ', result.msj_salida);
        return callback(null, {
            statusCode: 400,
            body: JSON.stringify({ message: result.errors }),
            headers: {
                "Access-Control-Allow-Origin": process.env.urlFront,
                "Access-Control-Allow-Credentials": true,
                "Accept": "application/json, text/plain, */*",
                "Content-Type": "application/json"
            }
        });
    }

    //console.log("CID OK. Fecha extraída:", result.fecha);



    // ===== FIN VALIDACIÓN CID =====



    //const salida = await obtieneAvisoRecibo(cid);
    const salida = await obtieneAvisoRecibo(cid);
    //const salida = { data: { ok: true, fechaCID: result.fecha } };


    const response = {
        statusCode: 200,
        body: JSON.stringify(salida.data),
        headers: {
            "Access-Control-Allow-Origin": process.env.urlFront,
            "Access-Control-Allow-Credentials": true,
            "Accept": "application/json, text/plain, */*",
            "Content-Type": "application/json"
        }
    };

    callback(null, response);
};

function validarCID(cidRaw) {
    const msj_salida_obligatorio = "El campo CID es obligatorio";
    const msj_salida_vigencia = "EL CID no está vigente";
    const msj_salida_numero = "El CID debe ser numérico";
    const msj_salida_length = "El CID debe de tener un largo de 26";
    const msj_salida_fecha = "El CID no es válido";

    const errors = [];
    const errors_salida = [];

    // valido si existe CID
    //------------
    if (cidRaw === undefined || cidRaw === null || cidRaw === "") {
        errors.push(msj_salida_obligatorio);
        errors_salida.push(msj_salida_obligatorio);

        return {
            ok: false,
            errors,
            errors_salida,
        };
    }

    const cid = String(cidRaw);

    //  valido si es Numérico
    //------------
    if (!/^\d+$/.test(cid)) {
        errors.push(msj_salida_numero);
        errors_salida.push(msj_salida_numero);
    }

    // valido Largo
    //------------
    if (cid.length !== 26) {
        errors.push(msj_salida_length);
        errors_salida.push(msj_salida_length);
    }

    if (errors.length > 0) {
        return {
            ok: false,
            errors,
            errors_salida,
        };
    }
    //valido fecha
    //------------
    const yy = cid.slice(12, 14);
    const mm = cid.slice(14, 16);
    const dd = cid.slice(16, 18);

    const year = 2000 + Number(yy);
    const month = Number(mm);
    const day = Number(dd);


    const fecha = new Date(year, month - 1, day);

    const esFechaValida =
        !isNaN(fecha.getTime()) &&
        fecha.getFullYear() === year &&
        fecha.getMonth() === (month - 1) &&
        fecha.getDate() === day;

    if (!esFechaValida) {
        errors.push(msj_salida_fecha);
        errors_salida.push(msj_salida_fecha);
    } else {

        // Vigencia
        const hoy = new Date();
        hoy.setHours(0, 0, 0, 0);
        fecha.setHours(0, 0, 0, 0);

        if (fecha < hoy) {
            errors.push(msj_salida_vigencia);
            errors_salida.push(msj_salida_vigencia);
        }

        if (errors.length === 0) {
            return {
                ok: true,
                fecha: fecha.toISOString().slice(0, 10),
                errors: [],
                errors_salida: [],
            };
        }
    }

    // hay errores , devuelvo lista
    return {
        ok: false,
        errors,
        errors_salida,
    };
}


async function obtieneAvisoRecibo(CID) {
    //console.log("Json a validar ", CID);

    const host = process.env.hostNameCUT;
    //console.log("hostNameCUT: ", host);

    const request = {
        host: host,
        method: "GET",
        path:
            "/api-servicios-cut/" +
            process.env.ENV +
            "/v1/aviso-recibos?codigo=" +
            CID,
        service: "execute-api",
    };

    const signedRequest = aws4.sign(request, {
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        sessionToken: process.env.AWS_SESSION_TOKEN,
    });

    delete signedRequest.headers["Host"];
    delete signedRequest.headers["Content-Length"];

    const url = `https://${request.host}${request.path}`;

    try {
        const resp = await axios({
            ...signedRequest,
            url,
            timeout: 15000,
        });

        return {
            ok: true,
            status: resp.status,
            data: resp.data,
            url,
        };
    } catch (err) {
        console.log('err', err);
        const status = err?.response?.status;
        const data = err?.response?.data;
        const code = err?.code;
        const message = err?.message || "Error al llamar CUT";


        console.error("Error CUT:", {
            url,
            status,
            code,
            message,
            responseData: data,
        });

        // Control específico para 404 cuando no se consigue Aviso de recibo
        if (status === 404) {
            return {
                ok: false,
                status: 404,
                data: {
                    message: "Aviso de recibo no encontrado"
                },
                url,
            };
        }
    }
}