"use strict";

const queryDB = require("./utils/dynamoDbServices");
const token = require("./utils/oauth2Token");
const util = require("./utils/util");
const ingresaTrx = require("./callIngresarTrxForm");
const moment = require("moment");
const error = require('./utils/CustomError');
const validar = require('./utils/validarJsonObligaciones');
const validaAdf = require("./callValidarAdf");
const servAmazon = require('./utils/awsService');
//const { evento: enviarEvento } = require('tgr-sdk/clients/eventos');
const { evento: enviarEvento } =  require('./eventos');
//const { OracleProvider } = require('tgr-sdk/clients/dss');
const { OracleProvider} = require('./oracleProvider');
let provider = new OracleProvider();
let oracleSchema = "WEBTGR";

module.exports.handler = async (event) => {

  // Inicializo variable.
  let resultadoServicio = {
    "codeStatus": 200,
    "respuesta": null
  };

  let evento = "obligaciones"
  let aplicacion = "api-recaudacion"

  let data = {
    "usuario": null,
    "statusCode": null,
    "operacion": "descargar",
    "tipoOperacion": "PUT"
  };

  try {

    const json = JSON.parse(event.body);

    let folioIn = "";
    let rutIn = "";
    let conceptoIn = "";
    let vencimientoIn = "";

    let formCod;
    let formVer;
    let folio;
    let rutContribuyente;
    let environment;
    let girador;
    let fechaCargaCUT;
    let jsonPayloadBD;

    let erroresBd = "";

    let idSalida;

    // Obtengo los datos del client-id a traves del token.
    let { institucion } = await util.getDataFromToken(event.headers.Authorization);

    // Seteo el usuario que esta usando la api.
    data.usuario = institucion;

    // Realizo validacion del json de entrada con la definicion swageer.
    await validar.validarjsonDescarga(json);

    console.log("Entrada:", event);

    let itemsEntrada = json.data.payload.items;

    console.log("Items", JSON.stringify(itemsEntrada));




    //si la consulta es con id   /{id}
    //la consulta se realiza en nube dynamodb
    if (event.hasOwnProperty("pathParameters") && event.pathParameters?.hasOwnProperty("id")) {

      var id = event.pathParameters.id;

      var params = {
        TableName: `${process.env.PREFIX}-obligaciones`,
        KeyConditionExpression: 'id = :hkey',
        ExpressionAttributeValues: {
          ':hkey': id,
        }
      };

      // Consulto dynamodb.
      var results = await queryDB.getItems(params);

      if (results.length < 1) {
        throw new error.CustomError("Obligación no encontrada.", 404);
      }

      data["concepto"] = results[0].payload.data.concepto;

      console.log("Item dynamo:", results);

      console.log("Payload obligacion id:" + id + ":", results[0].payload);


      if (results[0].nombreEstado == "DESCARGADA") {
        throw new error.CustomError("Obligación descargada anteriormente.", 409);
      }

      if (institucion != results[0].institucion) {
        throw new error.CustomError("No posee permisos para descargar la obligación.", 403);
      }

      conceptoIn = results[0].payload.data.concepto;


      /* Datos para Validar ADF. */
      // Obtener detalle de tabla Conceptos.
      let detConceptoIns = await util.getDetalleConceptoInstitucion(
        conceptoIn,
        institucion
      );

      let dataConcepto = detConceptoIns.data.data;

      environment = dataConcepto.etapa;

      girador = dataConcepto.codigoInstitucionOnPrem;

      // codigo del formulario.
      formCod = dataConcepto.formulario.split("#")[0];
      // version del formulario.
      formVer = dataConcepto.formulario.split("#")[1];

      console.log("formCod:", formCod, " ;formVer:", formVer);

      /*  Datos para Validar ADF. */





      //para obtener el folio y el rut desde dynamo
      let dynamoItems = results[0].payload.data.payload.items;
      console.log("dynamoItems", dynamoItems)
      for (let ind = 0; ind < dynamoItems.length; ind++) {
        let dynamoItem = dynamoItems[ind];
        if (dynamoItem.codigo == "7") {
          folio = dynamoItem.valor;
        }

        if (dynamoItem.codigo == "3") {
          const tieneGuion = dynamoItem.valor.includes("-");
          rutContribuyente = dynamoItem.valor.substring(0, dynamoItem.valor.length - (tieneGuion ? 2 : 1));
        }

      }
      //

      for (let ind = 0; ind < itemsEntrada.length; ind++) {
        let dataItm = itemsEntrada[ind];
        results[0].payload.data.payload.items.push(dataItm);
      }


      jsonPayloadBD = results[0].payload;



      // Para obtener el item 9939  desde api cuentas-tributarias          

      let jsonCuentaTributaria = JSON.stringify({ "formulario": formCod - 200, "folio": folio, "rut": rutContribuyente });
      console.log("Envio cuentaTributaria:", jsonCuentaTributaria)
      let cuentaTributaria = await servAmazon.consultaFormulario(jsonCuentaTributaria);
      console.log("Salida cuentaTributaria: ", cuentaTributaria);
      let out = cuentaTributaria.data.data;
      let outMovs = out[0].movimientos;
      let outItems = [];
      for (let idxMovs = 0; idxMovs < outMovs.length; idxMovs++) {
        let outMov = outMovs[idxMovs];
        if (outMov.descripcion == "CARGO" && outMov.estado == "CONFIRMADO") { //obtiens items del movimiento CARGO
          outItems = outMov.items;
          break;
        }
      }

      for (let idxItems = 0; idxItems < outItems.length; idxItems++) {
        let outItem = outItems[idxItems];
        if (outItem.codigo == "9939") {
          fechaCargaCUT = moment(outItem.valor, "YYYYMMDD").utc().toISOString().toString();
          break;
        }
      }

      idSalida = id;


    }



    //si la consulta es con parametros folio, rut, concepto, vencimiento
    //?folio=3456789&rut=2345678&concepto=DGA_MULTAS&vecimiento=3034-12-31
    //la consulta va a onPremise via DSS
    else {

      const queryParams = event.queryStringParameters;
      const requiredParams = ['folio', 'rut', 'concepto', 'vencimiento'];
      const missingParams = requiredParams.filter(param => !(param in queryParams));

      if (missingParams.length > 0) {
        const errorMessage = `Falta el parámetro: ${missingParams.join(', ')}`;
        throw new error.CustomError(errorMessage, 403);
      }
      else {
        folioIn = queryParams.folio;
        rutIn = queryParams.rut;
        conceptoIn = queryParams.concepto;
        vencimientoIn = queryParams.vencimiento;

        console.log("folio:", folioIn, " ;rut:", rutIn, " ;concepto:", conceptoIn, " ;vencimiento:", vencimientoIn);
      }


      /* Datos para Validar ADF. */
      // Obtener detalle de tabla Conceptos.
      let detConceptoIns = await util.getDetalleConceptoInstitucion(
        conceptoIn,
        institucion
      );

      let dataConcepto = detConceptoIns.data.data;

      environment = dataConcepto.etapa;

      girador = dataConcepto.codigoInstitucionOnPrem;

      // codigo del formulario.
      formCod = dataConcepto.formulario.split("#")[0];
      // version del formulario.
      formVer = dataConcepto.formulario.split("#")[1];

      console.log("formCod:", formCod, " ;formVer:", formVer);

      //restar 200 al formulario
      let formularioLimpio = formCod - 200;
      let vencimientoLimpio = vencimientoIn.replace(/-/g, '');


      //consulta la obligacion a onPremise via dss
      let resultadoBD = await getObligaciones(formularioLimpio, folioIn, rutIn, vencimientoLimpio);
      let resultadoDss = resultadoBD[0];
      let resultadoErr = resultadoBD[1];

      if (resultadoErr?.hasOwnProperty('error') && resultadoErr?.error && resultadoErr?.error != "0") {
        erroresBd.errors = resultadoErr.error;
      }

      /*console.log("resultadoDss: ", resultadoDss);
      console.log("resultadoErr: ", resultadoErr);
      console.log(resultadoDss.OUT_COD);
      console.log(resultadoDss.OUT_CURSOR_SET);
      console.log(resultadoErr.error);*/

      if (resultadoDss.OUT_COD === 200 && resultadoDss.OUT_CURSOR_SET.length > 0) {
        // Manejar el caso en el que OUT_COD es igual a 200

        let cursor = resultadoDss.OUT_CURSOR_SET;
        console.log("cursor:", cursor);
        folio = folioIn;
        rutContribuyente = rutIn;

        // Convertir los nombres de las propiedades a minúsculas
        cursor = cursor.map(item => ({
          codigo: item.CODIGO,
          valor: item.VALOR
        }));

        for (let idxItems = 0; idxItems < cursor.length; idxItems++) {
          let outItem = cursor[idxItems];
          if (outItem.codigo == "9939") {
            fechaCargaCUT = moment(outItem.valor, "YYYYMMDD").utc().toISOString().toString();
            break;
          }
        }
        console.log("fechaCargaCUT:", fechaCargaCUT);

        // Eliminar el elemento con CODIGO 9939
        cursor = cursor.filter(item => item.codigo !== 9939);

        jsonPayloadBD = {};
        jsonPayloadBD.data = jsonPayloadBD.data || {}; // Inicializa data si es undefined
        jsonPayloadBD.data.payload = jsonPayloadBD.data.payload || {}; // Inicializa payload si es undefined
        jsonPayloadBD.data.payload.items = cursor; // Asigna los items

        console.log("jsonPayloadBD antes de la asignación:", JSON.stringify(jsonPayloadBD));

        data["concepto"] = conceptoIn; //jsonEntradaCargo;

      }
      else {
        if (resultadoDss.OUT_COD === 404 || resultadoDss.OUT_CURSOR_SET.length === 0) {
          // Manejar el caso en el que OUT_COD es igual a 404
          throw new error.CustomError("Obligación no encontrada.", 404);
        }
        else {
          // Manejar cualquier otro caso
          throw new error.CustomError("Error Interno.", 500);
        }
      }

      idSalida = "Folio: " + folioIn + ", descargado exitosamente.";




    }







    // Datos para obtener el token.
    let event2 = await util.getEventToken();
    // Obtengo token.
    let tokenResp = await token.handler(event2);



    // valida el formulario con el adf.
    let respADF = await validaAdf.procesaAdf(formVer, formCod * -1, jsonPayloadBD, null, tokenResp, institucion, environment, girador, false, fechaCargaCUT)

    let detalleInstituciones = await util.getDetalleInstituciones(institucion);

    console.log("INSTITUCION->", detalleInstituciones.data.data.rut)

    let rut = detalleInstituciones.data.data.rut;


    let dataIngresarTrxform = util.getDataIngresarTrxForm(rut, formCod * -1, formVer, id, json.data.payload.items);

    dataIngresarTrxform.data.fechaValidez = fechaCargaCUT; //se asigna fecha carga CUT como fechavalidez


    // Se agrega la lista de items obtenidos de la respuesta del validarADF.
    dataIngresarTrxform.data.items = util.getListaItemIngTrx(respADF);




    console.log("Data Enviada a IngresarTrxForm: " + JSON.stringify(dataIngresarTrxform));

    let eventForm = {
      body: null,
      authorization: null,
    };

    eventForm.body = dataIngresarTrxform;
    eventForm.authorization = JSON.parse(tokenResp.body).access_token;

    // Realizo llamado al IngresarTrxForm.
    let respuestaIng = await ingresaTrx.handler(eventForm);

    if (respuestaIng.statusCode != 200) {
      console.log("Error al ingresar formulario:", respuestaIng.body)
      throw new error.CustomError("Error interno.", 500);
    }

    let respIngTrxform = JSON.parse(respuestaIng.body);

    let tranDuplicada = isTrnDuplicada(respIngTrxform, id);

    if (respIngTrxform.data.resultCode != 5 && !tranDuplicada) {

      console.log("respuesta IngresarTrxForm: ", respIngTrxform.data);
      console.log("IngresarTrxForm resultCode:", respIngTrxform.data.resultCode);
      console.log("IngresarTrxForm resultCode:", util.procesaRespIngresaTrxForm(respIngTrxform.data.recaMensajes));
      let recaMensajes = respIngTrxform.data.recaMensajes?.[0];

      if (recaMensajes.errMsg) {
        throw new error.CustomError(recaMensajes.errMsg || "Error no definido en BD", 400);
      }
      else {
        throw new error.CustomError("Error interno.", 500);
      }


    }

    console.log("Respuesta IngresarTrxForm:", JSON.stringify(respuestaIng));


    //si la consulta es con id   /{id}
    //la consulta se realiza en nube dynamodb
    //se actualiza a DESCARGADA
    if (event.hasOwnProperty("pathParameters") && event.pathParameters?.hasOwnProperty("id")) {

      try {

        let dateEst = moment.utc().toISOString().toString();

        var paramsUpdate = {
          TableName: `${process.env.PREFIX}-obligaciones`,
          Key: { "id": id, "fechaEvento": results[0].fechaEvento },
          UpdateExpression: "set nombreEstado = :exp_nombreEstado, fechaEstado = :exp_fechaEstado",
          ExpressionAttributeValues: {
            ':exp_nombreEstado': 'DESCARGADA',
            ':exp_fechaEstado': dateEst
          },
          ReturnValues: "UPDATED_NEW"
        };

        var resultsuP = await queryDB.updateItem(paramsUpdate);

        console.log("resultsuP:", resultsuP)

      }
      catch (e) {

        throw new error.CustomError("Error interno.", 500);

      }
    }

    if (tranDuplicada) {

      throw new error.CustomError("Obligación descargada anteriormente.", 409);

    }

    let salida = {
      data: {
        id: idSalida
      }
    }

    resultadoServicio.respuesta = salida;

    data.statusCode = resultadoServicio.codeStatus;

    try {
      await enviarEvento({ evento, aplicacion, data });
    }
    catch (e) {
      console.log("Error al Enviar Evento GCP:", e)
    }

    return send(resultadoServicio);

  }
  catch (ex) {

    console.error(ex);
    let salidaErr = util.getInfoError(ex);

    // Seteo el code status.
    data.statusCode = salidaErr.codeStatus;

    try {
      await enviarEvento({ evento, aplicacion, data });
    }
    catch (e) {
      console.log("Error al Enviar Evento GCP:", e)
    }

    return send(salidaErr);
  }


};

function isTrnDuplicada(trn, id) {

  if (trn.data != null && trn.data.hasOwnProperty("recaMensajes") && trn.data.recaMensajes != null && trn.data.resultCode == 3) {
    let msj = trn.data.recaMensajes[0].errMsg;
    if (msj != null && String(msj).toUpperCase() == 'TRANSACCIÓN DUPLICADA') {
      console.log("TRANSACCIÓN DUPLICADA : " + id);
      return true;
    }
    return false;
  }


}

function send(resultadoServicio) {

  const response = {
    statusCode: resultadoServicio.codeStatus,
    headers: {
      Accept: "application/json, text/plain, */*",
      "Content-Type": "application/json; charset=utf-8",
    },
  };

  if (resultadoServicio.respuesta) {
    response.body = JSON.stringify(resultadoServicio.respuesta);
  }

  console.log(response);

  return response;
}




async function getObligaciones(formulario, folio, rut, vencimiento) {

  let resultado;

  let params = [{
    "sql": oracleSchema + ".PKG_OBL_FSC.SP_CSU_DGA_OBL_FSC(IN_FMU, IN_FOL, IN_RUT, IN_VCT, OUT_CURSOR_SET, OUT_COD, OUT_MSJ);",
    "params": [{
        "parameterType": "IN",
        "type": 2,
        "name": "IN_FMU",
        "value": formulario
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "IN_FOL",
        "value": folio
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "IN_RUT",
        "value": rut
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "IN_VCT",
        "value": vencimiento
      },
      {
        "parameterType": "OUT",
        "type": -10,
        "name": "OUT_CURSOR_SET"
      },
      {
        "parameterType": "OUT",
        "type": 2,
        "name": "OUT_COD"
      },
      {
        "parameterType": "OUT",
        "type": 12,
        "name": "OUT_MSJ"
      }
    ]
  }];


  try {
    resultado = await provider.call(params);
    console.log("resultado: ", resultado)


  }
  catch (e) {
    console.log("Exception en getObligaciones: " + e.message);
    throw e;
  }

  return resultado;

}
