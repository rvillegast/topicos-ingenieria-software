"use strict";

const queryDB = require("./utils/dynamoDbServices");
const util = require("./utils/util");
const moment = require("moment");
const error = require('./utils/CustomError');

module.exports.handler = async(event) => {

  // Inicializo variable.
  let resultadoServicio = {
    "codeStatus": 200,
    "respuesta": null
  };

  try {

    console.log("Entrada:", event)

    var id = event.pathParameters.id;
    
    let json = event.body;


    var params = {
      TableName: `${process.env.PREFIX}-obligaciones`,
      KeyConditionExpression: 'id = :hkey',
      ExpressionAttributeValues: {
        ':hkey': id,
      }
    };

    // Consulto dynamodb.
    var results = await queryDB.getItems(params);

    if (results.length < 1) {
      throw new error.CustomError("Obligación no encontrada.", 404);
    }

    console.log(results);
    
    try {

      let dateEst = moment.utc().toISOString().toString();

      var paramsUpdate = {
        TableName: `${process.env.PREFIX}-obligaciones`,
        Key: { "id": id, "fechaEvento": results[0].fechaEvento },
        UpdateExpression: "set nombreEstado = :exp_nombreEstado, fechaEstado = :exp_fechaEstado, pago = :exp_pago",
        ExpressionAttributeValues: {
          ':exp_nombreEstado': 'PAGO_CONFIRMADO',
          ':exp_fechaEstado': dateEst,
          ':exp_pago': JSON.parse(json).data
        },
        ReturnValues: "UPDATED_NEW"
      };

      var resultsuP = await queryDB.updateItem(paramsUpdate);

      console.log("resultsuP:", resultsuP)

    }
    catch (e) {

      throw new error.CustomError("Error interno.", 500);

    }



    return send(resultadoServicio);

  }
  catch (ex) {

    console.error(ex);

    return send(util.getInfoError(ex));
  }


};

function send(resultadoServicio) {

  const response = {
    statusCode: resultadoServicio.codeStatus,
    headers: {
      Accept: "application/json, text/plain, */*",
      "Content-Type": "application/json; charset=utf-8",
    },
  };

  if (resultadoServicio.respuesta) {
    response.body = JSON.stringify(resultadoServicio.respuesta);
  }

  console.log(response);

  return response;
}
