const axios = require("axios");
const paramssm = require('./ssmUtils');
const util = require('./util');

module.exports.handler = async() => {

  let ssmPrefix = process.env.BUILD_SSM_PREFIX;
  let endpoint = process.env.HOST_TOKEN;

  // Datos para obtener el token.
  let event2 = await util.getEventToken();

  return new Promise((resolve) => {
    let rq = {
      headers: {
        "content-type": "application/x-www-form-urlencoded",
      },
      url: `https://${endpoint}/oauth2/token`,
      data: event2.body,
      method: "POST",
    };

    axios(rq)
      .then(({ status, data }) => {
        resolve({
          statusCode: status,
          body: JSON.stringify(data),
        });
      })
      .catch((error) => {
        console.error(error, error.stack);
        resolve({
          statusCode: 500,
          body: error.message,
        });
      });

  });
};
