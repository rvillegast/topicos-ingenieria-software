const jwt = require("jsonwebtoken");
const AWS = require("aws-sdk");
AWS.config.update({ region: 'us-east-1' });
const axios = require("axios");
const aws4 = require("aws4");
const paramssm = require('./ssmUtils');
const cognitoidentityserviceprovider = new AWS.CognitoIdentityServiceProvider();
let userPoolClientCache = {};
const moment = require("moment");
const validarEntrada = require("./validaciones");
const error = require('./CustomError');
// const { evento } = require('tgr-sdk/clients/eventos');

const cache = {};

exports.getDataFromToken = (authorizationHeader) => {
  try {
    const token = authorizationHeader.match(/Bearer (.*)/)[1];
    const decoded = jwt.decode(token);

    const clientId = decoded.client_id;
    const aud = decoded.aud;

    if (!aud) {
      throw new Error("El token no contiene 'aud'");
    }

    if (cache[clientId]) {
      return cache[clientId];
    }

    const audParts = aud.split(',');
    let institucion = '';
    let formulario = '';
    let girador = '';
    let environment = 'PRODUCCION'; // default
    let rut = '';

    for (const part of audParts) {
      const [key, value] = part.split('=');
      if (key === 'institucion') institucion = value;
      if (key === 'formulario') formulario = value;
      if (key === 'codigo') girador = value;
      if (key === 'ambiente') environment = value;
      if (key === 'rut') rut = value;
    }

    const resultado = { institucion, environment, formulario, girador, rut };
    cache[clientId] = resultado;

    return resultado;

  } catch (e) {
    console.error("Error en getDataFromToken:", e);
    throw new error.CustomError("Error en header Authorization", 403);
  }
};

exports.getDetalleConceptoInstitucion = (concepto, instit) => {
  let request = {
    method: "GET",
    host: process.env.API_AUTOSERVICIOS_HOST_SERVICE,
    path: `/portal-autoservicios/v1/conceptos/${concepto}?institucion=${instit}`,
    service: "execute-api",
  };

  let signedRequest2 = aws4.sign(request, {
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    sessionToken: process.env.AWS_SESSION_TOKEN,
  });

  return axios({
    ...signedRequest2,
    url: `https://${request.host}${request.path}`,
  });
}

exports.getDetalleInstituciones = (institucion) => {
  let request = {
    method: "GET",
    host: process.env.API_AUTOSERVICIOS_HOST_SERVICE,
    path: `/portal-autoservicios/v1/instituciones/${institucion}`,
    service: "execute-api",
  };

  let signedRequest2 = aws4.sign(request, {
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    sessionToken: process.env.AWS_SESSION_TOKEN,
  });

  return axios({
    ...signedRequest2,
    url: `https://${request.host}${request.path}`,
  });
}

exports.getAllConceptosByInstitucion = async(instit) => {

  let request = {
    method: "GET",
    host: process.env.API_AUTOSERVICIOS_HOST_SERVICE,
    path: `/portal-autoservicios/v1/conceptos?institucion=${instit}`,
    service: "execute-api",
  };

  let signedRequest2 = aws4.sign(request, {
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    sessionToken: process.env.AWS_SESSION_TOKEN,
  });

  let response = await axios({
    ...signedRequest2,
    validateStatus: false,
    url: `https://${request.host}${request.path}`,
  });

  return response;
}

exports.getDataValidarADF = (formVer, formCod, listaItems) => {

  let data = {
    data: {
      contextAdf: {
        fechaCaja: new Date(),
        formVer: formVer,
        formCod: formCod,
        traceLvl: 3,
      },
      usuario: "TGR",
      items: listaItems,
    },
  };

  return data;
}


exports.getDataIngresarTrxForm = (rut, formCod, formVer, uuid, listaItems) => {

  let date = moment.utc().toISOString().toString();
  let rutIra = rut.split("-")[0];
  let rutIraDv = rut.split("-")[1];

  let jsonIngresarForm = {
    data: {
      user: "API_OBLIGACIONES",
      rutIra: rutIra,
      rutIraDv: rutIraDv,
      formTipo: formCod,
      formVersion: formVer,
      fechaValidez: null,
      items: null,
      idOrigen: uuid,
      folioF01: null,
      fechaOrigen: date,
      fechaCaja: date,
      loteCaja: 48,
      loteTipo: 6,
      esReversa: false,
    },
  };

  if (listaItems) {
    for (let indextt = 0; indextt < listaItems.length; indextt++) {
      let dataItm = listaItems[indextt];

      // Recupero la fecha de vecimiento para pasarla al ingresarTrxFomr.
      if (dataItm.codigo == "15") {
        const myDate = moment(dataItm.valor, "YYYYMMDD").utc().toISOString().toString();
        jsonIngresarForm.data.fechaValidez = myDate;
      }

    }
  }

  return jsonIngresarForm;
}


exports.procesaRespADF = (respADF) => {

  let response = {
    statusCode: 400,
    body: null,
  };

  let errores = [];

  if (!respADF.contextADF) {

    let e = {
      message: respADF.resultMessage
    };

    errores.push(e);

    response.body = JSON.stringify({ errors: errores, });

    return response;

  }


  let listaData = respADF.recaMensajes;

  for (let indextt = 0; indextt < listaData.length; indextt++) {

    let e = {
      message: listaData[indextt].objName + " - " + listaData[indextt].errMsg + " - " + listaData[indextt].objDescrip
    };
    errores.push(e);

  }

  response.body = JSON.stringify({ errors: errores, });

  return response;
}

exports.procesaRespIngresaTrxForm = (data) => {

  let errores = [];

  let response = {
    statusCode: 400,
    body: null,
  };

  for (let indextt = 0; indextt < data.length; indextt++) {

    if (data[indextt].errMsg && (data[indextt].errMsg.toUpperCase() === 'EL CARGO YA EXISTE EN LA CUT')) {

      errores = [];

      response.statusCode = 409;
      let e = {
        message: "Cargo ya existe",
      };
      errores.push(e);
      break;
    }
    else {
      response.statusCode = 400;
      let e = {
        message: data[indextt].objName + " - " + data[indextt].errMsg,
      };
      errores.push(e);
    }

  }

  response.body = JSON.stringify({ errors: errores, });

  return response;
}


exports.getError = (estadoHttp) => {
  console.log(estadoHttp)
  let respServicio = {
    codeStatus: null,
    respuesta: null,
  };


  if (estadoHttp == "500") {
    respServicio.codeStatus = 500;
    respServicio.respuesta = JSON.parse(
      '{"errors":[{"message": "Error interno."}]}'
    );
  }

  if (estadoHttp == "401") {
    respServicio.codeStatus = 401;
    respServicio.respuesta = JSON.parse(
      '{"errors":[{"message": "No Autorizado"}]}'
    );
  }  

  if (estadoHttp == "403") {
    respServicio.codeStatus = 403;
    respServicio.respuesta = JSON.parse(
      '{"errors":[{"message": "insufficient_scope"}]}'
    );
  }

  if (estadoHttp == "400") {
    respServicio.codeStatus = 400;
    respServicio.respuesta = JSON.parse(
      '{"errors":[{"message": "Solicitud incorrecta"}]}'
    );
  }

  if (estadoHttp == "404") {
    respServicio.codeStatus = 404;
    respServicio.respuesta = JSON.parse(
      '{"errors":[{"message": "Obligación no encontrada"}]}'
    );
  }

  if (estadoHttp == "422") {
    respServicio.codeStatus = 422;
    respServicio.respuesta = JSON.parse(
      '{"errors":[{"message": "Contenido no procesable"}]}'
    );
  }

  

  return respServicio;
}

exports.getObjectError = (elemento) => {

  let error = {
    errors: []
  };

  if (elemento.hasOwnProperty("errors") && elemento.errors instanceof Array) {
    for (let indextt = 0; indextt < elemento.errors.length; indextt++) {
      let message = {
        message: elemento.errors[indextt].message
      }
      error.errors.push(message);
    }
  }
  else {

    let message = {
      message: elemento
    }
    error.errors.push(message);
  }

  return error;
}


exports.validaConcepto = async(institucion, concepto) => {

  // Recupero la informacion de la institucion.
  let responseAllConceptos;

  try {
    responseAllConceptos = await this.getAllConceptosByInstitucion(institucion);
  }
  catch (e) {
    console.log(e)
  }

  let results = responseAllConceptos.data.data.conceptos;

  // Valido el concepto.
  let e = validarEntrada.validacionesConcepto(
    results,
    institucion,
    concepto
  );

  // si no paso la validacion lanzo error.
  if (e !== null) {
    console.log("Concepto No Valido...");
    throw new error.CustomError(e, 400);
  }

}



exports.getCodigoTotal = (respADF) => {

  let codigo91 = {
    codigo: "91",
    valor: null,
  };

  // Recupero el codigo 91 de la respuesta del ADF.
  for (let indexad = 1; indexad < respADF.itemsADF.length; indexad++) {
    let dataitmadf = respADF.itemsADF[indexad];

    if (dataitmadf.codigo == 91) {
      //console.log("data item adf:", dataitmadf.valor);
      codigo91.valor = dataitmadf.valor;
      break;
    }
  }

  return codigo91;
}

exports.getEventToken = async() => {

  let ssmPrefix = process.env.BUILD_SSM_PREFIX;
  let grant_type = await paramssm.getParameterStore(ssmPrefix + 'portalsrv/grant-type');
  let clienteId = await paramssm.getParameterStore(ssmPrefix + 'portalsrv/client-id');
  let client_secret = await paramssm.getParameterStore(ssmPrefix + 'portalsrv/client-secret');
  let scope = await paramssm.getParameterStore(ssmPrefix + 'portalsrv/scope');

  let event2 = {
    body: `grant_type=${grant_type}&client_id=${clienteId}&client_secret=${client_secret}&scope=${scope}`,
  };

  return event2

}


exports.getListaItemIngTrx = (respADF) => {

  let lista = [];

  // Recupero el codigo 91 de la respuesta del ADF.
  for (let indexad = 0; indexad < respADF.itemsADF.length; indexad++) {
    let dataitmadf = respADF.itemsADF[indexad];

    let item = {
      codigo: dataitmadf.codigo,
      valor: dataitmadf.valor
    };

    lista.push(item)
  }

  return lista;
}


exports.getInfoError = (err) => {
  console.log("err>", err)
  let resultadoServicio = {
    codeStatus: 201,
    respuesta: null,
  };

  if(err.response){
    const errorInfo = this.getError(err.response.status);    
    return errorInfo;
  }

  if (!err.code) {
    resultadoServicio.codeStatus = 500;
    resultadoServicio.respuesta = this.getObjectError(['Error Interno.']);
    return resultadoServicio;
  }

  resultadoServicio.codeStatus = err.code;
  resultadoServicio.respuesta = this.getObjectError(err.message);
  return resultadoServicio;
};

exports.getUuidObligacionExistente = async(json, formulario) => {
 
  let rut, fechaVencimiento, folio;

  for (let indextt = 0; indextt < json.data.payload.items.length; indextt++) {
    let dataItm = json.data.payload.items[indextt];

    // Recupero la fecha de vecimiento para pasarla al ingresarTrxFomr.
    if (dataItm.codigo == "15") {
      const myDate = moment(dataItm.valor, "YYYYMMDD");
      fechaVencimiento = myDate.format("YYYY-MM-DD");
    }
    // Recupero el rut.
    if (dataItm.codigo == "3") {       
      const tieneGuion = dataItm.valor.includes("-");
      rut = dataItm.valor.substring(0, dataItm.valor.length - (tieneGuion ? 2 : 1));
    }
    // Recupero el folio.
    if (dataItm.codigo == "7") {
      folio = dataItm.valor;
    }
  }
  console.log("getcuentatributarias", rut)
  let respuesta = await this.getcuentatributarias(rut, formulario - 200, folio, fechaVencimiento);
  if (respuesta.status != 200) {
    console.log("cuentas-tributarias statusCode:", respuesta.status)
    throw new error.CustomError("Error interno", respuesta.status);
  }

  try {

    let cod9926 = respuesta.data.data[0].movimientos[0].items.filter(item => item.codigo == 9926);

    console.log("respuesta-->", cod9926[0].valor);

    return cod9926[0].valor;

  }
  catch (ErrorCt) {
    console.log("error al procesar data cuentas-tributarias:", ErrorCt)
    throw new error.CustomError("Error interno", 500);
  }

};


exports.getcuentatributarias = (rut, formulario, folio, fechaVencimiento) => {

  //https://api.dev.tegere.info/cuentas-tributarias/v1/cuentas

  let request = {
    method: "GET",
    host: process.env.API_AUTOSERVICIOS_HOST_SERVICE,
    path: `/cuentas-tributarias/v1/cuentas?rut=${rut}&formulario=${formulario}&folio=${folio}&vencimiento=${fechaVencimiento}&full=true`,
    service: "execute-api",
  };

  let signedRequest2 = aws4.sign(request, {
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    sessionToken: process.env.AWS_SESSION_TOKEN,
  });

  return axios({
    ...signedRequest2,
    url: `https://${request.host}${request.path}`,
  });

};
