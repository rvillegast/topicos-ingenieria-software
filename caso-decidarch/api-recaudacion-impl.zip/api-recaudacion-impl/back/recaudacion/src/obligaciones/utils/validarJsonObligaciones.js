const Ajv = require('ajv');
const ajv = new Ajv();
const error = require('./CustomError');
const localize = require('ajv-i18n');

exports.validarjson = (json) => {

  if (!json) {
    throw new error.CustomError("Debe informar el json de entrada", 400);
  }

  let archivo = require('../resource/openApi-obligaciones.json');
  var schemaO = archivo.paths['/obligaciones'].post.parameters[0].schema;
  var validate = ajv.compile(schemaO);

  // si en json de entrada no es valido, se lanza error 
  if (!validate(json)) {
    localize.es(validate.errors);
    // string with all errors and data paths
    console.log(ajv.errorsText(validate.errors, { separator: '\n' }));
    console.log("Json de entrada No Valido.")
    throw new error.CustomError(validate.errors[0].dataPath + " " + validate.errors[0].message, 400);
  }

};

exports.validarjsonDescarga = (json) => {

  if (!json) {
    throw new error.CustomError("Debe informar el json de entrada", 400);
  }

  let archivo = require('../resource/openApi-obligaciones.json');
  var schemaO = archivo.paths['/obligaciones/{id}'].put.parameters[1].schema;
  var validate = ajv.compile(schemaO);

  // si en json de entrada no es valido, se lanza error 
  if (!validate(json)) {
    localize.es(validate.errors);
    // string with all errors and data paths
    console.log(ajv.errorsText(validate.errors, { separator: '\n' }));
    console.log("Json de entrada No Valido.")
    throw new error.CustomError(validate.errors[0].message, 400);
  }

};
