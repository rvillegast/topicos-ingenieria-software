'use strict';

class CustomError extends Error {
    constructor(args, codError){
        super(args, codError);
        this.message =args;
        this.code=codError;
    }
}

module.exports = {CustomError};