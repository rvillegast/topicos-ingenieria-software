const _ = require("lodash");
const RUT = /^\d+$/;
const DV = /^[kK\d]$/;
const UNO_O_MAS_CUALQUIER_CARACTER = /^[^]+$/;
const NUMERO_POSITIVO = /^[1-9]\d*$/;

//VALIDAMOS CONCEPTO DE RECAUDACIÓN PARA LA INSTITUCION
//QUE REALIZA LA SOLICITUD DE RECAUDACIÓN
exports.validacionesConcepto = function (data, instit, concepto) {
  let bandera = data.includes(concepto, 0);
  let e = null;

  if (!bandera) {
    // Error de Concepto de Recaudación. No existe id Concepto
    e = {
      message: `El Concepto de Recaudación: ${concepto}, no está registrado en TGR para la institución: ${instit}. Favor configurarlo previamente`,
      code: 101,
    };
  }
  return e;
};

//GENERAMOS MENSAJE DE ERROR PARA EL CASO DE NO EXISTIR
//BILLETERA INGRESADA

function validaExpresion(campo, expresion) {
  return !expresion.test(campo);
}

function validaDv(dv, rut) {
  rut = _.toString(rut);
  dv = _.toUpper(dv);

  if (!rut || !rut.length || typeof rut !== "string") {
    return "1";
  }
  var secuencia = [2, 3, 4, 5, 6, 7, 2, 3];
  var sum = 0;

  for (var i = rut.length - 1; i >= 0; i--) {
    var d = rut.charAt(i);
    sum += Number(d) * secuencia[rut.length - (i + 1)];
  }

  var rest = 11 - (sum % 11);

  if (rest == 11) {
    rest = "0";
  }

  if (rest == 10) {
    rest = "K";
  }

  if (_.toString(rest) == _.toString(dv)) {
    return "0";
  } else {
    return "2";
  }
}
