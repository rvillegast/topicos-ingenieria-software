'use strict';

const isTest = process.env.JEST_WORKER_ID || process.env.IS_SERVERLESS_OFFLINE === 'true';
const {DocumentClient} = require('aws-sdk/clients/dynamodb');

let config;

if (isTest) {
    config = {
        convertEmptyValues: true,
        ...(isTest && {endpoint: 'localhost:8000', sslEnabled: false, region: 'local-env'})
    };
}
else {
    config = {
        region: "us-east-1"
    }
}
var docClient = new DocumentClient(config);

exports.docClient = docClient;

exports.putItem = function (uuid, json, estado, jsonCut , institucion, environment, formulario, girador, errors) {
    
    let fecha = new Date().toISOString();
 
    var params = {
        TableName: `${process.env.PREFIX}-obligaciones`,
        Item: {
            id: uuid,
            fechaEvento: fecha,
            fechaEstado: fecha,
            nombreEstado: estado,
            payload: json,
            jsonCut: jsonCut,
            institucion: institucion,
            codigoInstitucionOnPrem: girador,
            formulario: formulario,
            environment: environment,
            institucionEnvironment: `${institucion}#${environment}`,
            pago:null,
            errors:errors
        },
    };
   
    
    return new Promise((resolve, reject) => {
        docClient.put(params, function (err, data) {
            if (err) {
                console.log(err)
                //console.log("dynamodb insert error:", params.Item, JSON.stringify(err, null, 2), err.stack);
                reject({
                    errors: [{
                        statusCode: 500,
                        message: "Error al persistir en DynamoDB"
                    }]
                });
            }
            else {
                console.log(data)
                resolve(data);
            }
        });
    });
};

exports.getItem = function (params) {
    
    return new Promise((resolve, reject) => {
        docClient.get(params, function (err, data) {
            if (err) {
                console.log("dynamodb get error:", JSON.stringify(err, null, 2), err.stack);
                reject(err);
            }
            else {
                resolve(data.Item);
            }
        });
    });
};

exports.getConcepto = function (concepto) {
    var params = {
        TableName: `tgr-${process.env.ENV}-conceptos-instituciones`,
        KeyConditionExpression: 'idConcepto = :hkey',
        ExpressionAttributeValues: {
            ':hkey': concepto
        }
    };
    
    return new Promise((resolve, reject) => {
        docClient.query(params, function (err, data) {
            if (err) {
                console.log("dynamodb get error:", JSON.stringify(err, null, 2), err.stack);
                reject(err);
            }
            else {
                resolve(data);
            }
        });
    });
};

exports.getItems = function (params) {
    
    return new Promise((resolve, reject) => {
        docClient.query(params, function (err, data) {
            if (err) {
                console.log("dynamodb get error:", JSON.stringify(err, null, 2), err.stack);
                reject(err);
            }
            else {
                resolve(data.Items);
            }
        });
    });
};

exports.getDataQuery = function (params) {
    
    return new Promise((resolve, reject) => {
        docClient.query(params, function (err, data) {
            if (err) {
                console.log("dynamodb get error:", JSON.stringify(err, null, 2), err.stack);
                reject(err);
            }
            else {
                resolve(data);
            }
        });
    });
};


exports.updateItem = function (params) {
    
    return new Promise((resolve, reject) => {
        docClient.update(params, function (err, data) {
            if (err) {
                console.log("dynamodb get error:", JSON.stringify(err, null, 2), err.stack);
                reject(err);
            }
            else {
                resolve(data);
            }
        });
    });
};