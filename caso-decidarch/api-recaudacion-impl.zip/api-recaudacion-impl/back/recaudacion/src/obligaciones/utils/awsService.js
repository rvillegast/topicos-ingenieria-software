const axios = require('axios');
const aws4 = require('aws4');


async function consultaFormulario(body) {    
    let parametros = JSON.parse(body);          
    let formulario = parametros.formulario;
    let folio = parametros.folio;       
    let rut = parametros.rut;       

    let request = {
      method: 'GET',
      host: process.env.API_AUTOSERVICIOS_HOST_SERVICE,
      path: `/cuentas-tributarias/v1/cuentas?formulario=${formulario}&rut=${rut}&folio=${folio}&full=true`,
      service: 'execute-api'
  }

  let signedRequest2 = aws4.sign(request, {
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
      accessKeyId: process.env.AWS_ACCESS_KEY_ID,
      sessionToken: process.env.AWS_SESSION_TOKEN
  })  
  return axios({
        ...signedRequest2,
        url: `https://${request.host}${request.path}`,
    })
  }

  exports.consultaFormulario = consultaFormulario;