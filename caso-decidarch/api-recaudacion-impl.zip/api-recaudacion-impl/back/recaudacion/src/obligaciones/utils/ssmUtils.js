const AWS = require("aws-sdk");
AWS.config.update({ region: "us-east-1" });

const ssm = new AWS.SSM({ apiVersion: "2014-11-06" });
const NodeCache = require("node-cache");
const parametrosSSMCache = new NodeCache();

exports.getParameterStore = async(name) => {

  try {
    let item;
    let arrSSM = [];

    if (parametrosSSMCache.has('key')) {
       
      arrSSM = parametrosSSMCache.get("key");

      item = await arrSSM.find((item) => {
        return item.Name === name;
      })
    }
    else {
      let params;

      params = {
        Path: `${process.env.BUILD_SSM_PREFIX}portalsrv`,
        WithDecryption: true,
        Recursive: true
      };

      let resp = await ssm.getParametersByPath(params).promise();

      arrSSM = resp.Parameters;

      parametrosSSMCache.set('key', arrSSM, 10000);

      item = await arrSSM.find((item) => {
        return item.Name === name;
      })
    }
    return item.Value;
  }
  catch (e) {
    console.log(e);
    return e;
  }
}

// var params = {
//   Name: name,
//   WithDecryption: true,
// };

// return new Promise((resolve, reject) => {
//   ssm.getParameter(params, function(err, data) {
//     if (err) {
//       console.log("Parametros SSM:", name)
//       console.log(err, err.stack); // an error occurred
//       reject(err);
//     }
//     else {
//       resolve(data.Parameter.Value);
//     }
//   });
// });
