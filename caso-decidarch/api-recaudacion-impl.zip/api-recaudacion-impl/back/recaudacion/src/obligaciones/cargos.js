"use strict";

const token = require("./utils/oauth2Token");
const validaAdf = require("./callValidarAdf");
const ingresaTrx = require("./callIngresarTrxForm");
const util = require("./utils/util");
const validar = require('./utils/validarJsonObligaciones');
const queryDB = require("./utils/dynamoDbServices");
const { v4: uuidv4 } = require("uuid");
//const { evento: enviarEvento } = require('tgr-sdk/clients/eventos');
const { evento: enviarEvento } =  require('./eventos');

module.exports.handler = async(event) => {

  console.log("Entrada:", event);

  let evento = "obligaciones";
  let aplicacion = "api-recaudacion";

  let data = {
    "usuario": null,
    "statusCode": null,
    "operacion": "cargar",
    "tipoOperacion": "POST"
  };

  // Defino objeto de salida de la operacion.
  let resultadoServicio = {
    codeStatus: 201,
    respuesta: null,
  };

  let dataSalida = {
    data: {
      id: null,
    },
  };

  try {
    // Defino el uudi para la operacion.
    let uuid = uuidv4();
    console.log("uuid operacion:", uuid);

    // Obtendo los datos del client-id a traves del token.
    console.log("event", event)
    let { institucion, rut } = await util.getDataFromToken(event.headers.Authorization);

    // Seteo el usuario que esta usando la api.
    data.usuario = institucion;

    const json = JSON.parse(event.body);

    data["concepto"] = json.data.concepto;

    // Realizo validacion del json de entrada con la definicion swageer.
    await validar.validarjson(json);

    // Valido el concepto de entrada con la institucion.
    await util.validaConcepto(institucion, json.data.concepto);

    // Obtener detalle de tabla Conceptos.
    let detConceptoIns = await util.getDetalleConceptoInstitucion(json.data.concepto, institucion);
    console.log("detConceptoIns =>", detConceptoIns)
    let detalleInstituciones = await util.getDetalleInstituciones(institucion);

    console.log("Rut Institucion:", detalleInstituciones.data.data.rut);

    rut = detalleInstituciones.data.data.rut;

    let dataConcepto = detConceptoIns.data.data;
    let environment = dataConcepto.etapa;
    let girador = dataConcepto.codigoInstitucionOnPrem;
    // codigo del formulario.
    let formCod = dataConcepto.formulario.split("#")[0];
    // version del formulario.
    let formVer = dataConcepto.formulario.split("#")[1];

    // Obtengo token.
    let tokenResp = await token.handler();

    // valida el formulario con el adf.
    let respADF = await validaAdf.procesaAdf(formVer, formCod, json, uuid, tokenResp, institucion, environment, girador, true,null);

    // Defino objeto de entrada del ingresarTrxForm.
    let dataIngresarForm = util.getDataIngresarTrxForm(rut, formCod, formVer, uuid, json.data.payload.items);

    // Se agrega la lista de items obtenidos de la respuesta del validarADF.
    dataIngresarForm.data.items = util.getListaItemIngTrx(respADF);

    console.log("Data Enviada a IngresarTrxform:", JSON.stringify(dataIngresarForm));

    // datos ingresarTrxForm
    let eventForm = {
      body: dataIngresarForm,
      authorization: JSON.parse(tokenResp.body).access_token,
    };

    // Realizo llamado al IngresarTrxForm.
    let respuestaIng = await ingresaTrx.handler(eventForm);

    try {

      await ingresaTrx.getProcesaRespIngTrxForm(respuestaIng, uuid, json, dataIngresarForm, institucion, environment, formCod, girador);

    }
    catch (errorEx) {

      if (errorEx.code && errorEx.code == 409) {
        console.log("Cargo ya existe en CUT se busca uuid origen.")

        let idCargo = await util.getUuidObligacionExistente(json, formCod)
        console.log("idCargo",idCargo)
        dataSalida.data.id = idCargo;
        resultadoServicio.respuesta = dataSalida;

        return send(resultadoServicio);
      }    
      throw errorEx;
    }

    // Seteo el uuid que se ocupo en registrar la obligacion.
    dataSalida.data.id = uuid;


    // Persistir data en DynamoDB.
    await queryDB.putItem(uuid, json, 'CARGADA', dataIngresarForm, institucion, environment, formCod, girador, null);

    resultadoServicio.respuesta = dataSalida;

  }
  catch (err) {
    console.error("error:", err);

    let salidaErr = util.getInfoError(err);

    // Seteo el code status.
    data.statusCode = salidaErr.codeStatus;

    try {
      await enviarEvento({ evento, aplicacion, data });
    }
    catch (e) {
      console.log("Error al Enviar Evento GCP:", e);
    }

    return send(salidaErr);
  }

  data.statusCode = resultadoServicio.codeStatus;

  try {
    await enviarEvento({ evento, aplicacion, data });
  }
  catch (e) {
    console.log("Error al Enviar Evento GCP:", e);
  }

  return send(resultadoServicio);
};

function send(resultadoServicio) {
  const response = {
    statusCode: resultadoServicio.codeStatus,
    headers: {
      Accept: "application/json, text/plain, */*",
      "Content-Type": "application/json; charset=utf-8",
    },
  };

  if (resultadoServicio.respuesta) {
    response.body = JSON.stringify(resultadoServicio.respuesta);
  }

  console.log("response", response);
  return response;
}
