'use strict';

const { SNSClient, PublishCommand } = require('@aws-sdk/client-sns');

const sns = new SNSClient({ region: 'us-east-1' });

const evento = async ({ evento, aplicacion, data }) => {
    console.log('🛰️ evento SNS:', JSON.stringify({ evento, aplicacion, data }));

    const params = {
        Message: JSON.stringify({ evento, aplicacion, data }),
        Subject: 'Registro Eventos From Lambda',
        TopicArn: process.env.TGR_EVENTS_TOPIC
    };

    console.log('📤 Publicando evento SNS con params:', params);

    try {
        const command = new PublishCommand(params);
        const resp = await sns.send(command);
        console.log('✅ Evento SNS publicado con éxito:', resp);
    } catch (err) {
        console.error('❌ Error al publicar evento SNS:', err);
        throw err;
    }
};

module.exports = { evento };
