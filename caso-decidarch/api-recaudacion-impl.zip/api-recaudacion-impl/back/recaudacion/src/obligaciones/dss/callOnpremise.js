const { OracleProvider, OracleTypes} = require('../oracleProvider');
let provider = new OracleProvider();


exports.getSaldoCut = async function(rutRol, rutRolDv, folio, formulario, version, periodo){

    let params = [
          {
            "sql": "RECA.PKG_SERVICES_SICEX.CONSULTA_SALDO( inRutRol, inDigV, inFolio, inFormulario, inVersion, inPeriodo, cursorRs)",
            "params": [
              {"parameterType": "IN",  "type": 2, "name": "inRutRol",     "value": rutRol},
              {"parameterType": "IN",  "type": 12, "name": "inDigV",   "value": rutRolDv},
              {"parameterType": "IN",  "type": 2, "name": "inFolio",      "value": folio},
              {"parameterType": "IN",  "type": 2, "name": "inFormulario", "value": formulario},
              {"parameterType": "IN",  "type": 12, "name": "inVersion",    "value": version},
              {"parameterType": "IN",  "type": 91,    "name": "inPeriodo",    "value": periodo},
              {"parameterType": "OUT", "type": -10,  "name": "cursorRs"}
            ]
          }
        ]
        
    console.log("getSaldo params"+JSON.stringify(params));
    
    try {
      let resultado = await provider.call(params);
      console.log(resultado);
      return(resultado);
  
  } catch (e) {
      console.error(e.message)
  }
}