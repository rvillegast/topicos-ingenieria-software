'use strict';

const queryDB = require("./utils/dynamoDbServices");
const moment = require('moment-timezone');
const util = require("./utils/util");
const error = require('./utils/CustomError');
//const { evento: enviarEvento } = require('tgr-sdk/clients/eventos');
const { evento: enviarEvento } =  require('./eventos');

exports.handler = async(event) => {

    const pag = process.env.PAGINACION;

    // Inicializo variable.
    let resultadoServicio = {
        "codeStatus": 200,
        "respuesta": null
    };

    let evento = "obligaciones"
    let aplicacion = "api-recaudacion"

    let data = {
        "usuario": null,
        "statusCode": null,
        "operacion": "eventos",
        "tipoOperacion": "GET",
        "concepto": "TODOS"
    };

    try {

        let { institucion, formulario, girador, environment } = await util.getDataFromToken(event.headers.Authorization);

        console.log("institución invocadora: " + institucion + ", girador: " + girador + ", formulario: " + formulario + ", environment: " + environment);

        // Seteo el usuario que esta usando la api.
        data.usuario = institucion;

        let interval = event.queryStringParameters.interval;

        if (!interval) {
            throw new error.CustomError("Parámetro obligatorio: interval", 400);
        }
        let exp = /^\d+$/;

        if (!exp.test(interval)) {
            throw new error.CustomError("Parámetro interval permite solo numeros.", 400);
        }

        let next = event.queryStringParameters.next;
        let lastEvalKey;

        let from = moment().subtract(interval, 'minutes').toISOString();



        var params = {
            TableName: `${process.env.PREFIX}-obligaciones`,
            IndexName: `${process.env.PREFIX}-obligaciones-idx`,
            KeyConditionExpression: "institucion = :instEnv AND fechaEvento >= :dt",
            ExpressionAttributeValues: {
                ":dt": from,
                ":instEnv": `${institucion}`
            },
            Limit: parseInt(pag)
        };

        if (next) {

            try {
                params.ExclusiveStartKey = JSON.parse(new Buffer.from(next, 'base64').toString('ascii'));
            }
            catch (er) {
                throw new error.CustomError("Error interno.", 500);
            }
        }

        var dataDyn = await queryDB.getDataQuery(params);

        // Valido que la consulta retorne datos.
        if (dataDyn.Items.length < 1) {
            throw new error.CustomError("Obligación no encontrada.", 404);
        }

        if (dataDyn.LastEvaluatedKey) {
            lastEvalKey = new Buffer.from(JSON.stringify(dataDyn.LastEvaluatedKey)).toString('base64');
        }

        let datasalida = {
            metadata: {
                request: {
                    interval: parseInt(interval),
                    next: next
                },
                response: {
                    next: lastEvalKey
                }
            },
            data: dataDyn.Items.map(getResponseItem)
        };

        resultadoServicio.codeStatus = 200;
        resultadoServicio.respuesta = datasalida;

    }
    catch (e) {

        console.error("error:", e);

        let salidaErr = util.getInfoError(e);

        // Seteo el code status.
        data.statusCode = salidaErr.codeStatus;

        try {
            await enviarEvento({ evento, aplicacion, data });
        }
        catch (e) {
            console.log("Error al Enviar Evento GCP:", e)
        }

        return send(salidaErr);
    }

    data.statusCode = resultadoServicio.codeStatus;

    try {
        await enviarEvento({ evento, aplicacion, data });
    }
    catch (e) {
        console.log("Error al Enviar Evento GCP:", e)
    }

    return send(resultadoServicio)

};

function send(resultadoServicio) {

    const response = {
        statusCode: resultadoServicio.codeStatus,
        headers: {
            Accept: "application/json, text/plain, */*",
            "Content-Type": "application/json; charset=utf-8",
        },
    };

    if (resultadoServicio.respuesta) {
        response.body = JSON.stringify(resultadoServicio.respuesta);
    }

    console.log(response);

    return response;
}


function getResponseItem(item) {

    let elemento = {
        obligacion: {
            id: item.id
        },
        estado: {
            nombreEstado: item.nombreEstado,
            fechaEstado: item.fechaEstado
        },
        fechaEvento: item.fechaEvento,
        etapa: item.environment

    }
    return elemento;
}
