const axios = require("axios");
const paramssm = require('./utils/ssmUtils');
const queryDB = require("./utils/dynamoDbServices");
const util = require("./utils/util");
const error = require('./utils/CustomError');

module.exports.handler = async(event) => {

  let ssmPrefix = process.env.BUILD_SSM_PREFIX;

  let endpoint = await paramssm.getParameterStore(ssmPrefix + 'portalsrv/host')

  return new Promise((resolve) => {
    let rq = {
      headers: {
        "Content-Type": "application/json",
        "Authorization": event.authorization
      },
      url: `https://${endpoint}/v1/transacciones`,
      data: event.body,
      method: "POST",
    };

    axios(rq)
      .then(({ status, data }) => {
        resolve({
          statusCode: status,
          body: JSON.stringify(data),
        });
      })
      .catch((error) => {
        console.error(error, error.stack);
        resolve({
          statusCode: error.response.status,
          body: error.message,
        });
      });

  });
};


exports.getProcesaRespIngTrxForm = async(respuestaIng, uuid, json, dataIngresarForm, institucion, environment, formCod, girador) => {

  if (respuestaIng.statusCode != 200) {
    console.log("Error al ingresar formulario:", respuestaIng.body);
    let auxErr = util.getError(respuestaIng.statusCode)
    throw new error.CustomError(JSON.parse(auxErr).errors[0].message, respuestaIng.statusCode);
  }

  console.log("Respuesta ingresarTrxForm:", respuestaIng)

  let respIngTrxform = JSON.parse(respuestaIng.body);

  if (respIngTrxform.data.resultCode != 5) {

    console.log("IngresarTrxForm resultCode:", respIngTrxform.data.resultCode);
    //console.log("IngresarTrxForm resultCode:", util.procesaRespIngresaTrxForm(respIngTrxform.data.recaMensajes));

    let resultIng = util.procesaRespIngresaTrxForm(respIngTrxform.data.recaMensajes);

    // if (resultIng.statusCode == 409) {
    //   // Persistir data en DynamoDB.
    //   await queryDB.putItem(uuid, json, 'DUPLICADA', dataIngresarForm, institucion, environment, formCod, girador, JSON.parse(resultIng.body));
    // }

    throw new error.CustomError(JSON.parse(resultIng.body), resultIng.statusCode);

  }
}
