"use strict";

const axios = require("axios");
const { z } = require("zod");
const util = require("../../util");

let tokenHandler;

const ERR_MESSAGE = "Validación de forma";

/* =========================================================
   HELPERS
========================================================= */

const num = (fieldName, maxLen) =>
  z.preprocess(
    (v) => {
      if (v === null || v === undefined) return undefined;
      const s = String(v).trim();
      return s === "" ? undefined : s;
    },
    z
      .string({ required_error: `El ${fieldName} es obligatorio` })
      .min(1, { message: `El ${fieldName} es obligatorio` })
      .regex(/^\d+$/, { message: `El ${fieldName} debe ser del tipo Número` })
      .max(maxLen, {
        message: `El campo ${fieldName} no puede superar el largo ${maxLen}`,
      })
      .transform((s) => Number(s))
  );

function nowAsLocalIsoNoTZ() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(
    d.getHours()
  )}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

function dateOnlyFromIso(iso) {
  if (!iso) return null;
  return String(iso).slice(0, 10);
}

function extractFechaTerminoFromIdLiquidacion(idLiquidacion) {
  if (!idLiquidacion) return null;

  const id = String(idLiquidacion);
  const fechas = [];

  for (let i = 0; i <= id.length - 6; i++) {
    const chunk = id.slice(i, i + 6);
    if (!/^\d{6}$/.test(chunk)) continue;

    const yy = Number(chunk.slice(0, 2));
    const mm = Number(chunk.slice(2, 4));
    const dd = Number(chunk.slice(4, 6));

    if (mm < 1 || mm > 12 || dd < 1 || dd > 31) continue;

    const year = 2000 + yy;
    const dt = new Date(Date.UTC(year, mm - 1, dd));

    if (
      dt.getUTCFullYear() === year &&
      dt.getUTCMonth() === mm - 1 &&
      dt.getUTCDate() === dd
    ) {
      fechas.push({
        iso: `${year}-${String(mm).padStart(2, "0")}-${String(dd).padStart(2, "0")}`,
        time: dt.getTime(),
      });
    }
  }

  if (!fechas.length) return null;
  fechas.sort((a, b) => b.time - a.time);
  return fechas[0].iso;
}

/* =========================================================
   SCHEMA INPUT
========================================================= */

const schemaLiquidacionCUT = z.object({
  rutRol: num("rutRol", 9),

  rutRolDv: z.preprocess(
    (v) => {
      if (v === null || v === undefined) return undefined;
      const s = String(v).trim();
      return s === "" ? undefined : s;
    },
    z
      .string({ required_error: "El rutRolDv es obligatorio" })
      .min(1, { message: "El rutRolDv es obligatorio" })
      .max(1, { message: "El rutRolDv no puede superar el largo 1" })
  ),

  formulario: num("formulario", 4),
  folio: num("folio", 14),

  // ✅ opcional real (si no viene o viene vacío => undefined, no valida)
  // si viene, valida YYYY-MM-DD y fecha real
  periodo: z.preprocess(
    (v) => {
      if (v === null || v === undefined) return undefined;
      const s = String(v).trim();
      return s === "" ? undefined : s;
    },
    z.union([
      z.undefined(),
      z
        .string()
        .refine(
          (s) => {
            if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
            const [y, m, d] = s.split("-").map(Number);
            const dt = new Date(Date.UTC(y, m - 1, d));
            return (
              dt.getUTCFullYear() === y &&
              dt.getUTCMonth() === m - 1 &&
              dt.getUTCDate() === d
            );
          },
          { message: "El periodo debe tener formato YYYY-MM-DD" }
        ),
    ])
  ),

  version: z
    .preprocess(
      (v) => {
        if (v === null || v === undefined) return undefined;
        const s = String(v).trim();
        return s === "" ? undefined : s;
      },
      z.string().max(2, { message: "El version no puede superar el largo 2" })
    )
    .optional(),
});

/* =========================================================
   PARSE / SEND / VALIDATE
========================================================= */

function parseBody(event) {
  if (!event || event.body == null || event.body === "") return null;
  try {
    return typeof event.body === "object" ? event.body : JSON.parse(event.body);
  } catch {
    return null;
  }
}

function send(statusCode, payload) {
  return {
    statusCode,
    headers: {
      Accept: "application/json, text/plain, */*",
      "Content-Type": "application/json; charset=utf-8",
    },
    body: JSON.stringify(payload ?? {}),
  };
}

function validateInput(body) {
  if (typeof body !== "object" || body === null || Array.isArray(body)) {
    return {
      ok: false,
      statusCode: 400,
      payload: {
        status: 400,
        message: ERR_MESSAGE,
        errors: ["El parametro de entrada debe ser un objeto."],
      },
    };
  }

  const result = schemaLiquidacionCUT.safeParse(body);

  if (!result.success) {
    const errors = result.error.issues.map((issue) => {
      const missing =
        issue.code === "invalid_type" &&
        (issue.input === undefined ||
          issue.received === "undefined" ||
          issue.message?.includes("received undefined"));

      if (missing) {
        const field = issue.path?.[issue.path.length - 1] || "parámetro";
        return `El ${field} es obligatorio`;
      }

      return issue.message;
    });

    return {
      ok: false,
      statusCode: 400,
      payload: {
        status: 400,
        message: ERR_MESSAGE,
        errors,
      },
    };
  }

  return { ok: true, data: result.data };
}

/* =========================================================
   TOKEN
========================================================= */

async function getTokenCUT() {
  if (!tokenHandler) {
    const mod = await import("../../oauth2Token.mjs");
    tokenHandler = mod.handler;
  }

  const tokenResp = await tokenHandler({
    body: new URLSearchParams({
      grant_type: process.env.grantType,
      client_id: process.env.clientIdCUT,
      client_secret: process.env.clientSecretCUT,
      scope: process.env.scopeCUT,
    }).toString(),
  });

  const tokenJson = JSON.parse(tokenResp.body);
  if (!tokenJson?.access_token) throw new Error("No se pudo obtener token CUT");

  return tokenJson.access_token;
}

/* =========================================================
   CUT CALL
========================================================= */

async function LiquidaDeudaAR(input, token,institucion) {
  const ambiente = process.env.ENV;
  const url = `https://${process.env.hostNameCUT}/api-servicios-cut/${ambiente}/liquida-deudas/v1/deuda`;


  const sistema = institucion === "SICEX" ? 68 : 67;
  const payload = {
    rutRol: input.rutRol,
    rutRolDv: input.rutRolDv,
    sistema: sistema,  // 68 si es sicex, si no 67
    formTipo: input.formulario, 
    formFolio: input.folio,
    fechaOrigen: nowAsLocalIsoNoTZ(),
    clienteTipo: 1,
    canal: 4,
    grupo: 2,
    idConsulta: 1,
    codTransac: "AWSPPF",
    usuario: 1,
  };
  console.log("payload=>",payload)
  return axios.post(url, payload, {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    timeout: 15000,
  });
}

/* =========================================================
   RESPUESTAS
========================================================= */

function buildOkResponseFromCUT(salidaCUT, input) {
  const fechaEnvio = new Date().toISOString();
  const items = Array.isArray(salidaCUT?.data) ? salidaCUT.data : [];

  const periodoIn = input.periodo ?? null;
  const versionIn = input.version ?? null;

  const filtrados = items.filter((it) => {
    let ok = true;

    if (periodoIn) ok = ok && String(it.periodo || "").startsWith(periodoIn);
    if (versionIn) ok = ok && String(it.formVer || "") === versionIn;

    return ok;
  });

  return {
    metaData: { fechaEnvio },
    data: {
      liquidacion: filtrados.map((it) => ({
        titulo: "AVISO RECIBO",
        cid: it.idLiquidacion,
        fechaCalculo: dateOnlyFromIso(fechaEnvio),
        fechaIniciovigencia: dateOnlyFromIso(it.fechaLiquidacion),
        fechaTerminovigencia: extractFechaTerminoFromIdLiquidacion(it.idLiquidacion),
        monedaLiquidacion: "CLP",
        montoPagoliquidacion: it.montoTotalPagar,
      })),
    },
  };
}

function buildNoAplicaResponse() {
  return {
    metaData: { fechaEnvio: new Date().toISOString() },
    data: { liquidacion: { mensaje: "no aplica liquidacion" } },
  };
}

/* =========================================================
   HANDLER
========================================================= */

module.exports.handler = async (event) => {
  const body = parseBody(event);
  console.log("event=>", event);

  if (!body) {
    return send(400, {
      status: 400,
      message: ERR_MESSAGE,
      errors: ["El body no es un JSON válido."],
    });
  }

  const val = validateInput(body);
  if (!val.ok) return send(val.statusCode, val.payload);
  

  try {
    let { institucion } = await util.getDataFromToken(event.headers.Authorization);
    console.log("institucion",institucion)
    const token = await getTokenCUT();
    const resp = await LiquidaDeudaAR(val.data, token,institucion);
    console.log("resp=>", resp.data);
   

    return send(200, buildOkResponseFromCUT(resp.data, val.data));
  } catch (err) {
    console.log("err=>", err);

    if (err?.response?.status === 404) {
      return send(200, buildNoAplicaResponse());
    }

    return send(500, {
      status: 500,
      message: "Error al liquidar en CUT",
      errors: [err.message],
    });
  }
};
