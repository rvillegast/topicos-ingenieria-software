'use strict';

const { LambdaClient, InvokeCommand } = require("@aws-sdk/client-lambda");

const lambda = new LambdaClient({ region: 'us-east-1' });

class OracleProvider {
    constructor(params) {
        this.lambdaFunction = process.env.DSS_TIERRA_ORACLE_LAMBDA;
        
        if (params) {
            if (typeof params === 'string') {
                // Versión antigua
                console.log('Legacy DSS Library -', params);
                this.lambdaFunction = params;
            } else {
                if (params.lambdaFunction) {
                    this.lambdaFunction = params.lambdaFunction;
                }
                this.way = params.way;
            }
        }
    }

    async call(statements) {
        console.log('callOracle', JSON.stringify(statements));
        
        if (!statements || statements.length === 0) {
            return [{ error: '0' }];
        }
        
        if (this.way) {
            statements[0].way = this.way;
        }
        
        const ti = Date.now();
        
        try {
            const command = new InvokeCommand({
                FunctionName: this.lambdaFunction,
                InvocationType: 'RequestResponse',
                LogType: 'Tail',
                Payload: Buffer.from(JSON.stringify(statements)),
            });

            const data = await lambda.send(command);
            
            console.log('time (ms) callOracle', Date.now() - ti);

            const payload = Buffer.from(data.Payload).toString();
            const parsedData = JSON.parse(payload);
            console.log(parsedData);
            return parsedData;

        } catch (error) {
            console.error(error);
            throw error;
        }
    }
}

let OracleTypes = {
    BIT: -7,
    TINYINT: -6,
    SMALLINT: 5,
    INTEGER: 4,
    BIGINT: -5,
    FLOAT: 6,
    REAL: 7,
    DOUBLE: 8,
    NUMERIC: 2,
    DECIMAL: 3,
    CHAR: 1,
    VARCHAR: 12,
    LONGVARCHAR: -1,
    DATE: 91,
    TIME: 92,
    TIMESTAMP: 93,
    TIMESTAMPNS: -100,
    TIMESTAMPTZ: -101,
    TIMESTAMPLTZ: -102,
    INTERVALYM: -103,
    INTERVALDS: -104,
    BINARY: -2,
    VARBINARY: -3,
    LONGVARBINARY: -4,
    ROWID: -8,
    CURSOR: -10,
    BLOB: 2004,
    CLOB: 2005,
    BFILE: -13,
    STRUCT: 2002,
    ARRAY: 2003,
    REF: 2006,
    NCHAR: -15,
    NCLOB: 2011,
    NVARCHAR: -9,
    LONGNVARCHAR: -16,
    SQLXML: 2009,
    OPAQUE: 2007,
    JAVA_STRUCT: 2008,
    JAVA_OBJECT: 2000,
    PLSQL_INDEX_TABLE: -14,
    BINARY_FLOAT: 100,
    BINARY_DOUBLE: 101,
    NULL: 0,
    NUMBER: 2,
    RAW: -2,
    OTHER: 1111,
    FIXED_CHAR: 999,
    DATALINK: 70,
    BOOLEAN: 16,
};

module.exports = {
    OracleProvider,
    OracleTypes: Object.freeze(OracleTypes)
};
