const mocks = (nock, hostname) =>
    nock(hostname)
        .persist()
        .get('/config.json')
        .reply(200, JSON.stringify({
            "token_host": "wstest.tesoreria.cl",
            "token_id": "OauthInRecibeM1v5MBienesClient",
            "token_secret": "TGR.B!3nE81",
            "token_scope": "/RecibeM1Seg/RecibeM1WS.jws*",
            "token_grant": "client_credentials",
            "host": "https://wstest.tesoreria.cl/RecibeM1Seg/RecibeM1WS.jws",
            "user": "monitoreo",
            "pass": "monitoreo"
        }));

module.exports = mocks;
