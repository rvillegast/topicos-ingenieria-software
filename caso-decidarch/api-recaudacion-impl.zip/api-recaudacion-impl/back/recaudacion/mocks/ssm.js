process.env.BILLETERA_PATH = '/api-billetera-path';
process.env.BILLETERA_INTERNA_PATH = '/api-billetera-path';

const mocks = (nock, hostname) =>
    nock(hostname)
        .persist()
        .post('/')
        .reply(200, JSON.stringify({
            Parameters: [
                {
                    Name: '/tgr/lab/api-recaudacion/back/wallet/api-billetera-interna-path',
                    Value: process.env.BILLETERA_INTERNA_PATH
                },
                {
                    Name: '/tgr/lab/api-recaudacion/back/wallet/api-billetera-path',
                    Value: process.env.BILLETERA_PATH
                },
                {
                    Name: '/tgr/lab/api-recaudacion/back/wallet/service-host',
                    Value: 'api-billetera.tgr.cl'
                }
            ]
        }));

module.exports = mocks;
