const mocks = (nock, hostname) =>
    nock(hostname)
        .persist()
        .post('/')
        .reply(200, JSON.stringify({
            UserPoolClient:{
                ClientName: 'institucion=CBRR,formulario=776,codigo=710'
            }
        }));

module.exports = mocks;
