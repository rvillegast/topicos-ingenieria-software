const mocks = (nock, hostname) =>
    nock(hostname)
        .persist()
        .post(`${process.env.BILLETERA_PATH}/oauth2/token`)
        .reply(200, JSON.stringify({
            access_token: 'untoken'
        }));

module.exports = mocks;
