const mocks = (nock, hostname) =>
    nock(hostname)
        .persist()
        .post(`${process.env.BILLETERA_INTERNA_PATH}/billeteras`)
        .reply(200, JSON.stringify({
            data: {
                idBilletera: 123
            }
        }));

module.exports = mocks;
