const mocks = (nock, hostname) =>
    nock(hostname)
        .persist()
        .post('/oauth2/token')
        .reply(200, JSON.stringify({
            access_token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyLCJjbGllbnRfaWQiOiJlbGNsaWVudGlkIn0.YTETzO2SfED4qivVz54zPXFe7eaGyoQFnp3OtaUEzlQ',
            token_type: 'Bearer'
        }));

module.exports = mocks;
