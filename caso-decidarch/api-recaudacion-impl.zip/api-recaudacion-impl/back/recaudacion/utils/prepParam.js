const moment = require('moment-timezone');
const generate = require('nanoid/generate');

const alphabet = '123456789';

exports.prepararParametros = function(json, config) {

    var parametros = [];
    var tipoCuenta;

    if (json.data.receptor.cuentaDeposito.tipo == 'CUENTA_CORRIENTE') {
        tipoCuenta = 1;
    }

    if (json.data.receptor.cuentaDeposito.tipo == 'CUENTA_VISTA') {
        tipoCuenta = 2;
    }

    if (json.data.receptor.cuentaDeposito.tipo == 'CUENTA_AHORRO') {
        tipoCuenta = 3;
    }

    let items = [{
            "codigo": 1,
            "valor": json.data.receptor.nombre
        }, {
            "codigo": 16,
            "valor": json.data.receptor.cuentaDeposito.numero
        },
        {
            "codigo": 17,
            "valor": tipoCuenta //1 CUENTA_CORRIENTE, 2 CUENTA_VISTA, 3 CUENTA_AHORRO
        },
        {
            "codigo": 33,
            "valor": `${json.data.receptor.rut}-${json.data.receptor.dv}`
        },
        {
            "codigo": 62,
            "valor": json.data.receptor.apellidoPaternoORazonSocial
        },
        {
            "codigo": 102,
            "valor": json.data.conceptoRecaudacion
        },
        {
            "codigo": 301,
            "valor": json.data.receptor.cuentaDeposito.nombreBanco
        },
        {
            "codigo": 10,
            "valor": json.data.receptor.cuentaDeposito.banco //codigo sbif
        }
    ];
    //CLP, UF, UTM //ya está

    if (json.data.payload) { // Agregar items opcionales al M1
        if (json.data.payload.items) {
            if (json.data.payload.items.length > 0) {
                json.data.payload.items.forEach(element => {
                    items.push({
                        "codigo": element.codigo,
                        "valor": element.valor
                    })
                });
            }
        }
    }

    var itemStr = '';
    for (let i = 0; i < items.length; i++) {
        let itm = items[i];
        itemStr = itemStr + '<open:Item>\n';
        itemStr = itemStr + '<open:Codigo>' + itm.codigo + '</open:Codigo>\n';
        itemStr = itemStr + '<open:Contenido>' + itm.valor + '</open:Contenido>\n';
        itemStr = itemStr + '</open:Item>\n';
    }

    // [0]
    parametros.push(itemStr);

    // [1]
    var callbackURL = json.data.callbackURL;
    parametros.push(callbackURL);

    // [2]
    var dataTime = moment().toISOString();
    parametros.push(dataTime);

    let idExt;

    if (json.data.id) {
        idExt = json.data.id
        parametros.push(idExt);
    }
    else {
        // [3]    
        idExt = generate(alphabet, 20); //=> "97923848177398779838"
        parametros.push(idExt);
    }

    let folio;

    if (json.data.folio) {
        folio = json.data.folio
        parametros.push(folio);
    }
    else {
        // [4]
        folio = parseInt(generate(alphabet, 10));
        parametros.push(folio);
    }

    // [5]
    var fecha = new Date();
    parametros.push(fecha);

    // [6]
    var vencimiento = fecha.getFullYear() + '-' + (fecha.getMonth() + 1) + '-' + fecha.getDate();
    parametros.push(vencimiento);

    // [7]
    var url = config.host; //'https://wstest.tesoreria.cl/RecibeM1SegDesa/RecibeM1WS.jws';
    parametros.push(url);

    // [8]
    var user = config.user; //'cca'; //'77077860';
    parametros.push(user);

    // [9]
    var pass = config.pass; //'12345678'; //'77077860';
    parametros.push(pass);

    // [10]
    let contribuyente = Object.assign({ rut: 1, dv: '9' }, json.data.contribuyente);
    parametros.push(contribuyente);

    return parametros;
}

exports.prepararParametrosCarrito = function(data, metadata, config) {

    var parametros = [];
    var tipoCuenta;

    if (data.receptor.cuentaDeposito.tipo == 'CUENTA_CORRIENTE') {
        tipoCuenta = 1;
    }

    if (data.receptor.cuentaDeposito.tipo == 'CUENTA_VISTA') {
        tipoCuenta = 2;
    }

    if (data.receptor.cuentaDeposito.tipo == 'CUENTA_AHORRO') {
        tipoCuenta = 3;
    }

    let items = [{
            "codigo": 1,
            "valor": data.receptor.nombre
        }, {
            "codigo": 16,
            "valor": data.receptor.cuentaDeposito.numero
        },
        {
            "codigo": 17,
            "valor": tipoCuenta //1 CUENTA_CORRIENTE, 2 CUENTA_VISTA, 3 CUENTA_AHORRO
        },
        {
            "codigo": 33,
            "valor": `${data.receptor.rut}-${data.receptor.dv}`
        },
        {
            "codigo": 62,
            "valor": data.receptor.apellidoPaternoORazonSocial
        },
        {
            "codigo": 102,
            "valor": data.conceptoRecaudacion
        },
        {
            "codigo": 301,
            "valor": data.receptor.cuentaDeposito.nombreBanco
        },
        {
            "codigo": 10,
            "valor": data.receptor.cuentaDeposito.banco //codigo sbif
        }
    ];
    //CLP, UF, UTM //ya está

    if (data.payload) { // Agregar items opcionales al M1
        if (data.payload.items) {
            if (data.payload.items.length > 0) {
                data.payload.items.forEach(element => {
                    items.push({
                        "codigo": element.codigo,
                        "valor": element.valor
                    })
                });
            }
        }
    }

    var itemStr = '';
    for (let i = 0; i < items.length; i++) {
        let itm = items[i];
        itemStr = itemStr + '<open:Item>\n';
        itemStr = itemStr + '<open:Codigo>' + itm.codigo + '</open:Codigo>\n';
        itemStr = itemStr + '<open:Contenido>' + itm.valor + '</open:Contenido>\n';
        itemStr = itemStr + '</open:Item>\n';
    }

    // [0]
    parametros.push(itemStr);

    // [1]
    var callbackURL = metadata.callbackURL;
    parametros.push(callbackURL);

    // [2]
    var dataTime = moment().toISOString();
    parametros.push(dataTime);

    let idExt;

    if (data.id) {
        idExt = data.id
        parametros.push(idExt);
    }
    else {
        // [3]    
        idExt = generate(alphabet, 20); //=> "97923848177398779838"
        parametros.push(idExt);
    }

    let folio;

    if (data.folio) {
        folio = data.folio
        parametros.push(folio);
    }
    else {
        // [4]
        folio = parseInt(generate(alphabet, 10));
        parametros.push(folio);
    }

    // [5]
    var fecha = new Date();
    parametros.push(fecha);

    // [6]
    var vencimiento = fecha.getFullYear() + '-' + (fecha.getMonth() + 1) + '-' + fecha.getDate();
    parametros.push(vencimiento);

    // [7]
    var url = config.host; //'https://wstest.tesoreria.cl/RecibeM1SegDesa/RecibeM1WS.jws';
    parametros.push(url);

    // [8]
    var user = config.user; //'cca'; //'77077860';
    parametros.push(user);

    // [9]
    var pass = config.pass; //'12345678'; //'77077860';
    parametros.push(pass);

    // [10]
    let contribuyente = Object.assign({ rut: 1, dv: '9' }, metadata.contribuyente);
    parametros.push(contribuyente);

    return parametros;
}

// Obtener parametros a ocupar en las funciones.

exports.prepararParametrosV2 = function(json, config) {

    var parametros = [];

    let items = [{
        "codigo": 102,
        "valor": json.data.conceptoRecaudacion
    }];
    //CLP, UF, UTM //ya está

    if (json.data.payload) { // Agregar items opcionales al M1
        if (json.data.payload.items) {
            if (json.data.payload.items.length > 0) {
                json.data.payload.items.forEach(element => {
                    items.push({
                        "codigo": element.codigo,
                        "valor": element.valor
                    })
                });
            }
        }
    }

    var itemStr = '';
    for (let i = 0; i < items.length; i++) {
        let itm = items[i];
        itemStr = itemStr + '<open:Item>\n';
        itemStr = itemStr + '<open:Codigo>' + itm.codigo + '</open:Codigo>\n';
        itemStr = itemStr + '<open:Contenido>' + itm.valor + '</open:Contenido>\n';
        itemStr = itemStr + '</open:Item>\n';
    }

    // [0]
    parametros.push(itemStr);

    // [1]
    var callbackURL = json.data.callbackURL;
    parametros.push(callbackURL);

    // [2]
    var dataTime = moment().toISOString();
    parametros.push(dataTime);

    let idExt;

    if (json.data.id) {
        idExt = json.data.id
        parametros.push(idExt);
    }
    else {
        // [3]    
        idExt = generate(alphabet, 20); //=> "97923848177398779838"
        parametros.push(idExt);
    }

    let folio;

    if (json.data.folio) {
        folio = json.data.folio
        parametros.push(folio);
    }
    else {
        // [4]
        folio = parseInt(generate(alphabet, 10));
        parametros.push(folio);
    }

    // [5]
    var fecha = new Date();
    parametros.push(fecha);

    // [6]
    var vencimiento = fecha.getFullYear() + '-' + (fecha.getMonth() + 1) + '-' + fecha.getDate();
    parametros.push(vencimiento);

    // [7]
    var url = config.host; //'https://wstest.tesoreria.cl/RecibeM1SegDesa/RecibeM1WS.jws';
    parametros.push(url);

    // [8]
    var user = config.user; //'cca'; //'77077860';
    parametros.push(user);

    // [9]
    var pass = config.pass; //'12345678'; //'77077860';
    parametros.push(pass);

    // [10]
    let contribuyente = Object.assign({ rut: 1, dv: '9' }, json.data.contribuyente);
    parametros.push(contribuyente);

    return parametros;
}

exports.prepararParametrosV2Carrito = function(data, config, metadata) {

    var parametros = [];

    let items = [{
        "codigo": 102,
        "valor": data.conceptoRecaudacion
    }];
    //CLP, UF, UTM //ya está

    if (data.payload) { // Agregar items opcionales al M1
        if (data.payload.items) {
            if (data.payload.items.length > 0) {
                data.payload.items.forEach(element => {
                    items.push({
                        "codigo": element.codigo,
                        "valor": element.valor
                    })
                });
            }
        }
    }

    var itemStr = '';
    for (let i = 0; i < items.length; i++) {
        let itm = items[i];
        itemStr = itemStr + '<open:Item>\n';
        itemStr = itemStr + '<open:Codigo>' + itm.codigo + '</open:Codigo>\n';
        itemStr = itemStr + '<open:Contenido>' + itm.valor + '</open:Contenido>\n';
        itemStr = itemStr + '</open:Item>\n';
    }

    // [0]
    parametros.push(itemStr);

    // [1]
    var callbackURL = metadata.callbackURL;
    parametros.push(callbackURL);

    // [2]
    var dataTime = moment().toISOString();
    parametros.push(dataTime);

    let idExt;

    if (data.id) {
        idExt = data.id
        parametros.push(idExt);
    }
    else {
        // [3]    
        idExt = generate(alphabet, 20); //=> "97923848177398779838"
        parametros.push(idExt);
    }

    let folio;

    if (data.folio) {
        folio = data.folio
        parametros.push(folio);
    }
    else {
        // [4]
        folio = parseInt(generate(alphabet, 10));
        parametros.push(folio);
    }

    // [5]
    var fecha = new Date();
    parametros.push(fecha);

    // [6]
    var vencimiento = fecha.getFullYear() + '-' + (fecha.getMonth() + 1) + '-' + fecha.getDate();
    parametros.push(vencimiento);

    // [7]
    var url = config.host; //'https://wstest.tesoreria.cl/RecibeM1SegDesa/RecibeM1WS.jws';
    parametros.push(url);

    // [8]
    var user = config.user; //'cca'; //'77077860';
    parametros.push(user);

    // [9]
    var pass = config.pass; //'12345678'; //'77077860';
    parametros.push(pass);

    // [10]
    let contribuyente = Object.assign({ rut: 1, dv: '9' }, metadata.contribuyente);
    parametros.push(contribuyente);

    return parametros;
}

exports.generarIdExterno = function(data, config, metadata) {
    let idExt;
    idExt = generate(alphabet, 20); //=> "97923848177398779838"
    return idExt;
}
