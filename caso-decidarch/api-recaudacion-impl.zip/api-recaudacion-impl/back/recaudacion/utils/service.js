const https = require('https');
const _ = require('lodash');
const token = require('./tokenBilletera');

exports.post = async function(data) {
    let resp;
    try {

        let access_token = await token.obtenerToken(data.token);
        let path = data.request.path;
        let host = data.request.host;

        let method = data.method;
        resp = await httpRequest(host, path, access_token, method, data.request.body);

        if (resp.statusCode == 200) {
            resp.statusCode = 200;
        }

    }
    catch (e) {
        console.error("[error] request: " + e);
        resp = { statusCode: 400, content: { errors: { message: "Error" } } };
    }

    return resp;
};


function httpRequest(host, path, token, method, body) {
    const bodyString = body ? JSON.stringify(body) : "";

    return new Promise((resolve, reject) => {

        let options = {
            hostname: host,
            port: 443,
            path: path,
            method: method,
            headers: {
                'Content-Type': body
                  ? "application/json"
                  : 'application/x-www-form-urlencoded;charset=utf-8',
                'Authorization': 'Bearer ' + token,
                ...(body ? {"Content-Length": Buffer.byteLength(bodyString)} : {})
            }
        };

        let respuesta = '';
        let req = https.request(options, (res) => {

            res.on('data', (d) => {
                respuesta += d;
            });

            res.on('end', () => {
                try {
                    if (JSON.parse(respuesta) != null) {
                        resolve(JSON.parse(respuesta));
                    }
                }
                catch (error) {
                    console.log("error al generar token :" + error);
                    reject(error);
                }

            });
        });

        req.on('error', (e) => {
            console.error(e);
            reject(e);
        });

        if (body) {
            req.write(bodyString);
        }
        req.end();
    });
}

exports.postObj = async function(data) {
    let resp;
    try {
        let req = data.request.body;
        let access_token = await token.obtenerTokenAutoservicio(data.token);
        let path = data.request.path;
        let host = data.request.host;
        let method = data.method;
        resp = await httpRequestObj(host, path, access_token, method, req);

        if (resp.statusCode == 200) {
            resp.statusCode = 200;
        }
    }
    catch (e) {
        console.error("[error] request: " + e);
        resp = { statusCode: 400, content: { errors: { message: "Error" } } };
    }
    return resp;
};

exports.postGenerico = async function(data) {
    let resp;
    try {
        let req = data.request.body;
        let access_token = await token.obtenerTokenAutoservicio(data.token);
        let path = data.request.path;
        let host = data.request.host;
        let method = data.method;
        resp = await httpRequestGenerico(host, path, access_token, method, req);

        if (resp.statusCode == 200) {
            resp.statusCode = 200;
        }
    }
    catch (e) {
        console.error("[error] request: " + e);
        resp = { statusCode: 400, content: { errors: { message: "Error" } } };
    }
    return resp;
};


function httpRequestObj(host, path, token, method, obj) {

    let postData = JSON.stringify(obj);
    let options = {
        hostname: host,
        port: 443,
        path: path,
        method: method,
        headers: {
            'Authorization': token,
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(postData)
        }
    };
    let respuesta = "";
    return new Promise((resolve, reject) => {
        let req = https.request(options, (res) => {
            res.on('data', (d) => {
                respuesta += d;
            });

            res.on('end', () => {
                try {
                    resolve("OK");
                }
                catch (error) {
                    console.log("error al llamar al servicio :" + error);
                    reject(error);
                }

            });
        });
        req.on('error', (e) => {
            console.error(e);
            reject(e);
        });
        req.write(postData);
        req.end();
    });
}

function httpRequestGenerico(host, path, token, method, obj) {

    let postData = JSON.stringify(obj);
    //console.log("httpRequestGenerico postData: "+postData);
    let options = {
        hostname: host,
        port: 443,
        path: path,
        method: method,
        headers: {
            'Authorization': 'Bearer '+token,
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(postData)
        }
    };
    //console.log("httpRequestGenerico options: "+JSON.stringify(options));
    let respuesta = "";
    return new Promise((resolve, reject) => {
        let req = https.request(options, (res) => {
            res.on('data', (d) => {
                respuesta += d;
            });

            res.on('end', () => {
                try {
                    resolve(JSON.parse(respuesta));
                }
                catch (error) {
                    console.log("error al llamar al servicio :" + error);
                    reject(error);
                }

            });
        });
        req.on('error', (e) => {
            console.error(e);
            reject(e);
        });
        req.write(postData);
        req.end();
    });
}
