'use strict';
const https = require('https');

exports.obtenerToken = (data) => {
    return new Promise((resolve, reject) => {
        let postData = new URLSearchParams(data.credentials).toString();
        let options = {
            hostname: data.host,
            port: 443,
            path: data.path + '/oauth2/token',
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
                'Content-Length': Buffer.byteLength(postData)
            }
        };

        let respuesta = '';
        let req = https.request(options, (res) => {

            res.on('data', (d) => {
                respuesta += d;
            });

            res.on('end', () => {
                try {
                    if (JSON.parse(respuesta).access_token != null) {
                        resolve(JSON.parse(respuesta).access_token);
                    }
                }
                catch (error) {
                    console.log("error al generar token :" + error);
                    console.log("clientId:" + postData.clienteId, "scope:" + postData.scope);
                    reject(error);
                }
            });
        });

        req.write(postData);
        req.on('error', (e) => {
            console.error(e);
            reject(e);
        });
        req.end();
    });
}

exports.obtenerTokenAutoservicio = (data) => {
    return new Promise((resolve, reject) => {
        let postData = new URLSearchParams(data.credentials).toString();
        //console.log("obtenerTokenAutoservicio postData: "+JSON.stringify(postData));
        let options = {
            hostname: data.host,
            port: 443,
            path: data.path,
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
                'Content-Length': Buffer.byteLength(postData)
            }
        };
        //console.log("obtenerTokenAutoservicio options: "+JSON.stringify(options));
        let respuesta = '';
        let req = https.request(options, (res) => {
            //console.log(`STATUS: ${res.statusCode}`);
            //console.log(`HEADERS: ${JSON.stringify(res.headers)}`);
            res.on('data', (d) => {
                respuesta += d;
            });
            res.on('end', () => {
                try {
                    if (JSON.parse(respuesta).access_token != null) {
                        resolve(JSON.parse(respuesta).access_token);
                    }
                }
                catch (error) {
                    console.log("error al generar token :" + error);
                    console.log("clientId:" + postData.clienteId, "scope:" + postData.scope);
                    reject(error);
                }
            });
        });
        req.write(postData);
        req.on('error', (e) => {
            console.log(e);
            console.error(e);
            reject(e);
        });
        req.end();
    });
}
