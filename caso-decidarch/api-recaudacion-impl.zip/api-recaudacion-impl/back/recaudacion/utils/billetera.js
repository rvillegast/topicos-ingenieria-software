const Services = require('./service');
const Utils = require('./util');

exports.crearBilletera = (nemoInstitucion) => {
    return new Promise(async(resolve, reject) => {
        let walletParameters = await Utils.getParametrosSSM(`/tgr/${process.env.ENV}/api-recaudacion/back/`);
        let path = walletParameters.get('wallet/api-billetera-interna-path');
        let pathToken = walletParameters.get('wallet/api-billetera-path');
        var host = walletParameters.get('wallet/service-host');
        let data = {
            request: {
                path: path + '/billeteras',
                ...(nemoInstitucion ? { body: {institucion: nemoInstitucion} } : {})
            },
            token: {
                host,
                path: pathToken,
                credentials: {
                    grant_type: 'client_credentials',
                    client_id: walletParameters.get('wallet/client-id-billetera'),
                    client_secret: walletParameters.get('wallet/client-secret-billetera'),
                    scope: walletParameters.get('wallet/scope-billetera')
                }
            },
            method: 'POST'
        }
        data.request.host = host;
        let response = await Services.post(data);
        resolve(response.data.idBilletera);
    });
}

exports.buscarBilletera = (idBilletera) => {
    return new Promise(async(resolve, reject) => {
        let walletParameters = await Utils.getParametrosSSM(`/tgr/${process.env.ENV}/api-recaudacion/back/`);
        let path = walletParameters.get('wallet/api-billetera-path');
        var host = walletParameters.get('wallet/service-host');
        let data = {
            request: {
                path: path + '/billeteras/' + idBilletera + '/saldos'
            },
            token: {
                host,
                path,
                credentials: {
                    grant_type: 'client_credentials',
                    client_id: walletParameters.get('wallet/client-id-billetera'),
                    client_secret: walletParameters.get('wallet/client-secret-billetera'),
                    scope: walletParameters.get('wallet/scope-billetera')
                }
            },
            method: 'GET'
        }
        data.request.host = host;
        let response = await Services.post(data);
        resolve(response);
    });
}

exports.crearBilleteraInstitucion = (idBilletera, nemoInstitucion) => {
    return new Promise(async(resolve, reject) => {
        let walletParameters = await Utils.getParametrosSSM(`/tgr/${process.env.ENV}/api-recaudacion/back/`);
        let path = walletParameters.get('api-autoservicio/path-service');
        let pathToken = walletParameters.get('api-autoservicio/token-path-service');
        let host = walletParameters.get('api-autoservicio/host-service');
        let hostToken = walletParameters.get('api-autoservicio/token-host-service');
        let body = {
            data: {
                billetera: idBilletera,
                institucion: nemoInstitucion
            }
        }
        let data = {
            request: {
                path: path + '/billetera',
                body
            },
            token: {
                host: hostToken,
                path: pathToken,
                credentials: {
                    grant_type: 'client_credentials',
                    client_id: walletParameters.get('api-autoservicio/client-id'),
                    client_secret: walletParameters.get('api-autoservicio/client-secret'),
                    scope: walletParameters.get('api-autoservicio/scope')
                }
            },
            method: 'POST'
        }
        data.request.host = host;
        await Services.postObj(data);
        resolve("OK");
    });
}
