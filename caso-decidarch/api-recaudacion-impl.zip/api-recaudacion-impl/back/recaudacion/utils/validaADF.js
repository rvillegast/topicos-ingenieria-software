const Services = require('./service');
const Utils = require('./util');
exports.validaADF = (contextAdf,usuario, items) => {
    return new Promise(async(resolve, reject) => {
        let walletParameters = await Utils.getParametrosSSM(`/tgr/${process.env.ENV}/api-recaudacion/back/`);
        let path = walletParameters.get('valida-adf-path-service');
        let pathToken ='/oauth2/token';
        let host = walletParameters.get('test-host-service');
        let hostToken = walletParameters.get('test-token-host-service');
        let body = {
            data: {
                contextAdf,
                usuario,
                items
            }
        }
        let data = {
            request: {
                path,
                body
            },
            token: {
                host: hostToken,
                path: pathToken,
                credentials: {
                    grant_type: 'client_credentials',
                    client_id: walletParameters.get('valida-adf-client-id'),
                    client_secret: walletParameters.get('valida-adf-client-secret'),
                    scope: walletParameters.get('valida-adf-scope') 
                }
            },
            method: 'PATCH'
        }
        data.request.host = host;
        let response = await Services.postGenerico(data);
        resolve(response);
    });
}