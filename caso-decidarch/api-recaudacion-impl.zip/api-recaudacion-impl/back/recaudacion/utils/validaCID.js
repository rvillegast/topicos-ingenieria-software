'use strict';

const moment = require('moment-timezone');
const z = require('zod'); // Instalar ZOD

const CLP = "CLP";
const CID_DATE_FORMAT = "YYMMDD"; // aammdd


const validations = {
    tramite: async (tramite, detalleConcepto) => z.object({
        idTramite: z.number('El campo "idTramite" es requerido para la operación.'),
        conceptoRecaudacion: z.string('El concepto es requerido para la operación.'),
        recaudacion: z.object({
            cid: z.string('El CID debe ser varchar.').length(26, "El CID debe de tener un largo de 26."),
            moneda: z.literal(CLP, "La moneda debe ser CLP."),
            monto: z.number()
        })
    }).superRefine((tramite, ctx) => {
            validations.addIssue(tramite, detalleConcepto, ctx);
        }).safeParse(tramite),
    addIssue: (tramite, detalleConcepto, ctx) => {
        let path = [];
        let message = [];
        //Siempre que exista el CID, debe tener asociado el concepto que corresponda al formulario 18
        //Siempre que exista el concepto que corresponda al formulario 18, debe tener CID

        //Validación de formulario y concepto
        let formulario = tramite.recaudacion.cid.substr(19 - 1, 3);
        if (detalleConcepto.formulario && detalleConcepto.formulario === '18' && !formulario.includes(detalleConcepto.formulario)) {
            path.push('formulario invalido');
            message.push('El CID no pertenece al concepto de recaudación declarado.');
        }

        //En este punto CID existe
        //Validación vigencia
        let fecha_cid_string = tramite.recaudacion.cid.substr(13 - 1, 6);
        // let fecha_cid_string = '260114';
        if (validations.vigenciaCid(fecha_cid_string)) {
            path.push('cid vencido');
            message.push('El CID no se encuentra vigente.');
        }

        for (const msg of message) {
            ctx.addIssue({
                code: z.ZodIssueCode.custom,
                message: msg,
                path: path,
                params: {
                    code: '400'
                }
            });
        }
    },
    vigenciaCid: (fecha_cid_string) => {
        let fecha_cid = moment(fecha_cid_string, CID_DATE_FORMAT).startOf('day');
        let fecha_actual = moment().startOf('day');
        return fecha_cid.isBefore(fecha_actual); // Permite pagar HASTA el día indicado por fecha_cid
    }
}

exports.validaCID = async function cidValidator(tramite, detalleConcepto) {
    console.log("init validator");
    try {
        let is_validado = validations.tramite(tramite, detalleConcepto);
        console.log('end validator without errors')
        return is_validado;
    } catch (err) {
        if (err instanceof z.ZodError) {
            console.error(err.issues.map(err => err.message));
            console.log('ZodError validator')
            throw z.ZodError();
        }
        console.log(err)
        console.log('error validator')
        throw err;
    }
}
