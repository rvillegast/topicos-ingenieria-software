const callAdf = require("./validaADF");

exports.validaADF = async function(parametros, json, modeloCut, formulario, girador, modeloEgreso) {
    //console.log("Valida ADF json: "+ JSON.stringify(json));
    console.log("Valida ADF modeloCut: " + modeloCut);
    let rut;
    if (json.data.contribuyente) {
        rut = json.data.contribuyente.rut + "-" + json.data.contribuyente.dv;
    }
    else {
        rut = "1-9";
    }

    let fecha = parametros[6].split("-");
    if (Number(fecha[1] < 10)) {
        fecha[1] = "0" + fecha[1];
    }
    if (Number(fecha[2] < 10)) {
        fecha[2] = "0" + fecha[2];
    }
    let fechaVcto = fecha[2] + "-" + fecha[1] + "-" + fecha[0];
    let items = [{
            "codigo": 3,
            "valor": rut
        }, {
            "codigo": 7,
            "valor": parametros[4]
        },
        {
            "codigo": 15,
            "valor": fechaVcto
        },
        {
            "codigo": 102,
            "valor": json.data.conceptoRecaudacion
        }
    ];
    if (modeloEgreso == 'EGRESO_AUTOMATICO') {
        let rutReceptor = json.data.receptor.rut + "-" + json.data.receptor.dv;
        let tipoCuenta;

        if (json.data.receptor.cuentaDeposito.tipo == 'CUENTA_CORRIENTE') {
            tipoCuenta = 1;
        }

        if (json.data.receptor.cuentaDeposito.tipo == 'CUENTA_VISTA') {
            tipoCuenta = 2;
        }

        if (json.data.receptor.cuentaDeposito.tipo == 'CUENTA_AHORRO') {
            tipoCuenta = 3;
        }

        items.push({
            "codigo": 1,
            "valor": json.data.receptor.nombre
        }, {
            "codigo": 33,
            "valor": rutReceptor
        }, {
            "codigo": 62,
            "valor": json.data.receptor.apellidoPaternoORazonSocial
        }, {
            "codigo": 16,
            "valor": json.data.receptor.cuentaDeposito.numero
        }, {
            "codigo": 17,
            "valor": tipoCuenta
        }, {
            "codigo": 301,
            "valor": json.data.receptor.cuentaDeposito.nombreBanco
        }, {
            "codigo": 10,
            "valor": json.data.receptor.cuentaDeposito.banco
        })
    }
    if (modeloCut == 'PAYLOAD') {
        if (json.data.payload) { // Agregar items opcionales al M1
            if (json.data.payload.items) {
                if (json.data.payload.items.length > 0) {
                    json.data.payload.items.forEach(element => {
                        items.push({
                            "codigo": element.codigo,
                            "valor": element.valor
                        })
                    });
                }
            }
        }
    }
    else if (modeloCut == 'NO_CUT') {
        //No se hace nada
    }
    else {
        items.push({
            "codigo": modeloCut,
            "valor": json.data.recaudacion.monto
        })
    }
    let contextAdf = {
        "formVer": "A",
        "formCod": formulario,
        "traceLvl": 3,
        "fechaCaja": json.metadata.sentDate,
        "montoPoc": json.data.recaudacion.monto,
        "monedaDeclara": json.data.recaudacion.moneda,
        "tipoOperacion": "API_RECAUD"
    }
    console.log("Context ADF: " + JSON.stringify(contextAdf));
    console.log("Items para Valida ADF: " + JSON.stringify(items));
    return await callAdf.validaADF(contextAdf, "TGR", items)
}

exports.validaADFCarrito = async function(parametros, data, modeloCut, formulario, girador, modeloEgreso, metadata) {

    console.log("Valida ADF modeloCut: " + modeloCut);
    let rut;
    if (metadata.contribuyente) {
        rut = metadata.contribuyente.rut + "-" + metadata.contribuyente.dv;
    }
    else {
        rut = "1-9";
    }

    let fecha = parametros[6].split("-");
    if (Number(fecha[1] < 10)) {
        fecha[1] = "0" + fecha[1];
    }
    if (Number(fecha[2] < 10)) {
        fecha[2] = "0" + fecha[2];
    }
    let fechaVcto = fecha[2] + "-" + fecha[1] + "-" + fecha[0];
    let items = [{
            "codigo": 3,
            "valor": rut
        }, {
            "codigo": 7,
            "valor": parametros[4]
        },
        {
            "codigo": 15,
            "valor": fechaVcto
        },
        {
            "codigo": 102,
            "valor": data.conceptoRecaudacion
        }
    ];
    if (modeloEgreso == 'EGRESO_AUTOMATICO') {
        let rutReceptor = data.receptor.rut + "-" + data.receptor.dv;
        let tipoCuenta;

        if (data.receptor.cuentaDeposito.tipo == 'CUENTA_CORRIENTE') {
            tipoCuenta = 1;
        }

        if (data.receptor.cuentaDeposito.tipo == 'CUENTA_VISTA') {
            tipoCuenta = 2;
        }

        if (data.receptor.cuentaDeposito.tipo == 'CUENTA_AHORRO') {
            tipoCuenta = 3;
        }

        items.push({
            "codigo": 1,
            "valor": data.receptor.nombre
        }, {
            "codigo": 33,
            "valor": rutReceptor
        }, {
            "codigo": 62,
            "valor": data.receptor.apellidoPaternoORazonSocial
        }, {
            "codigo": 16,
            "valor": data.receptor.cuentaDeposito.numero
        }, {
            "codigo": 17,
            "valor": tipoCuenta
        }, {
            "codigo": 301,
            "valor": data.receptor.cuentaDeposito.nombreBanco
        }, {
            "codigo": 10,
            "valor": data.receptor.cuentaDeposito.banco
        })
    }
    if (modeloCut == 'PAYLOAD') {
        if (data.payload) { // Agregar items opcionales al M1
            if (data.payload.items) {
                if (data.payload.items.length > 0) {
                    data.payload.items.forEach(element => {
                        items.push({
                            "codigo": element.codigo,
                            "valor": element.valor
                        })
                    });
                }
            }
        }
    }
    else if (modeloCut == 'NO_CUT') {
        //No se hace nada
    }
    else {
        items.push({
            "codigo": modeloCut,
            "valor": data.recaudacion.monto
        })
    }
    let contextAdf = {
        "formVer": "A",
        "formCod": formulario,
        "traceLvl": 3,
        "fechaCaja": metadata.sentDate,
        "montoPoc": data.recaudacion.monto,
        "monedaDeclara": data.recaudacion.moneda,
        "tipoOperacion": "API_RECAUD"
    }
    console.log("Context ADF: " + JSON.stringify(contextAdf));
    console.log("Items para Valida ADF: " + JSON.stringify(items));
    return await callAdf.validaADF(contextAdf, "TGR", items)

}
