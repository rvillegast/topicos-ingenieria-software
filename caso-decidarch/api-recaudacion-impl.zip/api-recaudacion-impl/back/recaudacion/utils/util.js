const AWS = require('aws-sdk');
AWS.config.update({
    region: "us-east-1"
});

const parameterStore = new AWS.SSM();
// const NodeCache = require("node-cache");
// const parametrosSSMCache = new NodeCache();
let parametrosSSMCache = {};

exports.getParametrosSSM = async(prefix) => {

    if (parametrosSSMCache['key']) {
        console.log('Utilizando cache parametrosSSMCache para obtener datos');
        //return Promise.resolve(parametrosSSMCache.get('key'));
        return Promise.resolve(parametrosSSMCache['key']);
    }
    else {

        let token = null;
        let map = new Map();

        return new Promise(async(resolve, reject) => {

            let result = await getAllParameters(prefix, token);

            for (let item of result.Parameters) {
                map.set(item.Name.replace(prefix, ''), item.Value);
            }

            token = result.NextToken;

            while (token != undefined) {
                let resultNext = await getAllParameters(prefix, token);
                for (let item of resultNext.Parameters) {
                    map.set(item.Name.replace(prefix, ''), item.Value);
                }
                token = resultNext.NextToken;
            }

            console.log('Sin uso de cache parametrosSSMCache para obtener datos');
            //parametrosSSMCache.set('key', map, 10000);
            parametrosSSMCache['key'] = map;
            resolve(map);
        });
    }
}

async function getAllParameters(prefix, token) {

    let params = {
        Path: prefix,
        NextToken: token,
        Recursive: true,
        WithDecryption: true
    };

    return new Promise((resolve, reject) => {

        parameterStore.getParametersByPath(params, function(err, data) {

            if (err) {
                console.log(err, err.stack); // an error occurred
                reject(err);
            }
            else {
                return resolve(data);
            }
        });
    });
}
