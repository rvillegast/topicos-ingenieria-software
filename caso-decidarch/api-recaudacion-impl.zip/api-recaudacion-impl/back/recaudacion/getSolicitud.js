'use strict';

const queryDB = require('./aws/dynamoDbServices');
const util = require("./util");

const moment = require('moment');
const tz = require('moment-timezone');

exports.handler = async(event) => {
    console.log(event);
    try {
        let id = event.pathParameters.id;
        id = `${id}`;
        let response;

        let { institucion } = await util.getDataFromToken(event.headers.Authorization);
        console.log(institucion);

        let params = {
            TableName: `${process.env.PREFIX}-eventos`,
            IndexName: `${process.env.PREFIX}-ids-idx`,
            ExpressionAttributeValues: {
                ':pk': institucion,
                ':id': id
            },
            KeyConditionExpression: "institucion = :pk and begins_with(id, :id)"
        };

        console.log("params: ", params);
        let results = await queryDB.getItems(params);
        console.log("results: ", results);
        console.log("results length: ", results.length);

        let resultsRecibidas = results.filter(element => element.nombreEstado === 'RECIBIDA');

        if (results.length == 0) {
            response = {
                statusCode: 404,
                body: JSON.stringify({
                    errors: [
                        { message: "Recurso no existe" }
                    ]
                })
            };
            console.log("response: ", response);
            return response
        }

        if (institucion === 'MOP') {
            console.log('Mostrar sin cambios a MOP');

            let result;
            let resp;

            if (resultsRecibidas.length == 0) {
                resp = { data: getResponseItemMOP(results[0]) };
            }
            else if (results.length == 1) {
                resp = { data: getResponseItemMOP(results[0]) };
            }
            else if (results.length > 1 && results.length <= 2 && results[0].nombreEstado != results[1].nombreEstado) {

                result = results.find(element => element.nombreEstado === 'PAGO_CONFIRMADO');
                resp = { data: getResponseItemMOP(result) };
            }
            else if (results.length > 1 && results.length <= 2 && results[0].nombreEstado === results[1].nombreEstado) {
                resp = {
                    data: getResponseItemsCarrito(results)
                };
            }
            else if (results.length > 2 && resultsRecibidas.length == 1) {
                let newItems = results.filter((item) => {
                    return item.nombreEstado === 'PAGO_CONFIRMADO';
                })
                resp = {
                    data: getResponseItemMOP(newItems[0])
                };
            }
            else {
                resp = { data: getResponseItemsCarritoMOP(results) }
            }

            response = {
                statusCode: 200,
                body: JSON.stringify(resp)
            };

            console.log("response: ", response);
            return response;
        }
        else {

            let result;
            let resp;
            let data = []

            if (resultsRecibidas.length == 0) {
                resp = { data: getResponseItem(results[0]) };
            }
            else if (results.length == 1) {
                resp = { data: getResponseItem(results[0]) };
            }
            else if (results.length > 1 && results.length <= 2 && results[0].nombreEstado != results[1].nombreEstado) {

                result = results.find(element => element.nombreEstado === 'PAGO_CONFIRMADO');
                resp = { data: getResponseItem(result) };
            }
            else if (results.length > 1 && results.length <= 2 && results[0].nombreEstado === results[1].nombreEstado) {

                resp = {
                    data: getResponseItemsCarrito(results)
                };
            }
            else if (results.length > 2 && resultsRecibidas.length == 1) {
                let newItems = results.filter((item) => {
                    return item.nombreEstado === 'PAGO_CONFIRMADO';
                })

                resp = {
                    data: getResponseItem(newItems[0])
                };
            }
            else {
                resp = {
                    data: getResponseItemsCarrito(results)
                };
            }

            response = {
                statusCode: 200,
                body: JSON.stringify(resp)
            };

            console.log("response: ", response);
            return response;
        }
    }
    catch (e) {
        console.log(e);

        let response = {
            statusCode: 400,
            body: JSON.stringify(e)
        };

        return response;
    }
};

function getResponseItem(item) {
    console.log('Flujo Unitario');
    let id;

    // Si es de tipo carrito mostrar id # idTramite
    if (item.id.split('#').length > 2) {
        id = item.id.split('#')[0] + '#' + item.id.split('#')[1]
    }
    // Si no mostrar solo id
    else {
        id = item.id.split('#')[0]
    }

    if (item.nombreEstado === 'RECIBIDA') {
        return {
            "fechaEvento": item.fechaEvento,
            "solicitud": {
                "id": id
            },
            "estado": {
                "nombreEstado": item.nombreEstado,
                "fechaEstado": item.fechaEvento
            }
        }
    }
    else {
        return {
            "fechaEvento": item.fechaEvento,
            "solicitud": {
                "id": id
            },
            "estado": {
                "nombreEstado": item.nombreEstado,
                "fechaEstado": item.payload.Message.Confirmacion.Pago.FechaPago,
                "medioPago": {
                    "nombreIra": item.payload.Message.Confirmacion.Pago.Ira.Nombre,
                    "codigoIra": item.payload.Message.Confirmacion.Pago.Ira.Codigo
                }
            }
        }
    }
}

function getResponseItemsCarrito(items = []) {
    console.log('Flujo Carrito');

    let newItems = items.filter((item, index) => {
        return item.nombreEstado === 'PAGO_CONFIRMADO';
    })

    let objFinal = [];
    let objIndividual;

    console.log('newItems: ', newItems);

    // Si existen pagos confirmados mostrar solo pagos confirmados.
    if (newItems.length != 0) {
        for (let i = 0; i < newItems.length; i++) {

            let id;

            // Si es de tipo carrito mostrar id # id tramite
            if (newItems[i].id.split('#').length > 2) {
                id = newItems[i].id.split('#')[0] + '#' + newItems[i].id.split('#')[1]
            }
            // Si no mostrar solo id ya que anteriormente existian carritos solo idExt#idTramite
            else {
                id = newItems[i].id
            }

            objIndividual = {
                "fechaEvento": newItems[i].fechaEvento,
                "solicitud": {
                    "id": id
                },
                "estado": {
                    "nombreEstado": newItems[i].nombreEstado,
                    "fechaEstado": newItems[i].payload.Message.Confirmacion.Pago.FechaPago,
                    "medioPago": {
                        "nombreIra": newItems[i].payload.Message.Confirmacion.Pago.Ira.Nombre,
                        "codigoIra": newItems[i].payload.Message.Confirmacion.Pago.Ira.Codigo
                    }
                }
            }

            objFinal.push(objIndividual);
        }
    }
    // Si no mostrar solicitudes recibidas.
    else {
        for (let i = 0; i < items.length; i++) {

            let id;
            if (items[i].id.split('#').length >= 3) {
                id = items[i].id.split('#')[0] + '#' + items[i].id.split('#')[1]
            }
            else {
                id = items[i].id
            }

            objIndividual = {
                "fechaEvento": items[i].fechaEvento,
                "solicitud": {
                    "id": id
                },
                "estado": {
                    "nombreEstado": items[i].nombreEstado,
                    "fechaEstado": items[i].fechaEvento
                }
            }
            objFinal.push(objIndividual);
        }
    }
    return objFinal;
}

// TODO TD-019: Cuando DGA tenga presupuesto para que un programador configure la recepcion de un arreglo de datos y la fecha en formato correcto, borrar las siguientes 
// dos funciones.

function getResponseItemMOP(item) {
    console.log('Flujo Unitario MOP');
    let id;
    let fechaPago;

    // Si es de tipo carrito mostrar id # idTramite
    if (item.id.split('#').length > 2) {
        id = item.id.split('#')[0] + '#' + item.id.split('#')[1]
    }
    // Si no mostrar solo id
    else {
        id = item.id.split('#')[0]
    }

    if (item.nombreEstado === 'RECIBIDA') {
        return {
            "fechaEvento": item.fechaEvento,
            "solicitud": {
                "id": id
            },
            "estado": {
                "nombreEstado": item.nombreEstado,
                "fechaEstado": item.fechaEvento
            }
        }
    }
    else {
        let santiago = moment.tz(new Date(item.payload.Message.Confirmacion.Pago.FechaPago), 'America/Santiago');
        fechaPago = santiago.format().substring(0, 19) + "Z";

        return {
            "fechaEvento": item.fechaEvento,
            "solicitud": {
                "id": id
            },
            "estado": {
                "nombreEstado": item.nombreEstado,
                "fechaEstado": fechaPago,
                "medioPago": {
                    "nombreIra": item.payload.Message.Confirmacion.Pago.Ira.Nombre,
                    "codigoIra": item.payload.Message.Confirmacion.Pago.Ira.Codigo
                }
            }
        }
    }
}

function getResponseItemsCarritoMOP(items = []) {
    console.log('Flujo Carrito MOP');

    let newItems = items.filter((item, index) => {
        return item.nombreEstado === 'PAGO_CONFIRMADO';
    })

    let objFinal = [];
    let objIndividual;

    console.log('newItems: ', newItems);

    // Si existen pagos confirmados mostrar solo pagos confirmados.
    if (newItems.length != 0) {
        for (let i = 0; i < newItems.length; i++) {

            let id;
            let fechaPago;

            // Si es de tipo carrito mostrar id # id tramite
            if (newItems[i].id.split('#').length > 2) {
                id = newItems[i].id.split('#')[0] + '#' + newItems[i].id.split('#')[1]
            }
            // Si no mostrar solo id ya que anteriormente existian carritos solo idExt#idTramite
            else {
                id = newItems[i].id
            }

            let santiago = moment.tz(new Date(newItems[i].payload.Message.Confirmacion.Pago.FechaPago), 'America/Santiago');
            fechaPago = santiago.format().substring(0, 19) + "Z";

            objIndividual = {
                "fechaEvento": newItems[i].fechaEvento,
                "solicitud": {
                    "id": id
                },
                "estado": {
                    "nombreEstado": newItems[i].nombreEstado,
                    "fechaEstado": fechaPago,
                    "medioPago": {
                        "nombreIra": newItems[i].payload.Message.Confirmacion.Pago.Ira.Nombre,
                        "codigoIra": newItems[i].payload.Message.Confirmacion.Pago.Ira.Codigo
                    }
                }
            }

            objFinal.push(objIndividual);
        }
    }
    // Si no mostrar solicitudes recibidas.
    else {
        for (let i = 0; i < items.length; i++) {

            let id;
            if (items[i].id.split('#').length >= 3) {
                id = items[i].id.split('#')[0] + '#' + items[i].id.split('#')[1]
            }
            else {
                id = items[i].id
            }

            objIndividual = {
                "fechaEvento": items[i].fechaEvento,
                "solicitud": {
                    "id": id
                },
                "estado": {
                    "nombreEstado": items[i].nombreEstado,
                    "fechaEstado": items[i].fechaEvento
                }
            }
            objFinal.push(objIndividual);
        }
    }

    return objFinal;
}
