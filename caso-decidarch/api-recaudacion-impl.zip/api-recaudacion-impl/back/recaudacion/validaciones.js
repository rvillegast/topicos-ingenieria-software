const _ = require('lodash');
const RUT = /^\d+$/;
const DV = /^[kK\d]$/;
const UNO_O_MAS_CUALQUIER_CARACTER = /^[^]+$/;
const NUMERO_POSITIVO = /^[1-9]\d*$/;
exports.validacionesDatos = function(data) {
    let errores = [];

    try {

        //VALIDA CONCEPTO RECAUDACIÓN NO VACÍO
        if (validaExpresion(data.conceptoRecaudacion, UNO_O_MAS_CUALQUIER_CARACTER)) {
            let e = {
                message: "El Concepto de Recaudación debe contener un valor.",
                code: 100
            };

            errores.push(e);
        }

        //VALIDA MANTISA RUT NO VACÍA
        if (validaExpresion(data.contribuyente.rut, RUT)) {
            let e = {
                message: "El RUT del Contribuyente debe contener un valor numérico.",
                code: 200
            };

            errores.push(e);
        }

        //VALIDA DV NO VACÍO
        if (validaExpresion(data.contribuyente.dv, DV)) {
            let e = {
                message: "El DV del Contribuyente debe contener un valor.",
                code: 201
            };

            errores.push(e);
        }

        //VALIDA MODEDA NO VACÍA
        if (validaExpresion(data.recaudacion.moneda, UNO_O_MAS_CUALQUIER_CARACTER)) {
            let e = {
                message: "La Moneda debe contener un valor.",
                code: 300
            };

            errores.push(e);
        }

        //VALIDA MONEDA IGUAL A CLP
        if (data.recaudacion.moneda !== 'CLP' && data.recaudacion.moneda !== 'USD') {
            let e = {
                message: "La Moneda informada no es válida",
                code: 301
            };

            errores.push(e);
        }

        //VALIDA MONTO ENTERO POSITIVO
        if (data.recaudacion.moneda == 'CLP'){
            if (validaExpresion(data.recaudacion.monto, NUMERO_POSITIVO)) {
                let e = {
                    message: "El Monto debe contener un valor numérico mayor a 0.",
                    code: 302
                };

                errores.push(e);
            }
        }

        //VALIDA RUT-DV
        let val = validaDv(data.contribuyente.dv, data.contribuyente.rut);
        if (val != "0") {
            let e = {
                message: "El RUT-DV del Contribuyente no es válido.",
                code: 202
            };

            errores.push(e);
        }
    }
    catch (e) {
        console.log("Errores: " + e);
    }
    return errores;

};

exports.validacionesDatosCarrito = function(data, metadata) {
    let errores = [];

    try {

        //VALIDA CONCEPTO RECAUDACIÓN NO VACÍO
        if (validaExpresion(data.conceptoRecaudacion, UNO_O_MAS_CUALQUIER_CARACTER)) {
            let e = {
                message: "El Concepto de Recaudación debe contener un valor.",
                code: 100
            };

            errores.push(e);
        }

        //VALIDA MANTISA RUT NO VACÍA
        if (validaExpresion(metadata.contribuyente.rut, RUT)) {
            let e = {
                message: "El RUT del Contribuyente debe contener un valor numérico.",
                code: 200
            };

            errores.push(e);
        }

        //VALIDA DV NO VACÍO
        if (validaExpresion(metadata.contribuyente.dv, DV)) {
            let e = {
                message: "El DV del Contribuyente debe contener un valor.",
                code: 201
            };

            errores.push(e);
        }

        //VALIDA MODEDA NO VACÍA
        if (validaExpresion(data.recaudacion.moneda, UNO_O_MAS_CUALQUIER_CARACTER)) {
            let e = {
                message: "La Moneda debe contener un valor.",
                code: 300
            };

            errores.push(e);
        }

        //VALIDA MONEDA IGUAL A CLP
        if (data.recaudacion.moneda !== 'CLP') {
            let e = {
                message: "La Moneda informada no es válida",
                code: 301
            };

            errores.push(e);
        }

        //VALIDA MONTO ENTERO POSITIVO
        if (validaExpresion(data.recaudacion.monto, NUMERO_POSITIVO)) {
            let e = {
                message: "El Monto debe contener un valor numérico mayor a 0.",
                code: 302
            };

            errores.push(e);
        }

        //VALIDA RUT-DV
        let val = validaDv(metadata.contribuyente.dv, metadata.contribuyente.rut);
        if (val != "0") {
            let e = {
                message: "El RUT-DV del Contribuyente no es válido.",
                code: 202
            };

            errores.push(e);
        }
    }
    catch (e) {
        console.log("Errores: " + e);
    }
    return errores;

};

exports.validacionesCuenta = function(data) {
    let errores = [];
    console.log("tipoCuenta: " + data.receptor.cuentaDeposito.tipo);
    if (data.receptor.cuentaDeposito.tipo !== 'CUENTA_CORRIENTE' &&
        data.receptor.cuentaDeposito.tipo !== 'CUENTA_AHORRO' &&
        data.receptor.cuentaDeposito.tipo !== 'CUENTA_VISTA') {
        let e = {
            message: "El tipo de cuenta tiene que ser: CUENTA_CORRIENTE, CUENTA_AHORRO o CUENTA_VISTA",
            code: 17000
        };
        errores.push(e);
    }
    return errores;
};

//VALIDAMOS CONCEPTO DE RECAUDACIÓN PARA LA INSTITUCION
//QUE REALIZA LA SOLICITUD DE RECAUDACIÓN
exports.validacionesConcepto = function(data, instit, concepto) {

    let bandera = data.includes(concepto, 0);
    let e = null;

    let cantidad = data.length;
    if (!bandera) { // Error de Concepto de Recaudación. No existe id Concepto
        e = {
            message: `El Concepto de Recaudación: ${concepto}, no está registrado en TGR para la institución: ${instit}. Favor configurarlo previamente`,
            code: 101
        };
    }
    return e;
};

//GENERAMOS MENSAJE DE ERROR PARA EL CASO DE NO EXISTIR
//BILLETERA INGRESADA
exports.validacionBilletera = function() {

    let e = {
        message: "El idBilletera, no está registrado en TGR. Favor configurarlo previamente.",
        code: 101
    };
    return e;
};

//VALIDAMOS QUE CONCEPTOS IGUALES, TENGAN IGUAL BILLETERA
//Y QUE UNA MISMA BILLETERA SEA PARA EL MISMO CONCEPTO
exports.validacionesConceptoBilletera = function(vecData) {
    try {
        let mapConceptos = new Map();
        let mapBilletera = new Map();
        for (let i in vecData) {
            if (vecData[i].receptor == undefined) {
                if (vecData[i].idBilletera == undefined) {
                    if (mapConceptos.get(vecData[i].conceptoRecaudacion) == undefined) {
                        mapConceptos.set(vecData[i].conceptoRecaudacion, "undefined");
                    }
                    else if (mapConceptos.get(vecData[i].conceptoRecaudacion) != "undefined") {
                        console.log("ha indicado billeteras distintas para el mismo concepto");
                        let error = {
                            statusCode: 400,
                            body: JSON.stringify({
                                mensaje: 'Error de validación',
                                concepto: vecData[i].conceptoRecaudacion,
                                idTramite: vecData[i].idTramite,
                                errores: "Un mismo concepto no puede tener distintas billeteras"
                            })
                        }
                        throw error;
                    }
                }
                else {
                    if (mapConceptos.get(vecData[i].conceptoRecaudacion) == undefined) {
                        mapConceptos.set(vecData[i].conceptoRecaudacion, vecData[i].idBilletera);
                    }
                    else if (mapConceptos.get(vecData[i].conceptoRecaudacion) != vecData[i].idBilletera) {
                        console.log("ha indicado billeteras distintas para el mismo concepto");
                        let error = {
                            statusCode: 400,
                            body: JSON.stringify({
                                mensaje: 'Error de validación',
                                concepto: vecData[i].conceptoRecaudacion,
                                idTramite: vecData[i].idTramite,
                                errores: "Un mismo concepto no puede tener distintas billeteras"
                            })
                        }
                        throw error;
                    }
                    if (mapBilletera.get(vecData[i].idBilletera) == undefined) {
                        mapBilletera.set(vecData[i].idBilletera, vecData[i].conceptoRecaudacion);
                    }
                    else if (mapBilletera.get(vecData[i].idBilletera) != vecData[i].conceptoRecaudacion) {
                        console.log("ha indicado una misma billetera para distintos conceptos");
                        let error = {
                            statusCode: 400,
                            body: JSON.stringify({
                                mensaje: 'Error de validación',
                                concepto: vecData[i].conceptoRecaudacion,
                                idTramite: vecData[i].idTramite,
                                errores: "ha indicado una misma billetera para distintos conceptos"
                            })
                        }
                        throw error;
                    }
                }
            }
        }
    }
    catch (e) {
        console.log(e);
    }
};

//VALIDAMOS QUE MONTO CARRITO SEA IGUAL A SUMA DE MONTOS DE SUBTRAMITES
exports.validacionMontoTotal = function(vecData, montoCarrito) {
    let sumaMontos = 0;
    for (let i in vecData) {
        sumaMontos += vecData[i].recaudacion.monto;
    }
    if (sumaMontos != montoCarrito) {
        let error = {
            statusCode: 400,
            body: JSON.stringify({
                errors:[ 
                    {
                        message: "La suma de monto es distinto al monto del carrito.",
                        codError: 400
                    }
                ]
            })
        }
        throw error;
    }
};

//VALIDAMOS QUE LA MONEDA DE CADA TRÁMITE SEA CLP
exports.validacionMonedaCLP = function(vecData) {
    let sumaMontos = 0;
    for (let i in vecData) {
        if( vecData[i].recaudacion.moneda.toUpperCase().localeCompare('CLP') != 0){
            let error = {
                statusCode: 400,
                body: JSON.stringify({
                    mensaje: 'Error de validación',
                    errores: "La moneda de cada trámite de ser pesos CLP"
                })
            }
            throw error;
        }
        
    }
};


// VALIDAR QUE ID TRAMITE NO SE REPITA
exports.validarIdTramiteYDv = function(json) {

    for (let i = 0; i < json.data.length; i++) {
        for (let j = 0; j < json.data.length; j++) {
            if (i != j) {
                if (json.data[i].idTramite == json.data[j].idTramite) {
                    throw {
                        statusCode: 400,
                        body: JSON.stringify({
                            mensaje: 'Error de validación',
                            concepto: json.data[j].conceptoRecaudacion,
                            idTramite: json.data[j].idTramite,
                            errores: "El idTramite debe ser unico por transacción"
                        })
                    };
                }
            }
        }
    }

    if (json.metadata.contribuyente.dv.trim() == '') {
        throw {
            statusCode: 400,
            body: JSON.stringify({
                mensaje: 'Error de validación',
                errores: "El dv del contribuyente debe tener un valor"
            })
        };
    }
}

exports.validacionesIdExt = async(id) => {

    let params = {
        TableName: `${process.env.PREFIX}-eventos`,
        ExpressionAttributeValues: {
            ":id": id,
        },
        KeyConditionExpression: "id = :id"
    };

    let items = await require("./aws/dynamoDbServices").getItems(params);

    if (items.length > 0) {
        let error = {
            statusCode: 400,
            body: JSON.stringify({
                mensaje: 'Error de validación',
                errores: `El id (IdExt): ${id}, se encuentra duplicado. Favor ingresar un id diferente`
            })
        }

        throw error;
    }
    return true;
};

function validaExpresion(campo, expresion) {
    return !expresion.test(campo);
}

function validaDv(dv, rut) {

    rut = _.toString(rut);
    dv = _.toUpper(dv);

    if (!rut || !rut.length || typeof rut !== 'string') {
        return "1";
    }
    var secuencia = [2, 3, 4, 5, 6, 7, 2, 3];
    var sum = 0;

    for (var i = rut.length - 1; i >= 0; i--) {
        var d = rut.charAt(i);
        sum += Number(d) * secuencia[rut.length - (i + 1)];
    }


    var rest = 11 - (sum % 11);

    if (rest == 11) {
        rest = "0";
    }

    if (rest == 10) {
        rest = "K";
    }

    if (_.toString(rest) == _.toString(dv)) {
        return "0";
    }
    else {
        return "2";
    }
}
