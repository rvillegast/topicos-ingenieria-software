// module.exports = {
//     preset: '@shelf/jest-dynamodb'
// }
// DynamoDB en memoria compartida con recaudacion-int (../test-support/fakeDynamo.js); .mjs vía babel-jest.
process.env.TZ = 'UTC'; // como en AWS Lambda; los workers de jest heredan la zona del proceso padre
module.exports = {
    testEnvironment: 'node',
    moduleFileExtensions: ['js', 'mjs', 'json'],
    transform: { '^.+\\.m?js$': 'babel-jest' },
    // src/obligaciones/test/: scripts manuales contra servicios reales (con credenciales embebidas), no son tests unitarios
    testPathIgnorePatterns: ['/node_modules/', '<rootDir>/src/obligaciones/test/'],
    moduleNameMapper: {
        '^aws-sdk/clients/dynamodb$': '<rootDir>/../test-support/fakeDynamo.js'
    }
};
