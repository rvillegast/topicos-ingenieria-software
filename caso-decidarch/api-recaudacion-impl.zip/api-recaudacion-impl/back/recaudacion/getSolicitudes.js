'use strict';

const queryDB = require('./aws/dynamoDbServices');
const moment = require('moment-timezone');
const util = require("./util");
const pag = process.env.PAGINACION;

exports.handler = async(event) => {
    console.log(event);

    try {
        let interval = event.queryStringParameters.interval;
        let next = event.queryStringParameters.next;
        let lastEvalKey;

        let from = moment().subtract(interval, 'minutes').toISOString();

        let { institucion, girador, environment } = await util.getDataFromToken(event.headers.Authorization);
        console.log("institución invocadora: " + institucion + ", girador: " + girador + ", environment: " + environment);

        let params = {
            TableName: `${process.env.PREFIX}-eventos`,
            IndexName: `instEnv-idx`,
            KeyConditionExpression: "institucionEnvironment = :instEnv AND fechaEvento >= :dt",
            ExpressionAttributeValues: {
                ":dt": from,
                ":instEnv": `${institucion}#${environment}`
            },
            Limit: parseInt(pag)
        };

        if (next) {
            params.ExclusiveStartKey = JSON.parse(new Buffer.from(next, 'base64').toString('ascii'));
        }

        console.log('params: ', params);
        let data = await queryDB.getDataQuery(params);
        console.log('resp: ', data);

        if (data.LastEvaluatedKey) {
            lastEvalKey = new Buffer.from(JSON.stringify(data.LastEvaluatedKey)).toString('base64');
        }

        // TODO TD-019: Borrar IF de MOP cuando DGA configure lectura de fecha con formato correcto.
        if (institucion === 'MOP') {
            console.log('Mostrar sin cambios MOP');

            let eventos = [];

            for (let i = 0; i < data.Items.length; i++) {
                let resp = getResponseItemMOP(data.Items[i]);
                eventos.push(resp);
            }

            let response = {
                statusCode: 200,
                body: JSON.stringify({
                    metadata: {
                        request: {
                            interval: parseInt(interval),
                            next: next
                        },
                        response: {
                            next: lastEvalKey
                        }
                    },
                    data: eventos
                })
            };

            console.log(response);
            return response;
        }
        else {
            let response = {
                statusCode: 200,
                body: JSON.stringify({
                    metadata: {
                        request: {
                            interval: parseInt(interval),
                            next: next
                        },
                        response: {
                            next: lastEvalKey
                        }
                    },
                    data: data.Items.map(getResponseItem)
                })
            };

            console.log(response);
            return response;
        }
    }
    catch (e) {
        console.log(e);

        let response = {
            statusCode: 400,
            body: JSON.stringify(e)
        };

        return response;
    }
};

function getResponseItem(item) {

    let id;

    if (item.nombreEstado === 'RECIBIDA') {
        id = item.id;
    }
    else {
        // Si es de tipo carrito mostrar id # idTramite
        if (item.id.split('#').length > 2) {
            id = item.id.split('#')[0] + '#' + item.id.split('#')[1]
        }
        // Si no mostrar solo id
        else {
            id = item.id.split('#')[0]
        }
    }

    if (item.nombreEstado === 'RECIBIDA') {

        return {
            "fechaEvento": item.fechaEvento,
            "solicitud": {
                "id": id
            },
            "estado": {
                "nombreEstado": item.nombreEstado,
                "fechaEstado": item.fechaEvento
            }
        }
    }
    else {
        return {
            "fechaEvento": item.fechaEvento,
            "solicitud": {
                "id": id
            },
            "estado": {
                "nombreEstado": item.nombreEstado,
                "fechaEstado": item.payload.Message.Confirmacion.Pago.FechaPago,
                "medioPago": {
                    "nombreIra": item.payload.Message.Confirmacion.Pago.Ira.Nombre,
                    "codigoIra": item.payload.Message.Confirmacion.Pago.Ira.Codigo
                }
            }
        }
    }
}

// TODO TD-019: Borrar funcion cuando DGA configure lectura correcta de fechaPago.
function getResponseItemMOP(item) {

    let id;
    let fechaPago;

    if (item.nombreEstado === 'RECIBIDA') {
        id = item.id;
    }
    else {
        // Si es de tipo carrito mostrar id # idTramite
        if (item.id.split('#').length > 2) {
            id = item.id.split('#')[0] + '#' + item.id.split('#')[1]
        }
        // Si no mostrar solo id
        else {
            id = item.id.split('#')[0]
        }
    }

    if (item.nombreEstado === 'RECIBIDA') {

        return {
            "fechaEvento": item.fechaEvento,
            "solicitud": {
                "id": id
            },
            "estado": {
                "nombreEstado": item.nombreEstado,
                "fechaEstado": item.fechaEvento
            }
        }
    }
    else {
        let santiago = moment.tz(new Date(item.payload.Message.Confirmacion.Pago.FechaPago), 'America/Santiago');
        fechaPago = santiago.format().substring(0, 19) + "Z";

        return {
            "fechaEvento": item.fechaEvento,
            "solicitud": {
                "id": id
            },
            "estado": {
                "nombreEstado": item.nombreEstado,
                "fechaEstado": fechaPago,
                "medioPago": {
                    "nombreIra": item.payload.Message.Confirmacion.Pago.Ira.Nombre,
                    "codigoIra": item.payload.Message.Confirmacion.Pago.Ira.Codigo
                }
            }
        }
    }
}
