'use strict';
const https = require('https');
const genToken = require('./utils/tokenIntentoPago');
const utils = require('./utils/util');
let tokenCache = "A";

exports.handler = async (event, context, callback) => {

    console.log('event: ', event);

    // Recupero parametro de entrada.
    let data = event.body;

    //Se obtienen parametros de Seguridad DataPower

    let parameterStore = await utils.getParametrosSSM(`/tgr/${process.env.ENV}/api-recaudacion/back/wstIntentoPago/`);

    let clienteId = parameterStore.get("clienteId");
    let scope = parameterStore.get("scope");
    let clientSecret = parameterStore.get("clientSecret");
    let grantType = "client_credentials";
    let hostTierra = parameterStore.get("hostTierra");
    let hostPort = parameterStore.get("hostPort");
    /*********************************************************************************/

    let resultadoServicio = await sendApiIntentoPago(hostTierra, hostPort, tokenCache, data);

    //Si Falla el token volvemos a invocar token y servicio Tierra
    if (resultadoServicio.codeStatus == 401) {
        tokenCache = await genToken.obtenerToken(hostTierra, hostPort, clienteId, scope, clientSecret, grantType);
        resultadoServicio = await sendApiIntentoPago(hostTierra, hostPort, tokenCache, data);
    }

    console.log("Respuesta: " + JSON.stringify(resultadoServicio));
    send(resultadoServicio, callback);
};

function send(resultadoServicio, callback) {

    const response = {
        statusCode: resultadoServicio.codeStatus,
        headers: {
            "Access-Control-Allow-Origin": process.env.API_AUTOSERVICIOS_HOST_SERVICE, // Required for CORS support to work 
            "Access-Control-Allow-Credentials": true, // Required for cookies, authorization headers with HTTPS 
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json; charset=utf-8'
        }
    };

    if (resultadoServicio.respuesta) {
        response.body = JSON.stringify(resultadoServicio.respuesta);
    }

    callback(null, response);
}

function sendApiIntentoPago(hostTierra, hostPort, token, dataServicio) {

    return new Promise((resolve, reject) => {

        let respServicio = {
            codeStatus: "",
            respuesta: ""
        };
        let respuesta = '';

        //opciones para poder realizar la conexion al servicio
        let options = {
            hostname: hostTierra,
            port: hostPort,
            path: '/api-intento-pago/v1/intentoPagoCarrito',
            method: 'POST',
            rejectUnauthorized: true,
            secureProtocol: 'TLSv1_2_method',
            headers: {
                'Authorization': 'Bearer ' + token,
                'Content-Type': 'application/json'
            }
        };

        //Declaracion de variables y realizacion del request
        let req = https.request(options, (res) => {

            respServicio.codeStatus = res.statusCode;

            //guardado de dato obtenidos en respuesta
            res.on('data', (d) => {
                respuesta += d;

            });
        }).on('error', (error) => {
            console.error("Error: " + error);
            reject(error);
        });

        //terminado el request parsear la respuesta y entra al primer if donde lo devuelve a la promesa
        req.on('close', () => {
            if (404 == respServicio.codeStatus) {
                respuesta = JSON.parse('{"errors":[{"message": "Recurso no existe"}]}');
                respServicio.respuesta = respuesta;
            } else if (401 == respServicio.codeStatus) {
                respuesta = JSON.parse('{"errors":[{"message": "No Autorizado"}]}');
                respServicio.respuesta = respuesta;
            } else {
                respuesta = JSON.parse(respuesta);
                respServicio.respuesta = respuesta;
            }

            resolve(respServicio);
        });

        let postData = dataServicio;

        req.write(postData);
        req.end();
    });
}
