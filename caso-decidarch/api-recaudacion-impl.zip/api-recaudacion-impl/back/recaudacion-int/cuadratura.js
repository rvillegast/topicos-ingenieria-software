let { docClient } = require('./aws/dynamoDbServices');
exports.handler = async(event) => {
    console.log("Entrada: " +JSON.stringify(event));
    let data = JSON.parse(event.body);
    let id = data.id;
    let institucion = data.institucion;
    try {
        let paramsConfirmada = {
            TableName: `${process.env.PREFIX}-eventos`,
            IndexName: `${process.env.PREFIX}-ids-idx`,
            ExpressionAttributeValues: {
                ':pk': institucion,
                ':id': `${id}`,
                ':e1': "PAGO_CONFIRMADO"
            },
            KeyConditionExpression: 'institucion = :pk and begins_with(id, :id)',
            FilterExpression: 'nombreEstado = :e1'
        };
        console.log("params Pago Confirmado: "+JSON.stringify(paramsConfirmada, null, 2));
        let dataPagoConfirmado = await docClient.query(paramsConfirmada).promise();
        //console.log("Salida consulta evento pago: "+JSON.stringify(dataPagoConfirmado, null, 2));
        if(dataPagoConfirmado.Items.length == 0){
            let error = {
                mensaje: 'NO_TRX',
            }
            throw error;
        }
        let monto = 0;
        for (let i in dataPagoConfirmado.Items) {
            monto += dataPagoConfirmado.Items[i].payload.Message.Confirmacion.Pago.TotalPago;
        }
        console.log("Monto: " + monto);
        //let monto = dataPagoConfirmado.Items[0].payload.Message.Confirmacion.Pago.TotalPago;
        //let formulario = dataPagoConfirmado.Items[0].payload.Message.Confirmacion.Pago.Formulario;
        //let fechaEvento = dataPagoConfirmado.Items[0].fechaEvento;
        /*if(data.formulario !== formulario){
            let error = {
                mensaje: 'NO_FRM'
            }            
            throw error;
        }*/
        if(data.monto !== monto){
            let error = {
                mensaje: 'NO_MNT'
            }
            throw error;
        }
        let tipoCuadratura = data.tipoCuadratura;
        let update;
        let fechaEvento;
        let idSub;
        for (let i in dataPagoConfirmado.Items) {
            fechaEvento = dataPagoConfirmado.Items[i].fechaEvento;
            idSub= dataPagoConfirmado.Items[i].id;
            update = {
                TableName: `${process.env.PREFIX}-eventos`,
                Key: {
                    id: idSub,
                    fechaEvento: fechaEvento
                },
                UpdateExpression: "set estado_cuad = :e1",
                ConditionExpression: "nombreEstado = :e2",
                ExpressionAttributeValues: {
                    ":e1": tipoCuadratura,
                    ":e2": "PAGO_CONFIRMADO"
                }
            }
            await docClient.update(update).promise();
        }
        
        let salida = {
            statusCode: 200,
            body: JSON.stringify({
                mensaje: 'OK',
            })
        }
        return salida;
    } catch (e) {
        let response = {
            statusCode: 400,
            body: JSON.stringify(e)
        };
        console.log('Error===>' + JSON.stringify(e));
        return response;
    }
};