'use strict';
const moment = require('moment');
const momentTZ = require('moment-timezone');
let { docClient } = require('./aws/dynamoDbServices');
exports.handler = async(event) => {
    console.log(event);
    try {
        let data = JSON.parse(event.body);
        let institucion = data.institucion;
        let fechaHoraDesde = data.fechaHoraDesde;
        let fechaHoraHasta = data.fechaHoraHasta;
        let next = data.next;
        let fechaHoraDesdeUTC = momentTZ.tz(fechaHoraDesde, "UTC").format("YYYY-MM-DD[T]HH:mm:ss");
        let fechaHoraHastaUTC = momentTZ.tz(fechaHoraHasta, "UTC").format("YYYY-MM-DD[T]HH:mm:ss");
        var salida = [];
        var obj;
        let lastEvalKey;
        let paramsConfirmada = {
            TableName: `${process.env.PREFIX}-eventos`,
            IndexName: `instEnv-idx`,
            ExpressionAttributeValues: {
                ':pk': `${institucion}#PRODUCCION`,
                ':f1': `${fechaHoraDesdeUTC}`,
                ':f2': `${fechaHoraHastaUTC}`,
                ':e1': `PAGO_CONFIRMADO`
            },
            KeyConditionExpression: "institucionEnvironment = :pk AND fechaEvento BETWEEN :f1 AND :f2",
            FilterExpression: 'nombreEstado = :e1'
        };
        //EN EL CASO DE QUE SE LLENE BUFFER SE HACE OTRA LLAMADA
        if(data.next){
            paramsConfirmada.ExclusiveStartKey = JSON.parse(new Buffer.from(data.next, 'base64').toString('ascii'));
        }
        //console.log("paramsConfirmada:" + JSON.stringify(paramsConfirmada, null, 2));
        let dataConfirmada = await docClient.query(paramsConfirmada).promise();
        if (dataConfirmada.LastEvaluatedKey) {
            lastEvalKey = new Buffer.from(JSON.stringify(dataConfirmada.LastEvaluatedKey)).toString('base64');
        }
        //console.log("dataConfirmada: "+JSON.stringify(dataConfirmada));
        for (let i = 0; i < dataConfirmada.Items.length; i++) {
            let idExt = dataConfirmada.Items[i].id;
            //console.log("idExt: "+idExt);
            let monto = dataConfirmada.Items[i].payload.Message.Confirmacion.Pago.TotalPago;
            let paramsRecibida = {
                TableName: `${process.env.PREFIX}-eventos`,
                IndexName: `${process.env.PREFIX}-ids-idx`,
                ExpressionAttributeValues: {
                    ':pk': `${institucion}`,
                    ':id': `${idExt}`,
                    ':e1': `RECIBIDA`
                },
                KeyConditionExpression: "institucion = :pk AND id = :id",
                FilterExpression: 'nombreEstado = :e1'
            };
            let dataRecibida = await docClient.query(paramsRecibida).promise();
            //console.log("dataRecibida: "+JSON.stringify(dataRecibida));
            if(dataRecibida.Items.length > 0){
                if (typeof dataRecibida.Items[0].payload.data.receptor === 'undefined') {
                    continue;
                }
                obj = {
                    institucion,
                    numeroOrdenPago: idExt,
                    rut: dataRecibida.Items[0].payload.data.contribuyente.rut,
                    dv: dataRecibida.Items[0].payload.data.contribuyente.dv,
                    banco: dataRecibida.Items[0].payload.data.receptor.cuentaDeposito.banco,
                    tipoCta: dataRecibida.Items[0].payload.data.receptor.cuentaDeposito.tipo,
                    numeroCta: dataRecibida.Items[0].payload.data.receptor.cuentaDeposito.numero,
                    apellidoPaternoORazonSocial: dataRecibida.Items[0].payload.data.receptor.apellidoPaternoORazonSocial,
                    nombre: dataRecibida.Items[0].payload.data.receptor.nombre,
                    monto,
                    concepto: dataRecibida.Items[0].payload.data.conceptoRecaudacion
                }
                salida.push(obj);
            }
        }
        let response = {
            statusCode: 200,
            body: JSON.stringify({
                metadata: {
                    request: {
                        next: next
                    },
                    response: {
                        next: lastEvalKey
                    }
                },
                data: salida
            })
        }
        return response;
    }
    catch (e) {
        let response = {
            statusCode: 400,
            body: JSON.stringify(e)
        };

        console.log(e);
        return response;
    }
};