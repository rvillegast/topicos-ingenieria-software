// Solo para jest: transforma módulos ESM (.mjs) a CommonJS. 'unambiguous' deja los .js CommonJS como script
// (sin "use strict" implícito, que rompería asignaciones globales existentes, p.ej. aws/s3Services.js).
module.exports = {
    sourceType: 'unambiguous',
    presets: [['@babel/preset-env', { targets: { node: 'current' } }]]
};
