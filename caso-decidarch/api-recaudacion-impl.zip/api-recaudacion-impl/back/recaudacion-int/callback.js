'use strict';

const queryDB = require('./aws/dynamoDbServices');

exports.handler = async(event, context, callback) => {

    console.log('event: ', event);

    let idExt = event.queryStringParameters.idExt;
    console.log(idExt);

    var params = {
        TableName: `${process.env.PREFIX}-eventos`,
        KeyConditionExpression: 'id = :hkey',
        ExpressionAttributeValues: {
            ':hkey': idExt,
        }
    };

    var results = await queryDB.getItems(params);

    let data = results.filter(item=>{
        return item.nombreEstado === 'RECIBIDA'
    })[0];
    console.log('Retorno de BD --------------------- ' + JSON.stringify(data));

    var urlR = data.url;
    console.log(urlR);
    if(idExt.includes("#")){
        idExt = idExt.split("#")[0];
    }
    console.log(idExt);
    var response = '';
    try {
        var response = {
            statusCode: 301,
            headers: {
                Location: urlR + '?id=' + idExt //url ejemplo
            }
        }
        callback(null, response);
    }
    catch (e) {
        let response = {
            statusCode: 400,
            body: JSON.stringify(e)
        };

        console.log(response);
        callback(null, response);
    }
};
