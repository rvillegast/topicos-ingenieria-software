module.exports = {
    tables: [
        {
            TableName: 'tgr-dev-api-recaudacion-eventos',
            KeySchema: [
                {AttributeName: 'id', KeyType: 'HASH'},
                {AttributeName: 'fechaEvento', KeyType: 'RANGE'}
            ],
            AttributeDefinitions: [
                {AttributeName: 'id', AttributeType: 'S'},
                {AttributeName: 'fechaEvento', AttributeType: 'S'},
                {AttributeName: 'institucion', AttributeType: 'S'},
                {AttributeName: 'institucionEnvironment', AttributeType: 'S'}
            ],
            BillingMode: "PAY_PER_REQUEST",
            GlobalSecondaryIndexes: [{
                IndexName: 'tgr-dev-api-recaudacion-eventos-idx',
                Projection: {
                    ProjectionType: "ALL"
                },
                KeySchema: [{
                    AttributeName: 'institucion',
                    KeyType: 'HASH'
                }, {
                    AttributeName: 'fechaEvento',
                    KeyType: 'RANGE'
                }]
            },{
                IndexName: 'tgr-dev-api-recaudacion-ids-idx',
                Projection: {
                    ProjectionType: "ALL"
                },
                KeySchema: [{
                    AttributeName: 'institucion',
                    KeyType: 'HASH'
                }, {
                    AttributeName: 'id',
                    KeyType: 'RANGE'
                }]
            },{
                IndexName: 'instEnv-idx',
                Projection: {
                    ProjectionType: "ALL"
                },
                KeySchema: [{
                    AttributeName: 'institucionEnvironment',
                    KeyType: 'HASH'
                }, {
                    AttributeName: 'fechaEvento',
                    KeyType: 'RANGE'
                }]
            }
            ]
        }
    ]
}
