const { LambdaClient, InvokeCommand } = require('@aws-sdk/client-lambda');

const lambdaClient = new LambdaClient({ region: 'us-east-1' });

const lambda = {
    asyncInvoke: async (functionName, payload) => {
        console.log('async invocamos', functionName);
        try {
            const params = {
                FunctionName: functionName,
                InvocationType: 'Event',
                Payload: Buffer.from(JSON.stringify(payload)),
            };
            const command = new InvokeCommand(params);
            const response = await lambdaClient.send(command);
            console.log(response);
        } catch (err) {
            console.log(err);
        }
    },
    syncInvoke: async (functionName, payload) => {
        console.log('sync invocamos', functionName);
        try {
            const params = {
                FunctionName: functionName,
                InvocationType: 'RequestResponse',
                Payload: Buffer.from(JSON.stringify(payload)),
            };
            const command = new InvokeCommand(params);
            const response = await lambdaClient.send(command);
            return Buffer.from(response.Payload).toString('utf8');
        } catch (err) {
            console.log(err);
        }
    },
};

module.exports = {
    lambda,
};