const AWS = require('aws-sdk');
AWS.config.update({region: "us-east-1"});
s3 = new AWS.S3({apiVersion: '2006-03-01'});
const moment = require('moment');

exports.getObjectJSON = function (bucket, completeKey) {
    let params = {
        Bucket: bucket,
        Key: completeKey,
    };

    return new Promise((resolve, reject) => {
        s3.getObject(params, function (err, data) {
            if (err) {
                console.log("[s3] error getObject", params, err, err.stack);
                reject(err);
            } else {
                resolve(JSON.parse(data.Body.toString('utf-8')));
            }
        });
    })
};

exports.putObject = function (bucket, folder, relativeKey, object) {
    let d = moment(Date.now());
    const format = `year=${d.format('YYYY')}/month=${d.format('MM')}/date=${d.format('DD')}/hour=${d.format('HH')}`;

    let params = {
        Bucket: bucket,
        Key: folder + '/' + format + '/' + relativeKey,
        ContentType: 'application/json',
        Body: JSON.stringify(object),
    };

    return new Promise((resolve, reject) => {
        s3.putObject(params, function (err) {
            if (err) {
                console.log("[s3] error putObject", err);
                return reject(err);
            } else {
                resolve();
            }
        });
    })
};

exports.allBucketKeys = async function (bucket,prefix) {
  const params = {
     Bucket:bucket,
     Delimiter: '/',
     Prefix: prefix
  };

  var keys = [];
  for (;;) {
    var data = await s3.listObjects(params).promise();

    data.Contents.forEach((elem) => {
      keys = keys.concat({Key:elem.Key});
    });

    if (!data.IsTruncated) {
      break;
    }
    params.Marker = data.NextMarker;
  }

  return keys;
};

exports.listObjectBucket = function (bucket,prefix) {
    let params = {
        Bucket:bucket,
        Delimiter: '/',
        Prefix: prefix
    };
    
    return new Promise((resolve, reject) => {
        s3.listObjects(params, function(err, data) {
                if (err) {
                    console.log('No Se Pueden Listar los Archivos: ' + err.message);
                    reject(err);
                }else{
                    
                    
                    resolve(data.Contents);
                    
                }
        });
    });
};

exports.copyObjectBucket = function (bucket, oldKey, newKey) {
    var params = {
         Bucket: bucket,
         CopySource: bucket+'/'+oldKey,
         Key: newKey,
    };
    return new Promise((resolve, reject) => {
        s3.copyObject(params, function(err, data) {
          if (err) {
             reject(err);
          } else {
             resolve("success");
          }
        });
    });

};

exports.deleteObjectBucket = function (bucket, key) {
    var params = {  
        Bucket: bucket, 
        Key: key 
    };
    return new Promise((resolve, reject) => {
        s3.deleteObject(params, function(err, data) {
          if (err) {
             reject(err);
          } else {
             resolve("success");
          }
        });
    });

};


exports.existObjectBucket = function (bucket,key) {
    var params = {
        Bucket: bucket,
        Key: key
    };
    return new Promise((resolve,reject) =>{
        s3.headObject(params, function (err, metadata) {  
            if (err) {  
                if (err.code === 'NotFound'){
                    resolve(false);  
                }else{
                    reject(err);
                }
            } else {  
                resolve(true);  
            }
        });
    });
}




