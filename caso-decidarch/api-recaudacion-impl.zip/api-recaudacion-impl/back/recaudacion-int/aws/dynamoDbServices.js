'use strict';

const isTest = process.env.JEST_WORKER_ID || process.env.IS_SERVERLESS_OFFLINE === 'true';
const { DocumentClient } = require('aws-sdk/clients/dynamodb');
let config;

if (isTest) {
    config = {
        convertEmptyValues: true,
        ...(isTest && { endpoint: 'localhost:8000', sslEnabled: false, region: 'local-env' })
    };
}
else {
    config = {
        region: "us-east-1"
    }
}

let docClient = new DocumentClient(config);

exports.docClient = docClient;

exports.getItems = function(params) {

    return new Promise((resolve, reject) => {
        docClient.query(params, function(err, data) {
            if (err) {
                console.log("dynamodb get error:", JSON.stringify(err, null, 2), err.stack);
                reject(err);
            }
            else {
                resolve(data.Items);
            }
        });
    });
};
