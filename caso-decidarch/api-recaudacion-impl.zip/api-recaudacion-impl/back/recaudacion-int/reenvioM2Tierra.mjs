'use strict';

import momentTZ from 'moment-timezone';
import axios from 'axios';
import { OracleProvider } from 'tgr-sdk-layer/clients/dss.mjs';
let provider = new OracleProvider();

export const handler = async (event) => {
  console.log('event: ', event);

  let msg;
  let response = {
    statusCode: null,
    body: null
  };

  try {
    let pagosReenvioM2 = await getPagosReenvioM2();

    let idxMarcadosOK = 0;
    let idxMarcadosNOK = 0;

    if (pagosReenvioM2 != null && pagosReenvioM2.length > 0) {

      let nroTrxEnviarParalelo = 10;

      while (pagosReenvioM2.length > 0) {
        let trxEnviar = pagosReenvioM2.slice(0, nroTrxEnviarParalelo);
        pagosReenvioM2 = pagosReenvioM2.slice(nroTrxEnviarParalelo);

        let promises = [];

        for (let i = 0; i < trxEnviar.length; i++) {
          promises.push(reenviaM2(trxEnviar[i].I, trxEnviar[i].F, trxEnviar[i].M, trxEnviar[i].O, trxEnviar[i].T));
        }

        await Promise.all(promises)
          .then((results) => {
            for (let k = 0; k < results.length; k++) {
              if (results[k] == "OK") idxMarcadosOK = idxMarcadosOK + 1;
              else idxMarcadosNOK = idxMarcadosNOK + 1;
            }
          })
          .catch((e) => {
            console.log("Error en Reenvios: " + e);
          });
      }

      msg = "Resultado Reenvio M2. OK: " + idxMarcadosOK + " NOK: " + idxMarcadosNOK;
    } else {
      msg = "No se reciben Pagos para reenviar";
    }

    console.log(msg);
    response.statusCode = 200;
    response.body = JSON.stringify({ mensaje: msg });
  } catch (e) {
    console.log("Excepcion en proceso: " + e.message);
    response.statusCode = 500;
    response.body = JSON.stringify({ mensaje: "Excepcion en proceso: " + e.message });
  }

  return response;
}

async function getPagosReenvioM2() {

  let resultado;

  let params = [{
    "sql": "RECA.PKG_ESTADO_CUAD_API_RECAUD.get_pagos_reenvio_m2(cursorSalida);",
    "params": [{
      "parameterType": "OUT",
      "type": -10,
      "name": "cursorSalida"
    }]
  }];

  try {
    resultado = await provider.call(params);
    console.log('resultado: ', JSON.stringify(resultado));
    console.log('Consulta Reenvios M2.Cantidad :', resultado[0].cursorSalida.length);
  } catch (e) {
    console.log("Exception en getPagosCuadrados: " + e.message);
    throw e;
  }

  return resultado[0].cursorSalida;
}

async function getDatosM2(id, formulario, monto, idOperacion, idTransaccion) {

  let resultado;

  let params = [{
    "sql": "RECA.PKG_ESTADO_CUAD_API_RECAUD.get_datos_m2(id_externo, formulario, monto, idOperacion, idTransaccion, cursorSalida);",
    "params": [{
        "parameterType": "IN",
        "type": 12,
        "name": "id_externo",
        "value": id
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "formulario",
        "value": formulario
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "monto",
        "value": monto
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "idOperacion",
        "value": idOperacion
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "idTransaccion",
        "value": idTransaccion
      },
      {
        "parameterType": "OUT",
        "type": -10,
        "name": "cursorSalida"
      }
    ]
  }];

  try {
    resultado = await provider.call(params);
  } catch (e) {
    console.log("Excepcion al consultar M2 en base de datos:" + e);
  }

  if (resultado != null && resultado[0].cursorSalida.length > 0)
    return resultado[0].cursorSalida[0];
  else
    throw "No se encontro M2 en base de datos";
}

async function reenviaM2(id, formulario, monto, idOperacion, idTransaccion) {
  let resultado;
  let estadoMarca;

  try {
    let datosM2 = await getDatosM2(id, formulario, monto, idOperacion, idTransaccion);
    //console.log("Fecha pago Tabla: " + datosM2.FECHA_PAGO);

    //Se asigna como UTC para que la fecha se conserve igual
    //a como llega desde la lista_pagos
    let fechaPago = momentTZ.tz(datosM2.FECHA_PAGO, "UTC");
    //console.log("Fecha pago sin modificaciones: " + fechaPago.format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]"));

    //Se clona y se obtiene la diferencia en minutos entre Santiago y UTC
    let offSetUTC = fechaPago.clone().tz("America/Santiago").utcOffset();
    //console.log("offSet: " + offSetUTC);

    //Se obtiene la fecha UTC y se le da el formato correcto
    let fechaPagoUTC = fechaPago.add(Math.abs(offSetUTC), 'minutes').format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]"); //yyyy-MM-dd'T'HH:mm:ss.SSS'Z'
    //console.log("Fecha pago UTC: " + fechaPagoUTC);

    let mensajeM2 = {
      "Message": {
        "MessageId": {
          "Status": "OK",
          "DateTime": new Date(),
          "Number": 1,
          "FromAddress": "TESORERIA",
          "MsgDesc": "Confirma Pago",
          "IdExt": datosM2.ID_EXTERNO,
          "Version": 1,
          "Code": "M2",
          "RefAddress": datosM2.NUMERO_GIRADOR,
          "ToAddress": datosM2.NOMBRE_GIRADOR
        },
        "Confirmacion": {
          "Pago": {
            "Folio": datosM2.FOLIO,
            "IdTransaccion": datosM2.ID_TRANSACCION,
            "Rut": datosM2.RUT_ROL,
            "TipoPago": "E",
            "Ira": {
              "Codigo": datosM2.COD_IRA,
              "Nombre": datosM2.NOMBRE_IRA
            },
            "Vencimiento": datosM2.FECHA_VENCIMIENTO,
            "Formulario": datosM2.FORMULARIO,
            "Resultado": 0,
            "FechaPago": fechaPagoUTC,
            "IdOperacion": datosM2.ID_OPERACION,
            "TotalPago": datosM2.TOTAL_PAGAR
          }
        }
      }
    };

    let request = {
      method: 'POST',
      url: 'https://' + process.env.API_AUTOSERVICIOS_HOST_SERVICE + '/recaudacion-interno/v1/giradores/m2/createM2',
      service: 'execute-api',
      data: JSON.stringify(mensajeM2),
      headers: { 'content-type': 'application/json' }
    };
    await axios(request);
    resultado = "OK";
  } catch (e) {
    resultado = "NOK";
    console.log("Error en envio M2: " + e);
  }

  if (resultado == "NOK")
    estadoMarca = 1;
  else
    estadoMarca = 0;

  let resultadoEnvioTierra = await enviaResultadoTierra(id, idOperacion, idTransaccion, estadoMarca);

  if (resultadoEnvioTierra != 0) {
    resultado = "NOK";
  }

  return resultado;
}

async function enviaResultadoTierra(idExterno, idOperacion, idTransaccion, estadoMarca) {

  let resultado;

  let params = [{
    "sql": "RECA.PKG_ESTADO_CUAD_API_RECAUD.actualiza_reenvio_m2(idExterno, idOperacion, idTransaccion, estadoMarca,outResultado);",
    "params": [{
        "parameterType": "OUT",
        "type": 2,
        "name": "outResultado"
      },
      {
        "parameterType": "IN",
        "type": 12,
        "name": "idExterno",
        "value": idExterno
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "idOperacion",
        "value": idOperacion
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "idTransaccion",
        "value": idTransaccion
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "estadoMarca",
        "value": estadoMarca
      }
    ]
  }];

  try {
    resultado = await provider.call(params);
    console.log("resultadoEnvioTierra: " + JSON.stringify(resultado));

  } catch (e) {
    console.log("Excepcion al enviaResultadoTierra:" + e);
  }

  if (resultado != null)
    return resultado[0].outResultado;
  else
    throw "Excepcion al enviaResultadoTierra Objeto de salida nulo";
}
