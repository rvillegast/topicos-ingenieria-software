// DynamoDB en memoria (../test-support/fakeDynamo.js) en vez de @shelf/jest-dynamodb, que exige Java; .mjs vía babel-jest.
process.env.TZ = 'UTC'; // como en AWS Lambda; los workers de jest heredan la zona del proceso padre
module.exports = {
    testEnvironment: 'node',
    moduleFileExtensions: ['js', 'mjs', 'json'],
    transform: { '^.+\\.m?js$': 'babel-jest' },
    moduleNameMapper: {
        '^aws-sdk/clients/dynamodb$': '<rootDir>/../test-support/fakeDynamo.js'
    }
};
