const { metricScope } = require("aws-embedded-metrics");

module.exports.handler = metricScope(metrics => async (event) => {
  console.log('event: ', JSON.stringify(event));  
  let datosIn;

  // Validar y parsear el evento
  if (typeof(event) === 'object') {
    if (typeof(event.body) === 'string') {
      datosIn = JSON.parse(event.body);            
    } else {
      datosIn = event.body;
    }
  } else {
    //console.log("Error de validación");
    return { statusCode: 400, body: "Error de validación" };
  }
  //console.log (JSON.stringify(datosIn.metric));
  //console.log (JSON.stringify(datosIn.property));
  
  const { nameSpace, dimensions, metric, property } = datosIn;

  if (!nameSpace || !dimensions || !metric || !property) {
    console.error("Datos faltantes en la entrada");
    return { statusCode: 400, body: "Datos incompletos" };
  }

  // Tamaño de cada lote
  const batchSize = 1;  // Número de métricas por lote
  const nroEventoEnviarParalelo = 10;  // Número de lotes en paralelo
  let datosProperty = property.slice();
  //console.log(datosProperty);

  try {
    let batchIndex = 0;

    // Función para enviar una métrica con propiedades usando aws-embedded-metrics
    const sendMetricsBatch = async (loteDatos, batchIndex) => {
      loteDatos.forEach(item => {
      console.log(JSON.stringify({
        item: item,
        nameSpace: nameSpace,
        dimensions: {
          Service: dimensions.Service,
          Estado: dimensions.Estado
        },
        metricName: metric.metricName,
        metricValue: metric.value,
        metricUnit: metric.unit
      }, null, 2));
        // Configurar propiedades para cada métrica
        Object.keys(item).forEach(key => {
          metrics.setProperty(key, item[key]);
        });

        metrics.setNamespace(nameSpace);
        metrics.putDimensions({
          Service: dimensions.Service,
          Estado: dimensions.Estado
        });

        metrics.putMetric(metric.metricName, metric.value, metric.unit); // Registrar la métrica
        //console.log(`Lote ${batchIndex + 1} preparado con propiedades:`, item);
      });
    };

    // Procesamiento de los lotes
    while (datosProperty.length > 0) {
      //console.log('while:', datosProperty);
      const loteDatos = datosProperty.slice(0, batchSize);
      datosProperty.splice(0, batchSize);

      // Enviar el primer lote
      const promises = [sendMetricsBatch(loteDatos, batchIndex++)];

      for (let i = 0; i < nroEventoEnviarParalelo; i++) {
        if (datosProperty.length === 0) break;
        const nextBatch = datosProperty.slice(0, batchSize);
        datosProperty.splice(0, batchSize);
        promises.push(sendMetricsBatch(nextBatch, batchIndex++));
      }

      //console.log(`Esperando a que se completen los lotes paralelos: ${promises.length}`);
      const results = await Promise.allSettled(promises);
      //console.log (promises);
      console.log (results);

      
      results.forEach((result, index) => {
        if (result.status === "fulfilled") {
          //console.log(`Métrica del lote ${index + 1} procesada con éxito.`);
        } else {
          console.error(`Error en la métrica del lote ${index + 1}:`, result.reason);
          //console.error('Error en auditoría:', result.reason);
        }
      });      
    }

    //console.log('Métricas enviadas con éxito.');
    return {
      statusCode: 200,
      body: JSON.stringify('Métricas enviadas con éxito')
    };

  } catch (error) {
    console.error('Error en el procesamiento de métricas:', error);
    return {
      statusCode: 500,
      body: JSON.stringify('Error procesando las métricas')
    };
  }
});
