'use strict';
let { docClient } = require('./aws/dynamoDbServices');
exports.handler = async(event) => {
    //console.log(JSON.stringify(event));
    try {
        for (let i in event.Records) {
        if (event.Records[i].eventName === 'MODIFY') {
            if (typeof event.Records[i].dynamodb.NewImage.estado_cuad !== 'undefined'){
                console.log("ESTADO_CUAD: "+event.Records[i].dynamodb.NewImage.estado_cuad.S);
                let id = event.Records[i].dynamodb.Keys.id.S;
                console.log("Id: "+id);
                let paramsGetConcepto = {
                    TableName: `${process.env.PREFIX}-eventos`,
                    ExpressionAttributeValues: {
                        ':id': `${id}`,
                        ':e1': "RECIBIDA"
                    },
                    KeyConditionExpression: 'id = :id',
                    FilterExpression: 'nombreEstado = :e1'
                };
                //console.log("params Get Concepto: "+JSON.stringify(paramsGetConcepto, null, 2));
                let dataGetConcepto = await docClient.query(paramsGetConcepto).promise();
                let conceptoRecaudacion = dataGetConcepto.Items[0].payload.data.conceptoRecaudacion;
                console.log("Data Concepto: "+JSON.stringify(dataGetConcepto, null, 2));
                console.log("Concepto: "+ conceptoRecaudacion);
            }
            /*let estado_cuad; 
            if(event.Records[i].dynamodb.NewImage.estado_cuad === undefined){
                estado_cuad = undefined;
            } else {
                estado_cuad = event.Records[i].dynamodb.NewImage.estado_cuad.S;
            }
            console.log("estado_cuad: "+estado_cuad);
            if(estado_cuad !== 'ONLINE' || estado_cuad === undefined) {
                let solicitud = getConsolidadoFromRecord(event.Records[i]);
                
                await consolidar(solicitud, tableConsultaSol);
                
            }*/
        }
    }
        
        let response = {
            statusCode: 200,
            body: 'OK'
        };
        console.log(response);
        return response
    }
    catch (e) {
        console.log(e);
        let response = {
            statusCode: 400,
            body: JSON.stringify(e)
        };
        return response;
    }
};
