// Caracterización del suscriptor de réplica genérica (M2 en XML desde on-prem) antes del refactor del slice E3.
// TZ=UTC lo fija jest.config.js (como en Lambda): formatISO depende de la zona del proceso
process.env.ENV = 'dev';
process.env.PREFIX = 'tgr-dev-api-recaudacion';

const mockInvoke = jest.fn();
const mockInvokeAsync = jest.fn();
const mockDss = jest.fn();

// SDK v3: no está en package.json, lo provee el runtime de Lambda (dependencia implícita, R-04) → módulo virtual.
// Desde el slice E3 la búsqueda en `eventos` va por src/eventos (aws-sdk v2 → fakeDynamo en tests).
jest.mock('@aws-sdk/client-lambda', () => ({ Lambda: jest.fn(() => ({ invoke: mockInvoke, invokeAsync: mockInvokeAsync })) }), { virtual: true });
jest.mock('tgr-sdk-layer/clients/dss.mjs', () => ({ OracleProvider: jest.fn(() => ({ call: mockDss })), OracleTypes: {} }), { virtual: true });

const { handler } = require('../suscriptorSnsReplicaGenerica');
const { DocumentClient, __reset } = require('aws-sdk/clients/dynamodb');

const XML = `<Message><MessageId><Status>OK</Status><DateTime>01-06-2021 10:54:03</DateTime><Number>0</Number>`
    + `<FromAddress>TESORERIA</FromAddress><MsgDesc>Confirma Pago</MsgDesc><IdExt>331387</IdExt><Version>1</Version>`
    + `<Code>M2</Code><RefAddress>824</RefAddress><ToAddress>CONAF</ToAddress></MessageId>`
    + `<Confirmacion><Pago><Folio>331386</Folio><IdTransaccion>2021053185026401</IdTransaccion><Rut>7804226</Rut>`
    + `<Ira><Codigo>12</Codigo><Nombre>BANCO ESTADO</Nombre></Ira><Vencimiento>2021-05-31</Vencimiento>`
    + `<Formulario>707</Formulario><Resultado>0</Resultado><FechaPago>31-05-2021 11:10:32</FechaPago>`
    + `<IdOperacion>2021053106478943</IdOperacion><TotalPago>888</TotalPago></Pago></Confirmacion></Message>`;

// La columna replicada trae 5 campos separados por '#'; el XML es el tercero
const snsEvent = (xml = XML, reenvio) => ({
    Records: [{ Sns: {
        Message: JSON.stringify({ ID_PROCESO_JSON_DET: { N: '77' }, COL: `A#B#${xml}#D#E` }),
        MessageAttributes: reenvio ? { REENVIO: { Value: reenvio } } : {}
    } }]
});

const santiagoOffsetHoras = () => {
    const moment = require('moment-timezone');
    return Math.abs(moment.tz('America/Santiago').utcOffset()) / 60;
};

beforeEach(() => {
    jest.clearAllMocks();
    __reset();
    mockInvokeAsync.mockResolvedValue({ Status: 202 });
    mockDss.mockResolvedValue(['OK', null]);
});

describe('suscriptorSnsReplicaGenerica — caracterización', () => {

    it('traduce el XML a M2 JSON e invoca createM2 de forma asíncrona', async () => {
        await handler(snsEvent(XML, 'S'));

        expect(mockInvokeAsync).toHaveBeenCalledTimes(1);
        const { FunctionName, InvokeArgs } = mockInvokeAsync.mock.calls[0][0];
        expect(FunctionName).toBe('tgr-dev-api-recaudacion-int-createM2');
        const m2 = JSON.parse(JSON.parse(InvokeArgs).body);
        expect(m2).toMatchObject({
            Message: {
                MessageId: { Status: 'OK', Number: 0, FromAddress: 'TESORERIA', MsgDesc: 'Confirma Pago', IdExt: '331387',
                    Version: 1, Code: 'M2', RefAddress: 824, ToAddress: 'CONAF' },
                Confirmacion: { Pago: { Folio: 331386, IdTransaccion: 2021053185026401, Rut: 7804226,
                    Ira: { Codigo: 12, Nombre: 'BANCO ESTADO' }, Vencimiento: '2021-05-31', Formulario: 707, Resultado: 0,
                    IdOperacion: 2021053106478943, TotalPago: 888 } }
            },
            flag: 'M2_GIRADOR', ID_PROCESO_JSON_DET: '77', REENVIO: 'S'
        });
        expect(m2.Message.Confirmacion.Pago.TipoPago).toBeUndefined();
        // TD-012: suma el desfase de Santiago VIGENTE HOY (no el de la fecha del pago) a la hora local
        const h = santiagoOffsetHoras();
        expect(m2.Message.MessageId.DateTime).toBe(`2021-06-01T${String(10 + h).padStart(2, '0')}:54:03.000Z`);
        expect(m2.Message.Confirmacion.Pago.FechaPago).toBe(`2021-05-31T${String(11 + h).padStart(2, '0')}:10:32.000Z`);
    });

    it('si ya existe el pago, primero invoca deleteRegistrosEventos con su fechaEvento', async () => {
        await new DocumentClient().put({ TableName: 'tgr-dev-api-recaudacion-eventos',
            Item: { id: '331387#2021053185026401', fechaEvento: '2021-06-01T15:00:00.000Z' } }).promise();

        await handler(snsEvent());

        expect(mockInvoke).toHaveBeenCalledWith({
            FunctionName: 'tgr-dev-api-recaudacion-int-deleteRegistrosEventos',
            Payload: JSON.stringify({ idRecaudacion: '331387#2021053185026401', fechaEventoRecaudacion: '2021-06-01T15:00:00.000Z' })
        });
        expect(mockInvokeAsync).toHaveBeenCalledTimes(1);
    });

    it('marca la fecha de aceptación en DSS con IdOperacion e IdTransaccion', async () => {
        await handler(snsEvent());

        const [[sql]] = mockDss.mock.calls[0];
        expect(sql.sql).toBe('WEBTGR.pkg_envio_m2_dss.act_fecha_aceptacion( #ID_OPERACION, #ID_TRANSACCION, #SALIDA)');
        expect(sql.params.slice(0, 2).map(p => p.value)).toEqual([2021053106478943, 2021053185026401]);
    });

    it('TD-011 corregido: un mensaje con estructura distinta lanza (SNS reintenta) y no invoca createM2', async () => {
        const ev = { Records: [{ Sns: { Message: JSON.stringify({ ID_PROCESO_JSON_DET: { N: '1' }, COL: 'sin-separadores' }), MessageAttributes: {} } }] };

        await expect(handler(ev)).rejects.toThrow('La estructura de la columna JSON ha variado');
        expect(mockInvokeAsync).not.toHaveBeenCalled();
    });

    it('TD-011 corregido: un fallo de DSS lanza', async () => {
        mockDss.mockRejectedValue(new Error('DSS caído'));
        await expect(handler(snsEvent())).rejects.toThrow('DSS caído');
    });
});
