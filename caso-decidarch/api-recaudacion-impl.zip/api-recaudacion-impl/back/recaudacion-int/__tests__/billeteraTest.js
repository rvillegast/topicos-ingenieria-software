// Caracterización del adaptador de billetera (E4): armado del abono, reintentos y respuesta final.
process.env.SSM_WALLET_PATH = '/ssm/wallet/';

jest.mock('../utils/service');
jest.mock('../utils/util');
const Services = require('../utils/service');
const Utils = require('../utils/util');
const { abonarBilletera } = require('../src/integraciones/billetera');

const ssm = new Map([['api-billetera-interna-path', '/interna'], ['api-billetera-path', '/token'], ['service-host', 'host'],
    ['client-id-billetera', 'cid'], ['client-secret-billetera', 'sec'], ['scope-billetera', 'sc']]);
const entrada = (data) => ({ id: 'S1#T1', fechaPago: '2021-05-31', payload: { data: { conceptoRecaudacion: 'C', ...data } } });

beforeEach(() => {
    jest.clearAllMocks();
    Utils.getParametrosSSM.mockResolvedValue(ssm);
    jest.spyOn(global, 'setTimeout').mockImplementation(fn => fn()); // sin esperar el backoff
});

describe('integraciones/billetera — caracterización', () => {

    it('arma el abono con la ruta SSM de configuración y la billetera de la recaudación', async () => {
        Services.post.mockResolvedValue({ statusCode: 201, content: { data: 'ok' } });

        const r = await abonarBilletera(entrada({ recaudacion: { idBilletera: 'B1', monto: 888 } }), 'INST');

        expect(r).toEqual({ data: 'ok' });
        expect(Utils.getParametrosSSM).toHaveBeenCalledWith('/ssm/wallet/');
        const { request, token, method } = Services.post.mock.calls[0][0];
        expect(method).toBe('POST');
        expect(request).toEqual({ host: 'host', path: '/interna/billeteras/B1/transacciones', body: { data: { transaccion: {
            idExterno: 'S1#T1', tipo: 'Abono', monto: 888, institucion: 'INST', fechaPago: '2021-05-31', conceptoRecaudacion: 'C' } } } });
        expect(token.credentials).toEqual({ grant_type: 'client_credentials', client_id: 'cid', client_secret: 'sec', scope: 'sc' });
    });

    it('carrito: usa idBilletera del trámite cuando la recaudación no la trae', async () => {
        Services.post.mockResolvedValue({ statusCode: 200, content: 'ok' });
        await abonarBilletera(entrada({ idBilletera: 'B2', recaudacion: { monto: 1 } }), 'INST');
        expect(Services.post.mock.calls[0][0].request.path).toBe('/interna/billeteras/B2/transacciones');
    });

    it('reintenta ante error y devuelve la respuesta exitosa', async () => {
        Services.post.mockResolvedValueOnce({ statusCode: 500, content: { errors: ['x'] } })
            .mockResolvedValueOnce({ statusCode: 201, content: 'ok' });
        expect(await abonarBilletera(entrada({ recaudacion: { idBilletera: 'B1', monto: 1 } }), 'INST')).toBe('ok');
        expect(Services.post).toHaveBeenCalledTimes(2);
    });

    it('tras 4 intentos fallidos devuelve el error (ConfirmacionPago lo traduce a rechazo, I5)', async () => {
        Services.post.mockResolvedValue({ statusCode: 500, content: { errors: ['caído'] } });
        expect(await abonarBilletera(entrada({ recaudacion: { idBilletera: 'B1', monto: 1 } }), 'INST')).toEqual({ errors: ['caído'] });
        expect(Services.post).toHaveBeenCalledTimes(4);
    });
});
