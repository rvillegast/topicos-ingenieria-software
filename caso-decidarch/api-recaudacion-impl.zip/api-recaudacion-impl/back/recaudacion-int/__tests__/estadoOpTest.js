const estadoOP = require('../estadoOP');

process.env.PREFIX = 'tgr-dev-api-recaudacion';
//jest.setTimeout(20000);
//jest.mock('aws-sdk');

let {docClient} = require('../aws/dynamoDbServices');

describe('Prueba ingresa estadoOP', function () {
    
    it('Actualiza campo estado_op correctamente', async () => {
        
        let item = {"id":"11923773695726691631","fechaEvento":"2021-10-04T15:28:40.593Z","environment":"PRODUCCION","url":"https://www.google.cl","nombreEstado":"RECIBIDA","institucionEnvironment":"DEM#PRODUCCION","folio":2999857274,"codigoInstitucionOnPrem":878,"payload":{"data":{"callbackURL":"https://www.google.cl","contribuyente":{"rut":7023934,"dv":"5"},"recaudacion":{"moneda":"CLP","monto":20000},"receptor":{"rut":97995985,"apellidoPaternoORazonSocial":"RS DEL BENEFICIARIO","dv":"2","cuentaDeposito":{"nombreBanco":"CORPBANCA","banco":27,"tipo":"CUENTA_CORRIENTE","numero":47345611207},"nombre":"Juanito"},"payload":{"items":[]},"conceptoRecaudacion":"MULTA_EXTRANJERO"},"metadata":{"sentDate":"2019-12-11T17:13:12.840Z"}},"formulario":711,"numeroSolicitudRecaudacion":"11923773695726691631","institucion":"DEM"};
        await docClient.put({
            TableName: `${process.env.PREFIX}-eventos`,
            Item: item
        }).promise();
        
        let itemPagado = {"id":"11923773695726691631#2021100425980150","fechaEvento":"2021-10-04T15:29:29.038Z","environment":"PRODUCCION","url":"https://www.google.cl","nombreEstado":"PAGO_CONFIRMADO","institucionEnvironment":"DEM#PRODUCCION","folio":2999857274,"codigoInstitucionOnPrem":878,"payload":{"Message":{"Confirmacion":{"Pago":{"IdTransaccion":2021100425980150,"Rut":7023934,"IdOperacion":2021100429200406,"Resultado":0,"Folio":2999857274,"Formulario":711,"Ira":{"Nombre":"BANCO VIRTUAL","Codigo":999},"Vencimiento":"2021-10-04","TotalPago":20000,"TipoPago":"E","FechaPago":"2021-10-04T15:29:18.000Z"}},"MessageId":{"Status":"OK","FromAddress":"TESORERIA","Number":0,"IdExt":"11923773695726691631","Version":1,"MsgDesc":"Confirma Pago","Code":"M2","DateTime":"2021-10-04T12:29:19Z","ToAddress":"DEM","RefAddress":878}}},"formulario":711,"numeroSolicitudRecaudacion":"11923773695726691631#2021100425980150","institucion":"DEM"};
         await docClient.put({
            TableName: `${process.env.PREFIX}-eventos`,
            Item: itemPagado
        }).promise();
        
        /*Marca estado_op ENVIADO*/
        let event = {
            body: JSON.stringify({
                id: "11923773695726691631#2021100425980150",
                estadoOp: "ENVIADO"
            })
        }
        let data = await estadoOP.handler(event);
        console.log("Salida Marca EstadoOp: "+JSON.stringify(data));
        expect(JSON.parse(data.body).mensaje).toEqual("OK");
        
        
        /*Error transacción no encontrada*/
        event = {
            body: JSON.stringify({
                id: "11923773695726691631#2021100425980151",
                estadoOp: "ENVIADO"
            })
        }
        data = await estadoOP.handler(event);
        console.log("Salida Transacción no encontrada: "+JSON.stringify(data));
        expect(data.statusCode).toEqual(400);
        expect(JSON.parse(data.body).mensaje).toEqual("NO_TRX");
        
        let dynamodbResult = await docClient.query({
            TableName: `${process.env.PREFIX}-eventos`,
            IndexName: `${process.env.PREFIX}-ids-idx`,
            ExpressionAttributeValues: {
                ':pk': "DEM",
                ':id': `11923773695726691631`
            },
            KeyConditionExpression: 'institucion = :pk and begins_with(id, :id)'
        }).promise();
        console.log("Salida tabla: "+JSON.stringify(dynamodbResult, null, 2));
        expect(dynamodbResult).toBeDefined();
        expect(dynamodbResult.Items.length).toEqual(2);
        
    });
});