// Caracterización de publishSnsEventos (E5): verifica el flujo carrito antes de decidir sobre el SATD
// comentario legado «Configurar flujo Carrito» (TD-018, eliminado en el E5). Stream de `eventos` -> SNS de aviso a la institución.
process.env.PREFIX = 'tgr-dev-api-recaudacion';
process.env.SNS_ARN = 'arn:sns:avisos';

const mockPublish = jest.fn();
// __mocks__/aws-sdk.js automockea SNS sin .promise(); aquí se fija solo lo que usa el handler
jest.mock('aws-sdk', () => ({ config: { update: jest.fn() }, SNS: jest.fn(() => ({ publish: mockPublish })) }));
jest.mock('../utils/metrics', () => ({ putMetricPagoConfirmado: jest.fn() }));

const { handler } = require('../publishSnsEventos');
const { DocumentClient, __reset } = require('aws-sdk/clients/dynamodb');

const TABLA = 'tgr-dev-api-recaudacion-eventos';
const recibida = (id, conCuenta) => ({ id, institucion: 'INST', nombreEstado: 'RECIBIDA', fechaEvento: '2021-05-31T10:00:00.000Z',
    payload: { data: { conceptoRecaudacion: 'C-' + id, ...(conCuenta && { receptor: { cuentaDeposito: { numero: 1 } } }) } } });
const pago = id => ({ id, institucion: 'INST', nombreEstado: 'PAGO_CONFIRMADO', fechaEvento: '2021-05-31T11:00:00.000Z',
    environment: 'PRODUCCION', formulario: 707 });
const registro = (eventName, p, extra = {}) => ({ eventName, dynamodb: { NewImage: {
    id: { S: p.id }, institucion: { S: p.institucion }, nombreEstado: { S: p.nombreEstado }, fechaEvento: { S: p.fechaEvento }, ...extra } } });

const sembrar = (...items) => Promise.all(items.map(Item => new DocumentClient().put({ TableName: TABLA, Item }).promise()));
const publicados = () => mockPublish.mock.calls.map(([p]) => ({ ...p, evento: JSON.parse(p.Message).event }));

beforeEach(() => {
    jest.clearAllMocks();
    __reset();
    mockPublish.mockReturnValue({ promise: () => Promise.resolve({ MessageId: 'm' }) });
});

describe('publishSnsEventos — caracterización', () => {

    it('unitario: publica PAGO_CONFIRMADO con la RECIBIDA de la solicitud', async () => {
        await sembrar(recibida('S1', true), pago('S1#TX'));
        await handler({ Records: [registro('INSERT', pago('S1#TX'))] });

        const [p] = publicados();
        expect(p.Subject).toBe('Aviso Pago Confirmado');
        expect(p.MessageAttributes.estado.StringValue).toBe('PAGO_CONFIRMADO');
        expect(p.evento).toMatchObject({ id: 'S1#TX', tipoEgreso: 'EGRESO_AUTOMATICO', concepto: 'C-S1', payload: { recibida: { id: 'S1' } } });
    });

    it('carrito: cada PAGO_CONFIRMADO se publica con la RECIBIDA de su trámite', async () => {
        await sembrar(recibida('S2#T1', true), recibida('S2#T2', false), pago('S2#T1#TX'), pago('S2#T2#TX'));
        await handler({ Records: [registro('INSERT', pago('S2#T1#TX')), registro('INSERT', pago('S2#T2#TX'))] });

        expect(publicados().map(p => [p.evento.id, p.evento.payload.recibida.id, p.evento.tipoEgreso, p.MessageAttributes.concepto.StringValue]))
            .toEqual([['S2#T1#TX', 'S2#T1', 'EGRESO_AUTOMATICO', 'C-S2#T1'], ['S2#T2#TX', 'S2#T2', 'EGRESO_DIFERIDO', 'C-S2#T2']]);
        expect(publicados().every(p => p.MessageAttributes.estado.StringValue === 'PAGO_CONFIRMADO')).toBe(true);
    });

    it('carrito: la cuadratura (MODIFY con estado_cuad) publica PAGO_CUADRADO por trámite', async () => {
        await sembrar(recibida('S3#T1', false), recibida('S3#T2', false), pago('S3#T1#TX'), pago('S3#T2#TX'));
        await handler({ Records: [registro('MODIFY', pago('S3#T2#TX'), { estado_cuad: { S: 'CUADRADO' } })] });

        const [p] = publicados();
        expect(p.Subject).toBe('Aviso Pago Cuadrado');
        expect(p.MessageAttributes.estado.StringValue).toBe('PAGO_CUADRADO');
        expect(p.evento).toMatchObject({ id: 'S3#T2#TX', payload: { recibida: { id: 'S3#T2' } } });
    });

    it('sin RECIBIDA (flujo ipps) no publica', async () => {
        await sembrar(pago('S4#TX'));
        await handler({ Records: [registro('INSERT', pago('S4#TX'))] });
        expect(mockPublish).not.toHaveBeenCalled();
    });
});
