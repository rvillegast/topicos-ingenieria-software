const { DocumentClient, __reset } = require('aws-sdk/clients/dynamodb');

const T = 'tgr-dev-api-recaudacion-eventos';
const db = new DocumentClient();
const item = (id, fechaEvento, nombreEstado) => ({ id, fechaEvento, nombreEstado, institucion: 'DEM', institucionEnvironment: 'DEM#PRODUCCION' });

describe('fakeDynamo (soporte de tests)', () => {
    beforeEach(async () => {
        __reset();
        for (const i of [item('A1', '2021-01-01', 'RECIBIDA'), item('A1#X', '2021-01-02', 'PAGO_CONFIRMADO'), item('B1', '2021-02-01', 'RECIBIDA')]) {
            await db.put({ TableName: T, Item: i }).promise();
        }
    });

    it('query por índice con begins_with, BETWEEN y FilterExpression', async () => {
        const r = await db.query({
            TableName: T, IndexName: 'tgr-dev-api-recaudacion-ids-idx',
            KeyConditionExpression: 'institucion = :pk and begins_with(id, :id)',
            ExpressionAttributeValues: { ':pk': 'DEM', ':id': 'A1' }
        }).promise();
        expect(r.Items.map(i => i.id)).toEqual(['A1', 'A1#X']);

        const f = await db.query({
            TableName: T, IndexName: 'instEnv-idx',
            KeyConditionExpression: 'institucionEnvironment = :pk AND fechaEvento BETWEEN :f1 AND :f2',
            FilterExpression: 'nombreEstado = :e1',
            ExpressionAttributeValues: { ':pk': 'DEM#PRODUCCION', ':f1': '2021-01-01', ':f2': '2021-01-31', ':e1': 'PAGO_CONFIRMADO' }
        }).promise();
        expect(f.Items.map(i => i.id)).toEqual(['A1#X']);
    });

    it('update con ConditionExpression y callback-style', async () => {
        await db.update({
            TableName: T, Key: { id: 'A1#X', fechaEvento: '2021-01-02' },
            UpdateExpression: 'set estado_op = :e1', ConditionExpression: 'nombreEstado = :e2',
            ExpressionAttributeValues: { ':e1': 'ENVIADO', ':e2': 'PAGO_CONFIRMADO' }
        }).promise();
        const got = await new Promise((ok, ko) => db.get({ TableName: T, Key: { id: 'A1#X', fechaEvento: '2021-01-02' } }, (e, d) => e ? ko(e) : ok(d)));
        expect(got.Item.estado_op).toEqual('ENVIADO');

        await expect(db.update({
            TableName: T, Key: { id: 'B1', fechaEvento: '2021-02-01' },
            UpdateExpression: 'set estado_op = :e1', ConditionExpression: 'nombreEstado = :e2',
            ExpressionAttributeValues: { ':e1': 'ENVIADO', ':e2': 'PAGO_CONFIRMADO' }
        }).promise()).rejects.toMatchObject({ code: 'ConditionalCheckFailedException' });
    });

    it('falla fuerte ante tabla o expresión no soportada', async () => {
        await expect(db.scan({ TableName: 'otra' }).promise()).rejects.toMatchObject({ code: 'ResourceNotFoundException' });
        await expect(db.scan({ TableName: T, FilterExpression: 'attribute_exists(id)' }).promise()).rejects.toThrow('no soportada');
    });
});
