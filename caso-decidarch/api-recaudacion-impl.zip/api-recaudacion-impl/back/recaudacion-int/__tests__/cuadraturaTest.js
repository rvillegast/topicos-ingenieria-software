const cuadratura = require('../cuadratura');

process.env.PREFIX = 'tgr-dev-api-recaudacion';
//jest.setTimeout(20000);
//jest.mock('aws-sdk');

let {docClient} = require('../aws/dynamoDbServices');

describe('Prueba cuadratura', function () {
    
    it('Actualiza campo ESTADO_CUAD correctamente', async () => {
        let fechaEvento = new Date().toISOString();
        let idSolicitud = "18523676149716242622";
        let formulario = 711;
        let codigoInstitucionOnPrem = 878;
        let url = "http://52.3.3.94:4200/callback";
        let environment = "CERTIFICACION";
        let institucionEnvironment = "DEM#CERTIFICACION"; 
        let folio = "1612402058";
        
        let item = {
            "id": "35662464392562734997",
            "fechaEvento": fechaEvento,
            "institucion": "CBRR",
            "nombreEstado": "RECIBIDA",
            "numeroSolicitudRecaudacion": "35662464392562734997",
            "payload": {
                "data": {
                    "contribuyente": {"rut": 7023934, "dv": "5"},
                    "callbackURL": "http://52.3.3.94:4200/callback",
                    "receptor": {
                        "rut": 9799598,
                        "dv": "2",
                        "apellidoPaternoORazonSocial": "RS DEL BENEFICIARIO",
                        "cuentaDeposito": {
                            "nombreBanco": "CORPBANCA",
                            "banco": 27,
                            "tipo": "CUENTA_CORRIENTE",
                            "numero": 47311207
                        },
                        "nombre": "Juanito"
                    },
                    "recaudacion": {"moneda": "CLP", "monto": 50},
                    "conceptoRecaudacion": "Certificado de Dominio Vigente de Titulos de Dominio"
                },
                "metadata": {"mock": false, "sentDate": "2019-12-19T19:54:38.994Z"}
            },
            url,
            environment,
            institucionEnvironment, 
            formulario,
            codigoInstitucionOnPrem,
            folio
        };
        await docClient.put({
            TableName: `${process.env.PREFIX}-eventos`,
            Item: item
        }).promise();
        let fechaEventoPago = new Date().toISOString();
        let itemPagado = {
          "codigoInstitucionOnPrem": 878,
          "environment": "CERTIFICACION",
          "fechaEvento": "2020-07-27T14:59:26.766Z",
          "formulario": 711,
          "id": "35662464392562734997",
          "institucion": "DEM",
          "institucionEnvironment": "DEM#CERTIFICACION",
          "nombreEstado": "PAGO_CONFIRMADO",
          "numeroSolicitudRecaudacion": "35662464392562734997",
          "payload": {
            "Message": {
              "Confirmacion": {
                "Pago": {
                  "FechaPago": "2020-03-25T13:21:20Z",
                  "Folio": 1585143425,
                  "Formulario": 711,
                  "IdOperacion": 2020032506967610,
                  "IdTransaccion": 2020032502989658,
                  "Ira": {
                    "Codigo": 999,
                    "Nombre": "BANCO VIRTUAL"
                  },
                  "Resultado": 0,
                  "Rut": 9799598,
                  "TipoPago": "E",
                  "TotalPago": 20000,
                  "Vencimiento": "2020-03-25"
                }
              },
              "MessageId": {
                "Code": "M2",
                "DateTime": "2020-03-25T13:21:21Z",
                "FromAddress": "TESORERIA",
                "IdExt": "35662464392562734997",
                "MsgDesc": "Confirma Pago",
                "Number": 1,
                "RefAddress": 123,
                "Status": "OK",
                "ToAddress": "DEM",
                "Version": 1
              }
            }
          },
          "url": "http://...."
        };
         await docClient.put({
            TableName: `${process.env.PREFIX}-eventos`,
            Item: itemPagado
        }).promise();
        
        /*Marca Cuadratura ONLINE*/
        let event = {
            body: JSON.stringify({
                id: "35662464392562734997",
                formulario: 711,
                monto: 20000,
                tipoCuadratura: "ONLINE",
                institucion: "DEM"
            })
        }
        let data = await cuadratura.handler(event);
        console.log("Salida Marca Cuadratura: "+JSON.stringify(data));
        expect(JSON.parse(data.body).mensaje).toEqual("OK");
        
        /*Marca Cuadratura OFFLINE*/
        event = {
            body: JSON.stringify({
                id: "35662464392562734997",
                formulario: 711,
                monto: 20000,
                tipoCuadratura: "OFFLINE",
                institucion: "DEM"
            })
        }
        data = await cuadratura.handler(event);
        console.log("Salida Marca Cuadratura: "+JSON.stringify(data));
        expect(JSON.parse(data.body).mensaje).toEqual("OK");
        
        /*Error transacción no encontrada*/
        event = {
            body: JSON.stringify({
                id: "35662464392562734998",
                formulario: 711,
                monto: 20000,
                tipoCuadratura: "ONLINE",
                institucion: "DEM"
            })
        }
        data = await cuadratura.handler(event);
        console.log("Salida Transacción no encontrada: "+JSON.stringify(data));
        expect(data.statusCode).toEqual(400);
        expect(JSON.parse(data.body).mensaje).toEqual("NO_TRX");
        
        /*Error monto incorrecto*/
        event = {
            body: JSON.stringify({
                id: "35662464392562734997",
                formulario: 711,
                monto: 20001,
                tipoCuadratura: "ONLINE",
                institucion: "DEM"
            })
        }
        data = await cuadratura.handler(event);
        console.log("Salida monto incorrecto: "+JSON.stringify(data));
        expect(data.statusCode).toEqual(400);
        expect(JSON.parse(data.body).mensaje).toEqual("NO_MNT");
        
        let dynamodbResult = await docClient.query({
            TableName: `${process.env.PREFIX}-eventos`,
            KeyConditionExpression: 'id = :id',
            ExpressionAttributeValues: {
                ':id': "35662464392562734997"
            }
        }).promise();
        console.log("Salida tabla: "+JSON.stringify(dynamodbResult, null, 2));
        expect(dynamodbResult).toBeDefined();
        expect(dynamodbResult.Items.length).toEqual(2);
        
    });
    it('Actualiza campo ESTADO_CUAD para carrito', async () => {
        let items = [
                {"codigoInstitucionOnPrem":878,"environment":"PRODUCCION","fechaEvento":"2021-04-28T14:33:23.661Z","folio":7126886367,"formulario":756,"id":"62591141626539818688#12334","institucion":"DEM","institucionEnvironment":"DEM#PRODUCCION","nombreEstado":"RECIBIDA","numeroSolicitudRecaudacion":"62591141626539818688#12334","payload":{"data":{"callbackURL":"http://google.com?query1=valor1","conceptoRecaudacion":"MULTA_EXTRANJERO_DIFERIDO","contribuyente":{"dv":"7","rut":61979750},"idBilletera":"48T454.ggT2lZl02c24d","idTramite":12334,"recaudacion":{"moneda":"CLP","monto":100000}}},"url":"http://google.com?query1=valor1"},
                {"codigoInstitucionOnPrem":878,"environment":"PRODUCCION","fechaEvento":"2021-04-28T14:33:23.617Z","folio":1858696675,"formulario":756,"id":"62591141626539818688#12345","institucion":"DEM","institucionEnvironment":"DEM#PRODUCCION","nombreEstado":"RECIBIDA","numeroSolicitudRecaudacion":"62591141626539818688#12345","payload":{"data":{"callbackURL":"http://google.com?query1=valor1","conceptoRecaudacion":"MULTA_EXTRANJERO_DIFERIDO","contribuyente":{"dv":"7","rut":61979750},"idBilletera":"48T454.ggT2lZl02c24d","idTramite":12345,"recaudacion":{"moneda":"CLP","monto":100000}}},"url":"http://google.com?query1=valor1"},
                {"codigoInstitucionOnPrem":878,"environment":"PRODUCCION","fechaEvento":"2021-04-28T14:33:23.757Z","folio":1642783127,"formulario":711,"id":"62591141626539818688#3534345","institucion":"DEM","institucionEnvironment":"DEM#PRODUCCION","nombreEstado":"RECIBIDA","numeroSolicitudRecaudacion":"62591141626539818688#3534345","payload":{"data":{"callbackURL":"http://google.com?query1=valor1","conceptoRecaudacion":"MULTA_EXTRANJERO","contribuyente":{"dv":"7","rut":61979750},"idTramite":3534345,"recaudacion":{"moneda":"CLP","monto":100000},"receptor":{"apellidoPaternoORazonSocial":"GOBIERNO CENTRAL-DEPARTAMENTO DE EXTRANJERIA","cuentaDeposito":{"banco":12,"nombreBanco":"BANCO ESTADO","numero":9005706,"tipo":"CUENTA_CORRIENTE"},"dv":"8","nombre":"SUBSECRETARIA DEL INTERIOR-GASTOS DE OPERACION","rut":60501000}}},"url":"http://google.com?query1=valor1"},
                {"codigoInstitucionOnPrem":878,"environment":"PRODUCCION","fechaEvento":"2021-04-28T14:33:23.728Z","folio":2962696389,"formulario":10,"id":"62591141626539818688#435345","institucion":"DEM","institucionEnvironment":"DEM#PRODUCCION","nombreEstado":"RECIBIDA","numeroSolicitudRecaudacion":"62591141626539818688#435345","payload":{"data":{"callbackURL":"http://google.com?query1=valor1","conceptoRecaudacion":"PERMANENCIA_DEFINITIVA_F10_DEM","contribuyente":{"dv":"7","rut":61979750},"idBilletera":"3014639Z28c480214910","idTramite":435345,"recaudacion":{"moneda":"CLP","monto":50000}}},"url":"http://google.com?query1=valor1"},
                {"codigoInstitucionOnPrem":878,"environment":"PRODUCCION","fechaEvento":"2021-04-28T14:33:23.699Z","folio":9243566332,"formulario":756,"id":"62591141626539818688#53445345","institucion":"DEM","institucionEnvironment":"DEM#PRODUCCION","nombreEstado":"RECIBIDA","numeroSolicitudRecaudacion":"62591141626539818688#53445345","payload":{"data":{"callbackURL":"http://google.com?query1=valor1","conceptoRecaudacion":"MULTA_EXTRANJERO_DIFERIDO","contribuyente":{"dv":"7","rut":61979750},"idBilletera":"48T454.ggT2lZl02c24d","idTramite":53445345,"recaudacion":{"moneda":"CLP","monto":100000}}},"url":"http://google.com?query1=valor1"},
                {"codigoInstitucionOnPrem":878,"environment":"PRODUCCION","fechaEvento":"2021-04-28T14:36:04.868Z","folio":7126886367,"formulario":756,"id":"62591141626539818688#12334","institucion":"DEM","institucionEnvironment":"DEM#PRODUCCION","nombreEstado":"PAGO_CONFIRMADO","numeroSolicitudRecaudacion":"62591141626539818688#12334","payload":{"Message":{"Confirmacion":{"Pago":{"FechaPago":"2020-03-25T13:21:20Z","Folio":1618925700,"Formulario":100,"IdOperacion":2020032506967610,"IdTransaccion":2020032502989658,"Ira":{"Codigo":999,"Nombre":"BANCO VIRTUAL"},"Resultado":0,"Rut":7023934,"TipoPago":"E","TotalPago":100000,"Vencimiento":"2020-03-25"}},"MessageId":{"Code":"M2","DateTime":"2020-03-25T13:21:21Z","FromAddress":"TESORERIA","IdExt":"62591141626539818688","MsgDesc":"Confirma Pago","Number":1,"RefAddress":878,"Status":"OK","ToAddress":"DEM","Version":1}}},"url":"http://google.com?query1=valor1"},
                {"codigoInstitucionOnPrem":878,"environment":"PRODUCCION","fechaEvento":"2021-04-28T14:36:05.195Z","folio":1858696675,"formulario":756,"id":"62591141626539818688#12345","institucion":"DEM","institucionEnvironment":"DEM#PRODUCCION","nombreEstado":"PAGO_CONFIRMADO","numeroSolicitudRecaudacion":"62591141626539818688#12345","payload":{"Message":{"Confirmacion":{"Pago":{"FechaPago":"2020-03-25T13:21:20Z","Folio":1618925700,"Formulario":100,"IdOperacion":2020032506967610,"IdTransaccion":2020032502989658,"Ira":{"Codigo":999,"Nombre":"BANCO VIRTUAL"},"Resultado":0,"Rut":7023934,"TipoPago":"E","TotalPago":100000,"Vencimiento":"2020-03-25"}},"MessageId":{"Code":"M2","DateTime":"2020-03-25T13:21:21Z","FromAddress":"TESORERIA","IdExt":"62591141626539818688","MsgDesc":"Confirma Pago","Number":1,"RefAddress":878,"Status":"OK","ToAddress":"DEM","Version":1}}},"url":"http://google.com?query1=valor1"},
                {"codigoInstitucionOnPrem":878,"environment":"PRODUCCION","fechaEvento":"2021-04-28T14:36:05.195Z","folio":1642783127,"formulario":711,"id":"62591141626539818688#3534345","institucion":"DEM","institucionEnvironment":"DEM#PRODUCCION","nombreEstado":"PAGO_CONFIRMADO","numeroSolicitudRecaudacion":"62591141626539818688#3534345","payload":{"Message":{"Confirmacion":{"Pago":{"FechaPago":"2020-03-25T13:21:20Z","Folio":1618925700,"Formulario":100,"IdOperacion":2020032506967610,"IdTransaccion":2020032502989658,"Ira":{"Codigo":999,"Nombre":"BANCO VIRTUAL"},"Resultado":0,"Rut":7023934,"TipoPago":"E","TotalPago":100000,"Vencimiento":"2020-03-25"}},"MessageId":{"Code":"M2","DateTime":"2020-03-25T13:21:21Z","FromAddress":"TESORERIA","IdExt":"62591141626539818688","MsgDesc":"Confirma Pago","Number":1,"RefAddress":878,"Status":"OK","ToAddress":"DEM","Version":1}}},"url":"http://google.com?query1=valor1"},
                {"codigoInstitucionOnPrem":878,"environment":"PRODUCCION","fechaEvento":"2021-04-28T14:36:05.543Z","folio":2962696389,"formulario":10,"id":"62591141626539818688#435345","institucion":"DEM","institucionEnvironment":"DEM#PRODUCCION","nombreEstado":"PAGO_CONFIRMADO","numeroSolicitudRecaudacion":"62591141626539818688#435345","payload":{"Message":{"Confirmacion":{"Pago":{"FechaPago":"2020-03-25T13:21:20Z","Folio":1618925700,"Formulario":100,"IdOperacion":2020032506967610,"IdTransaccion":2020032502989658,"Ira":{"Codigo":999,"Nombre":"BANCO VIRTUAL"},"Resultado":0,"Rut":7023934,"TipoPago":"E","TotalPago":50000,"Vencimiento":"2020-03-25"}},"MessageId":{"Code":"M2","DateTime":"2020-03-25T13:21:21Z","FromAddress":"TESORERIA","IdExt":"62591141626539818688","MsgDesc":"Confirma Pago","Number":1,"RefAddress":878,"Status":"OK","ToAddress":"DEM","Version":1}}},"url":"http://google.com?query1=valor1"},
                {"codigoInstitucionOnPrem":878,"environment":"PRODUCCION","fechaEvento":"2021-04-28T14:36:05.920Z","folio":9243566332,"formulario":756,"id":"62591141626539818688#53445345","institucion":"DEM","institucionEnvironment":"DEM#PRODUCCION","nombreEstado":"PAGO_CONFIRMADO","numeroSolicitudRecaudacion":"62591141626539818688#53445345","payload":{"Message":{"Confirmacion":{"Pago":{"FechaPago":"2020-03-25T13:21:20Z","Folio":1618925700,"Formulario":100,"IdOperacion":2020032506967610,"IdTransaccion":2020032502989658,"Ira":{"Codigo":999,"Nombre":"BANCO VIRTUAL"},"Resultado":0,"Rut":7023934,"TipoPago":"E","TotalPago":100000,"Vencimiento":"2020-03-25"}},"MessageId":{"Code":"M2","DateTime":"2020-03-25T13:21:21Z","FromAddress":"TESORERIA","IdExt":"62591141626539818688","MsgDesc":"Confirma Pago","Number":1,"RefAddress":878,"Status":"OK","ToAddress":"DEM","Version":1}}},"url":"http://google.com?query1=valor1"}
            ]
        for (let i in items) {
            await docClient.put({
                TableName: `${process.env.PREFIX}-eventos`,
                Item: items[i]
            }).promise();
        }
       
        
        event = {
            body: JSON.stringify({
                id: "62591141626539818688",
                formulario: 100,
                monto: 450000,
                tipoCuadratura: "OFFLINE",
                institucion: "DEM"
            })
        }
        let data = await cuadratura.handler(event);
        console.log("Salida: "+JSON.stringify(data));
        let r = await docClient.scan({
            TableName: `${process.env.PREFIX}-eventos`, 
            FilterExpression: 'nombreEstado = :e1',
            ExpressionAttributeValues: {
                ':e1': "PAGO_CONFIRMADO"
            }
        }).promise();
        console.log("Salida tabla: "+JSON.stringify(r, null, 2));
    });
});