// Caracterización de postM2 (createM2): fija el comportamiento ACTUAL antes del refactor del slice E3.
// Los casos 1-6 vienen de la suite original (estaba en skip); se ajustaron conteos a la tabla vacía por test
// y se reemplazaron llamadas reales (billetera, portal autoservicios) por dobles. Los casos 7-9 son nuevos.
const postM2 = require('../postM2');
const axios = require('axios');
const billetera = require('../src/integraciones/billetera');
const { docClient, } = require('../aws/dynamoDbServices');
const { __reset } = require('aws-sdk/clients/dynamodb');

jest.mock('axios');
jest.mock('../src/integraciones/billetera'); // servicio externo de billetera (HTTPS + SSM)

process.env.PREFIX = 'tgr-dev-api-recaudacion';
const TABLA = `${process.env.PREFIX}-eventos`;

const m2 = ({ idExt, toAddress, refAddress = 878, idTrx, folio = 7126886367, formulario = 711, total = 100000, dateTime = '2019-11-29T15:45:33Z', tipoPago = 'E' }) => ({
    body: JSON.stringify({
        Message: {
            MessageId: { Status: 'OK', DateTime: dateTime, Number: 0, FromAddress: 'TESORERIA', MsgDesc: 'Confirma Pago',
                IdExt: idExt, Version: 1, Code: 'M2', RefAddress: refAddress, ToAddress: toAddress },
            Confirmacion: { Pago: { Folio: folio, IdTransaccion: idTrx, Rut: 61979750, TipoPago: tipoPago,
                Ira: { Codigo: 999, Nombre: 'BANCO VIRTUAL' }, Vencimiento: '2019-11-29', Formulario: formulario,
                Resultado: 0, FechaPago: '2019-11-29T15:45:33Z', IdOperacion: 2019112942900512, TotalPago: total } }
        }
    })
});

const recibida = (id, data, extra = {}) => ({
    codigoInstitucionOnPrem: 878, environment: 'PRODUCCION', fechaEvento: '2021-04-28T14:33:23.661Z', folio: 7126886367,
    formulario: 711, id, institucion: 'DEM', institucionEnvironment: 'DEM#PRODUCCION', nombreEstado: 'RECIBIDA',
    numeroSolicitudRecaudacion: id, payload: { data: { callbackURL: 'http://google.com?query1=valor1', ...data } },
    url: 'http://google.com?query1=valor1', ...extra
});

const sembrar = items => Promise.all(items.map(Item => docClient.put({ TableName: TABLA, Item }).promise()));
const todos = async () => (await docClient.scan({ TableName: TABLA }).promise()).Items;
const confirmados = async () => (await todos()).filter(i => i.nombreEstado === 'PAGO_CONFIRMADO');

beforeEach(() => {
    __reset();
    jest.clearAllMocks();
    billetera.abonarBilletera.mockResolvedValue({ data: 'ok' });
    // portal autoservicios: concepto por formulario (flujo on-prem)
    axios.mockResolvedValue({ data: { data: { concepto: { Items: [] } } } });
});

describe('postM2 — caracterización', () => {

    it('1. unitario: registra PAGO_CONFIRMADO con id idExt#idTrx y copia datos de la RECIBIDA', async () => {
        const id = '18523676149716242622';
        await sembrar([recibida(id, { recaudacion: { moneda: 'CLP', monto: 50 } },
            { institucion: 'CBRR', institucionEnvironment: 'CBRR#PRODUCCION', formulario: 739, codigoInstitucionOnPrem: 123 })]);

        const r = await postM2.handler(m2({ idExt: id, toAddress: 'CBRR', refAddress: 710, idTrx: 2019112797086319, folio: '9', formulario: 739 }));

        expect(r).toEqual({ statusCode: 200, body: 'OK' });
        const [pc] = await confirmados();
        expect(pc).toMatchObject({
            id: `${id}#2019112797086319`, numeroSolicitudRecaudacion: `${id}#2019112797086319`,
            nombreEstado: 'PAGO_CONFIRMADO', institucion: 'CBRR', institucionEnvironment: 'CBRR#PRODUCCION',
            environment: 'PRODUCCION', formulario: 739, codigoInstitucionOnPrem: 123,
            folio: 9, url: 'http://google.com?query1=valor1'
        });
        expect(pc.payload.Message.Confirmacion.Pago.Folio).toBe(9); // folio normalizado a número también en el payload
        expect(billetera.abonarBilletera).not.toHaveBeenCalled();
        expect((await todos()).length).toBe(2);
    });

    it('2. RECIBIDA con idTramite se trata como carrito aunque sea una sola; reenvío no duplica', async () => {
        const id = '62591141626539818688';
        await sembrar([recibida(id, { idBilletera: '48T454', idTramite: 12334, recaudacion: { moneda: 'CLP', monto: 100000 } })]);
        const ev = m2({ idExt: id, toAddress: 'DEM', idTrx: 2019112797086319 });

        expect(await postM2.handler(ev)).toEqual({ statusCode: 200, body: 'OK' });
        expect(await postM2.handler(ev)).toEqual({ statusCode: 200, body: 'OK' });

        const pcs = await confirmados();
        expect(pcs.length).toBe(1);
        // Caracterización: sin '#' en el id de la RECIBIDA la segunda parte queda 'undefined'
        expect(pcs[0].id).toBe(`${id}#undefined#2019112797086319`);
        expect(billetera.abonarBilletera).toHaveBeenCalledTimes(1);
    });

    it('3. carrito: un PAGO_CONFIRMADO por trámite con TotalPago = monto del trámite; pago doble con otro idTrx se registra', async () => {
        const id = '62591141626539818688';
        await sembrar([
            recibida(`${id}#12334`, { idBilletera: 'B1', idTramite: 12334, recaudacion: { moneda: 'CLP', monto: 100000 } }),
            recibida(`${id}#3534345`, { idTramite: 3534345, recaudacion: { moneda: 'CLP', monto: 100000 } }),
            recibida(`${id}#435345`, { idBilletera: 'B2', idTramite: 435345, recaudacion: { moneda: 'CLP', monto: 50000 } }),
        ]);
        const ev = m2({ idExt: id, toAddress: 'DEM', idTrx: 2019112797086319, total: 250000, formulario: 100 });

        await postM2.handler(ev);
        await postM2.handler(ev); // reenvío
        expect((await confirmados()).length).toBe(3);

        const r = await postM2.handler(m2({ idExt: id, toAddress: 'DEM', idTrx: 2019112797086320, total: 250000, formulario: 100 }));
        expect(r.body).toBe('OK');

        const pcs = await confirmados();
        expect(pcs.length).toBe(6);
        const t435 = pcs.find(p => p.id === `${id}#435345#2019112797086319`);
        expect(t435.payload.Message.Confirmacion.Pago.TotalPago).toBe(50000);
        expect(t435.folio).toBe(7126886367); // folio de la RECIBIDA, no del M2
        // abono: solo trámites con idBilletera, en cada pago no reenviado (2 trámites x 2 pagos)
        expect(billetera.abonarBilletera).toHaveBeenCalledTimes(4);
        // Caracterización: el id enviado a billetera ordena las partes distinto que el id persistido
        expect(billetera.abonarBilletera.mock.calls[0][0].id).toBe(`${id}#2019112797086319#12334`);
    });

    it('4. on-prem (sin RECIBIDA): registra con PRODUCCION y concepto GENERICO_<inst>; reenvío no duplica', async () => {
        const ev = m2({ idExt: 331387, toAddress: 'CONAF', refAddress: 824, idTrx: 2021053185026401, folio: 331386, formulario: 707, total: 888 });

        expect(await postM2.handler(ev)).toEqual({ statusCode: 200, body: 'OK' });
        expect(await postM2.handler(ev)).toEqual({ statusCode: 200, body: 'OK' });

        const pcs = await confirmados();
        expect(pcs.length).toBe(1);
        expect(pcs[0]).toMatchObject({
            id: '331387#2021053185026401', institucion: 'CONAF', environment: 'PRODUCCION',
            institucionEnvironment: 'CONAF#PRODUCCION', codigoInstitucionOnPrem: 824, folio: 331386
        });
        expect(pcs[0].payload.Message.Confirmacion.Pago.conceptoRecaudacion).toBe('GENERICO_CONAF');
        expect(axios).toHaveBeenCalledWith(expect.objectContaining({
            url: expect.stringContaining('/portal-autoservicios/v1/formularios?formulario=707&institucion=CONAF')
        }));
    });

    it('5. unitario con pagos previos del mismo idExt: registra el nuevo idTrx una sola vez', async () => {
        const id = '33593694226868865392';
        const previo = idTrx => ({ ...recibida(`${id}#${idTrx}`, {}), nombreEstado: 'PAGO_CONFIRMADO',
            payload: { Message: { Confirmacion: { Pago: { IdTransaccion: idTrx } } } } });
        await sembrar([recibida(id, { recaudacion: { moneda: 'CLP', monto: 20000 } }), previo(2021060118342646), previo(2021060118342647)]);
        const ev = m2({ idExt: id, toAddress: 'DEM', idTrx: 2021060118342648 });

        await postM2.handler(ev);
        await postM2.handler(ev);

        expect((await todos()).length).toBe(4);
    });

    it('6. on-prem con pagos previos: concepto en PRODUCCION del portal; nuevo idTrx una sola vez', async () => {
        const id = '33593694226868865568';
        const previo = idTrx => ({ id: `${id}#${idTrx}`, fechaEvento: '2021-06-30T18:52:08.871Z', institucion: 'SRCEI',
            nombreEstado: 'PAGO_CONFIRMADO', payload: { Message: { Confirmacion: { Pago: { IdTransaccion: idTrx } } } } });
        await sembrar([previo(2021060118342648), previo(2021060118342649)]);
        axios.mockResolvedValue({ data: { data: { concepto: { Items: [
            { idConcepto: 'CERT_QA', etapa: 'CERTIFICACION' }, { idConcepto: 'CERT_PROD', etapa: 'PRODUCCION' }] } } } });
        const ev = m2({ idExt: id, toAddress: 'SRCEI', refAddress: 806, idTrx: 2021060118342650, total: 1000, formulario: 100 });

        await postM2.handler(ev);
        await postM2.handler(ev);

        const pcs = await confirmados();
        expect(pcs.length).toBe(3);
        expect(pcs.find(p => p.id === `${id}#2021060118342650`).payload.Message.Confirmacion.Pago.conceptoRecaudacion).toBe('CERT_PROD');
    });

    it('7. DateTime sin zona del M2 no se usa para fechaEvento (se usa la hora de registro)', async () => {
        const antes = new Date().toISOString();
        await postM2.handler(m2({ idExt: 1, toAddress: 'CONAF', idTrx: 1 }));
        const [pc] = await confirmados();
        expect(pc.fechaEvento >= antes).toBe(true);
    });

    it('8. TD-010 corregido: unitario con abono rechazado → 400 NOK (mismo contrato que carrito) y no persiste', async () => {
        const id = '11111111111111111111';
        await sembrar([recibida(id, { recaudacion: { moneda: 'CLP', monto: 1, idBilletera: 'B1' } })]);
        billetera.abonarBilletera.mockResolvedValue({ errors: ['rechazado'] });

        const r = await postM2.handler(m2({ idExt: id, toAddress: 'DEM', idTrx: 9 }));

        // Antes del slice: ReferenceError por `callback` inexistente, serializado como body '{}' (TD-010)
        expect(r).toEqual({ statusCode: 400, body: JSON.stringify({ statusCode: 400, body: 'NOK' }) });
        expect((await confirmados()).length).toBe(0);
    });

    it('9. carrito con abono rechazado a mitad: 400 NOK pero los trámites anteriores ya quedaron persistidos', async () => {
        const id = '22222222222222222222';
        await sembrar([
            recibida(`${id}#1`, { idBilletera: 'B1', idTramite: 1, recaudacion: { moneda: 'CLP', monto: 10 } }, { fechaEvento: '2021-01-01T00:00:00.000Z' }),
            recibida(`${id}#2`, { idBilletera: 'B2', idTramite: 2, recaudacion: { moneda: 'CLP', monto: 20 } }, { fechaEvento: '2021-01-01T00:00:01.000Z' }),
        ]);
        billetera.abonarBilletera.mockResolvedValueOnce({ data: 'ok' }).mockResolvedValueOnce({ errors: ['rechazado'] });

        const r = await postM2.handler(m2({ idExt: id, toAddress: 'DEM', idTrx: 7 }));

        expect(r).toEqual({ statusCode: 400, body: JSON.stringify({ statusCode: 400, body: 'NOK' }) });
        expect((await confirmados()).length).toBe(1); // registro parcial (viola I5 a nivel de carrito)
    });

    it('10. expand (ADR-003): persiste `confirmacion` v1 junto al `payload` M2 legado', async () => {
        await postM2.handler(m2({ idExt: 5, toAddress: 'CONAF', refAddress: 824, idTrx: 55, folio: '12', formulario: 707, total: 888 }));
        const [pc] = await confirmados();
        expect(pc.payload.Message.Confirmacion.Pago.IdTransaccion).toBe(55); // legado intacto
        expect(pc.confirmacion).toEqual({
            version: 1, idSolicitud: 5, idTransaccion: 55, idOperacion: 2019112942900512, folio: 12, formulario: 707,
            fechaPago: '2019-11-29T15:45:33Z', montoTotal: 888, medioPago: { codigo: 999, nombre: 'BANCO VIRTUAL' },
            rutPagador: 61979750, tipoPago: 'E', vencimiento: '2019-11-29', resultado: 0, institucion: 'CONAF',
            codigoInstitucionOnPrem: 824, emitidoEn: '2019-11-29T18:45:33.000Z', origen: 'M2_JSON', reenvio: false,
            conceptoRecaudacion: 'GENERICO_CONAF'
        });
    });

    it('11. TD-024: on-prem con conceptos pero ninguno en PRODUCCION → TypeError → 400 con body {} y no persiste', async () => {
        axios.mockResolvedValue({ data: { data: { concepto: { Items: [{ idConcepto: 'CERT_QA', etapa: 'CERTIFICACION' }] } } } });
        const r = await postM2.handler(m2({ idExt: 77, toAddress: 'SRCEI', refAddress: 806, idTrx: 7701, formulario: 100 }));
        expect(r).toEqual({ statusCode: 400, body: '{}' });
        expect(await confirmados()).toEqual([]);
    });

    it('12. TD-025: dos RECIBIDA sin idTramite se registran como on-prem (sin abono, concepto del portal, ambiente PRODUCCION)', async () => {
        const id = '88';
        await sembrar([recibida(id, { recaudacion: { idBilletera: 'B1', monto: 1 } }, { environment: 'CERTIFICACION' }),
            recibida(`${id}x`, { recaudacion: { idBilletera: 'B1', monto: 1 } }, { environment: 'CERTIFICACION' })]);
        await postM2.handler(m2({ idExt: id, toAddress: 'DEM', idTrx: 8801 }));
        const [pc] = await confirmados();
        expect(pc).toMatchObject({ id: '88#8801', environment: 'PRODUCCION', institucionEnvironment: 'DEM#PRODUCCION' });
        expect(pc.payload.Message.Confirmacion.Pago.conceptoRecaudacion).toBe('GENERICO_DEM');
        expect(billetera.abonarBilletera).not.toHaveBeenCalled();
    });

    it('13. TD-026: la idempotencia usa `confirmacion` v1 aunque el pago previo no tenga `payload` M2', async () => {
        const id = '99';
        await sembrar([recibida(id, { recaudacion: { monto: 1 } }), { id: `${id}#9901`, fechaEvento: '2026-10-09T10:00:00.000Z',
            institucion: 'DEM', nombreEstado: 'PAGO_CONFIRMADO', confirmacion: { version: 1, idTransaccion: 9901 } }]);

        expect(await postM2.handler(m2({ idExt: id, toAddress: 'DEM', idTrx: 9901 }))).toEqual({ statusCode: 200, body: 'OK' });
        expect((await confirmados()).length).toBe(1); // reenvío: no duplica
        expect(await postM2.handler(m2({ idExt: id, toAddress: 'DEM', idTrx: 9902 }))).toEqual({ statusCode: 200, body: 'OK' });
        expect((await confirmados()).map(p => p.id).sort()).toEqual([`${id}#9901`, `${id}#9902`]);
    });

    it('14. TD-026: registrar() sin M2 legado persiste solo `confirmacion` (Q8 de AGENTS.md lo restringe hasta cerrar TD-015)', async () => {
        const { registrar } = require('../src/confirmacion-pago');
        const confirmacion = { version: 1, idSolicitud: '77', idTransaccion: 'px_1', folio: 5, formulario: 707,
            institucion: 'CONAF', codigoInstitucionOnPrem: 824, origen: 'PASARELA_X' };

        expect(await registrar({ confirmacion })).toBe('REGISTRADA');
        expect(await registrar({ confirmacion })).toBe('REENVIO');
        const [pc] = await confirmados();
        expect(pc.payload).toBeUndefined();
        expect(pc.confirmacion).toMatchObject({ idTransaccion: 'px_1', origen: 'PASARELA_X', conceptoRecaudacion: 'GENERICO_CONAF' });
    });
});
