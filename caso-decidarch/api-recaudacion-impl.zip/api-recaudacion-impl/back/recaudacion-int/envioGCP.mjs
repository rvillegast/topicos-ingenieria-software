import AWS from 'aws-sdk';
import axios from 'axios';
import aws4 from 'aws4';
import moment from "moment-timezone";
export const handler = async (event) => {
    console.log(JSON.stringify(event));
    try {
        const fechaHora = moment().tz("America/Santiago").format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z';
        const objAuditoria = {
            "data": {
                fechaHora: fechaHora,
                tipoConsultado: "api-recaudacion",
                ipCliente: "127.0.0.1",
                codigoAplicacion: "PRD033",
                tipoAplicacion: "AWS"
          }
        }
        for (let i in event.Records) {
            console.log("event.Records[i]", event.Records[i]);
            if (event.Records[i].eventName === 'MODIFY'){
                if(event.Records[i].dynamodb.NewImage.nombreEstado.S === 'PAGO_CONFIRMADO'){
                    objAuditoria.data.usuarioLogin = event.Records[i].dynamodb.NewImage.institucion.S;
                    objAuditoria.data.valorConsultado = event.Records[i].dynamodb.NewImage.numeroSolicitudRecaudacion.S;
                    if (event.Records[i].dynamodb.NewImage.hasOwnProperty("estado_cuad") 
                     && !event.Records[i].dynamodb.NewImage.hasOwnProperty("estado_op")){
                        objAuditoria.data.evento = 'estado_cuadratura(M2)';
                    } else if(event.Records[i].dynamodb.NewImage.hasOwnProperty("estado_op")){
                        objAuditoria.data.evento = 'estado_op(M2)'
                    }
                }
                let unmarshalled = AWS.DynamoDB.Converter.unmarshall(event.Records[i].dynamodb.NewImage);
                objAuditoria.data.parametros = unmarshalled;
                console.log("objAuditoria: ", objAuditoria);
                await ingresarAuditoria(objAuditoria)
            } else if(event.Records[i].eventName === 'INSERT'){
                objAuditoria.data.usuarioLogin = event.Records[i].dynamodb.NewImage.institucion.S;
                objAuditoria.data.valorConsultado = event.Records[i].dynamodb.NewImage.numeroSolicitudRecaudacion.S;
                if(event.Records[i].dynamodb.NewImage.nombreEstado.S === 'RECIBIDA'){
                    objAuditoria.data.evento = 'solicitud_recaudacion(M1)'
                } else if (event.Records[i].dynamodb.NewImage.nombreEstado.S === 'PAGO_CONFIRMADO'){
                    objAuditoria.data.evento = 'confirma_pago(M2)'
                }
                let unmarshalled = AWS.DynamoDB.Converter.unmarshall(event.Records[i].dynamodb.NewImage);
                objAuditoria.data.parametros = unmarshalled;
                console.log("objAuditoria: ", objAuditoria);
                await ingresarAuditoria(objAuditoria)
            }
        }
        
        let response = {
            statusCode: 200,
            body: 'OK'
        };
        console.log(response);
        return response
    }
    catch (e) {
        console.log(e);
        let response = {
            statusCode: 400,
            body: JSON.stringify(e)
        };
        return response;
    }
};

function ingresarAuditoria(json) {
    let request = {
        method: 'POST',
        host: process.env.API_AUTOSERVICIOS_HOST_SERVICE,
        path: `/transversales/v1/auditorias/app`,
        body: JSON.stringify(json),
        service: 'execute-api'
    }

    let signedRequest2 = aws4.sign(request, {
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        sessionToken: process.env.AWS_SESSION_TOKEN
    })
    console.log("request: ", request);
    console.log("signedRequest2: ", signedRequest2);

    return axios({
        ...signedRequest2,
        url: `https://${request.host}${request.path}`,
        method: request.method,
        data: request.body
    })
}