"use strict";
import AWS from 'aws-sdk';
AWS.config.update({
  region: "us-east-1"
});
let documentClient = new AWS.DynamoDB.DocumentClient();

export const handler = async (event) => {
  console.log('event: ', event);
  try {

    let id = event.pathParameters.id;
    id = `${id}`;

    let params = {
      TableName: `${process.env.PREFIX}-eventos`,
      KeyConditionExpression: "id = :hkey",
      ExpressionAttributeValues: {
        ":hkey": id,
      },
    };
    console.log('params: ', params);

    let results = await documentClient.query(params).promise();
    console.log("Primer Resultado --------------------- " + JSON.stringify(results));

    if (results.Items.length == 0) {
      params = {
        TableName: `${process.env.PREFIX}-eventos`,
        KeyConditionExpression: "id = :hkey",
        ExpressionAttributeValues: {
          ":hkey": id + "#1",
        },
      };
      results = await documentClient.query(params).promise();
      console.log("Segundo Resultado --------------------- " + JSON.stringify(results));
    }

    let response = {
      statusCode: 200,
      body: JSON.stringify(results.Items),
    };

    console.log("11. Entrega detalle de la recaudación al API IRA para que extraiga el monto");
    return response;
  } catch (e) {
    let response = {
      statusCode: 400,
      body: JSON.stringify(e),
    };

    console.log(JSON.stringify(e));
    return response;
  }
};
