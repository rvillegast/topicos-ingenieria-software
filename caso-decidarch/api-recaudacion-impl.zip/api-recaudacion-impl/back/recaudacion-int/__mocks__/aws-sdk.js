// Copyright (c) 2014-present, Facebook, Inc. All rights reserved.

'use strict';

const AWS = jest.genMockFromModule('aws-sdk');

AWS.CognitoIdentityServiceProvider.prototype.describeUserPoolClient = jest.fn((params, callback) => {
    callback(null, {
        UserPoolClient: {
            ClientName: 'institucion=CBRR,formulario=776'
        }
    });
});

AWS.DynamoDB.DocumentClient.prototype.query = jest.fn((params, callback) => {
    callback(null, { Items: [{"payload":{"data":{"contribuyente":{"rut":7023934,"dv":"5"},"callbackURL":"http://52.3.3.94:4200/callback","receptor":{"rut":9799598,"dv":"2","apellidoPaternoORazonSocial":"RS DEL BENEFICIARIO","cuentaDeposito":{"nombreBanco":"CORPBANCA","banco":27,"tipo":"CUENTA_CORRIENTE","numero":47311207},"nombre":"Juanito"},"recaudacion":{"moneda":"CLP","monto":50},"conceptoRecaudacion":"Certificado de Dominio Vigente de Titulos de Dominio"},"metadata":{"mock":false,"sentDate":"2019-12-19T19:54:38.994Z"}},"fechaEvento":"2019-12-19T19:54:39.559Z","numeroSolicitudRecaudacion":"18523676149716242622","institucion":"CBRR","id":"18523676149716242622","url":"http://52.3.3.94:4200/callback","nombreEstado":"RECIBIDA"}]
    });
});

AWS.DynamoDB.DocumentClient.prototype.put = jest.fn((params, callback) => {
    callback(null, {});
});

AWS.S3.prototype.getObject = jest.fn((params, callback) => {
    if(params.Key === 'config.json' ) {
        callback(null, {Body: JSON.stringify({baba:'baba'})})
    }
    //console.log(params);
    callback();
});

module.exports = AWS;