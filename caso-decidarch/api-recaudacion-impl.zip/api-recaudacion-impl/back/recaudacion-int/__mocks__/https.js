'use strict';

const https = jest.genMockFromModule('https');

https.__httpResponsesByURL = [];

https.setHttpResponsesByURL = (responses) => {
    https.__httpResponsesByURL = responses
};

https.request = jest.fn((options, callback) => {
    let req = {
        write: jest.fn((data) => {
            let result = {
                statusCode: 200,
                headers: {},
                on: (eventType, writeCallback) => {
                    switch (eventType) {
                        case 'data':
                            writeCallback(JSON.stringify(https.__httpResponsesByURL[options.path]));
                            break;
                        case 'end':
                            writeCallback();
                            break;
                    }
                }
            };

            callback(result);
        }),
        on: () => {
            return req;
        },

        end: () => {
        }
    };

    return req;
});

module.exports = https;