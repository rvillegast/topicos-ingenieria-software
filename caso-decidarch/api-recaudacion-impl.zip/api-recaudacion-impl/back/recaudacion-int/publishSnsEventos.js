'use strict';
const AWS = require('aws-sdk');
AWS.config.update({ region: "us-east-1" });
var sns = new AWS.SNS({ apiVersion: '2010-03-31' });

let { docClient } = require('./aws/dynamoDbServices');

const service = 'm2';
const nameSpace = `tgr-${process.env.ENV}-proceso-m2`;
const metrica = 'm2'
const estado = 'pago-confirmado'

const { putMetricPagoConfirmado } = require('./utils/metrics');

exports.handler = async (event) => {
    console.log('event: ', JSON.stringify(event));
    console.log('Records: ', JSON.stringify(event.Records));
    const arrayJsonMetric = [];
    let objSNS;
    let paramsPublishSNS;

    try {
        let resp;
        for (let i in event.Records) {
            if (event.Records[i].eventName === 'REMOVE') {
                console.log('no procesar eventos REMOVE');
            } else {
                console.log('Datos NewImage: ', event.Records[i].dynamodb.NewImage);

                let tipoEgreso;
               

                let paramsRegistrosId = {
                    TableName: `${process.env.PREFIX}-eventos`,
                    IndexName: `${process.env.PREFIX}-ids-idx`,
                    ExpressionAttributeValues: {
                        ':pk': `${event.Records[i].dynamodb.NewImage.institucion.S}`,
                        ':id': `${event.Records[i].dynamodb.NewImage.id.S.split('#')[0]}`
                    },
                    KeyConditionExpression: "institucion = :pk and begins_with(id, :id)"
                };

                console.log('params registros: ', paramsRegistrosId);
                let registrosId = await docClient.query(paramsRegistrosId).promise();
                console.log('Respuesta Dynamo: ', registrosId.Items);

                if (event.Records[i].eventName === 'INSERT' && event.Records[i].dynamodb.NewImage.nombreEstado.S === 'RECIBIDA') {
                    console.log('Aviso Recibida');
                } else if (event.Records[i].eventName === 'INSERT' && event.Records[i].dynamodb.NewImage.nombreEstado.S === 'PAGO_CONFIRMADO') {
                    if (event.Records[i].dynamodb.NewImage.flag) {

                        // PAGO_CONFIRMADO LLAMAR LA MÉTRICA

                         //// seteo de variables métrica
                let trxTransaccion = event.Records[i].dynamodb.NewImage.payload.M.Message.M.Confirmacion.M.Pago.M.IdTransaccion.N;
                let idOperacion = event.Records[i].dynamodb.NewImage.payload.M.Message.M.Confirmacion.M.Pago.M.IdOperacion.N;
                let folio = event.Records[i].dynamodb.NewImage.payload.M.Message.M.Confirmacion.M.Pago.M.Folio.N;
                let formulario = event.Records[i].dynamodb.NewImage.payload.M.Message.M.Confirmacion.M.Pago.M.Formulario.N;
                let montoTotal = event.Records[i].dynamodb.NewImage.payload.M.Message.M.Confirmacion.M.Pago.M.TotalPago.N;
                let fechaPago = event.Records[i].dynamodb.NewImage.payload.M.Message.M.Confirmacion.M.Pago.M.FechaPago.S;
                let fechaEvento = event.Records[i].dynamodb.NewImage.fechaEvento.S;
                let idGirador = event.Records[i].dynamodb.NewImage.payload.M.Message.M.MessageId.M.RefAddress.N;

                console.log("Params : ",trxTransaccion," - ",idOperacion," - ",folio," - ",formulario," - ", montoTotal," - ",fechaPago," - ",fechaEvento," - ",idGirador);
                
                const pago = {
                    trxTransaccion,
                    idOperacion,
                    folio,
                    formulario,
                    montoTotal,
                    fechaPago,
                    fechaEvento,
                    idGirador
                };
        
                arrayJsonMetric.push(pago);
                /** ********************************/
                  // FIN PAGO_CONFIRMADO LLAMAR LA MÉTRICA

                        let registroSnsRec = await docClient.get({
                            TableName: `${process.env.PREFIX}-eventos`,
                            Key: {
                                id: event.Records[i].dynamodb.NewImage.id.S,
                                fechaEvento: event.Records[i].dynamodb.NewImage.fechaEvento.S
                            }
                        }).promise();
                        console.log('registroSnsRec: ', JSON.stringify(registroSnsRec));
                        delete registroSnsRec.Item.flag;
                        delete registroSnsRec.Item.payload.flag;
                        console.log('registroSnsRec delete: ', JSON.stringify(registroSnsRec));

                        let input = {
                            Message: JSON.stringify(registroSnsRec.Item),
                            MessageAttributes: {
                                "flag": {
                                    DataType: "String",
                                    StringValue: 'Pagos700WL'
                                },
                                "institucion": {
                                    DataType: "String",
                                    StringValue: event.Records[i].dynamodb.NewImage.institucion.S
                                }
                            },
                            Subject: 'Aviso Replica Girador',
                            TopicArn: process.env.SNS_REPLICA_GIRADOR
                        };
                        console.log('input: ', input);
                        await sendSnsM2Girador(input);
                    } else {
                        let envioMsgSns = true;
                        // Obtener el pago confirmado correspondiente y evitar colisionar con el duplicado en caso de existir, 
                        let pago_confirmado = registrosId.Items.filter((item, index) => {
                            if (item.id === event.Records[i].dynamodb.NewImage.id.S) {
                                return item;
                            }
                        })

                        let recibida = registrosId.Items.filter((item, index) => {
                            if (item.nombreEstado === 'RECIBIDA') {
                                return item;
                            }
                        })

                        // Existen solicitudes solo pago_confirmado, solo agregar informacion de estado recibida si existe dicho registro.
                        if (recibida.length === 1) {
                            console.log('Unitaria');

                            let datosRecibida = {
                                id: recibida[0].id,
                                nombreEstado: recibida[0].nombreEstado,
                                fechaEvento: recibida[0].fechaEvento,
                                payload: recibida[0].payload
                            }

                            console.log('Datos Recibida: ', datosRecibida);

                            if (datosRecibida.payload.data.receptor && datosRecibida.payload.data.receptor.cuentaDeposito.numero) {
                                tipoEgreso = 'EGRESO_AUTOMATICO'
                            } else {
                                tipoEgreso = 'EGRESO_DIFERIDO'
                            }

                            objSNS = {
                                event: {
                                    id: pago_confirmado[0].id,
                                    fechaEvento: pago_confirmado[0].fechaEvento,
                                    nombreEstado: "PAGO_CONFIRMADO",
                                    tipoEgreso: tipoEgreso,
                                    institucion: pago_confirmado[0].institucion,
                                    environment: pago_confirmado[0].environment,
                                    formulario: pago_confirmado[0].formulario,
                                    concepto: datosRecibida.payload.data.conceptoRecaudacion,
                                    payload: {
                                        pago_confirmado: pago_confirmado[0],
                                        recibida: datosRecibida
                                    }
                                }
                            }



                            /*objSNS = {
                                event: {
                                    id:  event.Records[i].dynamodb.NewImage.id.S,
                                    fechaEvento: event.Records[i].dynamodb.NewImage.fechaEvento.S,
                                    nombreEstado: "PAGO_CONFIRMADO",
                                    tipoEgreso: tipoEgreso,
                                    institucion: event.Records[i].dynamodb.NewImage.institucion.S,
                                    environment: event.Records[i].dynamodb.NewImage.environment.S,
                                    formulario: event.Records[i].dynamodb.NewImage.formulario.S,
                                    concepto: datosRecibida.payload.data.conceptoRecaudacion,
                                    payload: {
                                        pago_confirmado: event.Records[i].dynamodb.NewImage,
                                        recibida: datosRecibida
                                    }
                                }
                            }*/

                            console.log('Objeto a publicar en SNS: ', JSON.stringify(objSNS));

                            paramsPublishSNS = {
                                Message: JSON.stringify(objSNS),
                                MessageAttributes: {
                                    "estado": {
                                        DataType: "String",
                                        StringValue: "PAGO_CONFIRMADO"
                                    },
                                    "tipoEgreso": {
                                        DataType: "String",
                                        StringValue: tipoEgreso
                                    },
                                    "institucion": {
                                        DataType: "String",
                                        StringValue: objSNS.event.payload.pago_confirmado.institucion
                                    },
                                    "environment": {
                                        DataType: "String",
                                        StringValue: objSNS.event.payload.pago_confirmado.environment
                                    },
                                    "formulario": {
                                        DataType: "Number",
                                        StringValue: JSON.stringify(Number(objSNS.event.payload.pago_confirmado.formulario))
                                    },
                                    "concepto": {
                                        DataType: "String",
                                        StringValue: objSNS.event.payload.recibida.payload.data.conceptoRecaudacion
                                    }
                                },
                                Subject: 'Aviso Pago Confirmado',
                                TopicArn: process.env.SNS_ARN
                            };
                        }
                        else if (recibida.length > 1) {
                            console.log('Carrito');

                            let arrayId = event.Records[i].dynamodb.NewImage.id.S.split("#");
                            let idRecibida = arrayId[0] + "#" + arrayId[1];
                            let recibida_check = registrosId.Items.filter((item, index) => {
                                if (item.nombreEstado === 'RECIBIDA' && item.id === idRecibida) {
                                    return item;
                                }
                            })
                            console.log('Datos recibida: ', JSON.stringify(recibida_check));
                            console.log('Datos Pago Confirmado: ', JSON.stringify(pago_confirmado));
                            let datosRecibida = {
                                id: recibida_check[0].id,
                                nombreEstado: recibida_check[0].nombreEstado,
                                fechaEvento: recibida_check[0].fechaEvento,
                                payload: recibida_check[0].payload
                            }

                            console.log('Datos Objeto Recibida: ', datosRecibida);

                            if (datosRecibida.payload.data.receptor && datosRecibida.payload.data.receptor.cuentaDeposito.numero) {
                                tipoEgreso = 'EGRESO_AUTOMATICO'
                            } else {
                                tipoEgreso = 'EGRESO_DIFERIDO'
                            }

                            objSNS = {
                                event: {
                                    id: pago_confirmado[0].id,
                                    fechaEvento: pago_confirmado[0].fechaEvento,
                                    nombreEstado: "PAGO_CONFIRMADO",
                                    tipoEgreso: tipoEgreso,
                                    institucion: pago_confirmado[0].institucion,
                                    environment: pago_confirmado[0].environment,
                                    formulario: pago_confirmado[0].formulario,
                                    concepto: datosRecibida.payload.data.conceptoRecaudacion,
                                    payload: {
                                        pago_confirmado: pago_confirmado[0],
                                        recibida: datosRecibida
                                    }
                                }
                            }

                            console.log('Objeto a publicar en SNS: ', JSON.stringify(objSNS));

                            paramsPublishSNS = {
                                Message: JSON.stringify(objSNS),
                                MessageAttributes: {
                                    "estado": {
                                        DataType: "String",
                                        StringValue: "PAGO_CONFIRMADO"
                                    },
                                    "tipoEgreso": {
                                        DataType: "String",
                                        StringValue: tipoEgreso
                                    },
                                    "institucion": {
                                        DataType: "String",
                                        StringValue: objSNS.event.payload.pago_confirmado.institucion
                                    },
                                    "environment": {
                                        DataType: "String",
                                        StringValue: objSNS.event.payload.pago_confirmado.environment
                                    },
                                    "formulario": {
                                        DataType: "Number",
                                        StringValue: JSON.stringify(Number(objSNS.event.payload.pago_confirmado.formulario))
                                    },
                                    "concepto": {
                                        DataType: "String",
                                        StringValue: objSNS.event.payload.recibida.payload.data.conceptoRecaudacion
                                    }
                                },
                                Subject: 'Aviso Pago Confirmado',
                                TopicArn: process.env.SNS_ARN
                            };


                        } else {
                            console.log('No existen registros con estado RECIBIDA, flujo ipps, no aplica')
                            envioMsgSns = false;
                        }

                        if (envioMsgSns) {
                            console.log('params SNS: ', paramsPublishSNS);
                            resp = await sns.publish(paramsPublishSNS).promise();
                            console.log('Respuesta publish sns: ', resp);
                        }
                    }
                } else if (event.Records[i].eventName === 'MODIFY' &&
                    event.Records[i].dynamodb.NewImage.estado_cuad.S &&
                    typeof event.Records[i].dynamodb.NewImage.estado_op == 'undefined') {

                    let envioMsgSns = true;
                    // Obtener el pago confirmado correspondiente y evitar colisionar con el duplicado en caso de existir, 
                    let pago_confirmado = registrosId.Items.filter((item, index) => {
                        if (item.id === event.Records[i].dynamodb.NewImage.id.S) {
                            return item;
                        }
                    })

                    let recibida = registrosId.Items.filter((item, index) => {
                        if (item.nombreEstado === 'RECIBIDA') {
                            return item;
                        }
                    })

                    // Existen solicitudes solo pago_confirmado, solo agregar informacion de estado recibida si existe dicho registro.
                    if (recibida.length === 1) {
                        console.log('Unitaria');

                        let datosRecibida = {
                            id: recibida[0].id,
                            nombreEstado: recibida[0].nombreEstado,
                            fechaEvento: recibida[0].fechaEvento,
                            payload: recibida[0].payload
                        }

                        console.log('Datos Recibida: ', datosRecibida);

                        if (datosRecibida.payload.data.receptor && datosRecibida.payload.data.receptor.cuentaDeposito.numero) {
                            tipoEgreso = 'EGRESO_AUTOMATICO'
                        } else {
                            tipoEgreso = 'EGRESO_DIFERIDO'
                        }

                        objSNS = {
                            event: {
                                id: pago_confirmado[0].id,
                                fechaEvento: pago_confirmado[0].fechaEvento,
                                nombreEstado: "PAGO_CUADRADO",
                                tipoEgreso: tipoEgreso,
                                institucion: pago_confirmado[0].institucion,
                                environment: pago_confirmado[0].environment,
                                formulario: pago_confirmado[0].formulario,
                                concepto: datosRecibida.payload.data.conceptoRecaudacion,
                                payload: {
                                    pago_confirmado: pago_confirmado[0],
                                    recibida: datosRecibida
                                }
                            }
                        }

                        console.log('Objeto a publicar en SNS: ', JSON.stringify(objSNS));

                        paramsPublishSNS = {
                            Message: JSON.stringify(objSNS),
                            MessageAttributes: {
                                "estado": {
                                    DataType: "String",
                                    StringValue: "PAGO_CUADRADO"
                                },
                                "tipoEgreso": {
                                    DataType: "String",
                                    StringValue: objSNS.event.tipoEgreso
                                },
                                "institucion": {
                                    DataType: "String",
                                    StringValue: objSNS.event.payload.pago_confirmado.institucion
                                },
                                "environment": {
                                    DataType: "String",
                                    StringValue: objSNS.event.payload.pago_confirmado.environment
                                },
                                "formulario": {
                                    DataType: "Number",
                                    StringValue: JSON.stringify(Number(objSNS.event.payload.pago_confirmado.formulario))
                                },
                                "concepto": {
                                    DataType: "String",
                                    StringValue: objSNS.event.payload.recibida.payload.data.conceptoRecaudacion
                                }
                            },
                            Subject: 'Aviso Pago Cuadrado',
                            TopicArn: process.env.SNS_ARN
                        };
                    }
                    else if (recibida.length > 1) {
                        console.log('Carrito');

                        let arrayId = event.Records[i].dynamodb.NewImage.id.S.split("#");
                        let idRecibida = arrayId[0] + "#" + arrayId[1];
                        let recibida_check = registrosId.Items.filter((item, index) => {
                            if (item.nombreEstado === 'RECIBIDA' && item.id === idRecibida) {
                                return item;
                            }
                        })
                        console.log('Datos recibidaç: ', JSON.stringify(recibida_check));
                        console.log('Datos Pago Confirmado: ', JSON.stringify(pago_confirmado));
                        let datosRecibida = {
                            id: recibida_check[0].id,
                            nombreEstado: recibida_check[0].nombreEstado,
                            fechaEvento: recibida_check[0].fechaEvento,
                            payload: recibida_check[0].payload
                        }

                        console.log('Datos Objeto Recibida: ', datosRecibida);

                        if (datosRecibida.payload.data.receptor && datosRecibida.payload.data.receptor.cuentaDeposito.numero) {
                            tipoEgreso = 'EGRESO_AUTOMATICO'
                        } else {
                            tipoEgreso = 'EGRESO_DIFERIDO'
                        }

                        objSNS = {
                            event: {
                                id: pago_confirmado[0].id,
                                fechaEvento: pago_confirmado[0].fechaEvento,
                                nombreEstado: "PAGO_CUADRADO",
                                tipoEgreso: tipoEgreso,
                                institucion: pago_confirmado[0].institucion,
                                environment: pago_confirmado[0].environment,
                                formulario: pago_confirmado[0].formulario,
                                concepto: datosRecibida.payload.data.conceptoRecaudacion,
                                payload: {
                                    pago_confirmado: pago_confirmado[0],
                                    recibida: datosRecibida
                                }
                            }
                        }

                        console.log('Objeto a publicar en SNS: ', JSON.stringify(objSNS));

                        paramsPublishSNS = {
                            Message: JSON.stringify(objSNS),
                            MessageAttributes: {
                                "estado": {
                                    DataType: "String",
                                    StringValue: "PAGO_CUADRADO"
                                },
                                "tipoEgreso": {
                                    DataType: "String",
                                    StringValue: tipoEgreso
                                },
                                "institucion": {
                                    DataType: "String",
                                    StringValue: objSNS.event.payload.pago_confirmado.institucion
                                },
                                "environment": {
                                    DataType: "String",
                                    StringValue: objSNS.event.payload.pago_confirmado.environment
                                },
                                "formulario": {
                                    DataType: "Number",
                                    StringValue: JSON.stringify(Number(objSNS.event.payload.pago_confirmado.formulario))
                                },
                                "concepto": {
                                    DataType: "String",
                                    StringValue: objSNS.event.payload.recibida.payload.data.conceptoRecaudacion
                                }
                            },
                            Subject: 'Aviso Pago Cuadrado',
                            TopicArn: process.env.SNS_ARN
                        };

                    } else {
                        console.log('No existen registros con estado RECIBIDA, flujo ipps, no aplica')
                        envioMsgSns = false;
                    }

                    if (envioMsgSns) {
                        console.log('params SNS: ', paramsPublishSNS);
                        resp = await sns.publish(paramsPublishSNS).promise();
                        console.log('Respuesta publish sns: ', resp);
                    }
                }
            }
        }

        let response = {
            statusCode: 200,
            body: JSON.stringify('OK')
        };

        try { if (arrayJsonMetric.length > 0) {
                console.log (arrayJsonMetric);            
                const result = await putMetricPagoConfirmado(nameSpace,service, metrica,estado,arrayJsonMetric);
                console.log("Resultado de la métrica:", result);}
            } catch (error) {
                console.error("Error al ejecutar la métrica:", error);
            }



        return response;
    } catch (e) {
        console.log(e);

        let response = {
            statusCode: 500,
            body: JSON.stringify(e)
        };

        return response;
    }
};

let attempt = 0;
async function sendSnsM2Girador(input) {
    try {
        let respPublishSns = await sns.publish(input).promise();
        console.log('respPublishSns: ', respPublishSns);
    } catch (err) {
        console.log('err: ', err);
        console.log('Intento: ', attempt);

        attempt++;
        if (attempt > 10) { // 10 Intentos da un total de 27.500ms.
            throw new Error('Se alcanzo el numero maximo de reintentos');
        }

        console.log(`Reintentando en ${(500 * attempt) / 1000} segundos...`);
        await new Promise(resolve => setTimeout(resolve, 500 * attempt));
        await sendSnsM2Girador(input);
    }
}
