'use strict';
// createM2: recibe el M2 (JSON) del proveedor de pago y lo registra. Lógica en src/confirmacion-pago (ADR-001).
const confirmacionPago = require('./src/confirmacion-pago');

exports.handler = async (event) => {
    console.log('event: ', event);
    try {
        const entrada = confirmacionPago.desdeM2Json(JSON.parse(event.body));
        await confirmacionPago.registrar(entrada);
        const response = { statusCode: 200, body: 'OK' };
        console.log(response);
        return response;
    }
    catch (e) {
        console.log(e);
        return { statusCode: 400, body: JSON.stringify(e) };
    }
};
