'use strict';
const axios = require('axios');
const aws4 = require('aws4');
const xml2js = require('xml2js');
const stripNS = require('xml2js').processors.stripPrefix;
const queryDB = require('./aws/dynamoDbServices');

async function recibeM1(event, context, callback) {

    console.log(event);
    const options = {
        tagNameProcessors: [stripNS],
        explicitArray: false
    };
    var parser = new xml2js.Parser(options);
    var mensajeM1;

    // XML string to be parsed to JSON
    var xmlEntrada = event.body;

    // convert XML to JSON
    parser.parseString(xmlEntrada, (err, result) => {
        if (err) {
            throw err;
        }

        mensajeM1 = result;
        const json = JSON.stringify(result, null, 4);

        console.log(json);
    });

    try {
        //var validaSeguridad = await validaUsernameToken(mensajeM1);
        //console.log("validaUsernameToken" + validaSeguridad);
        var parametrosApiRecaud = await datosApiRecaudacion(mensajeM1);
        var respuestaApiRecaud = await llamadaApiRecaudacion(parametrosApiRecaud);
    }
    catch (e) {
        console.log("Error al Llamar a Api Recaudacion: " + e);
        sendError(e, callback);
        return;
    }
    console.log("Respuesta Api Recaudacion: " + respuestaApiRecaud);

    send(respuestaApiRecaud, callback);

}
exports.handler = recibeM1;

function llamadaApiRecaudacion(parametros) {

    return new Promise((resolve, reject) => {

        let request = {
            method: 'POST',
            host: process.env.API_AUTOSERVICIOS_HOST_SERVICE,
            path: '/recaudacion/v1/solicitudes2',
            url: 'https://' + process.env.API_AUTOSERVICIOS_HOST_SERVICE + '/recaudacion/v1/solicitudes2',
            service: 'execute-api',
            data: parametros,
            body: JSON.stringify(parametros),
            headers: { 'content-type': 'application/json' }
        };

        console.log("lLAMADO API_RECAUDACION:" + JSON.stringify(parametros));

        let signedRequest2 = aws4.sign(request, {
            secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
            accessKeyId: process.env.AWS_ACCESS_KEY_ID,
            sessionToken: process.env.AWS_SESSION_TOKEN
        });

        console.log(signedRequest2);

        delete signedRequest2.headers['Host'];
        delete signedRequest2.headers['Content-Length'];

        axios(signedRequest2)
            .then(function(response) {
                resolve(JSON.stringify(response.data));
            })
            .catch(function(error) {
                console.log(JSON.stringify(error));
                reject(JSON.stringify(error.response.data));
            });
    });
}

function send(resultadoServicio, callback) {

    const response = {
        statusCode: 200,
        headers: {
            "Access-Control-Allow-Credentials": true, // Required for cookies, authorization headers with HTTPS 
            'Content-Type': 'text/xml; charset=utf-8',
            'Server': 'Apache',
            'Pragma': 'no-cache',
            'Expires': 'Thu, 01 Jan 1970 00:00:00 GMT',
            'Cache-Control': 'no-cache',
            'Keep-Alive': 'timeout=5, max=100'
        }
    };


    const body = `<?xml version="1.0" encoding="utf-8"?>
    <SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
   <SOAP-ENV:Body>
      <ns:recibeM1Response xmlns:ns="http://www.openuri.org/">
         <ns:recibeM1Result>OK</ns:recibeM1Result>
      </ns:recibeM1Response>
   </SOAP-ENV:Body>
</SOAP-ENV:Envelope>`;

    response.body = body;

    console.log(response);

    callback(null, response);
}

function sendError(resultadoServicio, callback) {

    const response = {
        statusCode: 400,
        headers: {
            "Access-Control-Allow-Credentials": true, // Required for cookies, authorization headers with HTTPS 
            'Content-Type': 'text/xml; charset=utf-8',
            'Server': 'Apache',
            'Pragma': 'no-cache',
            'Expires': 'Thu, 01 Jan 1970 00:00:00 GMT',
            'Cache-Control': 'no-cache',
            'Keep-Alive': 'timeout=5, max=100'
        }
    };


    const body = `<?xml version="1.0" encoding="utf-8"?>
    <SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
   <SOAP-ENV:Body>
      <SOAP-ENV:Fault>
         <faultcode xmlns:fc="http://www.bea.com/2003/04/jwFaultCode/">fc:JWSError</faultcode>
         <faultstring>` + resultadoServicio + `</faultstring>
         <detail>
            <jwErr:jwErrorDetail xmlns:jwErr="http://www.bea.com/2002/04/jwErrorDetail/">` + resultadoServicio + `</jwErr:jwErrorDetail>
         </detail>
      </SOAP-ENV:Fault>
   </SOAP-ENV:Body>
</SOAP-ENV:Envelope>`;

    response.body = body;

    callback(null, response);
}

function getConceptoInstitucionFormulario(instit, formulario) {

    return new Promise((resolve, reject) => {
        let request = {
            method: 'GET',
            host: process.env.API_AUTOSERVICIOS_HOST_SERVICE,
            path: `/portal-autoservicios/v1/conceptos-all?institucion=${instit}`,
            service: 'execute-api'
        };


        let signedRequest2 = aws4.sign(request, {
            secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
            accessKeyId: process.env.AWS_ACCESS_KEY_ID,
            sessionToken: process.env.AWS_SESSION_TOKEN
        });

        axios({
                ...signedRequest2,
                url: `https://${request.host}${request.path}`,
            }).then(function(response) {
                resolve(buscaConceptoRecaudacion(response.data.data.conceptos, formulario));
            })
            .catch(function(error) {
                reject(JSON.stringify(error.response.data));
            });
    });

}

function buscaConceptoRecaudacion(dataConceptos, formulario) {
    let conceptoRecaudacion = "";
    let i;
    for (i = 0; i < dataConceptos.length; i++) {
        if (dataConceptos[i].formulario == formulario)
            conceptoRecaudacion = dataConceptos[i].idConcepto;
    }

    return conceptoRecaudacion;
}

async function datosApiRecaudacion(datosM1) {

    let recibeM1 = datosM1.Envelope.Body.recibeM1;
    let messageId = recibeM1.messageId;
    let idDeuda = recibeM1.deuda.IdDeuda;

    //Campos del M1 a transferir a la Api Recaudacion
    let institucion = messageId.From.toLocaleUpperCase();
    let idExterno = messageId.IdExt;
    let rutContribuyente = parseInt(idDeuda.Rut, 10);
    let rutContribuyenteDv = idDeuda.Dv;
    let moneda = idDeuda.Moneda;
    let monto = parseFloat(idDeuda.Monto);
    let formulario = idDeuda.Formulario;
    let folio = parseInt(idDeuda.Folio, 10);
    let conceptoRecaudacion;
    let items = recibeM1.deuda.DetalleDeuda.Item;
    let fechaHoy = new Date();

    try {
        conceptoRecaudacion = await getConceptoInstitucionFormulario(institucion, formulario);

        if (conceptoRecaudacion == "") {
            console.log("No se encontro Concepto Asociado " + institucion + ". " + formulario);
            throw "No se encontro Concepto Asociado " + institucion + ". " + formulario;
        }

    }
    catch (e) {
        console.log("Error al Buscar Conceptos: " + e);
        throw e;
    }

    let nombre = "";
    let apellidoPaternoORazonSocial = "";
    let receptorRut = "";
    let receptorRutDv = "";
    let banco = "";
    let nombreBanco = "";
    let cuentaTipo = "";
    let cuentaNumero = "";
    var getRutItem = function(rut) { return rut.substr(0, rut.indexOf("-")) };
    var getDvItem = function(rut) { return rut.substr(rut.indexOf("-") + 1) };
    var getTipoCuenta = function(tipoCuenta) {
        switch (tipoCuenta) {
            case "1":
                return "CUENTA_CORRIENTE";
            case "2":
                return "CUENTA_AHORRO";
            case "3":
                return "CUENTA_VISTA";
            case "31":
                return "CUENTA_CORRIENTE";
            default:
                return "0";
        }
    };

    for (let idx = 0; idx < items.length; idx++) {
        if (items[idx].Codigo == 62)
            apellidoPaternoORazonSocial = items[idx].Contenido;
        if (items[idx].Codigo == 33) {
            receptorRut = parseInt(getRutItem(items[idx].Contenido), 10);
            receptorRutDv = getDvItem(items[idx].Contenido);
        }
        if (items[idx].Codigo == 10)
            banco = parseInt(items[idx].Contenido, 10);
        if (items[idx].Codigo == 301)
            nombreBanco = items[idx].Contenido;
        if (items[idx].Codigo == 17)
            cuentaTipo = getTipoCuenta(items[idx].Contenido);
        if (items[idx].Codigo == 16)
            cuentaNumero = parseInt(items[idx].Contenido, 10);
    }

    var parametrosApiRecaud = {
        "metadata": {
            "sentDate": fechaHoy
        },
        "data": {
            "callbackURL": "https://www.google.cl",
            "conceptoRecaudacion": conceptoRecaudacion,
            "contribuyente": {
                "dv": rutContribuyenteDv,
                "rut": rutContribuyente
            },
            "recaudacion": {
                "moneda": moneda,
                "monto": monto
            },
            "receptor": {
                "apellidoPaternoORazonSocial": apellidoPaternoORazonSocial,
                "nombre": nombre,
                "dv": receptorRutDv,
                "rut": receptorRut,
                "cuentaDeposito": {
                    "banco": banco,
                    "nombreBanco": nombreBanco,
                    "numero": cuentaNumero,
                    "tipo": cuentaTipo
                }
            },
            "id": idExterno,
            "folio": folio,
            "institucion": institucion
        }
    };
    return parametrosApiRecaud;
}

/*
async function validaUsernameToken(mensajeM1) {

    let institucion = mensajeM1.Envelope.Body.recibeM1.messageId.From;
    let userName = mensajeM1.Envelope.Header.Security.UsernameToken.Username;
    let password = mensajeM1.Envelope.Header.Security.UsernameToken.Password;

    var paramsUserPassw = {
        TableName: process.env.PREFIX + "-m1-security",
        KeyConditionExpression: "institucion = :hkey",
        ExpressionAttributeValues: {
            ":hkey": institucion
        }
    };

    var datosConsultaDynamo = await queryDB.getItems(paramsUserPassw);

    if (datosConsultaDynamo.length < 1)
        throw "Usuario/Password no autorizado";

    let datosInstitucion = datosConsultaDynamo[0];

    console.log(datosInstitucion.userName + " : " + userName);
    console.log(datosInstitucion.password + " : " + password);


    if (datosInstitucion.userName == userName && datosInstitucion.password == password)
        return 1;
    else
        throw "Usuario/Password no autorizado";

}
*/
