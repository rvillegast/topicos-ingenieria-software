'use strict';
// Réplica genérica on-prem: M2 en XML por SNS -> createM2. Formato M2 en src/confirmacion-pago (ADR-001),
// tabla eventos en src/eventos (ADR-002).
import { Lambda } from "@aws-sdk/client-lambda";
let lambda = new Lambda({ region: process.env.AWS_REGION });

import { parseStringPromise } from 'xml2js';
import { OracleProvider } from 'tgr-sdk-layer/clients/dss.mjs';
let provider = new OracleProvider();

import confirmacionPago from './src/confirmacion-pago/index.js';
import eventos from './src/eventos/index.js';

export const handler = async (event) => {
    try {
        console.log('event: ', JSON.stringify(event));

        for (let record of event.Records) {
            console.log('record: ', record);
            let mensaje = JSON.parse(record.Sns.Message);
            console.log('mensaje: ', mensaje);
            let xml = record.Sns.Message.split('#')[2];
            if (record.Sns.Message.split('#').length != 5) {
                console.log('La estructura de la columna JSON ha variado, no contiene 4# de separación, el codigo necesita una estructura fija para extraer el XML');
                throw Error('La estructura de la columna JSON ha variado, no contiene 4# de separación, el codigo necesita una estructura fija para extraer el XML')
            }
            console.log('xml: ', xml);

            const inputCreateM2 = confirmacionPago.m2JsonDesdeXml(await parseStringPromise(xml), {
                idProcesoJsonDet: mensaje.ID_PROCESO_JSON_DET.N,
                reenvio: record.Sns.MessageAttributes.REENVIO ? record.Sns.MessageAttributes.REENVIO.Value : undefined
            });
            const { confirmacion } = confirmacionPago.desdeM2Json(inputCreateM2);
            const idRecaudacion = eventos.idPago(confirmacion.idSolicitud, confirmacion.idTransaccion);

            // Si el pago ya existe se reemplaza: se borra y createM2 lo vuelve a crear (E2 I1)
            const existentes = await eventos.buscarPorId(idRecaudacion);
            console.log('existentes: ', existentes);
            if (existentes.length > 0) {
                let paramsInvoke = {
                    FunctionName: `tgr-${process.env.ENV}-api-recaudacion-int-deleteRegistrosEventos`,
                    Payload: JSON.stringify({ idRecaudacion, fechaEventoRecaudacion: existentes[0].fechaEvento })
                }
                console.log('paramsInvoke: ', JSON.stringify(paramsInvoke));
                let respInvoke = await lambda.invoke(paramsInvoke);
                console.log('respInvoke: ', respInvoke);
            } else {
                console.log('nueva sincronizacion');
            }

            console.log('inputCreateM2: ', JSON.stringify(inputCreateM2));
            var params = {
                FunctionName: `tgr-${process.env.ENV}-api-recaudacion-int-createM2`,
                InvokeArgs: JSON.stringify({ body: JSON.stringify(inputCreateM2) })
            };
            let respInvokeAsync = await lambda.invokeAsync(params);
            console.log('respInvokeAsync: ', respInvokeAsync);

            let paramsDss = [
                {
                    "sql": "WEBTGR.pkg_envio_m2_dss.act_fecha_aceptacion( #ID_OPERACION, #ID_TRANSACCION, #SALIDA)",
                    "params": [
                        { "parameterType": "IN", "type": 2, "name": "#ID_OPERACION", "value": confirmacion.idOperacion },
                        { "parameterType": "IN", "type": 2, "name": "#ID_TRANSACCION", "value": confirmacion.idTransaccion },
                        { "parameterType": "OUT", "type": 12, "name": "#SALIDA" }
                    ]
                }
            ]
            console.log('paramsDss: ', JSON.stringify(paramsDss));
            let resultadoDss = await provider.call(paramsDss);
            console.log('resultadoDss: ', resultadoDss[0], resultadoDss[1]);
        }
    } catch (err) {
        console.log('err: ', err);
        throw err; // TD-011: relanzar para que SNS/Lambda registre el fallo y reintente
    }
};
