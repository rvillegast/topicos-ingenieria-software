let { docClient } = require('./aws/dynamoDbServices');
exports.handler = async(event) => {
    console.log("Entrada: " +JSON.stringify(event));
    let data = JSON.parse(event.body);
    let id = data.id;
    try {
        let paramsConfirmada = {
            TableName: `${process.env.PREFIX}-eventos`,
            ExpressionAttributeValues: {
                ':pk': id,
            },
            KeyConditionExpression: 'id = :pk'
        };
        //console.log("params Pago Confirmado: "+JSON.stringify(paramsConfirmada, null, 2));
        let dataPagoConfirmado = await docClient.query(paramsConfirmada).promise();
        //console.log("Salida consulta evento pago: "+JSON.stringify(dataPagoConfirmado, null, 2));
        if(dataPagoConfirmado.Items.length == 0){
            let error = {
                mensaje: 'NO_TRX',
            }
            throw error;
        }
        
        let estadoOp = data.estadoOp;
        let update;
        let fechaEvento;
        let idSub;
        
        fechaEvento = dataPagoConfirmado.Items[0].fechaEvento;
        idSub= dataPagoConfirmado.Items[0].id;
        update = {
            TableName: `${process.env.PREFIX}-eventos`,
            Key: {
                id: idSub,
                fechaEvento: fechaEvento
            },
            UpdateExpression: "set estado_op = :e1",
            ConditionExpression: "nombreEstado = :e2",
            ExpressionAttributeValues: {
                ":e1": estadoOp,
                ":e2": "PAGO_CONFIRMADO"
            }
        }
        await docClient.update(update).promise();
        
        let salida = {
            statusCode: 200,
            body: JSON.stringify({
                mensaje: 'OK',
            })
        }
        console.log('Salida: ' + JSON.stringify(salida));
        return salida;
    } catch (e) {
        let response = {
            statusCode: 400,
            body: JSON.stringify(e)
        };
        console.log('Error===>' + JSON.stringify(e));
        return response;
    }
};