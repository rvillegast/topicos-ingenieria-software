'use strict';
// Anti-Corruption Layer del mensaje M2 (confirmación de pago del proveedor). ADR-001.
// Único lugar que conoce la estructura Message.MessageId / Message.Confirmacion.Pago, en JSON y en XML.
// El resto del sistema usa `Confirmacion` v1 (E2 §3.1). El M2 original sigue persistiéndose como `payload`
// mientras existan consumidores legados (expand/contract, ADR-003); este módulo es el que lo modifica.
const moment = require('moment-timezone');

const ZONA = 'America/Santiago';

// M2 JSON (cuerpo de createM2) -> { confirmacion, legado }
function desdeM2Json(m2) {
    const id = m2.Message.MessageId;
    const pago = m2.Message.Confirmacion.Pago;
    return {
        legado: m2,
        confirmacion: {
            version: 1,
            idSolicitud: id.IdExt,
            idTransaccion: pago.IdTransaccion, // sin normalizar: la detección de reenvío compara por igualdad estricta
            idOperacion: pago.IdOperacion,
            folio: pago.Folio,
            formulario: pago.Formulario,
            fechaPago: pago.FechaPago,
            montoTotal: pago.TotalPago,
            medioPago: pago.Ira ? { codigo: pago.Ira.Codigo, nombre: pago.Ira.Nombre } : null,
            rutPagador: pago.Rut,
            tipoPago: pago.TipoPago === undefined ? null : pago.TipoPago,
            vencimiento: pago.Vencimiento,
            resultado: pago.Resultado,
            institucion: id.ToAddress,
            codigoInstitucionOnPrem: id.RefAddress === undefined ? null : id.RefAddress,
            // TD-012: DateTime trae 'Z' pero se interpreta como hora de Santiago (supuesto heredado de postM2, sin validar con el proveedor)
            emitidoEn: moment.tz(id.DateTime.substring(0, id.DateTime.length - 1), ZONA).toISOString(),
            origen: m2.flag === 'M2_GIRADOR' ? 'M2_XML_REPLICA' : 'M2_JSON',
            reenvio: m2.REENVIO !== undefined
        }
    };
}

// IdTransaccion de un registro PAGO_CONFIRMADO ya persistido (su payload es un M2 legado)
const idTransaccionDePayload = payload => payload.Message.Confirmacion.Pago.IdTransaccion;

// Copias del M2 legado para persistir (no mutan el original: en carrito se persiste uno por trámite)
const conPago = (legado, cambios) => ({
    ...legado,
    Message: { ...legado.Message, Confirmacion: { ...legado.Message.Confirmacion, Pago: { ...legado.Message.Confirmacion.Pago, ...cambios } } }
});
const conFolioNumerico = legado => conPago(legado, { Folio: Number(legado.Message.Confirmacion.Pago.Folio) });
const conTotal = (legado, monto) => conPago(legado, { TotalPago: monto });
const conConcepto = (legado, concepto) => conPago(legado, { conceptoRecaudacion: concepto });

// M2 XML de la réplica on-prem (ya parseado por xml2js) -> M2 JSON para createM2
function m2JsonDesdeXml(xml, { idProcesoJsonDet, reenvio }) {
    const id = xml.Message.MessageId[0];
    const pago = xml.Message.Confirmacion[0].Pago[0];
    return {
        Message: {
            MessageId: {
                Status: id.Status[0],
                DateTime: fechaXmlAIso(id.DateTime[0]),
                Number: Number(id.Number[0]),
                FromAddress: id.FromAddress[0],
                MsgDesc: id.MsgDesc[0],
                IdExt: id.IdExt[0],
                Version: Number(id.Version[0]),
                Code: id.Code[0],
                RefAddress: Number(id.RefAddress[0]),
                ToAddress: id.ToAddress[0]
            },
            Confirmacion: {
                Pago: {
                    Folio: Number(pago.Folio[0]),
                    IdTransaccion: Number(pago.IdTransaccion[0]),
                    Rut: Number(pago.Rut[0]),
                    TipoPago: pago.TipoPago ? pago.TipoPago[0] : undefined,
                    Ira: { Codigo: Number(pago.Ira[0].Codigo[0]), Nombre: pago.Ira[0].Nombre[0] },
                    Vencimiento: pago.Vencimiento[0],
                    Formulario: Number(pago.Formulario[0]),
                    Resultado: Number(pago.Resultado[0]),
                    FechaPago: fechaXmlAIso(pago.FechaPago[0]),
                    IdOperacion: Number(pago.IdOperacion[0]),
                    TotalPago: Number(pago.TotalPago[0])
                }
            }
        },
        flag: 'M2_GIRADOR',
        ID_PROCESO_JSON_DET: idProcesoJsonDet,
        REENVIO: reenvio
    };
}

// 'DD-MM-YYYY HH:mm:ss' (hora de Santiago) -> ISO UTC.
// TD-012: suma el desfase de Santiago VIGENTE AL EJECUTAR, no el de la fecha del pago (error de 1 h entre
// períodos de horario de verano). Se preserva para no cambiar comportamiento en el slice.
function fechaXmlAIso(input) {
    let [datePart, timePart] = input.split(' ');
    if (timePart == undefined) {
        timePart = '00:00:00';
    }
    const [day, month, year] = datePart.split('-');
    const fechaISO = new Date(`${year}-${month}-${day}T${timePart}`).toISOString();
    const gmtCH = Math.abs(moment.tz(ZONA).utcOffset());
    return `${moment.tz(fechaISO, 'UTC').add(gmtCH, 'm').format('YYYY-MM-DDTHH:mm:ss')}.000Z`;
}

module.exports = { desdeM2Json, idTransaccionDePayload, conFolioNumerico, conTotal, conConcepto, m2JsonDesdeXml };
