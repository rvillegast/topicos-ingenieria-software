'use strict';
// ConfirmacionPago: registra de forma idempotente la confirmación de pago de una solicitud (E2 §3.1, ADR-001).
// Secreto: reglas unitario / carrito / on-prem, detección de reenvío y cuándo abonar billetera.
// El formato del proveedor queda en ./adaptadores/m2.js; la tabla y sus claves en ../eventos.
const m2 = require('./adaptadores/m2');
const eventos = require('../eventos');
const institucion = require('../institucion');
const billetera = require('../integraciones/billetera');

const RECHAZO_ABONO = { statusCode: 400, body: 'NOK' };

// I1: un (solicitud, idTransaccion) se registra a lo sumo una vez. Compara contra `confirmacion` v1; los registros
// anteriores a ADR-003 (expand) solo tienen el M2 legado en `payload`.
const idTransaccionRegistrada = i => (i.confirmacion ? i.confirmacion.idTransaccion : m2.idTransaccionDePayload(i.payload));
const esReenvio = (items, idTransaccion) => items.some(i =>
    i.nombreEstado === 'PAGO_CONFIRMADO' && idTransaccionRegistrada(i) === idTransaccion);

// `payload` (M2 legado) solo si la confirmación vino en M2. AGENTS.md Q8: sigue siendo obligatorio para proveedores
// nuevos mientras los lectores legados lo recorran (TD-015)
const siHayLegado = (legado, f) => (legado ? f(legado) : undefined);

// ponytail: despacho por función con 3 casos estables; Strategy no agrega variabilidad (E2 §6)
function tipoDeRegistro(recibidas) {
    const esCarrito = recibidas.some(r => typeof r.payload.data.idTramite !== 'undefined'); // TD-025: 1 RECIBIDA con trámite = carrito (test 2)
    if (recibidas.length === 1 && !esCarrito) return 'UNITARIO';
    if (recibidas.length > 0 && esCarrito) return 'CARRITO';
    return 'ON_PREMISE'; // sin RECIBIDA, o varias RECIBIDA sin trámite (TD-025, test 12)
}

// I5: si el abono falla, no se persiste el pago
async function abonar(recibida, id, fechaPago, institucionDestino) {
    const respuesta = await billetera.abonarBilletera({ ...recibida, id, numeroSolicitudRecaudacion: id, fechaPago }, institucionDestino);
    console.log('Respuesta abono:', respuesta);
    if (typeof respuesta.errors !== 'undefined') throw RECHAZO_ABONO;
}

async function unitario(c, legado, recibida) {
    const id = eventos.idPago(c.idSolicitud, c.idTransaccion);
    const idBilletera = recibida.payload.data.recaudacion.idBilletera;
    if (typeof idBilletera !== 'undefined') {
        console.log('Se abona a la billetera: ' + idBilletera);
        await abonar(recibida, id, c.fechaPago, c.institucion); // TD-010 corregido: antes `callback` inexistente
    }
    const payload = siHayLegado(legado, m2.conFolioNumerico);
    const item = {
        id, folio: Number(c.folio), payload, confirmacion: { ...c, folio: Number(c.folio) },
        institucion: c.institucion, url: recibida.payload.data.callbackURL, environment: recibida.environment,
        institucionEnvironment: eventos.institucionEnvironment(recibida.institucion, recibida.environment)
    };
    if (recibida.formulario) item.formulario = recibida.formulario;
    if (recibida.codigoInstitucionOnPrem) item.codigoInstitucionOnPrem = recibida.codigoInstitucionOnPrem;
    await eventos.registrarPagoConfirmado(item);
}

async function carrito(c, legado, recibidas) {
    // TD-013 (tests 3 y 9): se abona y persiste trámite por trámite; un rechazo a mitad deja los anteriores
    for (const r of recibidas) {
        if (typeof r.payload.data.idBilletera !== 'undefined') {
            console.log('Se abona a la billetera: ' + r.payload.data.idBilletera);
            await abonar(r, eventos.idAbonoTramite(r.id, c.idTransaccion), c.fechaPago, c.institucion);
        }
        const monto = r.payload.data.recaudacion.monto;
        const item = {
            id: eventos.idPagoTramite(r.id, c.idTransaccion), folio: r.folio,
            payload: siHayLegado(legado, l => m2.conTotal(l, monto)), confirmacion: { ...c, montoTotal: monto, folio: r.folio },
            institucion: c.institucion, url: r.url, environment: r.environment, institucionEnvironment: r.institucionEnvironment
        };
        if (r.formulario) item.formulario = r.formulario;
        if (r.codigoInstitucionOnPrem) item.codigoInstitucionOnPrem = r.codigoInstitucionOnPrem;
        await eventos.registrarPagoConfirmado(item);
    }
}

async function onPremise(c, legado) {
    const concepto = await institucion.conceptoPorFormulario(c.formulario, c.institucion);
    console.log('Concepto para formulario ' + c.formulario + ': ' + concepto);
    const payload = siHayLegado(legado, l => m2.conConcepto(m2.conFolioNumerico(l), concepto));
    const item = {
        id: eventos.idPago(c.idSolicitud, c.idTransaccion), folio: Number(c.folio), payload,
        confirmacion: { ...c, folio: Number(c.folio), conceptoRecaudacion: concepto },
        institucion: c.institucion, environment: 'PRODUCCION',
        institucionEnvironment: eventos.institucionEnvironment(c.institucion, 'PRODUCCION'),
        flag: legado && legado.flag ? legado.flag : undefined
    };
    if (c.codigoInstitucionOnPrem) item.codigoInstitucionOnPrem = c.codigoInstitucionOnPrem;
    await eventos.registrarPagoConfirmado(item);
}

// -> 'REGISTRADA' | 'REENVIO'. Lanza { statusCode: 400, body: 'NOK' } si billetera rechaza el abono.
async function registrar({ confirmacion: c, legado }) {
    const items = await eventos.buscarPorSolicitud(c.institucion, c.idSolicitud);
    const recibidas = items.filter(i => i.nombreEstado === 'RECIBIDA');
    const tipo = tipoDeRegistro(recibidas);
    console.log(`Registro ${tipo}: ${c.idSolicitud}#${c.idTransaccion}`);

    if (esReenvio(items, c.idTransaccion)) {
        console.log('Mensaje con reenvío');
        return 'REENVIO';
    }
    if (tipo === 'UNITARIO') await unitario(c, legado, recibidas[0]);
    else if (tipo === 'CARRITO') await carrito(c, legado, recibidas);
    else await onPremise(c, legado);
    return 'REGISTRADA';
}

module.exports = { registrar, desdeM2Json: m2.desdeM2Json, m2JsonDesdeXml: m2.m2JsonDesdeXml };
