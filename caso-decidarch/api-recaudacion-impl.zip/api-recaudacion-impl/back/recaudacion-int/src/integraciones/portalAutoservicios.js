'use strict';
// Adaptador del portal de autoservicios (API Gateway firmada con SigV4).
const axios = require('axios');
const aws4 = require('aws4');

function get(path) {
    const request = { method: 'GET', host: process.env.API_AUTOSERVICIOS_HOST_SERVICE, path, service: 'execute-api' };
    const firmado = aws4.sign(request, {
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        sessionToken: process.env.AWS_SESSION_TOKEN
    });
    return axios({ ...firmado, url: `https://${request.host}${request.path}` });
}

// Conceptos asociados a un formulario de una institución: [{ idConcepto, etapa, ... }]
async function conceptosPorFormulario(formulario, institucion) {
    const r = await get(`/portal-autoservicios/v1/formularios?formulario=${formulario}&institucion=${institucion}`);
    return r.data.data.concepto.Items;
}

module.exports = { conceptosPorFormulario };
