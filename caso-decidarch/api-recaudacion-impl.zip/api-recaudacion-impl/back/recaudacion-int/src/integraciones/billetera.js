const Services = require('../../utils/service');
const Utils = require('../../utils/util');

// Máxima cantidad de intentos de abono a billetera
const MAX_RETRIES = 3;

const abonarBilletera = async (dataEntrada, institucion, intento) => {
    console.log("dataEntrada M1: ", dataEntrada);
    console.log(`Intento #${(intento || 0) + 1}`)
    let idBilleteraProcess;
    if (dataEntrada.payload.data.recaudacion.idBilletera) {
        idBilleteraProcess = dataEntrada.payload.data.recaudacion.idBilletera
    } else {
        idBilleteraProcess = dataEntrada.payload.data.idBilletera
    }

    let walletParameters = await Utils.getParametrosSSM(process.env.SSM_WALLET_PATH);
    let path = walletParameters.get('api-billetera-interna-path');
    let pathToken = walletParameters.get('api-billetera-path');
    let host = walletParameters.get('service-host');

    let body = {
        data: {
            transaccion: {
                idExterno: dataEntrada.id,
                tipo: 'Abono',
                monto: dataEntrada.payload.data.recaudacion.monto,
                institucion,
                fechaPago: dataEntrada.fechaPago,
                conceptoRecaudacion: dataEntrada.payload.data.conceptoRecaudacion
            }
        }
    }

    let data = {
        request: {
            path: path + '/billeteras/' + idBilleteraProcess + '/transacciones',
            body
        },
        token: {
            host,
            pathToken,
            credentials: {
                grant_type: 'client_credentials',
                client_id: walletParameters.get('client-id-billetera'),
                client_secret: walletParameters.get('client-secret-billetera'),
                scope: walletParameters.get('scope-billetera')
            }
        },
        method: 'POST'
    }

    data.request.host = host;
    let response = await Services.post(data);
    if (response.statusCode === 200 || response.statusCode === 201) {
        return response.content;
    }
    if ((intento || 0) >= MAX_RETRIES) {
        console.log("Demasiados intentos de abono a billetera:", (intento || 0) + 1);
        return response.content;
    }
    await new Promise((resolve) => setTimeout(resolve, 500 * ((intento || 0) + 1)));
    return await abonarBilletera(dataEntrada, institucion, (intento || 0) + 1);
}

module.exports.abonarBilletera = abonarBilletera;
