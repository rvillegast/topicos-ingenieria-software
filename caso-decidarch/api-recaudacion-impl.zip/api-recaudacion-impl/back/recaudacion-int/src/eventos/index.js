'use strict';
// EventosRecaudacion: owner único de la tabla `eventos` (ADR-002). Oculta nombre de tabla, índices y
// composición de claves. ponytail: módulo simple sin interfaz de repositorio; en tests, moduleNameMapper
// reemplaza el DocumentClient por test-support/fakeDynamo.js.
const { DocumentClient } = require('aws-sdk/clients/dynamodb');

const enTest = process.env.JEST_WORKER_ID || process.env.IS_SERVERLESS_OFFLINE === 'true';
const docClient = new DocumentClient(enTest
    ? { convertEmptyValues: true, endpoint: 'localhost:8000', sslEnabled: false, region: 'local-env' }
    : { region: process.env.AWS_REGION });


// Claves compuestas
const idPago = (idSolicitud, idTransaccion) => `${idSolicitud}#${idTransaccion}`;
const partes = idRecibida => idRecibida.split('#');
const idPagoTramite = (idRecibida, idTransaccion) => `${partes(idRecibida)[0]}#${partes(idRecibida)[1]}#${idTransaccion}`;
// TD-025: el id que se informa a billetera ordena las partes distinto que el id persistido (test 3)
const idAbonoTramite = (idRecibida, idTransaccion) => `${partes(idRecibida)[0]}#${idTransaccion}#${partes(idRecibida)[1]}`;
const institucionEnvironment = (institucion, environment) => `${institucion}#${environment}`;

// Todos los eventos (RECIBIDA y PAGO_CONFIRMADO) de una solicitud de una institución
async function buscarPorSolicitud(institucion, idSolicitud) {
    const r = await docClient.query({
        TableName: `${process.env.PREFIX}-eventos`,
        IndexName: `${process.env.PREFIX}-ids-idx`,
        ExpressionAttributeValues: { ':pk': `${institucion}`, ':id': `${idSolicitud}` },
        KeyConditionExpression: 'institucion = :pk and begins_with(id, :id)'
    }).promise();
    return r.Items;
}

async function buscarPorId(id) {
    const r = await docClient.query({
        TableName: `${process.env.PREFIX}-eventos`,
        KeyConditionExpression: 'id = :id',
        ExpressionAttributeValues: { ':id': id }
    }).promise();
    return r.Items;
}

// `item` ya trae sus claves; aquí se fijan estado, numeroSolicitud y fecha de registro
async function registrarPagoConfirmado(item) {
    const Item = { ...item, nombreEstado: 'PAGO_CONFIRMADO', numeroSolicitudRecaudacion: item.id, fechaEvento: new Date().toISOString() };
    try {
        await docClient.put({ TableName: `${process.env.PREFIX}-eventos`, Item }).promise();
    } catch (err) {
        console.log(err);
        throw { errors: [{ statusCode: 500, message: 'Error al persistir en DynamoDB' }] };
    }
    return Item;
}

module.exports = {
    buscarPorSolicitud, buscarPorId, registrarPagoConfirmado,
    idPago, idPagoTramite, idAbonoTramite, institucionEnvironment
};
