'use strict';
// Institucion: reglas para resolver datos de una institución (E2 §2). En el slice, solo el concepto por formulario.
const portal = require('../integraciones/portalAutoservicios');

// Concepto en PRODUCCION del formulario; si la institución no tiene conceptos, `GENERICO_<institucion>`.
// TD-024: si hay conceptos pero ninguno en PRODUCCION, falla (TypeError) igual que el código original (test 11).
async function conceptoPorFormulario(formulario, institucion) {
    const items = await portal.conceptosPorFormulario(formulario, institucion);
    if (items[0]) {
        return items.filter(i => i.etapa === 'PRODUCCION')[0].idConcepto;
    }
    return `GENERICO_${institucion}`;
}

module.exports = { conceptoPorFormulario };
