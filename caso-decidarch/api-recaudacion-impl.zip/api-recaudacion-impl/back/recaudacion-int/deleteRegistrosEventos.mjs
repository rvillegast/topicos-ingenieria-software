'use strict';
import { DynamoDB } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocument } from "@aws-sdk/lib-dynamodb";
const documentClient = DynamoDBDocument.from(new DynamoDB({region: 'us-east-1'}));

export const handler = async (event) => {
    try {
        console.log('event: ', JSON.stringify(event));
        let params = {
            TableName: `tgr-${process.env.ENV}-api-recaudacion-eventos`,
            Key: {
                id: event.idRecaudacion,
                fechaEvento: event.fechaEventoRecaudacion,
            },
            ReturnValues: 'ALL_OLD'
        };
        console.log('params: ', params);

        let resp = await documentClient.delete(params);
        console.log('registro eliminado: ', resp);
    } catch (err) {
        console.log('err: ', err);
    };
}
