const AWS = require('aws-sdk');
AWS.config.update({
    region: "us-east-1"
});

// const NodeCache = require("node-cache");
// const parametrosSSMCache = new NodeCache();
let parametrosSSMCache = {};

const parameterStore = new AWS.SSM();

exports.getParametrosSSM = (prefix) => {

    if (parametrosSSMCache['key']) {
        console.log('Utilizando cache parametrosSSMCache para obtener datos');
        return Promise.resolve(parametrosSSMCache['key']);
        //return Promise.resolve(parametrosSSMCache.get('key'));
    }
    else {
        return new Promise((resolve, reject) => {
            let params = {
                Path: prefix.replace("${env}", process.env.ENV),
                Recursive: true,
                WithDecryption: true
            };

            parameterStore.getParametersByPath(params, function(err, data) {
                if (err) {
                    console.log(err, err.stack); // an error occurred
                    reject(err);
                }
                else {
                    console.log(data);
                    let map = new Map();
                    for (let item of data.Parameters) {
                        map.set(item.Name.replace(prefix, ''), item.Value);
                    }
                    console.log('Sin uso de cache parametrosSSMCache para obtener datos');
                    //parametrosSSMCache.set('key', map, 10000);
                    parametrosSSMCache['key'] = map;
                    return resolve(map);
                }
            });
        });
    }
}
