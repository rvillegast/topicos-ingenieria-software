const https = require('https');
const _ = require('lodash');
const token = require('./tokenBilletera');

exports.post = async function(data) {
    let resp;
    try {
        let req = data.request.body;
        let access_token = await token.obtenerToken(data.token);
        let path = data.request.path;
        let host = data.request.host;
        let method = data.method;
        resp = await httpRequest(host, path, access_token, method, req);
    }
    catch (e) {
        console.error("[error] request: " + e);
        resp = { statusCode: 400, content: { errors: { message: "Error" } } };
    }
    return resp;

};


function httpRequest(host, path, token, method, obj) {
    console.log("req: " + JSON.stringify(obj));
    let postData = JSON.stringify(obj);
    let options = {
        hostname: host,
        port: 443,
        path: path,
        method: method,
        headers: {
            'Authorization': token,
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(postData)
        }
    };

    let respuesta = "";
    return new Promise((resolve, reject) => {
        let req = https.request(options, (res) => {
            res.on('data', (d) => {
                respuesta += d;
            });

            res.on('end', () => {
                try {
                    console.log('Respuesta: ' + respuesta);
                    if (JSON.parse(respuesta) != null) {
                        resolve({
                            statusCode: res.statusCode,
                            headers: res.headers,
                            content: JSON.parse(respuesta)
                        });
                    }
                }
                catch (error) {
                    console.log("error al llamar al servicio :" + error);
                    reject(error);
                }

            });
        });
        req.on('error', (e) => {
            console.error(e);
            reject(e);
        });
        req.write(postData);
        req.end();
    });
}
