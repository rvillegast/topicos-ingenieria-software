const { lambda } = require('../aws/lambda.js');

module.exports.putMetricPagoConfirmado= async function (nameSpace, service, metric, estado, jsonArray  ){
     
    const jsonMetric = {
        body: {
            nameSpace: nameSpace,
            dimensions: {
                Service: service,
                Estado: estado
            },
            metric: {
                metricName: metric,
                value: 1,
                unit: "Count"
            },
            property: jsonArray
        }
    };
        
    console.log (jsonMetric);
    await lambda.asyncInvoke(`${process.env.PREFIX}-int-metrica`, jsonMetric); 

    return ("putMetric ejecutado");   
};
