'use strict';

import momentTZ from 'moment-timezone';
import axios from 'axios';
import { OracleProvider } from 'tgr-sdk-layer/clients/dss.mjs';
let provider = new OracleProvider();

export const handler = async (event) => {

  console.log('event: ', event);

  let msg;
  let response = {
    statusCode: null,
    body: null
  };

  try {
    let pagosCuadratura = await getPagosCuadrados();

    let idxMarcadosOK = 0;
    let idxMarcadosNOK = 0;

    if (pagosCuadratura != null && pagosCuadratura.length > 0) {

      let nroTrxEnviarParalelo = 10;

      while (pagosCuadratura.length > 0) {
        let trxEnviar = pagosCuadratura.slice(0, nroTrxEnviarParalelo);
        pagosCuadratura = pagosCuadratura.slice(nroTrxEnviarParalelo);

        let promises = [];

        for (let i = 0; i < trxEnviar.length; i++) {
          promises.push(marcarEstadoCuadrado(trxEnviar[i].I, trxEnviar[i].F, trxEnviar[i].M, trxEnviar[i].N, trxEnviar[i].PK, trxEnviar[i].O, trxEnviar[i].T, trxEnviar[i].A));
        }

        await Promise.all(promises)
          .then((results) => {
            for (let k = 0; k < results.length; k++) {
              if (results[k] == "OK") idxMarcadosOK = idxMarcadosOK + 1;
              else idxMarcadosNOK = idxMarcadosNOK + 1;
            }
          })
          .catch((e) => {
            console.log("Error en Marcas: " + e);
          });
      }
      msg = "Resultado Marca Estado Cuadratura. OK: " + idxMarcadosOK + " NOK: " + idxMarcadosNOK;
    } else {
      msg = "No se reciben Pagos para Cuadrar";
    }

    console.log(msg);
    response.statusCode = 200;
    response.body = JSON.stringify({ mensaje: msg });
  } catch (e) {
    console.log("Excepcion en proceso: " + e.message);
    response.statusCode = 500;
    response.body = JSON.stringify({ mensaje: "Excepcion en proceso: " + e.message });
  }
  return response;
}

async function getPagosCuadrados() {

  let resultado;

  let params = [{
    "sql": "RECA.PKG_ESTADO_CUAD_API_RECAUD.GET_PAGOS_CUADRADOS(fechaRecaudacion, pageSeq, pageSize,cursorSalida);",
    "params": [{
        "parameterType": "IN",
        "type": 2,
        "name": "fechaRecaudacion",
        "value": "20000101"
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "pageSeq",
        "value": 10
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "pageSize",
        "value": 10
      },
      {
        "parameterType": "OUT",
        "type": -10,
        "name": "cursorSalida"
      }
    ]
  }];

  try {
    resultado = await provider.call(params);
    console.log('resultado: ', JSON.stringify(resultado));
    console.log('Consulta Transacciones Cuadratura.Cantidad :', resultado[0].cursorSalida.length);
  } catch (e) {
    console.log("Exception en getPagosCuadrados: " + e.message);
    throw e;
  }

  return resultado[0].cursorSalida;
}

async function marcarEstadoCuadrado(id, formulario, monto, institucion, idTran, idOperacion, idTransaccion, avisado) {
  let resultado;
  let resultadoMarca;
  let msgMarca;
  let estadoMarca;

  let idUnico;

  if (formulario == 100)
    idUnico = id;
  else
    idUnico = id + '#' + idTransaccion;

  try {
    resultadoMarca = await invocaLambdaCuadratura(idUnico, formulario, monto, institucion, "ONLINE");
    console.log("resultadoCuadratura:" + resultadoMarca);
  } catch (e) {
    console.log("Error en envio cuadratura:" + e.message);

    resultadoMarca = "NOK";
  }

  if (resultadoMarca == "OK") {
    resultado = "OK";
    msgMarca = "OK_ONLINE";
  } else {
    resultado = "NOK";
    msgMarca = "NOK";

    if (resultadoMarca == "NO_TRX") {
      let resultadoM2 = await enviaM2(id, formulario, monto, idOperacion, idTransaccion);
      console.log("Reenvio M2:" + JSON.stringify(resultadoM2));
      if (resultadoM2 == "OK") {

        //Debemos esperar unos milisegundos por problema de consistencia de la la Dynamo. (detectado en produccion)
        await sleep(500);

        resultadoMarca = await invocaLambdaCuadratura(idUnico, formulario, monto, institucion, "OFFLINE");
        console.log("resultadoCuadratura:" + resultadoMarca);

        if (resultadoMarca == "OK") {
          resultado = "OK";
          msgMarca = "OK_OFFLINE";
        }
      }
    }
  }

  if (msgMarca == "NOK")
    estadoMarca = 1;
  else
    estadoMarca = 0;

  let resultadoEnvioTierra = await enviaResultadoTierra(idTran, id, idOperacion, idTransaccion, avisado, estadoMarca, msgMarca);

  if (resultadoEnvioTierra != 0) {
    resultado = "NOK";
  }

  console.log("Termina Marca Cuadratura: " + id + "-" + formulario + "-" + monto + "-" + institucion + "-" + resultado);
  return resultado;
}

function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

async function invocaLambdaCuadratura(id, formulario, monto, institucion, tipoCuadratura) {

  let resultado;
  let mensajeCuadratura = {
    id: id,
    formulario: formulario,
    monto: monto,
    institucion: institucion,
    tipoCuadratura: tipoCuadratura
  };

  let request = {
    method: 'POST',
    url: 'https://' + process.env.API_AUTOSERVICIOS_HOST_SERVICE + '/recaudacion-interno/v1/iras/cuadraturas',
    data: JSON.stringify(mensajeCuadratura),
    headers: { 'content-type': 'application/json' }
  };

  await axios(request).then(function (response) {
      console.log(JSON.stringify(response.data));
      resultado = "OK";
    })
    .catch(function (error) {
      console.log("Respuesta lambda cuadraturas:" + error.message);
      if (error.response.status == 400)
        resultado = error.response.data.mensaje;
      else
        resultado = "NOK";

    });

  return resultado;
}

async function getDatosM2(id, formulario, monto, idOperacion, idTransaccion) {

  let resultado;
  let params = [{
    "sql": "RECA.PKG_ESTADO_CUAD_API_RECAUD.get_datos_m2(id_externo, formulario, monto, idOperacion, idTransaccion, cursorSalida);",
    "params": [{
        "parameterType": "IN",
        "type": 12,
        "name": "id_externo",
        "value": id
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "formulario",
        "value": formulario
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "monto",
        "value": monto
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "idOperacion",
        "value": idOperacion
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "idTransaccion",
        "value": idTransaccion
      },
      {
        "parameterType": "OUT",
        "type": -10,
        "name": "cursorSalida"
      }
    ]
  }];

  try {
    resultado = await provider.call(params);
  } catch (e) {
    console.log("Excepcion al consultar M2 en base de datos:" + e);
  }

  if (resultado != null && resultado[0].cursorSalida.length > 0)
    return resultado[0].cursorSalida[0];
  else
    throw "No se encontro M2 en base de datos";
}

async function enviaM2(id, formulario, monto, idOperacion, idTransaccion) {
  let resultado;

  try {

    let datosM2 = await getDatosM2(id, formulario, monto, idOperacion, idTransaccion);
    //console.log("Fecha pago Tabla: " + datosM2.FECHA_PAGO);

    //Se asigna como UTC para que la fecha se conserve igual
    //a como llega desde la lista_pagos
    let fechaPago = momentTZ.tz(datosM2.FECHA_PAGO, "UTC");
    //console.log("Fecha pago sin modificaciones: " + fechaPago.format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]"));

    //Se clona y se obtiene la diferencia en minutos entre Santiago y UTC
    let offSetUTC = fechaPago.clone().tz("America/Santiago").utcOffset();
    //console.log("offSet: " + offSetUTC);

    //Se obtiene la fecha UTC y se le da el formato correcto
    let fechaPagoUTC = fechaPago.add(Math.abs(offSetUTC), 'minutes').format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]"); //yyyy-MM-dd'T'HH:mm:ss.SSS'Z'
    //console.log("Fecha pago UTC: " + fechaPagoUTC);

    let mensajeM2 = {
      "Message": {
        "MessageId": {
          "Status": "OK",
          "DateTime": new Date(),
          "Number": 1,
          "FromAddress": "TESORERIA",
          "MsgDesc": "Confirma Pago",
          "IdExt": datosM2.ID_EXTERNO,
          "Version": 1,
          "Code": "M2",
          "RefAddress": datosM2.NUMERO_GIRADOR,
          "ToAddress": datosM2.NOMBRE_GIRADOR
        },
        "Confirmacion": {
          "Pago": {
            "Folio": datosM2.FOLIO,
            "IdTransaccion": datosM2.ID_TRANSACCION,
            "Rut": datosM2.RUT_ROL,
            "TipoPago": "E",
            "Ira": {
              "Codigo": datosM2.COD_IRA,
              "Nombre": datosM2.NOMBRE_IRA
            },
            "Vencimiento": datosM2.FECHA_VENCIMIENTO,
            "Formulario": datosM2.FORMULARIO,
            "Resultado": 0,
            "FechaPago": fechaPagoUTC,
            "IdOperacion": datosM2.ID_OPERACION,
            "TotalPago": datosM2.TOTAL_PAGAR
          }
        }
      }
    };

    let request = {
      method: 'POST',
      url: 'https://' + process.env.API_AUTOSERVICIOS_HOST_SERVICE + '/recaudacion-interno/v1/giradores/m2/createM2',
      service: 'execute-api',
      data: JSON.stringify(mensajeM2),
      headers: { 'content-type': 'application/json' }
    };
    await axios(request);
    resultado = "OK";
  } catch (e) {
    resultado = "NOK";
    console.log("Error en envio M2: " + e);
  }

  return resultado;
}

async function enviaResultadoTierra(idTran, idExterno, idOperacion, idTransaccion, avisado, estadoMarca, msgMarca) {

  let resultado;
  let params = [{
    "sql": "RECA.PKG_ESTADO_CUAD_API_RECAUD.ACTUALIZA_TABLAS(idTrnTran, idExterno, idOperacion, idTransaccion, avisado, estadoMarca, msgMarca,outResultado);",
    "params": [{
        "parameterType": "OUT",
        "type": 2,
        "name": "outResultado"
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "idTrnTran",
        "value": idTran
      },
      {
        "parameterType": "IN",
        "type": 12,
        "name": "idExterno",
        "value": idExterno
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "idOperacion",
        "value": idOperacion
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "idTransaccion",
        "value": idTransaccion
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "avisado",
        "value": avisado
      },
      {
        "parameterType": "IN",
        "type": 2,
        "name": "estadoMarca",
        "value": estadoMarca
      },
      {
        "parameterType": "IN",
        "type": 12,
        "name": "msgMarca",
        "value": msgMarca
      }
    ]
  }];

  try {
    resultado = await provider.call(params);
    console.log("resultadoEnvioTierra: " + JSON.stringify(resultado));

  } catch (e) {
    console.log("Excepcion al enviaResultadoTierra:" + e);
  }

  if (resultado != null)
    return resultado[0].outResultado;
  else
    throw "Excepcion al enviaResultadoTierra Objeto de salida nulo";
}
