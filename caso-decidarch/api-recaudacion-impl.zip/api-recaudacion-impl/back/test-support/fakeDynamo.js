'use strict';
// DocumentClient en memoria para tests: reemplaza DynamoDB Local (que exige Java).
// Compartido por back/recaudacion y back/recaudacion-int (vía moduleNameMapper de jest).
// Esquema de tablas e índices: recaudacion-int/jest-dynamodb-config.js + tablas extra abajo.
// Los nombres se normalizan sin ambiente (tgr-dev-x == tgr-lab-x) porque los tests usan PREFIX distintos.
// ponytail: solo soporta las expresiones que usa el código (=, <, <=, >, >=, begins_with, BETWEEN, AND, set);
// sin paginación (Limit/ExclusiveStartKey se ignoran). Ampliar si un test lo necesita.
const { tables } = require('../recaudacion-int/jest-dynamodb-config');

const EXTRA = [
    // tgr-{ENV}-conceptos-instituciones: owner externo (portal autoservicios), se lee por idConcepto
    { TableName: 'tgr-dev-conceptos-instituciones', KeySchema: [{ AttributeName: 'idConcepto', KeyType: 'HASH' }] },
];

const logical = name => String(name).replace(/^tgr-[a-z]+-/, '');
const schemas = {};
for (const t of [...tables, ...EXTRA]) {
    const keys = ks => ks.map(k => k.AttributeName);
    schemas[logical(t.TableName)] = { keys: keys(t.KeySchema), indexes: {} };
    for (const i of t.GlobalSecondaryIndexes || []) schemas[logical(t.TableName)].indexes[logical(i.IndexName)] = keys(i.KeySchema);
}

let store = {};
const reset = () => { store = {}; };

function awsError(code, message) {
    const e = new Error(message);
    e.code = code;
    return e;
}

function schemaOf(name) {
    if (!schemas[logical(name)]) throw awsError('ResourceNotFoundException', `fakeDynamo: tabla no definida: ${name}`);
    return schemas[logical(name)];
}

const rows = name => (store[logical(name)] ||= new Map());
const keyOf = (name, item) => JSON.stringify(schemaOf(name).keys.map(k => item[k]));
const clone = o => JSON.parse(JSON.stringify(o));

// Evalúa expresiones de condición: a = :v, begins_with(a, :v), a BETWEEN :x AND :y, unidas por AND.
function matches(expr, item, values = {}, names = {}) {
    if (!expr) return true;
    const attr = a => item[names[a] || a];
    const val = v => {
        if (!(v in values)) throw new Error(`fakeDynamo: falta ExpressionAttributeValue ${v}`);
        return values[v];
    };
    const terms = expr.replace(/(\S+)\s+BETWEEN\s+(:\w+)\s+AND\s+(:\w+)/gi, 'between($1,$2,$3)').split(/\s+AND\s+/i);
    return terms.every(t => {
        let m;
        if ((m = t.trim().match(/^between\((\S+),(:\w+),(:\w+)\)$/))) return attr(m[1]) >= val(m[2]) && attr(m[1]) <= val(m[3]);
        if ((m = t.trim().match(/^begins_with\(\s*(\S+)\s*,\s*(:\w+)\s*\)$/i))) return String(attr(m[1]) ?? '').startsWith(val(m[2]));
        if ((m = t.trim().match(/^(\S+)\s*(=|<=|>=|<|>)\s*(:\w+)$/))) {
            const a = attr(m[1]), b = val(m[3]);
            return { '=': a === b, '<': a < b, '<=': a <= b, '>': a > b, '>=': a >= b }[m[2]];
        }
        throw new Error(`fakeDynamo: expresión no soportada: "${t}"`);
    });
}

function sortKey(p) {
    const s = schemaOf(p.TableName);
    return (p.IndexName ? s.indexes[logical(p.IndexName)] : s.keys)?.[1];
}

const ops = {
    put(p) {
        schemaOf(p.TableName);
        rows(p.TableName).set(keyOf(p.TableName, p.Item), clone(p.Item));
        return {};
    },
    get(p) {
        const it = rows(p.TableName).get(keyOf(p.TableName, p.Key));
        return it ? { Item: clone(it) } : {};
    },
    delete(p) {
        rows(p.TableName).delete(keyOf(p.TableName, p.Key));
        return {};
    },
    query(p) {
        if (p.IndexName && !schemaOf(p.TableName).indexes[logical(p.IndexName)]) {
            throw awsError('ValidationException', `fakeDynamo: índice no definido: ${p.IndexName}`);
        }
        const v = p.ExpressionAttributeValues, n = p.ExpressionAttributeNames;
        const sk = sortKey(p);
        let items = [...rows(p.TableName).values()].filter(i => matches(p.KeyConditionExpression, i, v, n));
        if (sk) items.sort((a, b) => (a[sk] > b[sk] ? 1 : a[sk] < b[sk] ? -1 : 0) * (p.ScanIndexForward === false ? -1 : 1));
        const scanned = items.length;
        items = items.filter(i => matches(p.FilterExpression, i, v, n));
        return { Items: clone(items), Count: items.length, ScannedCount: scanned };
    },
    scan(p) {
        schemaOf(p.TableName);
        const all = [...rows(p.TableName).values()];
        const items = all.filter(i => matches(p.FilterExpression, i, p.ExpressionAttributeValues, p.ExpressionAttributeNames));
        return { Items: clone(items), Count: items.length, ScannedCount: all.length };
    },
    update(p) {
        const k = keyOf(p.TableName, p.Key);
        const current = rows(p.TableName).get(k);
        const v = p.ExpressionAttributeValues, n = p.ExpressionAttributeNames || {};
        if (p.ConditionExpression && !(current && matches(p.ConditionExpression, current, v, n))) {
            throw awsError('ConditionalCheckFailedException', 'The conditional request failed');
        }
        const m = (p.UpdateExpression || '').match(/^\s*set\s+(.+)$/i);
        if (!m) throw new Error(`fakeDynamo: UpdateExpression no soportada: "${p.UpdateExpression}"`);
        const item = current || clone(p.Key);
        for (const a of m[1].split(',')) {
            const [, name, ref] = a.trim().match(/^(\S+)\s*=\s*(:\w+)$/) || [];
            if (!name) throw new Error(`fakeDynamo: asignación no soportada: "${a}"`);
            item[n[name] || name] = v[ref];
        }
        rows(p.TableName).set(k, item);
        return p.ReturnValues === 'ALL_NEW' ? { Attributes: clone(item) } : {};
    },
};

// API estilo aws-sdk v2: método(params, callback) o método(params).promise()
class DocumentClient {
    constructor() {
        for (const [name, fn] of Object.entries(ops)) {
            this[name] = (params, cb) => {
                const run = () => new Promise(resolve => resolve(fn(params)));
                if (cb) { run().then(d => cb(null, d), e => cb(e)); return undefined; }
                return { promise: run };
            };
        }
    }
}

module.exports = { DocumentClient, __reset: reset };
