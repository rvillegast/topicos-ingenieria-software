import { handler } from "../recaudacion/oauth2Token.mjs";
process.env.PREFIX = "tgr-dev-api-recaudacion";
process.env.USER_POOL_URL = "https://tgr-dev-api-recaudacion-at-186180787863.auth.us-east-1.amazoncognito.com";

let event = {
    body: `grant_type=client_credentials&client_id=79fvlu7gdus0oq685ntajua9kj&client_secret=pg8htd9ce253srjuacban55gckhbfmc07h58fcvh09h38j6i1m1&scope=recaudacion%2Fipps`
};

handler(event).then(( data) => {
    console.log(data);
});