const moment = require('moment');

var date = new Date('2019-11-28T16:55:00Z');
var fecha = moment(date).format("DD-MM-YYYY HH:mm:ss");

console.log(date);
console.log(fecha);
    