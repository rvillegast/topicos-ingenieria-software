const validar = require('../recaudacion/validarJson.js');

var json = {
  "metadata": {
    "sentDate": "2019-12-11T17:13:12.840Z"
  },
  "data": {
    "conceptoPago": "CERTIFICADOS",
    "contribuyente": {
      "rut": 9799598,
      "dv": "4"
    },
    "receptor": {
      "rut": 9799598,
      "dv": "2",
      "nombre": "Juanito",
      "apellidoPaternoORazonSocial": "RS DEL BENEFICIARIO",
      "cuentaDeposito": {
        "numero": "47345611207",
        "tipo": "CUENTA_CORRIENTE",
        "nombreBanco": "CORPBANCA",
        "banco": 27
      }
    },
    "recaudacion": {
      "monto": "5356",
      "moneda": "CLP"
    },
    "callbackURL": "http://...."
  }
}

validar.validarjson(json).then((resolve) => {
    console.log(resolve);
}, (reject) => {
    console.log(reject);
});