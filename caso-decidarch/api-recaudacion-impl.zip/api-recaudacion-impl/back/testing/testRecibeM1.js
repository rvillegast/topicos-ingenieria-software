process.env.API_AUTOSERVICIOS_HOST_SERVICE = "api-qa.tegere.info";
process.env.AWS_ACCESS_KEY_ID = 'ASIARFQEYFKCFJB2FPDF';
process.env.AWS_SECRET_ACCESS_KEY = '5XvsafWWLv75+BvsHQ1L2rba36dmDPjCSTBOQsLS';
process.env.AWS_SESSION_TOKEN = 'IQoJb3JpZ2luX2VjEJX//////////wEaCXVzLWVhc3QtMSJIMEYCIQDCqJAHidqQ5auuXLYMHfHqIiq6VRekhi0PMkCdlt03XwIhANi2JhDcJBu4SSfO43wiVqxkDAmdszTasBTgVE6AExqYKusBCC4QAhoMMDgwNTQwNjA5MTU2Igz2fN8qfRVOLss2NLkqyAG38I6uZm/S2KTCxKnCV/MB7fVekBc1NWW+iEDNIF0H0K7nCbMHk0noajAKh2zJ92SUbrd+s41B88fCkHeGFLI2jM0PBzxOBVgK5+JJQPCizqFa+1OLtyRn6HGEsND25AFf1NFvlXplvmI4PxdNJf++G/z/YH2iBHmqAox/2Bdl23e4hRoJ5Dcvuby/k6m6IzDOvP5c6sQWxaqpzinN8ufmvUswnmMqK+d/dKKEquHSUAPrwZrA/iGqNzXGUNfwZZqEby4FRfxcKjD3wrj+BTrfAZv5u4NDUvTwNognCI/+eJrtaTicF+fcM/WHjGNI/I4YPi/0j5tl/sUFnj5KUx8b39UKitKFQ4/9JLIEXzmU8o+TuXBDMhWIo1AXTUQnjm0hGpxnHH6U8JLLNs1E9o4qozwWCGl3HYlRiXOr0y0S+Z4/FR0jhgapRk+CFR43wWIVXg125dyUYT7tax4ixhFZ/1iZSza0T/oTYEmEjLlbmhWam5PQhow4NgQi/XxG4G+HRblizn8XW5e9dp8ujOrXd7EhR0aBN4Eq+MylJeeakvAq5Bp5vwNwvxn21IBXYeg=';
process.env.PREFIX = "tgr-dev-api-recaudacion";
const clase = require('../recaudacion-int/recibeM1');


var xml = {
  body:   `<soapenv:Envelope
   xmlns:open="http://www.openuri.org/"
   xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
   <soapenv:Header>
   <wsse:Security
   xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd">
   <wsse:UsernameToken>
   <wsse:Username>monitoreo</wsse:Username>
   <wsse:Password>monitoreo</wsse:Password>
   </wsse:UsernameToken>
   </wsse:Security>
   </soapenv:Header>
   <soapenv:Body>
   <open:recibeM1>
   <open:messageId>
   <open:Code>M1</open:Code>
   <open:MsgDesc>M1 API</open:MsgDesc>
   <open:From>MTT</open:From>
   <open:Ref>806</open:Ref>
   <open:Datetime>2020-08-12T15:07:46.199Z</open:Datetime>
   <open:IdExt>11112233</open:IdExt>
   </open:messageId>
   <open:deuda>
   <open:IdDeuda>
   <open:Rut>9799598</open:Rut>
   <open:Dv>2</open:Dv>
   <open:Formulario>768</open:Formulario>
   <open:Folio>11</open:Folio>
   <open:Vencimiento>2020-8-12</open:Vencimiento>
   <open:Moneda>UTM</open:Moneda>
   <open:Monto>1.5</open:Monto>
   <open:Movimiento>C</open:Movimiento>
   </open:IdDeuda>
   <open:DetalleDeuda>
			<open:Item>
				<open:Codigo>10</open:Codigo>
				<open:Contenido>16</open:Contenido>
			</open:Item>
			<open:Item>
				<open:Codigo>16</open:Codigo>
				<open:Contenido>11531444</open:Contenido>
			</open:Item>
			<open:Item>
				<open:Codigo>17</open:Codigo>
				<open:Contenido>1</open:Contenido>
			</open:Item>
			<open:Item>
				<open:Codigo>33</open:Codigo>
				<open:Contenido>69072100-7</open:Contenido>
			</open:Item>
			<open:Item>
				<open:Codigo>62</open:Codigo>
				<open:Contenido>2 JPL PUENTE ALTO</open:Contenido>
			</open:Item>
			<open:Item>
				<open:Codigo>102</open:Codigo>
				<open:Contenido>PAGO CAUSA cl.mtt.rpi.model.RpiCausas[ rpiCausasPK=cl.mtt.rpi.model.RpiCausasPK[ rolCausa=237119, anoCausa=2018, codigoJpl=3784 ] ]</open:Contenido>
			</open:Item>
			<open:Item>
				<open:Codigo>301</open:Codigo>
				<open:Contenido>BCI</open:Contenido>
			</open:Item>
			<open:Item>
				<open:Codigo>316</open:Codigo>
				<open:Contenido>13201</open:Contenido>
			</open:Item>
		</open:DetalleDeuda>
   </open:deuda>
   </open:recibeM1>
   </soapenv:Body>
   </soapenv:Envelope>`} ;
  
  

let event = {xml}; 

clase.handler(xml, null, (a,response)=>{ console.log(response)});

