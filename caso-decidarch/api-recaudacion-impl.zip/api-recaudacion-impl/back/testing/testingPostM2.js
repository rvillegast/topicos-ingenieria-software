const m2 = require('../recaudacion-int/postM2');
process.env.PREFIX = 'tgr-dev-api-recaudacion';
process.env.ENV = 'dev';
process.env.API_AUTOSERVICIOS_HOST_SERVICE = 'api.dev.tegere.info';

(async () => {
  var event = {
    body: JSON.stringify({
      "Message": {
        "MessageId": {
          "Status": "OK",
          "DateTime": "02-04-2024 15:56:23",
          "Number": 0,
          "FromAddress": "TESORERIA",
          "MsgDesc": "Confirma Pago",
          "IdExt": "89476500000000000043",
          "Version": 1,
          "Code": "M2",
          "RefAddress": 894,
          "ToAddress": "CPA"
        },
        "Confirmacion": {
          "Pago": {
            "Folio": 91071,
            "IdTransaccion": 2015020643234928,
            "Rut": 16509403,
            "TipoPago": "E",
            "Ira": { "Codigo": 999, "Nombre": "BANCO VIRTUAL" },
            "Vencimiento": "30-08-2014",
            "Formulario": 765,
            "Resultado": 0,
            "FechaPago": "06-02-2015 13:05:12",
            "IdOperacion": 2015020605337161,
            "TotalPago": 1000
          }
        }
      }
    })
  };

  await m2.handler(event);
})();
