const estadoCuadratura = require("../recaudacion-int/estadoCuadratura");
process.env.API_AUTOSERVICIOS_HOST_SERVICE = "api.dev.tegere.info";

let event ;

estadoCuadratura.handler(event);

console.log("termino Test");
