const m2 = require("../recaudacion/oauth2Token");
process.env.PREFIX = "tgr-dev-api-recaudacion";

let event = {
    "headers": {
        "Accept": "*/*",
        "Accept-Encoding": "gzip, deflate",
        "Cache-Control": "no-cache",
        "CloudFront-Forwarded-Proto": "https",
        "CloudFront-Is-Desktop-Viewer": "true",
        "CloudFront-Is-Mobile-Viewer": "false",
        "CloudFront-Is-SmartTV-Viewer": "false",
        "CloudFront-Is-Tablet-Viewer": "false",
        "CloudFront-Viewer-Country": "CL",
        "Content-Type": "application/x-www-form-urlencoded",
        "Host": "ocgq4h9vz1.execute-api.us-east-1.amazonaws.com",
        "Postman-Token": "f021c10d-a2f0-479f-8fb7-e1e5d46292b4",
        "User-Agent": "PostmanRuntime/7.20.1",
        "Via": "1.1 488bd882973f218b61aacda0ee63106f.cloudfront.net (CloudFront)",
        "X-Amz-Cf-Id": "bT5IUqXGd154_GClKz4K_ObJ8IZXopWUsIC1z6ZcdO8yYumm0EHMuw==",
        "X-Amzn-Trace-Id": "Root=1-5df26a46-cc776e2c9a89a0148896b10a",
        "X-Forwarded-For": "163.247.65.3, 64.252.175.77",
        "X-Forwarded-Port": "443",
        "X-Forwarded-Proto": "https"
    },
    body: `grant_type=client_credentials&client_id=5ikm6fkfq2d698ttfplbt72ml9&client_secret=11mfk30ppm0sunktrqcdkevprh8rh8kc5f5vfbp29ouc79dn5hpm&scope=recaudacion%2Fipps`
};

m2.handler(event).then(( data) => {
    console.log(data);
});