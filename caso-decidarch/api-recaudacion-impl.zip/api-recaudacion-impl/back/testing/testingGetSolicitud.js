const m2 = require("../recaudacion/getSolicitud");
process.env.PREFIX = "tgr-dev-api-recaudacion";

let event = {
    pathParameters: {
        id: "82552845189132653811"
    }
};

m2.handler(event, null, (err, data) => {
});