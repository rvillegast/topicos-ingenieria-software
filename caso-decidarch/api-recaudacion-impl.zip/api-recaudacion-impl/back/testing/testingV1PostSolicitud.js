process.env.PREFIX = 'tgr-dev-api-recaudacion';
process.env.BUCKET_NAME = 'tgr-dev-api-recaudacion-data-at-186180787863';
process.env.USER_POOL_ID = "us-east-1_iY3gIYii0";
process.env.ENV = "dev";
process.env.PATH_PORTAL_PAGOS = 'https://test.tesoreria.cl/portal/portlets/pagos_externos/pagosExternosController.jpf';
process.env.BOTON_PAGO_CLOUD_BASE_URL = "https://pagos.dev.tegere.info";
process.env.SCOPE_API_AUTOSERVICIOS = 'tgr-dev-api-portal-autoservicios/all';
process.env.API_AUTOSERVICIOS_CLIENT_ID = '35l8t1trd8gpge3p53dv936jnj';
process.env.API_AUTOSERVICIOS_CLIENT_SECRET = '1cqg4utvbsea4o2uvctd3rg8oijkna68jg0bgf1m9mir17r3mog5';
process.env.API_AUTOSERVICIOS_HOST_SERVICE = 'api.dev.tegere.info';
process.env.API_AUTOSERVICIOS_TOKEN_HOST_SERVICE = 'id.dev.tegere.info';
process.env.AWS_ACCESS_KEY_ID = 'ASIASWWJ5L2L4BNQGDNH';
process.env.AWS_SECRET_ACCESS_KEY = 'PguNLjYB9aTHWOoLW2967rLSPC+cBN93NoWccxnO';
process.env.AWS_SESSION_TOKEN = 'FwoGZXIvYXdzEEsaDOrkNc+Hch8SoNEfpSKyAQrT4Dq+grY9ESlcekRcOx5OAXQOZ+IAXhMkMPmYACpKLoGh3RumIu7Al/iRJkJ8nXE2NUPZ1NbSG3jam8+d34keL2MnMrFajBSPeiVfScX60QyKDKzXj8t/n6EsfdSXvEtDaH0Ss9/t7TQeeuYtq7JnHMwJAO9VopsIX1uogwi34JCr/fbW2eg4XUHJu6WxEyubx7XjMCZTejtOPfWxprP6qc+vNBhto4Gtr6oEswBrqWoo6rWB+QUyLWU5+i5RjLIGMwc0XxbN55mzg2SJP/CA8sHvKHRKR2iVjSgDfPPzVvRB1LAAJg==';
const m1 = require('../recaudacion/postSolicitud');

(async() => {
    let json = {
        "metadata": {
            "sentDate": "2019-12-11T17:13:12.840Z"
        },
        "data": {
            "callbackURL": "https://www.google.cl",
            "conceptoRecaudacion": "MULTA_EXTRANJERO",
            "contribuyente": {
                "dv": "5",
                "rut": 7023934
            },
            "recaudacion": {
                "moneda": "CLP",
                "monto": 20000
            },
            "receptor": {
                "apellidoPaternoORazonSocial": "RS DEL BENEFICIARIO",
                "cuentaDeposito": {
                    "banco": 27,
                    "nombreBanco": "CORPBANCA",
                    "numero": 47345611207,
                    "tipo": "CUENTA_CORRIENTE"
                },
                "dv": "2",
                "nombre": "Juanito",
                "rut": 97995985
            }
        }
    };

    await m1.handler({
        headers: {
            // QA
            // Authorization: 'Bearer ',
            // PROD
            Authorization: 'Bearer eyJraWQiOiJhRDM5TklURjJQUEFzZWE3TTBFWkhCNk9pQW1ZM01FNFdWMGhkVnU3MmZFPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiIxc3JwcDdsdnM2ODhyajgwNG1oYjZvdXF2IiwidG9rZW5fdXNlIjoiYWNjZXNzIiwic2NvcGUiOiJyZWNhdWRhY2lvblwvaXBwcyIsImF1dGhfdGltZSI6MTU5NTk1NzM0NSwiaXNzIjoiaHR0cHM6XC9cL2NvZ25pdG8taWRwLnVzLWVhc3QtMS5hbWF6b25hd3MuY29tXC91cy1lYXN0LTFfaVkzZ0lZaWkwIiwiZXhwIjoxNTk1OTYwOTQ1LCJpYXQiOjE1OTU5NTczNDUsInZlcnNpb24iOjIsImp0aSI6Ijg2Yjg4NmE2LTYxMjAtNDk4Ny05YmM0LTY4YjkxNTAxZDFlZiIsImNsaWVudF9pZCI6IjFzcnBwN2x2czY4OHJqODA0bWhiNm91cXYifQ.E-f8a5L2rulmPvt2UtL7puF31bhWBUD-gEASYmUDsISq8nZOA5cEX7RZlq8lmK10z0TrRjofJHCa4jkHDgcFfA3iS3XAuJh1HBsWpUD36D7tUQPsU4yK_lLwtQIORzXkue6Mm_Kt9D-Fiw9dhq64eWgyIHavsZdqUeX6m_jAwLc6KiBklAQdu5i9A6i13TfStSNN83mBDzntK_tGFT1RCrR5IsxD38WApR_j1j2vlKh6eTAV82JWDL02zZi-7umwiq-U9sRct1Ry3rgNrxdRtU3lG24isRjmPNI0SLF50zpD9RujYUt66hhPtI8EdBDDG7hGDXKynJmrZSiJvvyWBg',
            'Content-Type': 'application/json'
        },
        path: "/recaudacion/v1/solicitudes",
        body: JSON.stringify(json),
    })
})
();
