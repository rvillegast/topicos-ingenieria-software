
const clase = require('../recaudacion-int/intentoPago');

let json ={
   "data":{
      "idGirador":"878",
      "fechaOrigen":"2020-10-21",
      "rut":1,
      "formCod":711,
      "formVer":"A",
      "formFolio":1603313244,
      "fechaVcto":"2020-10-21",
      "periodo":"2020-10-01",
      "montoPlazo":169404,
      "reajustes":0,
      "intereses":0,
      "multas":0,
      "condonaciones":0,
      "montoTotal":169404,
      "idMoneda":0,
      "totalPagar":169404,
      "idExterno":"53366329575156716881",
      "items":[
         {
            "codigo":1,
            "valor":"SUBSECRETARIA DEL INTERIOR-GASTOS DE OPERACION"
         },
         {
            "codigo":3,
            "valor":"19"
         },
         {
            "codigo":7,
            "valor":"1603313244"
         },
         {
            "codigo":10,
            "valor":"12"
         },
         {
            "codigo":15,
            "valor":"20201021"
         },
         {
            "codigo":16,
            "valor":"9005706"
         },
         {
            "codigo":17,
            "valor":"1"
         },
         {
            "codigo":33,
            "valor":"605010008"
         },
         {
            "codigo":62,
            "valor":"GOBIERNO CENTRAL-DEPARTAMENTO DE EXTRANJERIA"
         },
         {
            "codigo":91,
            "valor":"169404"
         },
         {
            "codigo":102,
            "valor":"MULTA_EXTRANJERO"
         },
         {
            "codigo":301,
            "valor":"BANCO_DEL_ESTADO_DE_CHILE"
         }
      ]
   }
};

let event = {"body": JSON.stringify(json)}; 

clase.handler(event, null, (a,response)=>{ console.log("termino")});

console.log("fin codigo");