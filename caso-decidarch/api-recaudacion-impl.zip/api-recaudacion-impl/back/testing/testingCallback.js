const m2 = require("../recaudacion-int/callback");
process.env.PREFIX = "tgr-dev-api-recaudacion";

let event = {
    queryStringParameters: {
        idExt: "63681913491441841182"
    }
};



m2.handler(event, null, (err, data) => {
}); 