const m2 = require("../recaudacion/getSolicitudes");
process.env.PREFIX = "tgr-dev-api-recaudacion";
process.env.USER_POOL_ID = "us-east-1_oPAQBGrx0";

let event = {
    headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer eyJraWQiOiJkUDljNmRqaFNpanRNVHFtbnBuSHphVWtYTW1CdGtEbUIweFwvK0kwRG9YMD0iLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiI1aWttNmZrZnEyZDY5OHR0ZnBsYnQ3Mm1sOSIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiaW5zdGl0dWNpb25lcy1hdXRvc2VydmljaW9cL2FsbCIsImF1dGhfdGltZSI6MTU3NjA5MjUyOCwiaXNzIjoiaHR0cHM6XC9cL2NvZ25pdG8taWRwLnVzLWVhc3QtMS5hbWF6b25hd3MuY29tXC91cy1lYXN0LTFfb1BBUUJHcngwIiwiZXhwIjoxNTc2MDk2MTI4LCJpYXQiOjE1NzYwOTI1MjgsInZlcnNpb24iOjIsImp0aSI6ImJhM2U1ZTAyLWRiNDEtNDI2Yy1iNTRlLTY3NTI1Y2Q3MTE1OSIsImNsaWVudF9pZCI6IjVpa202ZmtmcTJkNjk4dHRmcGxidDcybWw5In0.DgmsJi5zJqysWPbeYVwVh80p2gcBQIINN9qpBF01xHH0b3e6dL2S8jnRMQ4vdeLKymqCAOWJPGlUhRWWb1yQpw_dOmDVHUqpFXsxV3aOXDEZElgzv6yj61Kkqek7YMF2rSM1fSJihyzP0iokOsrC3zrqdqsd61n2Litje9P8Shq4V1xzm97-aow3OyvYTG8sGZt0ORbzYZy4mOP0WRUu8a43nrrBkBCmHP3VQ2Gr2rEAB-3Z_xdZ0pBMaySNSkk7VFzrQj4Upz557cYyZmNrC4Ca4soAv9MenB-L7WO2gQ6kYV-y6Bt87PAJGjPDkt0LJWLI8Hr1828QtsP8LnDA5g`
    },
    "resource": "/solicitudes",
    "path": "/solicitudes",
    "httpMethod": "GET",
    "queryStringParameters": {
        "interval": "20000",
        "next": "eyJpZCI6Ijc5NTkzMTg2NDQyMTYxOTcyMjQxIiwiZmVjaGFFdmVudG8iOiIyMDE5LTEyLTE3VDIxOjI3OjQ5LjIzNFoiLCJpbnN0aXR1Y2lvbiI6IkNCUlIifQ=="
    }
};

m2.handler(event,null, (err, data)=>{
});