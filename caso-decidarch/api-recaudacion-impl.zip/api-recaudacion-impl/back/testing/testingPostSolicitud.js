process.env.PREFIX = 'tgr-dev-api-recaudacion';
process.env.BUCKET_NAME = 'tgr-dev-api-recaudacion-data-at-186180787863';
process.env.USER_POOL_ID = "us-east-1_iY3gIYii0";
process.env.ENV = "dev";
process.env.PATH_PORTAL_PAGOS = 'https://test.tesoreria.cl/portal/portlets/pagos_externos/pagosExternosController.jpf';
process.env.BOTON_PAGO_CLOUD_BASE_URL = "https://pagos.dev.tegere.info";
process.env.SCOPE_API_AUTOSERVICIOS = 'tgr-dev-api-portal-autoservicios/all';
process.env.API_AUTOSERVICIOS_CLIENT_ID = '35l8t1trd8gpge3p53dv936jnj';
process.env.API_AUTOSERVICIOS_CLIENT_SECRET = '1cqg4utvbsea4o2uvctd3rg8oijkna68jg0bgf1m9mir17r3mog5';
process.env.API_AUTOSERVICIOS_HOST_SERVICE = 'api.dev.tegere.info';
process.env.API_AUTOSERVICIOS_TOKEN_HOST_SERVICE = 'id.dev.tegere.info';
const m1 = require('../recaudacion/postSolicitud');

(async() => {
    let json =

    /* TEST DEM F10 */
    {
        "metadata": { "sentDate": "2019-12-06T11:46:07.581Z" },
        "data": {
            "conceptoRecaudacion": "TEST_F10_DEM",
            "contribuyente": {
                "rut": 9799598,
                "dv": "2"
            },
            "recaudacion": {
                "monto": 10000,
                "moneda": "CLP",
                "idBilletera": 'sm5yezpwqw7t9y8743w9'
            },
            "callbackURL": "https://www.google.cl",
            "payload": {
                "items": [{
                        "codigo": 619,
                        "valor": 10000
                    },
                    {
                        "codigo": 324,
                        "valor": 10
                    },
                    {
                        "codigo": 325,
                        "valor": 20200803
                    },
                    {
                        "codigo": 1,
                        "valor": "Ojeda"
                    },
                    {
                        "codigo": 2,
                        "valor": "Rojas"
                    },
                    {
                        "codigo": 5,
                        "valor": "Edgar"
                    }
                ]
            }
        }
    }
    

    /* DATOS DEM AUTOMATICO
    {
        "metadata": { "sentDate": "2019-12-06T11:46:07.581Z" },
        "data": {
            "conceptoRecaudacion": "MULTA_EXTRANJERO",
            "contribuyente": {
                "rut": 9799598,
                "dv": "2"
            },
            "recaudacion": {
                "monto": 1000,
                "moneda": "CLP",
                "idBilletera": "T78b-1-6T02b1Td8bTl8"
            },
            "callbackURL": "https://www.google.cl",
            "receptor": {
                "apellidoPaternoORazonSocial": "RS DEL BENEFICIARIO",
                "nombre": "Juanito",
                "dv": "2",
                "rut": 97995985,
                "cuentaDeposito": {
                    "banco": 27,
                    "nombreBanco": "CORPBANCA",
                    "numero": 47345611207,
                    "tipo": "CUENTA_CORRIENTE"
                }
            },
            "payload": {
                "items": [{
                        "codigo": 1001,
                        "valor": "string"
                    },
                    {
                        "codigo": 1002,
                        "valor": 1000
                    }
                ]
            }
        }
    };
    */

    /* DATOS LA_LIGUA AUTOMATICO
        {
        "metadata": { "sentDate": "2019-12-06T11:46:07.581Z" },
        "data": {
            "conceptoRecaudacion": "TEST_CONCEPTO_AUTOMATICO",
            "contribuyente": {
                "rut": 9799598,
                "dv": "2"
            },
            "recaudacion": {
                "monto": 1000,
                "moneda": "CLP",
                "idBilletera": "T78b-1-6T02b1Td8bTl8"
            },
            "callbackURL": "https://www.google.cl"
        }
    };
    */

    await m1.handler({
        headers: {
            // CERTIFICACION LA_LIGUA
            //Authorization: 'Bearer eyJraWQiOiJhRDM5TklURjJQUEFzZWE3TTBFWkhCNk9pQW1ZM01FNFdWMGhkVnU3MmZFPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiI3aGU0dGk5bmpnNWpocmJrb2I5OWJtbmVyZCIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoicmVjYXVkYWNpb25cL2lwcHMiLCJhdXRoX3RpbWUiOjE1OTYwNjEzMDQsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC51cy1lYXN0LTEuYW1hem9uYXdzLmNvbVwvdXMtZWFzdC0xX2lZM2dJWWlpMCIsImV4cCI6MTU5NjA2NDkwNCwiaWF0IjoxNTk2MDYxMzA0LCJ2ZXJzaW9uIjoyLCJqdGkiOiJmZmY4MWZmNS1iMWExLTQ3ZTItYmFkMy0xZThlMTc1M2RjNDAiLCJjbGllbnRfaWQiOiI3aGU0dGk5bmpnNWpocmJrb2I5OWJtbmVyZCJ9.EYpwh7XmoRIKOFZq97drDbu76doW2VVbBdvHGijlcm_VlY4PxantVTLSk1d6WnjQxfRsjCuNo1SfT4cB7dVLxC4WhM2wuJuQeYMkRB5d9TzyR_i_Iv6xC9jKZsKEO8fzUnETHuoQGCwELOi2Fnncxo60VEpp6jSISq39D74IbzsSd-yGgXVGOgiJuGjFKiKJi8KC2cFBmudjzuREuAt5ubEc6JFNKGJ5IhlJk30y11bTI3mhwdrc3Nhx75OxUSqdt5bC8s1M_ZjbCgjyU7WKF99EfVu77zxaUo3DaC1105ZONMOH--iD1ioXWYThGCFd6sDfs3Tp6dgwronhexQ4Rg',
            // PRODUCCION LA_LIGUA
            // Authorization: 'Bearer eyJraWQiOiJhRDM5TklURjJQUEFzZWE3TTBFWkhCNk9pQW1ZM01FNFdWMGhkVnU3MmZFPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiI3aHZlb2VpdGdiMjZzdmdqbWMxOHQzcThkIiwidG9rZW5fdXNlIjoiYWNjZXNzIiwic2NvcGUiOiJyZWNhdWRhY2lvblwvaXBwcyIsImF1dGhfdGltZSI6MTU5NjA2MTU1MSwiaXNzIjoiaHR0cHM6XC9cL2NvZ25pdG8taWRwLnVzLWVhc3QtMS5hbWF6b25hd3MuY29tXC91cy1lYXN0LTFfaVkzZ0lZaWkwIiwiZXhwIjoxNTk2MDY1MTUxLCJpYXQiOjE1OTYwNjE1NTEsInZlcnNpb24iOjIsImp0aSI6IjBiMDEyNzM1LTViMDgtNGFiNy04YzJjLTMyYzZiMWY0ZTk0MCIsImNsaWVudF9pZCI6IjdodmVvZWl0Z2IyNnN2Z2ptYzE4dDNxOGQifQ.T61xhl6_zvKT6lQZgutL78YZR6eR5P3WEIdbr7Q_W3tdv0GeJ7abUHfU83GqEzJ7RyftoavS-9DSQJ__74jiOi6wbapTCG1shzpuUvTxnzOq1_eg4Uh7NgjtADqe-SkoGPnKIOy12Vvd5XLeYFuYs_7Jtw5SRoQlfCShl5TqgpYoXCU_u7LwXFLTZui4i7NLZO5ePORHFKamvdZOaeTKaoqcEwgZ45ljryeWP2wvCX24Vda0BOrLWi04sx5ncMwekM0RmFx0huTUB04RMMiAkg3AKoCzfEXgbasAW3Fhq2iqg_vkJzD7pIF9MY7gYraRl7DY_qKZijBMXsyPJHKK8g',
            // PROD DEM
            Authorization: 'Bearer eyJraWQiOiJhRDM5TklURjJQUEFzZWE3TTBFWkhCNk9pQW1ZM01FNFdWMGhkVnU3MmZFPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiI2bXMxcGZ2MGdlYml2NjYwN2xhY2h2NzdrbiIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoicmVjYXVkYWNpb25cL2lwcHMiLCJhdXRoX3RpbWUiOjE1OTU3OTE1MjEsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC51cy1lYXN0LTEuYW1hem9uYXdzLmNvbVwvdXMtZWFzdC0xX2lZM2dJWWlpMCIsImV4cCI6MTU5NTc5NTEyMSwiaWF0IjoxNTk1NzkxNTIxLCJ2ZXJzaW9uIjoyLCJqdGkiOiJlNjRkNDQ0Mi0wYzM0LTRkNWYtOTQ2Ny02MzA3ZGYzN2I0ZDIiLCJjbGllbnRfaWQiOiI2bXMxcGZ2MGdlYml2NjYwN2xhY2h2NzdrbiJ9.lR5tnxOu_l1jC_99tijxKSrRNlOvC0mLE-_hyMQN17ewEJ8A99VczgZI9qy5zYGJvYk2QcbO_iY50f2igr-KMgI5wmbJ68u1oSy_Ax6Z6c-928pqSR2p3TwTRJYhyDPoaIGE7CuVXZ-6y-GyX8zUzn02wyLQXXMeYFJl0usSLIHZ5AODGf9adPJLWDo3QumB5_h2Lc9qAfL_tSSHZT87YVtArXEWw06nkFWuQo0Gd4RQhN44IldBxB7ers1sArgFxXoBilbPgTOfP5cxnPBrkfcrESWjFrGb6yLBqyj-Ge07ZGgmnBGky40wCZzqp98frEJZtIRxnKeS1Pi7pgSX4w',
            // PROD SRCEI
            //Authorization: 'Bearer eyJraWQiOiJhRDM5TklURjJQUEFzZWE3TTBFWkhCNk9pQW1ZM01FNFdWMGhkVnU3MmZFPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiIzanJyZWx0N3F2OGxkNTVkNW00Y2Y0OGpldSIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoicmVjYXVkYWNpb25cL2lwcHMiLCJhdXRoX3RpbWUiOjE1OTY3MzM5MzcsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC51cy1lYXN0LTEuYW1hem9uYXdzLmNvbVwvdXMtZWFzdC0xX2lZM2dJWWlpMCIsImV4cCI6MTU5NjczNzUzNywiaWF0IjoxNTk2NzMzOTM3LCJ2ZXJzaW9uIjoyLCJqdGkiOiJkNGVlNGU2ZC02OTZiLTRmYWQtYmU0Yy0zMzZkNDQzOTMyYWIiLCJjbGllbnRfaWQiOiIzanJyZWx0N3F2OGxkNTVkNW00Y2Y0OGpldSJ9.XCNgzRe9yKoApAlhYuxZG1djUwsUxxs17URIDVIy0SkUJwMd3hEDTu7kDZJ5RXuy4FxKUXFUF00OAkJHMw6bwqiblc1KB176MAQATg-4JsRtP7cIWpBgQSMWciOtbsHHx5Q1dx9nfN0PBdYSquxVYfRCBrDTPuVOegCUiJyRaMZ-gvceoIgB23NC8AuBBXv1z1bcQW6aBguLal0mAlEag0yN1ZnFiSug8y6n4BgcaIgBDSDe6lOBiDJlhgfTHMxuH4LiIGGaZZeNbyRxBUsI1np3ggOQ5tdLIPvmB4M-VJkoHsDhrqzXekWEY8OV2Ckw80lYCXV1D5VFJWdD9zpCZQ',
            'Content-Type': 'application/json'
        },
        path: "/recaudacion/v1/solicitudes",
        body: JSON.stringify(json),
    })
})
();
