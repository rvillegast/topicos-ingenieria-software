# ARCHITECTURAL INTENT — api-recaudacion-impl

Contrato para cualquier agente de IA (o persona) que modifique este repositorio. Es el E7 del caso DecidArch; su justificación está en `arch/E7-architectural-intent.md`.
**No pidas ni entregues «que funcione»:** cada cambio declara responsabilidad, secreto, frontera, datos, restricciones y evidencia.

## 0. Antes de escribir código

1. Lee `arch/adr/README.md` y los ADR de los módulos que vas a tocar.
2. Lee el contrato del módulo en `arch/E2-arquitectura-to-be.md` §3 y la deuda abierta en `arch/debt-ledger.md`.
3. Completa la **intención de la tarea** (plantilla en `arch/E7-architectural-intent.md` §4) y muéstrala antes de implementar.
4. Corre el gate en el estado inicial: `SEMGREP=semgrep arch/fitness/quality-gate.sh`. Si no está en verde antes de empezar, detente e informa.

## 1. Módulos, secretos y fronteras

Todo vive en `back/recaudacion-int/src/`. Un módulo se importa **solo** por su `index.js` (FF-4). Cada archivo de `integraciones/` es público.

| Module | Responsibility | Secret (no debe salir del módulo) | Owned data | Public contract | Allowed dependencies | Forbidden dependencies |
|---|---|---|---|---|---|---|
| **ConfirmacionPago** `confirmacion-pago/` | Registrar de forma idempotente la confirmación de pago de una solicitud | Formato M2 en JSON y XML (`adaptadores/`); reenvío por `idTransaccion`; reglas unitario/carrito/on-prem; cuándo abonar | Registros `PAGO_CONFIRMADO` (los persiste EventosRecaudacion) | `registrar({confirmacion, legado?}) → 'REGISTRADA' \| 'REENVIO'` (idempotencia por `confirmacion.idTransaccion`); `desdeM2Json`; `m2JsonDesdeXml` | `eventos`, `institucion`, `integraciones/*`, `moment-timezone` | `aws-sdk`, `@aws-sdk/*`, `axios`, `aws4`, `utils/`, `aws/`, handlers, Notificacion, Conciliacion |
| **EventosRecaudacion** `eventos/` | Único punto de lectura y escritura de la tabla `eventos` | Nombre de tabla, `PREFIX`, índices, claves compuestas (`id#idTransaccion`, `institucion#environment`), `payload` + `confirmacion` | Tabla `eventos` (**owner único**) | `buscarPorSolicitud`, `buscarPorId`, `registrarPagoConfirmado`, `idPago`, `idPagoTramite`, `idAbonoTramite`, `institucionEnvironment` | `aws-sdk/clients/dynamodb` | Cualquier módulo de `src/`, `utils/`, `aws/`, handlers (es una hoja) |
| **Institucion** `institucion/` | Resolver datos de una institución | Concepto por formulario y regla `GENERICO_<inst>` | Ninguno | `conceptoPorFormulario(formulario, institucion)` | `integraciones/portalAutoservicios` | SDK/HTTP directo, tabla `conceptos-instituciones` |
| **integraciones/** `billetera.js`, `portalAutoservicios.js` | Hablar con un proveedor externo | Endpoint, firma (SigV4/OAuth), rutas SSM, reintentos | Ninguno | `abonarBilletera(dataEntrada, institucion)`; `conceptosPorFormulario(formulario, institucion)` | `axios`, `aws4`, `utils/service`, `utils/util` | Módulos de dominio de `src/` |
| **Handlers** (`postM2.js`, `suscriptorSnsReplicaGenerica.mjs`) | Traducir el evento de Lambda | Formato del evento de Lambda y de la respuesta HTTP | Ninguno | Contratos externos **sin cambios** (ADR-001) | `src/<modulo>/index.js` | Rutas internas de módulos, tabla `eventos` |

**Legado (fuera de `src/`):** Solicitud (`recaudacion/*`), Notificacion (`publishSnsEventos`), Conciliacion (`cuadratura`, `estadoOP`, `envioOp`, `getDataOP`, `envioGCP`, `estadoCuadratura`, `reenvioM2Tierra`) y Obligaciones. Están bajo *ratchet*: se pueden modificar, pero **no pueden empeorar**. Si migras uno, aplica el contrato TO-BE del E2 §2 y ADR-003/ADR-004.

## 2. Restricciones de calidad (el gate las verifica)

| # | Restricción | Verificación |
|---|---|---|
| Q1 | Sin dependencias circulares | FF-1 |
| Q2 | Los tipos y campos del proveedor (`MessageId`, `Confirmacion`, M2 XML, y los de cualquier proveedor nuevo) no salen de su adaptador; el resto usa `Confirmacion` v1 | FF-2 |
| Q3 | Solo `eventos/` nombra la tabla `eventos` y construye sus claves | FF-3 |
| Q4 | Dirección: handlers → dominio → `eventos`/`integraciones`; nunca al revés; nada de rutas internas ajenas | FF-4 |
| Q5 | Región, rutas SSM, hosts y ambientes vienen de configuración (`serverless.yml` → `process.env`) | FF-5 |
| Q6 | Sin SATD no gestionada: todo `TODO`/`FIXME`/«arreglar»/«temporal»/«caracterizado»/«heredado» lleva `TD-xxx` | FF-6 |
| Q7 | El comportamiento se preserva con tests; `src/` mantiene ≥ 90 % de líneas y ≥ 75 % de ramas | FF-7 |
| Q8 | Contratos externos sin cambios: `POST createM2`, SNS de réplica, forma de `PAGO_CONFIRMADO` (solo cambios aditivos), mensajes SNS a instituciones. **Todo `PAGO_CONFIRMADO` nuevo conserva `payload` M2 mientras TD-015 siga abierto** (lo leen `cuadratura`, `getDataOP` y `publishSnsEventos`). `registrar()` ya acepta una confirmación sin `legado` (TD-026 cerrado), pero un proveedor que no es M2 requiere antes ADR-003 fase *migrate* | Tests de caracterización |

## 3. Cómo trabajar (§11.1 del caso)

**Tests de caracterización → refactor pequeño → tests → gate → informe.** Un paso a la vez y con la suite en verde entre pasos.

- **Antes de cambiar comportamiento, fíjalo con un test.** Si encuentras un comportamiento raro, **presérvalo** y regístralo como TD. Solo corrígelo si la tarea lo pide (refactor ≠ corrección).
- **Un test que agregas debe poder fallar:** rompe a propósito la regla que protege, confirma que falla y restaura.
- **Sin abstracciones sin presión de cambio:** nada de interfaces con una sola implementación, factories para un solo producto ni Strategy para casos estables (ADR-001, ADR-002). Un adaptador nuevo se justifica con un **formato o proveedor real** adicional.
- **Sin dependencias nuevas** en `package.json` salvo que la tarea lo exija. Si hace falta, decláralo en el informe.

## 4. Prohibido (detente y pregunta)

- Cambiar un contrato externo (Q8), el esquema de `eventos` (salvo cambios aditivos) o crear tablas.
- Subir un máximo de `arch/fitness/deuda-conocida.tsv`, bajar umbrales o editar reglas de `arch/fitness/` para que el gate pase. Eso requiere actualizar ADR-005 y aprobación humana.
- Borrar un comentario de deuda sin evidencia (test, historia de git o error real), o reformularlo para que FF-6 no lo detecte.
- Ejecutar, leer o copiar `back/recaudacion/src/obligaciones/test/`: contiene credenciales reales (TD-006).
- Llamar a AWS, SSM o APIs reales. Usa `test-support/fakeDynamo.js` y dobles de prueba (`jest.mock`).
- `git push`, o commitear sin que te lo pidan.

## 5. Evidencia obligatoria en tu informe final

1. La intención de la tarea (§0.3) y, **por cada restricción Q1–Q8**, cómo se cumple y con qué evidencia.
2. La salida real de `arch/fitness/quality-gate.sh` (exit 0) y el conteo de tests antes y después.
3. Los tests agregados, el comportamiento que fijan y la prueba de que fallan si se rompe la regla.
4. Los TD nuevos o actualizados en `arch/debt-ledger.md`, con owner, fecha y verificación.
5. Los ADR afectados (los «Affected modules» que tocaste) y lo que cambió en ellos.
6. **Cada cifra o afirmación del informe sale de un comando ejecutado, no de memoria.** Si dices «caracterizado» o «cubierto», nombra el test.
