# Instrucciones para Claude Code

El contrato de intención arquitectónica del repositorio está en AGENTS.md y es obligatorio para cualquier cambio:

@AGENTS.md
